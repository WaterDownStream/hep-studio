#pragma once
#include <QQuickPaintedItem>
#include <QVariantList>
#include <QUrl>
namespace hep {
class HistogramItem:public QQuickPaintedItem {
    Q_OBJECT
    Q_PROPERTY(QVariantList series READ series WRITE setSeries NOTIFY plotChanged)
    Q_PROPERTY(QVariantList curve READ curve WRITE setCurve NOTIFY plotChanged)
    Q_PROPERTY(QString title READ title WRITE setTitle NOTIFY plotChanged)
    Q_PROPERTY(QString xLabel READ xLabel WRITE setXLabel NOTIFY plotChanged)
    Q_PROPERTY(int fontSize READ fontSize WRITE setFontSize NOTIFY plotChanged)
    Q_PROPERTY(QString legendPosition READ legendPosition WRITE setLegendPosition NOTIFY plotChanged)
    Q_PROPERTY(QString style READ style WRITE setStyle NOTIFY plotChanged)
    Q_PROPERTY(bool logY READ logY WRITE setLogY NOTIFY plotChanged)
public:
    explicit HistogramItem(QQuickItem* parent=nullptr):QQuickPaintedItem(parent){setAntialiasing(true);}
    QVariantList series()const{return series_;}void setSeries(const QVariantList& v){series_=v;update();emit plotChanged();}
    QVariantList curve()const{return curve_;}void setCurve(const QVariantList& v){curve_=v;update();emit plotChanged();}
    QString title()const{return title_;}void setTitle(const QString& v){title_=v;update();emit plotChanged();}
    QString xLabel()const{return xLabel_;}void setXLabel(const QString& v){xLabel_=v;update();emit plotChanged();}
    int fontSize()const{return fontSize_;}void setFontSize(int n){fontSize_=n;update();emit plotChanged();}
    QString legendPosition()const{return legendPosition_;}void setLegendPosition(const QString& s){legendPosition_=s;update();emit plotChanged();}
    QString style()const{return style_;}void setStyle(const QString& s){style_=s;update();emit plotChanged();}
    bool logY()const{return logY_;}void setLogY(bool v){logY_=v;update();emit plotChanged();}
    void paint(QPainter*)override;
    Q_INVOKABLE void zoom(double factor);
    Q_INVOKABLE void pan(double fraction);
    Q_INVOKABLE void resetView();
    Q_INVOKABLE bool exportFigure(const QUrl&);
signals:void plotChanged();
private:
    void render(QPainter&,const QRectF&)const;
    QVariantList series_,curve_;QString title_{"Histogram"},xLabel_{"Observable (canonical units)"};bool logY_{false};
    int fontSize_{12};QString legendPosition_{"right"},style_{"step"};
    double zoom_{1},pan_{0};
};
}
