#include "render/plots/scan_grid_item.hpp"
#include <QPainter>
#include <QPdfWriter>
#include <QPageLayout>
#include <QFileInfo>
#include <QImage>
#include <algorithm>
#include <cmath>
#include <limits>
namespace hep {
namespace {
struct View {
    QRectF area;double xmin{},xmax{1},ymin{},ymax{1};bool valid{};
    QPointF position(double x,double y)const{return {area.left()+(x-xmin)/(xmax-xmin)*area.width(),area.bottom()-(y-ymin)/(ymax-ymin)*area.height()};}
};
View view(const QVariantMap& data,const QRectF& bounds,double zoom,double px,double py){
    View v;v.area=bounds.adjusted(78,55,-125,-68);
    const auto xs=data.value("xValues").toList(),ys=data.value("yValues").toList();
    if(xs.empty()||ys.empty()||v.area.width()<=0||v.area.height()<=0)return v;
    auto range=[](const QVariantList& values){double lo=std::numeric_limits<double>::infinity(),hi=-lo;for(const auto& raw:values){const auto d=raw.toDouble();if(std::isfinite(d)){lo=std::min(lo,d);hi=std::max(hi,d);}}if(lo==hi){lo-=.5;hi+=.5;}return std::pair{lo,hi};};
    const auto [xl,xh]=range(xs);const auto [yl,yh]=range(ys);
    if(!std::isfinite(xl+xh+yl+yh))return v;
    const double xr=(xh-xl)*1.12/zoom,yr=(yh-yl)*1.12/zoom,xc=(xl+xh)/2+px*(xh-xl),yc=(yl+yh)/2+py*(yh-yl);
    v.xmin=xc-xr/2;v.xmax=xc+xr/2;v.ymin=yc-yr/2;v.ymax=yc+yr/2;v.valid=true;return v;
}
QColor color(double fraction){return QColor::fromHsvF(static_cast<float>(.69-.54*std::clamp(fraction,0.,1.)),.70F,.96F);}
}
void ScanGridItem::paint(QPainter* p){render(*p,boundingRect());}
void ScanGridItem::zoom(double factor){if(std::isfinite(factor)&&factor>0){zoom_=std::clamp(zoom_*factor,.5,20.);update();}}
void ScanGridItem::pan(double dx,double dy){if(std::isfinite(dx+dy)){panX_+=dx/zoom_;panY_+=dy/zoom_;update();}}
void ScanGridItem::resetView(){zoom_=1.;panX_=panY_=0.;update();}
QVariantMap ScanGridItem::pointAt(double x,double y)const{
    const auto v=view(data_,boundingRect(),zoom_,panX_,panY_);if(!v.valid||!v.area.contains(x,y))return {};
    double closest=15.;QVariantMap result;for(const auto& raw:data_.value("grid").toList()){
        const auto p=raw.toMap();const auto pos=v.position(p.value("x").toDouble(),p.value("y").toDouble());
        const double distance=std::hypot(pos.x()-x,pos.y()-y);if(distance<closest){closest=distance;result=p;}
    }return result;
}
void ScanGridItem::render(QPainter& p,const QRectF& bounds)const{
    p.fillRect(bounds,QColor("#111b25"));p.setPen(QColor("#e6edf3"));p.setFont(QFont("Sans Serif",12));
    p.drawText(bounds.adjusted(20,12,-20,0),Qt::AlignHCenter|Qt::AlignTop,data_.value("title","Parameter scan").toString());
    const auto v=view(data_,bounds,zoom_,panX_,panY_);if(!v.valid)return;
    const auto rows=data_.value("grid").toList();double lo=std::numeric_limits<double>::infinity(),hi=-lo;
    for(const auto& raw:rows){const auto row=raw.toMap();if(row.value("status")=="Completed"&&!row.value("value").isNull()){const auto value=row.value("value").toDouble();if(std::isfinite(value)){lo=std::min(lo,value);hi=std::max(hi,value);}}}
    p.setPen(QColor("#91a4b4"));p.drawRect(v.area);
    for(int i=0;i<=4;++i){const double fraction=i/4.;const auto x=v.area.left()+fraction*v.area.width(),y=v.area.bottom()-fraction*v.area.height();
        p.drawLine(QPointF(x,v.area.bottom()),QPointF(x,v.area.bottom()+5));p.drawLine(QPointF(v.area.left()-5,y),QPointF(v.area.left(),y));
        p.drawText(QRectF(x-38,v.area.bottom()+7,76,22),Qt::AlignCenter,QString::number(v.xmin+fraction*(v.xmax-v.xmin),'g',4));
        p.drawText(QRectF(bounds.left(),y-11,72,22),Qt::AlignRight|Qt::AlignVCenter,QString::number(v.ymin+fraction*(v.ymax-v.ymin),'g',4));
    }
    p.drawText(QRectF(v.area.left(),bounds.bottom()-32,v.area.width(),22),Qt::AlignCenter,data_.value("xLabel").toString());
    p.save();p.translate(bounds.left()+18,v.area.center().y());p.rotate(-90);p.drawText(QRectF(-v.area.height()/2,-12,v.area.height(),24),Qt::AlignCenter,data_.value("yLabel").toString());p.restore();
    p.save();p.setClipRect(v.area);
    for(const auto& raw:rows){const auto row=raw.toMap();const auto position=v.position(row.value("x").toDouble(),row.value("y").toDouble());const auto val=row.value("value");
        if(row.value("status")=="Completed"&&!val.isNull()&&std::isfinite(val.toDouble())){
            p.setPen(QColor("#e6edf3"));p.setBrush(color(hi>lo?(val.toDouble()-lo)/(hi-lo):.5));p.drawRect(QRectF(position.x()-7,position.y()-7,14,14));
        }else{p.setPen(QPen(QColor("#ef8b89"),2));p.drawLine(position+QPointF(-6,-6),position+QPointF(6,6));p.drawLine(position+QPointF(-6,6),position+QPointF(6,-6));}
    }p.restore();
    if(std::isfinite(lo+hi)){const QRectF legend(v.area.right()+25,v.area.top()+35,15,std::max(20.,v.area.height()-85));
        for(int i=0;i<100;++i)p.fillRect(QRectF(legend.left(),legend.bottom()-(i+1)*legend.height()/100.,legend.width(),legend.height()/100.+1),color(i/99.));
        p.setPen(QColor("#c6d6e3"));p.drawText(QRectF(legend.right()+4,legend.top()-8,60,22),QString::number(hi,'g',4));p.drawText(QRectF(legend.right()+4,legend.bottom()-12,60,22),QString::number(lo,'g',4));
    }
    p.setPen(QColor("#a9bdce"));p.setFont(QFont("Sans Serif",10));p.drawText(QRectF(v.area.right()+8,v.area.top()-15,112,48),Qt::TextWordWrap,data_.value("valueLabel").toString());
}
bool ScanGridItem::exportFigure(const QUrl& file)const{
    if(!file.isLocalFile())return false;
    const auto path=file.toLocalFile();
    if(QFileInfo(path).suffix().compare("pdf",Qt::CaseInsensitive)==0){QPdfWriter writer(path);writer.setPageSize(QPageSize(QPageSize::A4));writer.setPageOrientation(QPageLayout::Landscape);writer.setResolution(120);QPainter p(&writer);if(!p.isActive())return false;render(p,{0,0,static_cast<double>(writer.width()),static_cast<double>(writer.height())});return p.end();}
    QImage image(1600,1000,QImage::Format_ARGB32_Premultiplied);QPainter p(&image);render(p,{0,0,1600,1000});p.end();return image.save(path,"PNG");
}
}
