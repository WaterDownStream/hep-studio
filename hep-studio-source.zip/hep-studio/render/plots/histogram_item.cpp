#include "render/plots/histogram_item.hpp"
#include <QPainter>
#include <QPainterPath>
#include <QImage>
#include <QPdfWriter>
#include <QPageSize>
#include <QFileInfo>
#include <algorithm>
#include <cmath>
namespace hep {
void HistogramItem::zoom(double factor){zoom_=std::clamp(zoom_*factor,1.,100.);update();}
void HistogramItem::pan(double fraction){pan_+=fraction/zoom_;pan_=std::clamp(pan_,-.5,.5);update();}
void HistogramItem::resetView(){zoom_=1;pan_=0;update();}
void HistogramItem::paint(QPainter* p){render(*p,boundingRect());}
void HistogramItem::render(QPainter& p,const QRectF& bounds)const{
    auto font=p.font();font.setPixelSize(std::clamp(fontSize_,8,28));p.setFont(font);
    p.fillRect(bounds,QColor("#121c25"));p.setRenderHint(QPainter::Antialiasing);p.setPen(QColor("#d6e3ee"));
    p.drawText(QRectF(20,8,bounds.width()-40,30),Qt::AlignCenter,title_);
    if(series_.isEmpty()){p.drawText(bounds,Qt::AlignCenter,"Run an analysis or select a stored 1D histogram");return;}
    const auto first=series_.front().toMap();const auto edges=first["edges"].toList();if(edges.size()<2)return;
    const double fullLo=edges.front().toDouble(),fullHi=edges.back().toDouble(),span=fullHi-fullLo;
    const double center=(fullLo+fullHi)/2+pan_*span,lo=center-span/(2*zoom_),hi=center+span/(2*zoom_);
    double ymax=0,ymin=0,smallest=1e300;
    for(const auto& raw:series_){const auto s=raw.toMap();const auto values=s["values"].toList(),errors=s["errors"].toList();
        for(qsizetype i=0;i<values.size();++i){const double v=values[i].toDouble(),e=i<errors.size()?errors[i].toDouble():0;ymax=std::max(ymax,v+e);ymin=std::min(ymin,v-e);if(v>0)smallest=std::min(smallest,v);}}
    for(const auto& raw:curve_){const auto point=raw.toList();if(point.size()!=2||point[1].isNull())continue;const double v=point[1].toDouble();if(!std::isfinite(v))continue;ymax=std::max(ymax,v);ymin=std::min(ymin,v);if(v>0)smallest=std::min(smallest,v);}
    ymax=std::max(ymax*1.15,1.);if(logY_){ymin=smallest<1e299?std::log10(smallest*.5):-1;ymax=std::log10(ymax);if(ymax<=ymin)ymax=ymin+1;}else ymin*=1.15;
    QRectF area(76,48,std::max(10.,bounds.width()-105),std::max(10.,bounds.height()-115));
    auto x=[&](double v){return area.left()+(v-lo)/(hi-lo)*area.width();};
    auto y=[&](double v){const double value=logY_?std::log10(std::max(v,std::pow(10.,ymin))):v;return area.bottom()-(value-ymin)/(ymax-ymin)*area.height();};
    p.setPen(QColor("#6e899b"));p.drawRect(area);
    for(int i=0;i<=5;++i){const auto fraction=static_cast<double>(i)/5;const auto xx=area.left()+area.width()*fraction;
        p.drawText(QRectF(xx-40,area.bottom()+7,80,22),Qt::AlignCenter,QString::number(lo+(hi-lo)*fraction,'g',4));
        const auto yy=area.bottom()-area.height()*fraction;const auto value=ymin+(ymax-ymin)*fraction;
        p.drawText(QRectF(0,yy-10,68,20),Qt::AlignRight|Qt::AlignVCenter,QString::number(logY_?std::pow(10.,value):value,'g',3));
    }
    p.save();p.translate(16,area.center().y());p.rotate(-90);p.drawText(QRectF(-area.height()/2,-12,area.height(),22),Qt::AlignCenter,first.value("normalization","counts").toString());p.restore();
    p.drawText(QRectF(70,bounds.height()-29,bounds.width()-90,22),Qt::AlignCenter,xLabel_);
    p.save();p.setClipRect(area);const QColor colors[]{QColor("#62d6bc"),QColor("#eeaa6b"),QColor("#a18cf5")};int color=0;
    for(const auto& raw:series_){const auto s=raw.toMap();const auto es=s["edges"].toList(),vs=s["values"].toList(),errs=s["errors"].toList();if(es.size()!=vs.size()+1)continue;
        p.setPen(QPen(colors[color%3],2));QPainterPath path;
        for(qsizetype i=0;i<vs.size();++i){const auto left=x(es[i].toDouble()),right=x(es[i+1].toDouble()),yy=y(vs[i].toDouble());if(i==0)path.moveTo(left,yy);else path.lineTo(left,yy);path.lineTo(right,yy);}
        if(style_=="bar"){auto fill=colors[color%3];fill.setAlpha(60);for(qsizetype i=0;i<vs.size();++i){const double left=x(es[i].toDouble()),right=x(es[i+1].toDouble()),yy=y(vs[i].toDouble()),base=y(0);p.fillRect(QRectF(QPointF(left,std::min(yy,base)),QPointF(right,std::max(yy,base))),fill);}}
        p.drawPath(path);p.setPen(QPen(colors[color%3],1));
        for(qsizetype i=0;i<vs.size();++i){const auto xx=x((es[i].toDouble()+es[i+1].toDouble())/2);const auto v=vs[i].toDouble(),err=i<errs.size()?errs[i].toDouble():0;
            p.drawLine(QPointF(xx,y(v-err)),QPointF(xx,y(v+err)));p.drawEllipse(QPointF(xx,y(v)),2,2);}
        ++color;
    }
    if(!curve_.isEmpty()){p.setPen(QPen(QColor("#f4e68b"),2));QPainterPath fit;bool firstPoint=true;for(const auto& raw:curve_){auto point=raw.toList();if(point.size()!=2||point[0].isNull()||point[1].isNull()||!std::isfinite(point[0].toDouble())||!std::isfinite(point[1].toDouble())){firstPoint=true;continue;}const auto xx=x(point[0].toDouble()),yy=y(point[1].toDouble());if(firstPoint){fit.moveTo(xx,yy);firstPoint=false;}else fit.lineTo(xx,yy);if(first.value("curveMarkers",false).toBool())p.drawEllipse(QPointF(xx,yy),2,2);}p.drawPath(fit);}
    p.restore();color=0;
    for(const auto& raw:series_){p.setPen(first.value("curveMarkers",false).toBool()?QColor("#f4e68b"):colors[color%3]);p.drawText(QRectF(legendPosition_=="left"?area.left()+8:area.right()-205,area.top()+32+color*21,195,20),legendPosition_=="left"?Qt::AlignLeft:Qt::AlignRight,raw.toMap().value("legend","Histogram").toString());++color;}
    if(first.value("showStatistics",true).toBool()){p.setPen(QColor("#9cafbd"));p.drawText(QRectF(area.left()+8,area.top()+8,300,40),QString("Entries %1   Mean %2   RMS %3").arg(first["entries"].toDouble(),0,'g',6).arg(first["mean"].toDouble(),0,'g',4).arg(first["rms"].toDouble(),0,'g',4));}
}
bool HistogramItem::exportFigure(const QUrl& file){
    if(!file.isLocalFile())return false;
    const auto path=file.toLocalFile();
    if(QFileInfo(path).suffix().toLower()=="pdf"){
        QPdfWriter writer(path);writer.setPageSize(QPageSize(QPageSize::A4));writer.setPageOrientation(QPageLayout::Landscape);writer.setResolution(120);
        QPainter p(&writer);if(!p.isActive())return false;render(p,QRectF(0,0,writer.width(),writer.height()));return p.end();
    }
    QImage image(1600,1000,QImage::Format_ARGB32_Premultiplied);QPainter p(&image);render(p,QRectF(0,0,1600,1000));p.end();return image.save(path,"PNG");
}
}
