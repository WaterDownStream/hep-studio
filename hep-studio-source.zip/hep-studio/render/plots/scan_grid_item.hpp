#pragma once
#include <QQuickPaintedItem>
#include <QVariantMap>
#include <QUrl>
namespace hep {
// Presentation of compact immutable scan results. No backend/execution access.
class ScanGridItem:public QQuickPaintedItem {
    Q_OBJECT
    Q_PROPERTY(QVariantMap plotData READ plotData WRITE setPlotData NOTIFY plotChanged)
public:
    explicit ScanGridItem(QQuickItem* parent=nullptr):QQuickPaintedItem(parent){setAntialiasing(true);}
    QVariantMap plotData()const{return data_;}
    void setPlotData(const QVariantMap& value){data_=value;resetView();emit plotChanged();}
    void paint(QPainter*)override;
    Q_INVOKABLE void zoom(double factor);
    Q_INVOKABLE void pan(double dx,double dy);
    Q_INVOKABLE void resetView();
    Q_INVOKABLE QVariantMap pointAt(double x,double y)const;
    Q_INVOKABLE bool exportFigure(const QUrl&)const;
signals:void plotChanged();
private:
    void render(QPainter&,const QRectF&)const;
    QVariantMap data_;
    double zoom_{1},panX_{0},panY_{0};
};
}
