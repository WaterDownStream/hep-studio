# MadGraph adapter

`plugins/madgraph/backend.py` runs the pinned SDK as bounded scientific
subprocesses in the existing research worker. The desktop never imports it.
Source URLs, commits, archive checksums and compiler verification are recorded in
`docs/developer/research-dependencies.json`; `scripts/build_research_sdk.py`
recreates the installation without privileged package installation.

The executed subset is Standard Model LO (`sm` with default restrictions, or
`sm-full` with unrestricted external parameters), structured incoming/outgoing PDG IDs,
exclusions and QCD/QED order bounds, beam energies, integration seed, event count,
allowed run-card cuts and explicit SLHA block:index parameters. `mass:6` and
`decay:6`, for example, have GeV units. Couplings remain dimensionless unless a
binding declares another supported dimension. Unknown bindings fail rather than
being ignored. Entries marked dependent by the generated model card are rejected
as overrides; changing one can otherwise disagree between matrix element and
shower. Some light masses fixed by `sm` are external parameters in `sm-full`.
Derived quantities, such as the W mass in this input scheme, remain controlled
by the model equations. The isolated upstream parameter updater refreshes these
before generation; the effective final card and defaults are recorded. See
[ADR-028](../adr/ADR-028.md). NLO, external UFO resources and matched/merged ME–PS generation
are rejected by this adapter; the executable's broader capabilities are not
claimed as HEP Studio support.

Generation records effective process/run/parameter/compiler cards, process text,
beam configuration, integration cross section/error, nominal event-weight
convention, requested/actual event count, sumw, sumw2 and LHE content checksum.
The native shower consumes a first-class LHE sample and does not silently generate
a replacement hard process. LHE/HepMC files remain in worker-local transactions.
One MadGraph integration subprocess uses one CPU; shower blocks use the central
broker allocation. Logical block seeds do not depend on physical worker count.

Unavailable compilers and present-but-broken compilers have distinct capability
states. Timeout/cancellation/worker death terminates subprocess descendants.
Failed stages retain raw logs when storage permits and never become reusable
complete samples. The fixed-seed QED numerical reference and its tolerance are
in `part4-reference-results.json`; this is not NLO/UFO validation.

Compiler selection happens before MadGraph process export, as well as during
event generation. A private `gfortran` alias executes the identified compiler;
exported make options are checked and recorded. Inherited Make overrides are
removed. Settings use upstream `--no_save` and `MADGRAPH_DATA` behavior so neither
the SDK configuration nor shared LO template compiler settings are changed.
Compiler identity is checked again before publication. A compiler that passes
version discovery but fails real compilation cannot produce a complete sample.

`tests/research/validate_model_scan.py` executes three real photon-only LO points
with different `sminputs:1` values. Their cross sections and weighted histograms
are compared with the analytic QED coupling scaling. Fixed seeds/common streams
across the points make this a correlated parameter study, not three independent
Monte Carlo samples. The same test deliberately fails Fortran compilation,
checks retained diagnostics and verifies shared SDK configuration is unchanged.

`tests/research/test_madgraph_models.py` additionally executes both model variants
and a controlled massive-muon reference with two coupling values. It checks the
finite-mass QED formula, LHE mass/momentum closure, effective cards, cache reuse
and rejection without publication of an ignored restricted parameter. Numerical
evidence is `part4-model-selection-validation.json`. Generated UFO import pickles
are excluded from the scientific source fingerprint; model source edits are not.
