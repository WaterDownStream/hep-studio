# HepMC3 adapter

Validated locally with HepMC3 3.02.05. The core semantic type is EventStream;
serialized VPIR contains no HepMC C++ types. Native interoperability uses GenEvent,
ReaderAscii/WriterAscii and the installed PYTHIA-to-HepMC3 converter.

Records preserve PDG/status, four-momenta, generated mass, weights, vertices and
ancestry. Inspection uses GeV and mm; nonfinite pseudorapidity is displayed as
undefined. Particle tables and a bounded ancestry tree are presentation only.
The jet constituent index space is explicitly declared (PYTHIA or HepMC).

The initial interchange format is HepMC3 Asciiv3. Preview returns at most 20
events; each record limits particles/vertices to 10000. Full Runs retain one
inspection event. Bulk events remain in the worker. Reading checks the end marker
without loading the whole file and distinguishes parse errors from normal EOF;
partial analyses are discarded on malformed input. Other HepMC formats are not
silently treated as supported. See data-locality.md for materialization/integrity.

Persisted parallel samples use `hep-studio-hepmc-shards-v1` manifests (ADR-021).
Checksums/end markers/counts/ranges are verified before sequential shard streaming.
A sample remains one logical resource. Explicit single-file export streams through
HepMC3 ReaderAscii/WriterAscii with atomic publication and cancellation; the UI
receives compact metadata. Corrupt/incomplete shards block reuse.
