# PYTHIA adapter

Validated locally with PYTHIA 8.318. Essential controls cover beams, sqrt(s), event
count, QCD/Drell–Yan/W/Higgs/top/minimum-bias processes, tune, showers, MPI and
hadronisation. Advanced settings use installed flag/mode/parameter/word metadata.
Research overrides are separate, range checked, recorded and rejected when they
conflict with graphical or other expert settings. Decay controls use particle
PDG IDs. Initialization failures retain raw diagnostics.

Fixed seeds are decimal integers 1..900000000. Project-derived seeds use SHA-256
of `hep-studio-seed-v1`, project seed and node ID separated by NUL, taking the first
big-endian uint64 modulo 900000000 plus one. The project seed participates in
scientific hashes only for nodes using that strategy.

New generators use `logical-blocks-v2`: fixed accepted-event blocks (default
4096), each initialized with a distinct recorded seed. Advanced → Generator
workers schedules those streams on 1–32 isolated processes, subject to the central
CPU/memory budget. Worker count is execution metadata and does not affect
scientific identity. Block size/policy does. Old projects migrate to a fixed
`legacy-streams-v1` logical stream count matching their original sample definition.

Each process executes the fused pipeline locally. Raw weighted accumulators are
reduced in logical index order, followed by normalization and fitting. HepMC
materialization uses one shard per logical stream and one atomic sample manifest.
Preview uses a bounded single stream and is not a Run. A killed child invalidates
the Run; siblings are stopped/reaped and incomplete samples are not published.

Seeds are `(baseSeed - 1 + blockIndex) % 900000000 + 1`. Logical ranges, all actual
seeds, stream policy and physical execution budget are recorded. The same installed
environment, scientific configuration, master seed and requested count produce the
same logical sequence regardless of physical worker count. This is a sequence of
separately initialized PYTHIA streams, not one uninterrupted RNG stream. No
cross-platform/version/compiler bitwise guarantee is claimed. See ADR-020, which
supersedes ADR-019 randomness. Limits: 4096 blocks and 128 MiB accumulators.

Selected external LHAPDF is attached through the installed PYTHIA >=8.318 plugin
interface when compiled with LHAPDF. Unsupported builds reject that selection.
Set/member data checksums accompany provenance. Configuration export is readable
PYTHIA settings; graph/VPIR remains canonical. The tested C++ exporter covers the
supported generation/jet/selection/1D histogram graph, including weights.
