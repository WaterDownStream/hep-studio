# Delphes adapter and reconstructed semantics

The research worker invokes real `DelphesHepMC3`/`DelphesLHEF` with its recorded
SDK/dictionaries. `plugins/delphes/backend.py` owns cards and process execution;
`plugins/research/reconstruction.py` maps output branches into native RDataFrame
helpers. ROOT-specific classes do not enter serialized VPIR or desktop classes.

| Node | Semantic collection | Additional structural property |
| --- | --- | --- |
| Muons | RecoMuonCollection | isolation |
| Electrons | RecoElectronCollection | isolation |
| Combined electrons/muons | RecoLeptonCollection | isolation when both inputs provide it |
| Photons | RecoPhotonCollection | isolation |
| Jets | RecoJetCollection | btag (stored Delphes bit mask) |
| Tracks | RecoTrackCollection | mass/charge from stored track |
| MissingET | RecoMissingETCollection | transverse missing momentum |

Common properties are pT/mass/energy in GeV, eta dimensionless and phi in radians.
Isolation uses the stored `IsolationVar`; its interpretation follows the selected
card. B-tag values retain the stored mask, not an invented tagging decision.
Missing branches/capabilities fail explicitly. Unsupported properties are never
substituted with fake zeros. Generator collections and reconstructed collections
cannot be connected implicitly. Collection filters/sorts/takes/counts/HT and
opposite-sign same-flavour pairs reuse the canonical AST and typed contracts.
Delta-phi, delta-R and transverse-mass expressions require indexed scalar inputs
with checked units. Typed **OverlapRemoval** keeps primary objects only when no
reference object satisfies strict ΔR < radius. Phi differences wrap at ±π, and the
radius is dimensionless. Muons/electrons/photons/tracks/jets can be references;
MET and composite pairs are excluded. Empty references keep all primary objects.
The output preserves the primary type/capabilities. Both graph inputs participate
in dependency hashes. Pure collection definitions share one event-row prepass;
event filters remain separate branches and all histogram actions are booked lazily.

**CollectionCombine** is an explicitly ordered union. Compatible physical types
can be combined; electrons/muons become a distinct `RecoLeptonCollection` rather
than silently being relabelled as either input type. Within one event, branch
identity and original object index survive filtering/sorting/taking. Union emits
each source object once, primary order first and then unseen reference objects.
It does not equate different tracks/particles merely because momenta are similar.
Sort explicitly before taking leading objects. Structural capabilities are the
intersection of both inputs. Mixed leptons preserve flavour/charge for optional
opposite-sign/same-flavour pairing. Incompatible unions, MET and composite-pair
unions are rejected. Other arbitrary heterogeneous record unions are outside v1.

CMS and the small ideal-muon reference card are selectable. **Select / relink
custom card** identifies a trusted Tcl bundle by primary SHA256 and the checksums
of its relative Tcl dependencies. The scientific config contains a versioned
logical resource reference; physical locations are project resource metadata.
Relocation of an identical bundle preserves scientific identity. Changed contents
must be explicitly selected, creating a new identity. Legacy path-based cards
retain their old hash behavior. Cards are executable configuration, not inert text.

Only identified Tcl dependencies (at most 256 files / 16 MiB) are privately staged;
unrelated files in the parent folder are not copied. Unidentified non-Tcl resources
are outside this first bundle contract. The recorded private card appends the
explicit logical detector seed. Original cards are not modified. Detector blocks
are presently serial; reproducible ranges and per-block seeds remain explicit.

`part4-reference-results.json` checks ideal response and a seeded CMS software
reference. `part4-reconstructed-validation.json` independently checks known class
records, exact weighted bins/sumw2, isolation/tags and standalone export. Neither
is experimental detector certification. Upstream field documentation:
https://delphes.github.io/workbook/root-tree-description/ .
