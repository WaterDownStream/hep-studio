# LHAPDF adapter

Validated locally with LHAPDF 6.5.6 and CT14lo member 0 (data version 1). Workers
scan configured paths for installed sets, reporting member counts, metadata and
storage. PDF Explorer evaluates actual x*f(x,Q), with flavour, member and x/Q
validation; requests outside the fitted domain are rejected rather than silently
extrapolated. Plotting does not create a publication Run.

Installation requires the explicit UI action. Downloads use the official CERN
set endpoint, default to a 100 MiB approved cap, validate archive entries and
expanded-size/disk budgets, reject links/path escapes and commit into a user-owned
runtime-local directory. Existing sets are not overwritten. Installed PDFs work
offline. Tests of download policy/archive handling use transport fixtures, not
fabricated scientific values. Real PDF tests conditionally skip when no set is
installed; tests never implicitly download one.

Generator selection records set/member plus metadata/data-file checksums. External
PYTHIA support is capability gated. Multiple PDF error-member scans, uncertainty
bands and automatic set catalog downloads are outside this milestone.
