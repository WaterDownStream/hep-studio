# FastJet adapter

Validated locally with FastJet 3.5.1. Clustering uses actual ClusterSequence and
JetDefinition: anti-kT, kT, Cambridge/Aachen; radius, minimum pT; E/pt/pt2
recombination. Final-state particles are inputs; neutrinos are excluded by default
and this choice is explicit. Deterministic manual-vector tests verify all three
algorithms, constituent membership, jet count and four-momentum.

Neutral jet records expose momentum, pT, eta, phi, mass and constituent IDs.
Generic collection Filter/Sort/Take/Count and Property nodes support leading-jet
analysis. Typed scalar Define/Filter/aggregation/histogram nodes then reuse ROOT
contracts. Histogram default weight is the nominal generator/event weight.

The eta–phi inspector displays real constituents and axes. It does not invent
jet boundaries. Node extensions and adapter boundaries leave room for areas,
background, grooming and substructure; these algorithms are not implemented.
