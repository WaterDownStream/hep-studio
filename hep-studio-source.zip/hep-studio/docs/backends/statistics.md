# RooFit, RooStats and template likelihoods

These adapters run in the isolated research worker. The first RooFit interface
consumes a typed binned histogram, a structured model, explicit bounds/range,
constraints and `poisson` or `sumw2` error convention. Implemented components are
Gaussian, exponential, polynomial, Breit-Wigner, histogram PDF, recursive sums
and products. A histogram PDF can be fitted as a component of a mixture. A model
with no floating parameters is rejected as an optimizer fit; its fixed predictions
are not misreported as estimated parameters. Expert structured configuration is
available in the Research Inspector; arbitrary RooFit source execution is absent.

Exact bin integrals avoid a midpoint approximation. Fit ranges coincide with bin
edges. Negative/nonfinite expectations, empty integrals and incompatible errors
fail explicitly. Optimizer status, covariance quality, EDM, NLL, parameters,
uncertainties, covariance/correlation, model/input identities, expected bins,
pulls, constraints and warnings are preserved. Pulls outside the fit range are
omitted. A valid optimizer status alone does not establish model adequacy or a
statistical goodness-of-fit p-value.

RooStats initially supports one-channel positive-mean counting inference with
explicit observed integer counts or labelled Asimov data, asymptotic one-sided
q_mu CLs, optional Gaussian auxiliary background measurement, q0 discovery and
profile-likelihood intervals. Template workflows use real HistFactory:
`TemplateSet → BinnedLikelihood → Inference`. References resolve immutable
Run/node/content identities, including their original environment and seed.
No source events are loaded to build these compact template models.

Up to eight analysis channels, sixteen uniquely identified samples and 256 fitted
bins in total are supported. Existing single-channel projects retain their original
representation and template identity. Samples may name a channel; channels may
have different observables, dimensions and bin edges. Every channel needs positive
background in each bin; at least one channel must contain signal. Observed mode
requires one integer-count data histogram per channel. Multiple channels require
an explicit `disjoint-event-categories` assumption; source arrays cannot establish
that assumption. Reusing one histogram as independent samples is rejected even
across channels. A single shared signal strength scales all signal samples.

Roles, expected
event yields, flow convention, POI range, shared correlation identities and
statistical interpretations are explicit. Shape nuisances reference existing
nominal/down/up arrays with identical units/binning. Normalization/shape priors
require an explicit standard-normal ±1σ interpretation. Poisson gamma MC statistics
require an explicit independent-effective-count assumption. HistFactory's version-
default interpolation/stat-error behavior is recorded with the frozen backend.
Raw weights/cross sections are not silently promoted to Poisson expectations.
Duplicate sample references, invalid Runs and empty expected-background bins fail.

Numerical tests recover analytic Gaussian/exponential/Breit-Wigner/polynomial
parameters, a known template-mixture fraction and a product-model slope. Counting
and one-/two-bin CLs are checked against independently computed Poisson references.
The multichannel Poisson reference also sums independently calculated bin log-
likelihoods across different observables. Shared versus channel-specific nuisance
identities, observed data, standalone export and missing-independence rejection
are tested. Shared normalization, genuine bin-redistribution shape variation and explicit MC
statistics are exercised. Sparse-bin/boundary coverage and source-event independence
are not established by those software checks; warnings remain in every result.

The Statistical Inspector displays parameters, up to 32 correlations, pull/CLs
curves and PNG/PDF export. Complete covariance remains in the Run. Template
PyROOT export executes independently. Reconstructed-analysis export also executes
native fits and structured RooFit/RooStats actions, checks recorded input checksums
and preserves full statistical histogram input identities. Real CMS-card response
tests compare parameters/errors/status, RooFit input identity and counting limits.
Receipts:
`part4-statistics-validation.json` and `part4-template-validation.json`.
