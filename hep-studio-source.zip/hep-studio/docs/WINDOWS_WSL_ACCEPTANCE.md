# Windows 11 / WSL2 external acceptance

Platform status: **UNVERIFIED**. The scripts and Linux probe tests are preparation,
not evidence of a Windows run. Part 3 remains open until native Windows 11 x86-64
acceptance is performed and its receipts reviewed.

## Prerequisites and explicit setup

Use a native Qt build containing `hep-studio.exe`, `hep-studio-tests.exe`,
`hep-host-acceptance.exe`, `hep-worker.exe`, deployed Qt DLLs/QML plugins and the
repository's `examples/collider-workflow.json`. A maintainer can build with CMake
and MSVC; the existing Windows CI packages a test bundle when actually executed.
No prebuilt Windows bundle or tested runtime image is shipped in this checkpoint.

Start HEP Studio → Scientific Runtime. **Enable WSL2** uses Windows elevation;
a reboot may be required. **Install Runtime Image** imports a trusted image as
`HEPStudioRuntime` without replacing an existing distribution. Maintainer image
recipes are under `packaging/wsl`; they have not been executed here. Ordinary
scientific use uses the native UI and does not require Linux package management.

Install/select a small PDF set explicitly through the PDF Manager before the
offline PDF test. The harness never downloads PDF sets or modifies scientific
packages. Library presence and installed PDF data are distinct requirements.

## Automated developer command

Run Windows PowerShell 5.1 or PowerShell 7 from the repository:

```powershell
.\scripts\windows\acceptance.ps1 -BinDirectory .\build\bin `
    -OutputDirectory C:\HEP-test-evidence
```

For explicit first import, add `-RuntimeImage C:\path\trusted-runtime.tar` and
optionally `-InstallDirectory C:\HEP-runtime`. For explicit repair/update, add
`-RepairBundle C:\path\trusted-payload.tar.gz`. No action unregisters a
distribution, removes user home data or silently replaces an installed runtime.
Repair creates a harness-owned user-data sentinel, verifies preservation, records
before/after runtime and scientific-environment versions, and checks health.
A payload bundle does not repair the WSL OS layer or a missing administrator tool.

The script records `windows-acceptance.json`, `worker-acceptance.json`, Qt test
output, a saved project and reference C++. It captures actual OS build, CPU/core
counts, RAM, GPU/driver inventory, WSL version, distribution, runtime manifest,
backend/compiler versions, scientific environment and timestamps. A nonzero exit
means an automated failure. Timeouts and errors stay in the receipt.

The native C++ probe uses the existing Qt `RootService`, Resource Broker and v1
private-pipe transport. On Windows it launches the real WSL worker through
`ManagedRuntime`, rather than testing Linux-to-Linux communication as a substitute.
It checks preview, real 1/2/4-worker results within available budgets, independent
scientific identity, sharded materialization/reuse, explicit HepMC export, native
project roundtrip/C++ export, cancellation, killed worker/parallel child, restart,
PDF discovery/offline evaluation and compact IPC counters. Worker-count reduction
results are exact. HepMC roundtrip histogram bins/counts are exact; uncertainties
and moments use relative/absolute `1e-12` tolerance for square-root rounding,
decimal serialization and summation.

The Qt desktop integration suite is required (`HEP_REQUIRE_COLLIDER=1`), so absence
of the WSL collider runtime fails instead of silently skipping the workflow.
This is automated bridge/QML acceptance; complete the interactive checklist too.

## Measured data locality

By default `scripts/wsl/locality_probe.py` creates a 1,000-event sample inside
WSL-native storage, copies its manifest/shards once to the chosen Windows drive,
then analyzes the same sample in place at both locations. It reports filesystem
type/mount point, wall time, event-loop time, sample bytes, copy throughput,
compact result size and numerical equality. Input validation/checksum time is
included in wall time. The native Windows wrapper separately copies a 256 MiB
fixture over the WSL filesystem share with `FileStream`, flushes it and verifies
SHA-256. This deliberate export is measured separately from ordinary control IPC.

Use `-Events 5000 -TransferMiB 1024` for a larger explicit test, subject to free
space; generation admission estimates are conservative. Temporary sample copies
are harness-owned and cleaned normally. The transfer fixture is deleted after
verification; a failed native copy can leave a recognisable `acceptance-transfer-`
file for inspection. No user sample/project is deleted. Use a local C: evidence
directory for the `/mnt/c` comparison; another drive is recorded as its actual
`/mnt/<drive>` path. Never rename a Linux control measurement as WSL evidence.

`-SkipFilesystemBenchmark` explicitly leaves that gate **UNVERIFIED**. Single
trials have uncontrolled cache state and load; they are not cold-disk benchmarks.
No filesystem or native-transfer result has yet been measured on Windows here.

## Interactive native desktop checklist

Record PASS/FAIL, screenshot/log reference and an explanation for each step:

1. Create a project/workflow; configure pp beams, energy, process and event count.
2. Add anti-kT R=0.4, jet selection, leading-jet pT and histogram without code.
3. Run parallel generation; observe progress/resources and a responsive canvas.
4. Preview without adding a Run; inspect ancestry and jet constituent display.
5. Store a sample inside WSL, reuse it and export a single file deliberately.
6. Save/close/reopen; inspect Run provenance and environment/version identities.
7. Change R to 0.6; confirm generator stays fresh and affected outputs become stale.
8. Rerun; compare parameters, overlay, export figure/configuration/reference C++.
9. Change only worker budget; confirm identical hash/results and no stale outputs.
10. Cancel, kill/restart the worker and reopen an interrupted recovery checkpoint.
11. Repair/update through the native UI; confirm projects, samples, PDF data and
    historical Run environments are preserved; record any version mismatch.
12. Test WSL absent/disabled, declined elevation and reboot-required paths where
    appropriate. Capture honest setup actions; do not destroy an existing runtime
    merely to manufacture a clean-install test.

The top-level receipt deliberately stays **UNVERIFIED** even when automated
tests pass. Attach the interactive and setup/repair evidence for review before
changing repository platform status. A mocked contract or Linux test never
becomes a Windows certification.

Linux preparation evidence is retained under `docs/developer/external-*-linux-*`
and `external-acceptance*-tests.txt`: all 15 worker checks and 11 desktop cases
pass on Linux. Evidence copies omit bounded event particle payloads while retaining
their SHA-256, count and the full source receipt hash. These are Linux checks only.
The PowerShell script has not run or been parsed by PowerShell in this environment;
its parser gate is configured in Windows CI, whose execution is still outstanding.
