# Architecture decisions

- [ADR-001: VPIR is canonical](ADR-001.md)
- [ADR-002: Isolate scientific execution](ADR-002.md)
- [ADR-003: Semantic cross-platform equality](ADR-003.md)
- [ADR-004: Schema-based worker protocol](ADR-004.md)
- [ADR-005: Units are part of scientific types](ADR-005.md)
- [ADR-006: Preserve historical runs](ADR-006.md)
- [ADR-007: Deterministic versioned serialization](ADR-007.md)

Part 2 decisions:
- [ADR-008: identities and commands](ADR-008.md)
- [ADR-009: optional isolated ROOT](ADR-009.md)
- [ADR-010: AST and neutral results](ADR-010.md)

Part 3 decisions:
- [ADR-011: Managed WSL scientific runtime](ADR-011.md)
- [ADR-012: Logical resources and physical locations](ADR-012.md)
- [ADR-013: Workflow-level collider placement](ADR-013.md)
- [ADR-014: Neutral event semantics and HepMC interoperability](ADR-014.md)
- [ADR-015: Preserve semantics during collider fusion](ADR-015.md)
- [ADR-016: Generator randomness policy](ADR-016.md)
- [ADR-017: Frozen scientific environments](ADR-017.md)
- [ADR-018: Match scientific SDK language standards](ADR-018.md)
- [ADR-019: Isolated parallel collider partitions](ADR-019.md)

- ADR-020: CPU-independent logical generator streams (supersedes ADR-019 randomness).
- ADR-021: Transactional sharded HepMC samples and explicit single-file export.
- ADR-022: Versioned managed runtime bundle repair (Windows validation outstanding).
- [ADR-023: External platform acceptance preserves evidence levels](ADR-023.md)

- [ADR-024: Isolated typed research pipeline](ADR-024.md)
- [ADR-025: Scientific artifact caching and explicit campaigns](ADR-025.md)
- [ADR-026: Canonical statistical assumptions](ADR-026.md)
- [ADR-027: Binary reconstructed collections share one event row](ADR-027.md)
- [ADR-028: Identified models and effective parameter cards](ADR-028.md)
- [ADR-029: Explicit channel independence and discrete scan displays](ADR-029.md)
