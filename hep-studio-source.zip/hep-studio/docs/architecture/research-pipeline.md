# Research pipeline integration boundary

Part 4 extends the existing VPIR, worker protocol, Resource Broker and immutable
Run model. The initial backend reference evidence is under `docs/developer`.
Windows/WSL and macOS execution remain unverified; their harnesses are preserved.

| Existing interface | Required extension |
| --- | --- |
| `core/vpir/Parameter`, `core/types::domain` | Stable parameter/card bindings; distinct LHE, generator and reconstructed semantic types |
| `core/graph`, `core/editing::scientificJson` | Validate typed research edges and propagate existing scientific dependency hashes; execution budgets stay excluded |
| `core/analysis::inferExpression` | Reuse units/AST for reconstructed records and general physics combinators |
| `runtime/root::RootService` | Reuse the v1 isolated service with a research backend identity; no new WSL protocol |
| `plugins/pythia::configure`, collider engine C ABI | Explicit LHE shower operation; stable logical input ranges/seeds, no independent automatic hard process |
| `plugins/collider` shard transaction | Verified worker-local intermediate artifacts and ordered logical shard metadata |
| `core/scheduler::placeWorkflow`, Resource Broker | Co-locate MG/shower/Delphes/ROOT; one centrally allocated stage/scan budget |
| `core/project`, `core/run_model` | Versioned research/scan/systematic extensions; old schema-1 projects and historical Runs remain unchanged |
| `apps/desktop/Bridge`, existing Qt layout | Research worker controller and progressive inspectors; scientific libraries remain outside the desktop |

New adapters own MadGraph process/card generation and Delphes subprocess/card
execution. Process generation and materialization are explicit boundaries; heavy
LHE/HepMC/ROOT files stay in the selected scientific runtime. Only compact typed
results, diagnostics and bounded previews enter coordinator IPC. The recorded
cards and generated commands are transparency artifacts; structured VPIR remains
canonical.

MadGraph model selection and effective parameter cards follow
[ADR-028](../adr/ADR-028.md). Dependent SLHA entries cannot be user overrides;
the installed model updater refreshes them before generation. Model/restriction
selection is scientific state, and generated import caches are excluded from
scientific source identity.

Reconstruction objects retain their semantic identity and branch capabilities.
Generic collection operations must reject accidental generator/reco connections.
ROOT/RDataFrame compiles supported analysis expressions once, rather than routing
all particles through Python or the UI. Actions are booked coherently.

Binary reconstructed collection operations use explicit named ports. Object
definitions form a common lazy event-row prepass before event filters/actions,
so primary/reference columns can be accessed without joining independently cut
RDataFrames. Their dependencies and semantic types remain graph-visible. See
[ADR-027](../adr/ADR-027.md). Grouped primitive edits make node/edge creation atomic.

Systematics and scans bind parameters/weights to affected graph nodes. Reuse keys
extend existing scientific/dependency hashes with frozen environment and input
identities. Committed artifacts are checksum-verified; interrupted staging cannot
be reused. A scan owns immutable point Runs and explicit failure/completion state.
Execution realization and cache reuse are provenance, not physics parameters.

RooFit/RooStats run in the isolated ROOT-capable worker and consume explicit models,
histogram templates and statistical assumptions. Negative template expectations,
failed fits and incompatible binning are errors or evidence-based diagnostics;
no statistical convention is chosen silently. Implementation and numerical
verification are tracked separately in STATUS.md.

## Campaign recovery and transparency

A scan freezes one base workflow, its unit-aware axes, point Run IDs/hashes and
scientific environment. Each point commits an fsynced JSON record and checksum
before notifying the desktop. Autosave preserves completed Runs while marking
an active scan interrupted. Kernel ownership locks prevent recovery of live jobs.
Resume verifies recorded identities/checksums, replays completed point references
without regeneration and executes remaining points sequentially under one lease.
An environment change requires a new scan; historical points stay immutable.

Systematic descriptors bind affected identities, explicit nominal/variations,
correlation group and interpretation. Values lower to canonical units in core.
Normalization scales weights/errors and squares the factor for sumw2; altered
histogram inputs are refitted. Templates remain individual variations until a
user supplies an explicit statistical model; no prior is inferred.

Equivalent export produces executable standalone PyROOT for supported reconstructed
histograms, native ROOT fits and structured RooFit/RooStats actions, plus a frozen
upstream configuration ledger. It consumes the recorded
Delphes files and does not claim to regenerate an entire detector pipeline.
Recorded artifact checksums are verified before analysis; relinking locations
cannot silently change scientific input. Histogram arrays include the same units,
yield conventions, statistics and identity as the worker. Unmodified ROOT histograms
are retained separately from folded/normalized display copies, preserving native
fit semantics. The reference suite executes exports and compares every bin/error,
fit parameter/uncertainty/status and counting limit with the worker result.

SDK selection reads a versioned local manifest and scopes runtime paths to the
research subprocess. The managed WSL bundle recipe now includes the same worker
and SDK boundary. Recipe/Windows host execution remains unverified.

## Template likelihoods

The separate typed template workflow selects immutable histogram Run/node
references, with source content identity, environment, workflow hash and seed.
It does not rerun their event sources. HistogramSet contains nominal, role and
individual systematic endpoints. BinnedLikelihood records dataset role, POI
range, flow/interpolation conventions, constraints and correlations. Inference
uses real HistFactory/RooStats in the existing isolated research worker.

The supported subset combines up to eight explicitly disjoint event channels,
sixteen uniquely identified samples and 256 total bins. Legacy one-channel
projects retain their exact input representation/identity. One shared POI scales
all signal samples. Different channels may use different observable units and
bins; each channel requires positive background and observed mode requires data
in every channel. Histograms alone cannot establish event-category independence.
Sample identities and correlation groups remain explicit across channels. See
[ADR-029](../adr/ADR-029.md). Optional integer-count data, explicitly excluded/folded
flows, and optional explicit normalization/shape/gamma MC constraints. Raw MC
weights and cross sections are not silently used as Poisson expectations. Empty
background bins, negative expectations, missing endpoints, differing units/bins,
duplicate sample references and invalid source Runs are rejected.

No prior is inferred from campaign labels. Statistical interpretations and shared
nuisance identities are chosen in the Inspector. The desktop reports failed fits,
unbracketed scans and coverage limitations. Template inference is a full immutable
Run; generation preview is disabled for this workflow. Layout is still excluded
from science, and changing a likelihood constraint stales inference without
invalidating its input template Run.

Equivalent export for this subset is executable standalone PyROOT with embedded
identified template arrays, model configuration and source provenance. The
numerical suite executes it and compares its limit with the worker adapter.
Current control-frame/result-size bounds still apply to unusually large template
sets; no bulk event stream is sent through IPC.

## Inspection and evidence

The Statistical Inspector reads stored typed results for parameter/correlation
tables, pull and CLs curves. Native plotting accepts breaks for undefined points
and hides histogram statistics on a curve-only view. Fits select their own input
histogram; changing presentation does not execute a backend. The initial matrix
view is limited to 32 parameters, while complete covariance stays in provenance.
Template likelihoods are limited to 256 fitted bins to bound native model/result
growth; rebinning must be an explicit scientific change.

One-axis scan curves resolve the frozen parameter binding and completed point
Runs, convert canonical/display units and omit failed/missing/nonfinite results.
The first quantities are in-range histogram yields, matrix-element cross sections,
valid limits and discovery significance; fitted parameters also have a generic
query. Connecting lines guide the eye. Two-axis scans use a native discrete marker
view with numerical axes, value color scale, point/Run inspection, zoom/pan and
PNG/PDF export. Frozen base workflows expose uncommitted points as missing;
failed/invalid/unavailable values are null, never interpolated or assigned zero.
Three-axis execution records remain available in provenance without a 3D plot.

Recorded-card inspection reads bounded, manifest-addressed text and checks its
checksum independently of large event files. It neither validates a full sample
nor loads it for display. The Run-evidence JSON export contains the immutable
workflow, environment, results/provenance and any inspected generation/first
detector-partition card text. Complete logical seeds remain in the Run. Missing
card text is explicit; historical Runs are never edited to append inspection data.

## Versioned detector-card resources

New custom cards use `resourceVersion: 1`, logical resource ID, primary content
checksum and relative Tcl dependency checksums. Physical paths live in the
existing project resource-location model. Selection/relinking reuses the same
resource identity for an identical bundle; changed dependencies create a new
scientific identity. Legacy path-based cards retain their historical hash behavior.
Worker stage keys include the verified card bundle and omit resolved paths only
for these identified resources. Small cards are staged privately; unrelated parent
files are not copied. The existing native/WSL resource-path mapping is shared by
collider samples and cards, without changing the versioned worker transport.

Transactions flush artifact data and manifest before atomic publication, and
sync parent-directory metadata. Hash verification is cancellable. Failed data is
unpublished; failure-log retention is best effort under disk exhaustion. Scan
execution enforces its frozen environment in the worker as well as the desktop.
Completed and failed point Runs stay immutable; a failed point is retried by a new
scan, not by silently replacing a historical Run.
