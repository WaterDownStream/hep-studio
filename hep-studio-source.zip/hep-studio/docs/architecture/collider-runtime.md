# Collider runtime

The existing VPIR and scientific-worker protocol remain canonical. The desktop
never links PYTHIA, HepMC3, FastJet, LHAPDF or ROOT. `core/collider` validates event
and collection contracts; `runtime/collider_worker/lowering.cpp` revalidates the
submitted graph inside the worker. `plugins/*/adapter` contains each library API.

The C++23 lowering object exchanges JSON values with the native event engine.
Scientific adapter translation units use the installed ROOT SDK's C++ standard
(detected from RConfigure.h; overridable with HEP_COLLIDER_CXX_STANDARD). This
avoids importing VPIR's C++23 requirements into scientific SDK headers. It is an
internal build boundary, not a stable public C++ plugin ABI.

Python hosts a C ABI library through ctypes. Compilation of the small expression
AST happens once into native function objects. Generation, clustering, selection,
weighting and TH1 filling then execute in a fused C++ loop. Python is not called
per event except a cheap cancellation check; progress is throttled to 200 ms.
Only compact histograms/scalars and explicitly bounded inspection records return.
Fits reuse the established isolated ROOT adapter on compact histogram bins.

Native and WSL workers use the same private inherited pipes and protocol v1.
Negotiated result chunks are ordered, capped at 16 MiB and framed at 1 MiB;
older local workers can still use temporary result files. No listener or exposed
network port is needed. Process EOF, cancellation, malformed frames, startup and
heartbeat timeouts remain bounded. Process isolation is not a security sandbox.

A Run records graph/config/AST, derived seed, actual library/compiler/interpreter
versions, adapter and engine hashes, resource placement, event counters, outputs,
input identity and diagnostics. Environment descriptions are frozen into Runs.
Preview never appends a Run. See ADRs 011–017 and the backend documents.

Parallel generation uses `plugins/collider/parallel.py` to supervise independent
instances of the same v1 worker. Broker allocation must equal the explicit
configured process count (one scientific thread each). Raw TH1 sufficient
statistics, bin errors and scalar counts/sums are reduced in partition order;
fits and normalization are applied once. No event arrays cross partition IPC.
Only partition zero returns a bounded event-inspection record. EOF stops native
children if their parent is killed; normal, error and cancellation paths also
reap children with bounded waits. See ADR-020 for logical seeds/limits and ADR-021 for materialization.

Part 3 hardening replaces worker-count-dependent randomness with ADR-020 logical
streams and parallel sample manifests (ADR-021). Execution worker budgets remain
separate from scientific identity. The native engine supports explicit single-file
HepMC export; normal analysis streams verified shards in place. Managed runtime
payload locking/repair is described by ADR-022; actual Windows validation remains
an open release gate. CPU/RAM quotas are considered by the Linux Resource Broker.

Shutdown enters Stopping synchronously; requests cannot enter a closing pipe, and
restart becomes available only after the replacement worker handshake. The
external acceptance executable uses this same service and protocol (ADR-023),
including parallel-child termination and recovery. Platform receipts distinguish
automated scientific checks from interactive native desktop and setup evidence.
