# Logical samples and physical locations

Project resources have a logical `hep://sample/<id>` identity, format, name,
count, provenance, creation Run and physical `locations[]`. Each location records
runtime ID, kind and path. Nodes reference resource IDs plus content fingerprints;
physical relocation of unchanged content does not alter scientific identity.

Generation streams by default. A StoreHepMC node explicitly materializes data
inside the chosen runtime. The UI's Store in runtime action allocates a path
there; Windows need not move that sample back to NTFS. Local Windows inputs can
be represented by an explicit /mnt/<drive> location; no repeated copying occurs.
Only histogram arrays, metadata and bounded event inspections cross the boundary.

Parallel generation writes one private HepMC3 shard per logical stream and
publishes a sample manifest only after all counts/checksums succeed (ADR-021).
Analysis reads verified shards successively in place. Single-file export is an
explicit worker operation, never an eager prerequisite for analysis. Publication
uses a same-filesystem atomic hard link; unsupported filesystems need runtime-local
storage. Abrupt kills may leave recognisable staging/partial directories, which
are never completed samples. Disk admission estimates 1 MiB/generated event plus
64 MiB; this heuristic cannot guarantee space for all physics configurations.

The desktop records actual per-job control bytes sent/received, diagnostic bytes
and decoded result size in Run transport metadata. Partition metrics separately
record worker control traffic. Result payloads are bounded to 16 MiB; bulk events
remain worker-local. These counters permit actual Windows/WSL transfer audits;
no WSL-native versus `/mnt/c` timing has been measured in this Linux-only session.

Generated files use full SHA-256. External sample inspection uses size and first/
last 64 KiB SHA-256; that strategy cannot prove interior equality. Recorded full
checksums remain full when relinking. Input changes block execution until an
explicit relink accepts the new identity. Missing samples preserve graph and Run
history. Relinking new content updates dependent hashes, never historical Runs.

Research stage artifacts remain worker-local. Their addresses combine scientific
configuration, full input checksums and frozen environment; committed manifests
verify every file. Failures retain logs separately and never publish pending LHE,
HepMC or reconstructed files. Scan point JSON/checksums and compact histogram
arrays can cross control IPC; no bulk event collection does. Runtime repair keeps
`~/HEPStudio/research-artifacts` outside immutable SDK releases.
