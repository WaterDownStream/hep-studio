# Runtime and process contract

The coordinator asynchronously launches `hep-worker` next to the desktop binary.
The local server is created before launch, with user-only access. If the OS refuses a listening socket, the coordinator uses inherited anonymous pipes instead; it does not relax socket permissions. A timer checks pipe readiness without blocking the event loop or owning an input thread. An ephemeral
secret supplied through the child environment authenticates Hello. Worker
version and `hep.mock/1` capability must match. Startup times out after 5 seconds.
The secret authenticates this child connection, not a hostile same-user process.

Control messages are JSON with a documented JSON Schema and C++ `std::variant`
representations. This is the Phase 0 alternative to Protobuf. Each UTF-8 payload
has a four-byte big-endian length prefix and a 1 MiB limit. The parser limits
nesting to 64; messages validate ranges and protocol version. Large scientific
data does not enter this channel. `Channel` operates on QIODevice so a future
transport can be adapted without changing message types.

Messages: Hello, StartJob, CancelJob, Progress, Log, JobCompleted, JobFailed,
Heartbeat. Progress is counted lifecycle ticks, explicitly not simulated events.
Completion contains validated node IDs and an empty scientificOutputs array.
The mock job uses a Qt timer, never sleep on the UI thread. A heartbeat arrives
every 500 ms; 5 seconds without it is a control-plane failure.

CancelJob requests graceful cancellation. If no acknowledgement arrives within
1 second, the coordinator terminates the worker, then kills it after another
500 ms if needed. Direct process death marks an active run Interrupted; cancelled
or interrupted results are partial/invalid. A cancellation racing with an already
completed job can legitimately return Completed. Terminal records append exactly
once. Restarting creates a fresh endpoint and authenticated worker.

A ResourceBroker inventories logical CPUs, physical RAM (when available), OS
and architecture. It grants resource leases, reserves one logical CPU where
possible, and budgets up to half physical RAM. Phase 0 uses one thread and a
64 MiB accounting reservation per job. Worker launch caps common OpenMP/BLAS
thread environment variables. Memory budgets are admission accounting, not
OS-enforced limits. Part 3 coordinates HEP Studio instances for the same host user with a
lock-protected lease registry; this does not control unrelated applications. GPU, NUMA, P/E topology, storage and container quotas
are unknown, not fabricated.

Runs preserve workflow snapshot/hash, environment, backend, seed, timestamps,
resource inventory/allocation, plan metadata, structured logs and result status.
Mock execution uses no RNG. Seed is a lossless decimal string, not an implemented
scientific RNG hierarchy. ROOT Runs additionally record ROOT version/location, interpreter, source
fingerprints, complete AST/plan/configuration, per-node hashes, workflow revision,
Qt/application/OS metadata and worker timings. No bitwise cross-version
reproducibility guarantee is claimed.

`QSaveFile` performs atomic replacement without an unsafe direct-write fallback;
`QLockFile` prevents simultaneous writers. Autosave uses a separate recovery
file in Qt's application data directory. During a job that file contains an
Interrupted snapshot, so a later recovery cannot claim a killed job completed.
Named project files are only replaced when explicitly saved. There is no schema
migration yet, therefore no destructive migration to back up.

Implementation references: [Qt local sockets](https://doc.qt.io/qt-6/qlocalsocket.html)
map to Unix domain sockets or Windows named pipes;
[QProcess](https://doc.qt.io/qt-6/qprocess.html) provides child lifecycle handling.

## ROOT worker contract (Part 2)

`RootService` owns one persistent Python process and allows one operation at a
time. It uses inherited anonymous pipes on all platforms, without a listening
port. This private parent-child transport does not need the mock socket token.
The worker duplicates its protocol output and redirects ROOT/Cling stdout to
stderr so native diagnostics cannot corrupt framing. Windows CRT pipe handles
are set to binary mode. The desktop bounds captured diagnostics to 64 KiB.

Protocol v1 messages: hello(capability), request(id, operation, payload,
resultPath), progress(id, stage), completed(id), failed(id, message, cancelled),
heartbeat, cancel, shutdown. Framing remains 4-byte big endian / 1 MiB. Results
use negotiated ordered resultChunk frames (including across WSL); legacy local
workers may use a private temporary file. Both paths have a 16 MiB cap and
result-shape validation. Large event arrays never traverse
IPC. Preview is explicitly capped at 500 rows, 32 selected columns, 16 values per
collection; the initial UI previews up to 12 columns. Preview is not a Run.

ROOT initialization and heartbeat deadlines are 30 seconds. Partial control
frames time out after 3 seconds (2 seconds for the mock channel). Shutdown and
cancellation have a 1-second process-kill fallback. Destructors use bounded waits.
RDataFrame GetValue and Fit release the Python GIL for the control thread. A native
ROOT call is not assumed cooperatively interruptible: killing its worker is a
supported cancellation path. Failed/interrupted output is never valid output.

A FileCache reuses one TFile until its fingerprint changes. TTree previews seek
the requested entries and enable selected branches only. RNTuple preview uses typed RNTupleReader entries with indexed entry access;
it does not scan preceding rows to reach a preview page. Collection display
conversion only indexes the first 16 values, without copying an entire vector. Inspection
limits directory depth to 32 and keys to 10,000.

All RDataFrame actions are booked before any result is requested, preserving a
single shared event loop for branching actions. One source per workflow and one
scientific thread are supported. The shared ResourceBroker accounts for a 512 MiB
ROOT reservation; this is an estimate, not an enforced RSS limit. ROOT/Cling may
exceed it. There is no Python per-event loop in scientific execution.

Histograms return edges, values, errors, flows, normalization, dimensions and
statistics. Fits return parameters/errors, covariance/status, chi-square, ndf,
p-value and sampled curves. A failed/unreliable fit is labelled explicitly;
unreliable covariance suppresses the overlay. Histo2D is implemented/tested in
the adapter; its visual editor/renderer is deferred. Snapshot export is deferred.

## Input identity and equivalent code

A dataset reference separates logical ID from current file location. A Run
captures location-at-run, size, nanosecond mtime, checksum and hashing strategy.
Files up to 2 MiB use full SHA-256; larger files use first+last 1 MiB plus size and
mtime. This partial strategy cannot prove byte-for-byte identity for all interior
changes. Fingerprints are checked before/after execution; changes require an
explicit refresh/relink. Missing input is a recoverable error. Old provenance
is retained, never rewritten to claim a changed input was identical.

Equivalent PyROOT is informational/exportable and generated from the executed
plan, not parsed back as canonical state. It books actions lazily and includes
fit models/settings. Fit normalization/flow details are explicitly approximate
in the exported text. Preview operations do not generate publication Runs.


Fit configuration uses ROOT's B option when user initialization/bounds must be
preserved, and F for bounded polynomials so the linear fitter cannot ignore
constraints. The objective is bin-center chi-square. A p-value below 0.001 is
flagged as poor model adequacy separately from minimizer convergence. These
choices follow the [TH1 fitting contract](https://root.cern.ch/doc/master/classTH1.html).
