# Architecture

The authoritative chain is UI → VPIR → validation → backend lowering →
execution plan → coordinator → worker. Generated code is not canonical.
The Qt-free core owns types, units, graph structure and deterministic JSON.
The runtime owns operating-system integration; QML owns presentation.

Part 2 adds `core/analysis` (schema, AST inference, ROOT plan contracts),
`core/editing` (command deltas and workflow identities), `runtime/root`
(asynchronous process service), `plugins/root` (isolated PyROOT adapter), and
`render/plots` (native Qt plot data). The original mock backend remains a
lifecycle test; its empty scientific output is never presented as ROOT output.

The ROOT boundary is VPIR → validated, topologically ordered ROOT plan →
RootService → inherited-pipe worker → RDataFrame → typed JSON result objects.
PyROOT is an implementation choice behind that boundary, not a requirement for
the C++ core or GUI build. The worker alone imports ROOT. Missing capabilities
are reported explicitly; the adapter does not substitute synthetic results.

No scientific library is loaded in the UI process. QProcess starts a worker
using structured arguments, never a shell string. A crash can terminate the
worker without terminating the UI. This is fault isolation, not an operating
system sandbox for hostile plugins. There is no general third-party plugin loader. ROOT file reading retains ROOT's own trust assumptions; process separation is fault isolation.

Projects have stable logical identities and environment IDs, not platform
paths as scientific identity. Save locations are local UI choices and are
not serialized into the workflow. The same project bytes can travel between
Windows, macOS and Linux. Part 3 adds managed WSL setup/launch contracts; actual Windows verification and
a distributable image remain pending. Remote execution is not implemented.

Dependencies are narrowly contained: nlohmann/json is used by the core;
Qt Core/Network by the runtime; Qt Gui/Qml/Quick/QuickControls2 by the desktop.
There is no public C++ plugin ABI yet. Compiler/transport interfaces are
internal, replaceable seams. No empty plugin integrations are presented as
implemented features.

## Project and presentation ownership

A Project owns shared dataset references and any number of workflows. The
active workflow is an explicit persisted ID. Duplication copies only its graph;
it shares dataset references and leaves immutable Run history alone. Command
history stores node/edge/parameter deltas per workflow (bounded to 200 commands),
not repeated Project snapshots. Execution and Run history are never undoable.
History is session-local; saved project state is persistent.

Scientific identity excludes a documented set of layout/presentation fields.
Results carry per-node dependency hashes, allowing the UI to mark downstream
results stale without deleting old data or silently rerunning the graph.
Plot controls are workflow presentation state; QPainter renders neutral arrays,
never a ROOT TCanvas. Runs embed bounded result records. Worker-local sample
manifests and verified scientific stage caches are separate from those compact
records; remote artifact storage is not implemented.

## Collider extension (Part 3)

See [collider runtime](collider-runtime.md), [placement](execution-planner.md) and
[data locality](data-locality.md). They extend the existing VPIR, editing and Run
models; project schema version 1 and unknown-field preservation remain intact.
The isolated native worker integrates real PYTHIA/HepMC3/FastJet/LHAPDF and ROOT
histograms. No marketplace or remote execution is introduced.

## Research extension (Part 4)

[Research pipeline](research-pipeline.md) extends those same interfaces with
typed LHE/shower/Delphes/reconstructed stages, explicit systematics, frozen
parameter scans and RooFit/RooStats/HistFactory. Scientific libraries stay in the
worker. Matrix-element generation and detector materialization are explicit
subprocess boundaries, with transactional artifacts, descendant lifelines and
one broker allocation. Identified custom-card bundles reuse logical resources;
legacy scientific hashes and historical Runs are preserved. Numerical Linux
references and Qt acceptance are separate from unverified external host execution.
System 1/2, SciSpec generalization and Part 5 are not implemented.
