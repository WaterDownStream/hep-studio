# Execution placement

`core/scheduler/placement` produces an explicit plan: chosen worker, ordered node
IDs, co-located stages, thread budget, preserved materializations, transfer list
and reasons. It filters candidates by health, available threads, required library
capabilities and explicit placement override. Physical input locations constrain
eligible workers. Mounted Windows data carries a size-proportional cost; an
existing runtime-local copy is preferred. No implicit bulk-copy operation exists.

The initial executor places one complete collider pipeline in one worker. This
preserves the one-event-stream contract and avoids shipping particles through
IPC. ROOT-only workflows retain their Part 2 native ROOT service. On Windows the
collider candidate is the managed WSL runtime. Multiple candidate selection is
unit tested, but the desktop currently exposes one collider runtime candidate;
it is not a general arbitrary multi-stage distributed scheduler.

The host ResourceBroker uses a lock-protected per-user registry shared by HEP
Studio instances. It reserves one logical CPU where possible, accounts for up to
half RAM, reclaims dead processes and retries releases after temporary lock
contention. Reallocation is atomic. ROOT jobs lease one thread and 512 MiB. Collider generation
leases the exact configured worker count and 512 MiB per process; Preview uses
one. Plans carry this thread requirement and reject insufficient candidates.
Sequential jobs release their leases. This is admission accounting, not an OS
memory limit; parallel children disable nested library thread expansion. GPU/NUMA utilization is not invented or inferred.

Physical worker count schedules fixed logical generator streams (ADR-020), and
is excluded from scientific hashes. Linux admission accounts for cgroup v2 CPU
and RAM ceilings before the UI reservation. This is host-budget accounting, not
a guarantee that unrelated external applications obey those leases.

Research plans add explicit MadGraph, LHE shower, Delphes, RooFit and RooStats
capabilities. MadGraph subprocess generation and detector materialization are
preserved boundaries. Logical LHE streams schedule across physical shower workers;
analysis actions share a native RDataFrame loop. Scans hold one peak allocation
and execute points sequentially. Subprocesses force OpenMP/BLAS thread budgets to
one. This admission model does not yet parallelize matrix-element integration or
Delphes partitions and does not claim arbitrary distributed research placement.
