# VPIR v1 foundation

A Project owns named Workflows and terminal Runs. A Workflow owns Nodes and
Connections. Node/port IDs are explicit, stable, opaque ASCII identifiers.
Type descriptors contain a domain name, primitive storage kind and a physical
dimension vector. Connections require exact type and streaming-mode agreement;
implicit precision widening, structural subtyping and materialization are not
implemented. Ports have one incoming edge, can be optional, and outputs fan out.

Dimensions use independent energy, length, time and angle exponents. Canonical
scales are GeV, mm, ns and rad. Natural-unit equivalences are NOT applied
implicitly. This prevents accidental energy/length interchange. The registry contains eV, keV, MeV, GeV, TeV, mm, cm, m, ns, s, rad, pb,
fb^-1 and dimensionless `1`.
One pb is 10^-34 mm², one fb^-1 is 10^37 mm^-2; their product is 1000.
Addition performs a checked scale conversion and rejects incompatible dimensions.

Parameters carry typed values/defaults, units, range, origin, role and docs.
Changed-from-default is derived. Scalar parameter units/ranges are validated;
the mock backend accepts no parameters. Part 2 expressions are structured AST objects in each ROOT node's `config`.
Parts 3–4 add typed collection transforms and versioned explicit systematic
descriptors; neither changes the canonical AST representation.

## Expression AST and type mapping

Leaves: `{"op":"column","name":"px"}` and
`{"op":"literal","value":1,"unit":"GeV"}`. Internal operations use `args`:
`add/sub/mul/div/min/max`, `square/sqrt/abs/neg/sin/cos/exp/log`, comparisons
`gt/ge/lt/le/eq/ne`, and groups `and/or/not`. `index` takes a collection and a
bounded nonnegative constant integer. `property` resolves a named record field
through a flattened schema column. The editor assembles these objects directly;
no raw-code AST node is accepted. There are 32-level/32-operand limits.

Inference rejects unknown columns, opaque values, scalar/collection confusion,
non-Boolean filters and incompatible physical dimensions. Unknown units remain
explicitly unknown with dimensionless treatment until the user assigns units.
The adapter converts known units to canonical scales before ROOT arithmetic.
Numeric scalar expression operands are promoted to Float64 (including indexed
collection elements), preventing integer division and small-integer overflow in
physics formulas. Integer identity arithmetic above 2^53 is not exact in this
initial expression model; original schema types and integer previews are retained.
User column names are mapped to generated safe aliases. Only whitelisted
operators/functions become C++ expressions; the graph remains canonical.

`DatasetSchema` stores object/format, entry count, columns and metadata. A column
has a core Type, dimension, collection flag, original backend type, path and unit
knowledge flag. Common ROOT signed/unsigned integers, Float32/64 and Boolean
map to core primitives. Numeric vectors map to collection metadata. Unsupported
records are Opaque; supported nested numeric leaves appear as dotted paths.
Schema extraction reads metadata, not whole columns. `hep_units` TObjString JSON
is the initial optional units convention; missing units are never guessed.

Serialization sorts objects, node IDs, port IDs, parameter names and connections.
Run order remains chronological append order. Both project and workflow have
schemaVersion 1. Reader limits: 16 MiB per project, nesting 64, 100 workflows,
10,000 nodes/workflow, 50,000 edges/workflow. Unknown object fields are retained,
including nested types/positions. Unsupported schema versions fail before save;
no migration or auto-upgrade occurs. Invalid but representable graphs can be
saved and reopened for repair; execution requires validation.

## Scientific and layout identity

A Run keeps the full snapshot and its revision digest, plus an independent
scientific SHA-256 digest. `scientificJson` removes workflow/node display names,
positions, `presentation`, `comments` and `collapsed`. All configuration,
parameters, ASTs, units, dataset identity/fingerprint, contracts and unknown
non-presentation fields remain scientific. `layoutJson` contains presentation
state. Worker-local research stage caches add full input/environment identity to
these contracts; the desktop dependency hash remains the stale-state check.

Per-node dependency digests include that node and all ancestors. Changing a
Filter marks it and downstream histogram/Fit stale. Binning changes only the
histogram and its descendants. Moving nodes or changing plot titles/fonts does
not affect scientific identity. Stale historical results remain accessible.

The mock compiler performs structural validation, checks exact supported node
contracts and computes deterministic topological order. It refuses unsupported
node types/versions/parameters and altered signatures. It does not reorder
randomized operations or claim optimization passes that do not exist.

## Collider semantics (Part 3)

EventStream, JetCollection and EventTable are core semantic types. Library
objects never enter VPIR serialization. Collider configuration uses structured
JSON and the existing AST/units model; jet pT/mass/energy use GeV, phi uses radians,
eta/count/weights are dimensionless. Project-derived generator seeds extend
scientific/dependency hashes. Sample content fingerprints are scientific; current
physical paths remain project resource-location metadata.

## Research semantics (Part 4)

LHEEventSample, ReconstructedEventDataset, distinct reconstructed collection
identities, HistogramSet, LikelihoodModel, FitResult and HypothesisResult are
domain contracts. Library C++ classes never enter serialization. Structural
properties such as isolation and jet tags are available only on their declared
collections; runtime schema checks reject absent branches. Physics operations
`deltaPhi`, `deltaR` and `transverseMass` retain scalar/unit checks.

Parameters/scans bind stable node IDs and canonical JSON pointers; unit conversion
occurs in core before lowering. Missing defaults remain explicitly unknown.
A scan stores one base workflow, axes and immutable point Runs, not copied
Projects. Execution budgets cannot be scientific variation axes. Systematics
state affected identities, nominal/endpoints, correlation and interpretation;
priors are not inferred.

Research/project, systematic, scan, stage-artifact and detector-card-resource
extensions are individually versioned. Project schema 1 and unknown-field
preservation remain unchanged. New identified cards separate content/dependency
checksums from physical location; legacy path-based card hashes are retained.
Fixed logical LHE/detector partitions determine randomness independently of
physical shower scheduling. Environment and execution realization remain
separate from scientific workflow and layout identities.
