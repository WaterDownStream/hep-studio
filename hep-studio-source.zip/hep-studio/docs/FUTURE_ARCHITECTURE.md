# Deterministic authority and future AI boundaries

The existing scientific compiler, type/unit/schema validators, dependency hashes,
provenance and environment resolution are System 0. They remain authoritative,
deterministic and usable entirely offline without AI.

Future optional System 1 semantic assistance and System 2 reasoning may propose
structured VPIR edits. Every proposal must pass the same deterministic validation
and become inspectable canonical state before execution. Models must not own
hidden physics settings, execute inside core/runtime scientific classes, or
replace reproducibility, hashing, dependency analysis or environment resolution.

No LLM integration, local semantic models or AI-required functionality is added
in Part 4. This document reserves a boundary; it implements no AI subsystem.
