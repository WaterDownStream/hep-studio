# ROOT Studio walkthrough

1. Launch the desktop from a Python/ROOT-enabled shell (see README). The ROOT
   status shows availability, version and runtime path. The project initially
   retains the original mock workflow; selecting a ROOT dataset creates a ROOT
   analysis alongside it.
2. Choose **Open ROOT / Relink**, select a file, then select a TTree or RNTuple in
   the indented object browser. Inspect column types and the dataset entry count.
   The fixture generator in README creates px/py in known GeV units. For your
   own file, assign column units when known; unknown units are not guessed.
3. **Load sample** reads only a bounded PREVIEW. Set offset and size (up to 500).
   It creates no scientific Run. Cancel remains available during worker tasks.
4. In **Build analysis**, choose **New observable**. Name it pT, use **pT preset**,
   and confirm. It builds sqrt(add(square(px), square(py))) as structured objects.
   Select individual formula parts to choose columns, operations or unit literals.
   The output type/dimension is shown. There is no conventional code to enter.
5. With Define pT selected, choose **Filter** and **Cut preset**. Select the literal
   to set a threshold in GeV. AND/OR nodes accept nested comparison groups; NOT
   wraps a condition. For example add abs(eta) < 2.5 to an ALL group.
6. With Filter selected, choose **Histogram**. Select pT as the expression and set
   bins/range, optional explicit edges, weight, normalization and flow policy.
   Initial supported visual histograms are 1D. Other actions include Count,
   Mean, Sum and Min/Max.
7. Select the histogram and **Fit selected histogram** if desired. Choose Gaussian,
   exponential or polynomial (order 0–5); range, initial values and bounds are
   numeric inputs. Gaussian parameters are amplitude, mean, sigma. Exponential
   uses exp(p0+p1*x). Fit failure or unreliable covariance is clearly labelled.
8. **Run analysis** submits the entire graph to ROOT. Native results appear in
   **Plot & fit**. Select a histogram in Build analysis if there are several.
   A fit is overlaid only when its result and covariance are usable.
9. Change title, axis label, font, legend, step/bar style, log Y, zoom and pan freely.
   These do not rerun physics. Title/label/font/legend/style/log settings persist;
   interactive zoom/pan is session-local. Export PNG or PDF.
10. Save the project, close and reopen. Workflows, ASTs, units, dataset references,
    layout, presentation controls, Runs, diagnostics and result arrays survive.
11. Edit the Filter threshold. Downstream nodes show **STALE**; upstream Define
    does not. Rerun. In **Runs & transparency**, select primary/comparison Runs to
    see configuration differences. Compatible histogram edges/dimensions/
    normalization allow an overlay in Plot & fit.
12. Inspect full provenance or equivalent PyROOT in Runs & transparency; code is
    exportable and informational. The graph is always canonical.

Workflow controls provide switching, rename, duplicate and confirmed delete.
Undo/redo covers graph editing and definitions; it never undoes a scientific Run.
The graph canvas retains explicit port connection/disconnection and dragging.

For missing/changed files, Open ROOT / Relink and select the dataset again. This
updates the current source reference while preserving past Run identities. A
changed fingerprint requires this explicit refresh before a new Run can succeed.

After worker failure, use **Restart ROOT** and rerun. A killed/cancelled Run stays
invalid in history. Recovery autosave preserves an interrupted record. Preview
and inspection failures do not produce publication Runs.
