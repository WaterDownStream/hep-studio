# Collider Studio walkthrough

Check Runtime / Samples first. PYTHIA, HepMC3, FastJet and ROOT must be available;
missing science libraries are not replaced with demonstration data.

1. Open Collider Studio and choose Leading-jet example, or create a workflow and
   add PYTHIA, Cluster Jets, collection selection/sort/take, Property and Histogram.
2. Select PYTHIA. Choose beams, energy, a searchable process, event count and seed.
   Essential is sufficient; Advanced and Research expose installed settings.
3. Select Cluster Jets: anti-kT, R=0.4. Select/filter jets, sort descending pT,
   take one leading jet, and extract pT. The histogram reads the scalar value.
4. Generate PREVIEW (1–20 events). Inspect the particle table, selected ancestry
   and eta–phi constituents. Preview is not a scientific Run.
5. Full Run records immutable provenance. Watch event counters and rate. Plot
   controls change presentation only; export PNG or PDF from the plot tab.
6. Save the project. Change R to 0.6; dependent results show stale. Run again and
   choose the previous Run as an overlay. Inspect parameter/environment differences,
   complete provenance, placement and generated C++/generator configuration.
7. To keep events, add Store in runtime before running. This adds a real HepMC
   materialization node. Samples can be reused in another workflow. Existing
   output files are never overwritten; allocate a new destination for another Run.
8. Missing or changed samples can be explicitly relinked in Runtime / Samples.
   Relinking unchanged bytes does not alter physics hashes. Old Runs stay intact.

PDF Explorer lists installed sets and evaluates actual distributions. Install a
new set only through the explicit download action; already installed sets work
offline. A generator PDF selection is recorded with its member and checksums.

Current limitations: one collider placement candidate; HepMC3
Asciiv3 interchange; no collider Histo2D editor or full standalone Fit/HepMC code
export. Unsupported export paths display a configuration/plan listing rather
than pretending to be an executable implementation. Windows image/host validation
is still pending; see STATUS.md. No terminal or conventional code is needed once
a working scientific runtime is installed.

For longer streaming Runs, select the generator's Advanced tab and set Generator
workers. The Run needs that exact CPU/memory budget; reduce the value if busy.
Physical worker count changes scheduling, not scientific identity. New generators
use fixed logical streams; changing their stream size/policy does change the sample.
Old projects retain their former stream count. The guarantee requires the same
installed scientific environment; no cross-platform bitwise guarantee is claimed.

Stored HepMC runs write shards in parallel and appear as one sample. Use **Export
one file** only when a single HepMC file is needed. Keep the manifest and its shard
directory together when relocating. Preview stays bounded and is not a full Run.
Equivalent C++ executes the recorded streams sequentially; the generated base
PYTHIA settings alone do not reproduce a multi-stream sample. Provenance includes
both scientific stream definitions and the physical execution budget. Runtime
repair/update uses an explicitly selected trusted bundle and preserves user data;
the Windows image and host flow still require validation.

Actual active processes are limited by the number of logical streams. A 100-event
Run with a 4096-event stream is one stream even if four workers are available.
The Inspector shows the stream count; physical workers do not silently change it.
