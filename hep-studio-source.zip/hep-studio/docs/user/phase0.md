# Phase 0 walkthrough

1. Launch HEP Studio. The initial graph is Mock ParticleSource → Mock Filter →
   Mock Histogram. Wait for the worker indicator to show Healthy.
2. Select a card or its entry in Project Explorer. The Inspector shows real
   input/output types. Drag a card by its title to reposition it.
3. Choose JetCluster in the node menu and click Add node. Connect the particle
   source OUTPUT to its INPUT. A ParticleCollection is accepted. Connecting
   the histogram OUTPUT to a JetCluster INPUT is rejected. Disconnect the
   input first if it is already occupied. Validation lists required inputs.
4. Click Run mock. The bottom panel reports completed mock steps. These are
   process-lifecycle ticks, not simulated events. No histograms are generated.
5. Start another run and click Cancel. The run history records Cancelled.
6. Start another run and click Kill worker (crash test). The window remains
   open and the job becomes Interrupted. Restart worker to run again.
7. Save a `.hep.json` project, then use Project → Open. Graph, run snapshots,
   environment, seed and logs are retained. Each run has a new identity.
8. Project → New jet workflow creates the second mock chain. Save the current
   project first if you want a named copy; replacing the active project is
   confirmed. Project → Recover last autosave opens the latest recovery file.

The only scientific graph displayed in the editor is the first workflow in a
project. Other workflows are preserved by serialization but have no switching
UI yet. Graph editing/open/new is disabled while a job is active. Save retains
terminal history; an in-progress job is separately protected by recovery.

Keyboard: Ctrl/Cmd+S opens Save, Ctrl/Cmd+O opens Open, Escape clears a pending
port connection. Canvas scrollbars reach larger graphs. Undo/redo, zoom,
expression building, parameter forms and real data browsing are later work.
