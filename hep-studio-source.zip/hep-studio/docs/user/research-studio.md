# Research Studio

Configure a verified `research-sdk.json` through **Research → Runtime → Select
SDK**. The worker health view distinguishes missing and incompatible components.
Core/desktop still run without those libraries; no scientific output is fabricated.
`examples/README.md` describes three executed projects and their limits.

For the initial no-code analysis, choose **New research workflow**. Configure the
MadGraph process, beams, event count and seed in Essential; use Advanced for
explicit run-card/model bindings. The pipeline already includes the typed LHE
shower handoff, Delphes, reconstructed muons, selection, opposite-sign pair,
invariant mass and histogram. Configure the shower/detector and build the cut in
the structured expression dialog. Choose raw weights, cross section or luminosity
explicitly. Add RooFit and set model/range/parameter bounds in its Inspector.

The Essential model selector offers **SM — default restrictions** and
**SM — unrestricted parameters**, both at LO. Use the latter for external model
parameters fixed by the default restrictions. Derived entries cannot be changed
directly; the worker refreshes them from the model equations. Invalid bindings
fail clearly, and the effective final card is retained in Run provenance.

**Generate PREVIEW** uses a bounded sample without changing the full scientific
configuration or adding a Run. **Full Run** records immutable provenance, compact
results and worker-side artifact references. **Preview / Objects** inspects a
bounded event range after execution. Schema metadata comes from actual stored
branches; a custom detector card lacking a requested collection reports an error.
Photons/tracks/jets/electrons/MET use their own semantic collections.

For overlap removal, create the primary and reference collection branches first
(for example, jets and selected muons from the same Delphes node). Select primary
objects, choose **OverlapRemoval → Add**, and pick the reference branch in the
dialog. Set the ΔR radius in the Inspector. The rule removes objects strictly
inside the radius; reference-object cuts participate in staleness. Creation and
both connections undo together. MET/composite pairs are not overlap references.

**CollectionCombine → Add** uses the same reference picker. It unites compatible
collections without counting a source object twice. Electrons and muons form a
typed lepton collection; add **Pairs** to choose opposite-sign/same-flavour rules.
Sort the combined collection explicitly before selecting leading objects. The
combination keeps primary order followed by unseen reference objects.

**Statistics** shows stored diagnostics. **Plot** supports native figure export.
**Runs / Provenance** compares Runs, overlays compatible histograms, shows the
frozen configuration/environment and exports equivalent configuration. **Inspect
recorded cards** retrieves bounded checksum-verified text when the original cache
exists. **Export Run evidence** saves the complete immutable Run and inspected
cards; missing cache text is explicit. Historic compact results survive missing
worker-side event files.

For inference, generate separate signal/background Runs, then choose **New
template likelihood**. Select each identified histogram, its role and a stable
sample identity. Declare expected-count interpretation when appropriate; use
luminosity-scaled yields for the generated examples. Configure the dataset role,
POI range, flow convention and each nuisance interpretation explicitly. Shared
correlation groups create shared nuisance parameters. Shape nuisances use existing
systematic endpoints. Gamma MC constraints require the independent-effective-count
assumption. Run the model and inspect status, limits, covariance and coverage
warnings. Source Runs remain unchanged when the model is edited.

For combined inference, assign channel names when adding templates and explicitly
confirm that their event categories are disjoint. Each channel needs background;
observed mode also needs data in each channel. Different channels may use different
observables/binning. Keep sample identities unique across channels. One shared
signal-strength parameter scales their signals. Reusing the same histogram in
two channels is rejected; distinct histograms still do not prove independence.

**Campaigns** adds explicit systematic descriptors and generic unit-aware scans.
The basic controls expose normalization and parameter variations; expert JSON
supports the remaining implemented descriptor kinds. Upstream scientific stages
are reused when their inputs/configuration are unchanged. A scan never changes
the nominal workflow; each point has an immutable Run. Completed points survive
cancellation/crash. Recover/resume uses the frozen base workflow, point identities
and environment. Failed point Runs remain explicit; retry with a new scan rather
than rewriting their historical outcome. Plot recorded one-axis yields, cross
sections, valid limits or significance. **Scan a second parameter** adds a second
unit-aware range; the total grid is limited to 64 points. Two-axis plots show
discrete recorded values on numerical axes, with no interpolation or implied
confidence contour. Hover identifies the point and Run; crosses mark failed,
missing or unavailable values. Zoom/pan/export change presentation only.

Equivalent reconstructed-analysis PyROOT executes supported histograms, native
ROOT fits and structured RooFit/RooStats calculations. It verifies recorded input
checksums before running. Relink `INPUT_FILES` to the same contents if files moved;
select the recorded Delphes SDK/environment. Upstream generator/detector settings
remain a transparency ledger rather than a claim to regenerate the whole chain.

Saving/reopening preserves workflows, expressions, systematics, scans and Run
history. Identical custom Tcl card bundles can be relinked through the file picker;
changed dependencies create a new scientific identity. Data and cards unavailable
in the selected runtime must be relinked. Cross-platform acceptance remains
unverified on Windows/WSL and macOS; use the preserved host harnesses to establish
actual evidence before claiming validation.
