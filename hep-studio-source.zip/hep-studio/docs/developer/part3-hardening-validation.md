# Part 3 hardening acceptance evidence

The source checkpoint is not a Part 3 completion certificate. No Part 4 work.

## Linux

Baseline before changes: 9/9 suites, 60.26 s. Expanded real backend tests exercise
fixed logical streams on 1/2/4 physical workers, transactional shards and reuse,
explicit single-file export, worker kill/restart, stage cancellation and C++ export.
Portable contract tests add malformed/incomplete/version frames, negative weighted
accumulator fixtures, insufficient storage and interrupted staging recovery.
Final Linux CTest: 11/11 suites pass, 84.27 s; see `part3-hardening-tests.txt`.
Local-socket test is skipped because this sandbox prohibits native sockets.
Pipe transport is exercised. The real backend suite includes weighted normalized
C++ export and actual filesystem-capacity refusal before sample generation.

The no-science build passes nine applicable suites in 12.89 s, with ROOT/collider
backend tests explicitly skipped (`part3-hardening-portable-tests.txt`).

The final Qt suite passes all ten cases, including worker-count-only edits,
unchanged scientific hashes/results/stale flags, separate execution comparison,
undo/redo through the inspector, and reopening an interrupted job checkpoint.
Unchanged JSON numeric values retain their canonical representation across Qt
serialization. Full suite details are in `part3-hardening-detail.txt`. The
checkpoint test reopens a fresh Qt bridge; it is not an OS-level application kill.
The separate real parent-death test kills the worker supervisor and verifies its
native children terminate.

Desktop integration uses the actual Qt bridge and QML lifecycle with offscreen
rendering. It is automated acceptance, not an interactive Windows/macOS session.

## Required Windows 11 evidence (outstanding)

Record Windows build, CPU/RAM, WSL version/kernel, distribution version, runtime
manifest and every library version. Use the native desktop to create the leading-
jet workflow, run 1/2/4 worker budgets, inspect events/constituents, save/reopen,
change R, rerun, overlay/diff and export. Check preview, cancellation, killed-worker
recovery, repaired-runtime health and unchanged project/sample/PDF files.
Measure the same persisted sample workload in WSL-native storage and `/mnt/c`;
record bytes/rate/wall/peak RAM and `partitionRuns[].controlBytes`. The latter must
stay compact rather than grow with total particle bytes. Include a large output
case; do not infer storage behavior from small Linux-only fixtures.

No such host session or prebuilt native desktop/runtime image is available here.

## macOS (outstanding)

Build configuration exists. No macOS build, CI result or physical Apple Silicon
session has been observed. Record desktop, worker, backend capability versions,
end-to-end persistence/comparison and available PDF integration when performed.

## Fault evidence interpretation

Synthetic transport/negative-weight fixtures test contracts and algebra; real
PYTHIA/FastJet/HepMC tests verify actual adapters. Neither substitutes for native
Windows/WSL transport, OS repair/elevation/reboot testing or filesystem benchmarks.

The opt-in Windows 11 runner sets `HEP_REQUIRE_COLLIDER=1`: a missing collider
runtime fails desktop acceptance instead of silently skipping the real workflow.
This gate is configured, not yet executed.

Per-job desktop transport counters are `Run.extensions.transport`: actual control
bytes sent/received, diagnostic bytes received, and decoded result bytes. The
100-event desktop test requires a nonzero result and fewer than 2 MiB received
control traffic. This is a bounded-payload acceptance check, not a WSL bandwidth
measurement. Progress/heartbeat frames count toward the total.

Release timings are single trials on a shared VM. The matrix resumes completed
cases after session interruption; it is not an uninterrupted dedicated-host
campaign. Load/frequency variation can affect speedup/efficiency. Library and
adapter identities are retained for every case; no cross-machine comparison is
claimed. Startup totals sum per-stream process overhead; initialization/setup
is separately estimated as operation time minus native event-loop time.
