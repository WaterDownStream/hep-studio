# Part 3 continuation / release gates

Open STATUS.md first. The source archive retains the existing Part 2 repository;
it is not a replacement project. No Part 4 work is authorized.

Remaining major gates:

- Build a distributable, checksum-published scientific runtime image and native
  Windows bundle. Execute Windows 11 setup/import/handshake/end-to-end tests.
  Packaging recipes and CI artifact steps exist; neither is a verified release.
- Run macOS native builds and scientific integrations on an actual host/CI runner.
- Validate parallel process partitions on Windows/WSL and macOS. Linux now has
  deterministic reduction, exact broker budgets and bounded failure handling.
  Persisted HepMC uses logical shards; standalone C++ reproduces the recorded
  logical streams sequentially and reduces their raw histograms deterministically.
- Measure Windows/WSL control overhead and a deliberate large-resource locality
  test. Do not use Linux adapter timings as substitutes.
- Validate the production ROOT/PYTHIA/FastJet/HepMC/LHAPDF distribution and complete
  binary/source/license packaging. The locally tested ROOT wheel is alpha.

Independent implemented work includes library adapters, native event loop,
no-code configuration, plot/Run integration, sample integrity/relinking, PDF
management/exploration, environment locking, settings/code export and fixtures.
Unsupported standalone code paths show the validated plan explicitly.

Build one configuration at a time in a given build directory. Do not run two
Ninja builds concurrently. Require build success before interpreting test results;
otherwise an old test binary can report a misleading pass. Test logs should be
paired with the build log from the same checkpoint.
