Historical record; superseded for current capabilities by STATUS.md.

# Phase 0 delivery status

## Implemented

- C++23 CMake targets, explicit build switches, strict compiler warnings and CTest.
- Qt-free IDs, primitive/domain type descriptors, physical dimensions, nine unit
  definitions, checked quantities, VPIR nodes/ports/parameters/connections.
- Graph validation: missing endpoints, port direction, required inputs,
  cardinality, exact type/stream compatibility, duplicate identities and cycles.
- Deterministic schema-versioned project/workflow JSON; nested unknown fields
  preserved; duplicate JSON keys and unsupported versions rejected.
- Atomic project saves, writer locks, recovery autosave and terminal run history.
- Mock capability lowering into a deterministic plan; unsupported contracts fail.
- Typed versioned worker messages, bounded framing, local socket transport and
  inherited anonymous-pipe fallback; worker handshake, job submission, counted
  progress, heartbeat, graceful cancellation, escalation, crash detection/restart.
- Resource broker inventory and thread/memory admission accounting.
- Qt Quick shell: Explorer, draggable graph, typed connections, Inspector,
  Jobs/Validation/Logs, worker diagnostics, save/open and both mock graphs.
- CI configuration, developer/user docs, JSON schemas and seven required ADRs.

## Architecture

VPIR is canonical. The scientific core has no Qt dependency. Qt runtime owns
processes and transport; the UI never performs scientific computation. JSON
control messages are small metadata; there is no event-data JSON path. Historical
runs preserve workflow snapshots and provenance; future backends lower VPIR.

## Files / modules

`core/` — types, units, VPIR, graph, validation, compiler, project, run model.
`runtime/` — IPC, worker, coordinator, broker and atomic store.
`apps/desktop/` — C++ bridge and QML shell.
`sdk/schemas/`, `tests/`, `.github/workflows/`, `docs/`, `examples/`.

## Tests

Linux GCC 13.3, Qt 6.4.2, CMake 4.4.3, Debug with warnings as errors.
All three CTest suites passed (14 core cases, 8 runtime cases plus QtTest hooks,
and the desktop lifecycle test). An independent Qt-free core build/test also
passed. Final recorded evidence is in `docs/developer/test-results.txt`.

- 14 core cases: conversions, incompatible units, IDs, typing, graphs,
  transactional rejection, cycles, deterministic round trips, extensions,
  quantity parameters, run snapshots, schema rejection and mock lowering.
- 8 runtime cases: protocol round trips/ranges, broker budget, handshake and
  completion, cancellation/reuse, crash/restart, failed launch, atomic save/load,
  invalid graph rejection. QtTest also reports its init/cleanup hooks.
- Desktop smoke: actual QML load, completion, cancellation, deliberate worker
  kill, UI/coordinator survival, restart, another completion, and save/reopen
  with four preserved run records. Offscreen software rendering was used.

The test environment denies local socket creation; runtime tests exercise the
anonymous-pipe transport. Native socket operation awaits unrestricted CI.
The workspace also lost the worker's executable mode during file synchronization;
restoring +x on the locally built binary resolved launch failures. No permission
relaxation or shell-based launch was added to application code.

## Platform status

| Platform | Status |
| --- | --- |
| Ubuntu 24.04 x86-64 | Full source build and three test suites verified locally |
| Other Linux distributions | Portable source; not tested |
| Windows x86-64 | CI defined for hosted Windows Server 2022; not executed here |
| Windows 11 x86-64 | Opt-in self-hosted CI gate defined; runner not supplied |
| macOS Apple Silicon | CI defined for macos-14 / Qt universal clang_64; not executed here |

CI files are configuration, not evidence of passing remote runs. The Windows 11
gate requires `HEP_WINDOWS11_RUNNER=true` and a runner labeled `hep-windows11`
with the toolchain installed. No remote repository or runner was provisioned.

## Known limitations

- No scientific backend integration or physics algorithms. Mocks only validate
  contracts and exercise lifecycle; completion contains zero scientific outputs.
- No packaged Windows/macOS installers, app signing, WSL appliance, or remote jobs.
- One active job and one displayed workflow per project. Additional workflows
  are preserved but lack an editor selector.
- No undo/redo, zoom, expression builder or user-editable parameter forms yet.
- Schemas are versioned but have no migration implementation; future versions
  fail closed. No silent environment upgrade.
- Runs are append-only by application behavior, not a tamper-proof ledger.
- Mock runs record a seed but use no RNG. Scientific seed derivation, weights,
  covariance and systematics are not implemented.
- Broker reservations are process-local accounting, not enforced OS memory
  limits, multi-instance arbitration, GPU scheduling or container quota handling.
- Unknown GPU/NUMA/P-E topology/storage is reported as undetected.

## Risks / rough edges

- Split scientific identity from presentation before adding result caching.
  Moving a node currently changes the snapshot hash and staleness indicator.
- Add compatibility negotiation and schema/code consistency gates before a
  public SDK. The current strict protocol-version match is only a foundation.
- Bound embedded history with separate immutable result storage before large
  analyses; Phase 0 caps projects at 16 MiB and messages at 1 MiB.
- Provide hardened plugin sandboxing before executing third-party code.
- Verify native file dialogs, HiDPI, accessibility, Windows named pipes and
  cancellation on real desktop hosts; offscreen Linux is not a substitute.
- Choose a project release license and review dependency notices before shipping
  binary distributions. This archive contains source and no Qt runtime bundle.

## Next tasks, in dependency order

1. Run the existing CI on Windows and Apple Silicon, then the Windows 11 gate.
2. Exercise socket transport, cancellation escalation and recovery on native hosts.
3. Add workflow switching and undo/redo without changing scientific semantics.
4. Introduce a scientific-only hash and formal environment/input provenance.
5. Finalize Phase 1 ROOT capability and dataset/column schema contracts.
6. Implement isolated ROOT file inspection with bounded previews.
7. Lower supported Filter/Define/histogram graphs into one RDataFrame event loop.
8. Add golden ROOT results, generated-code inspection and publication provenance.

Phase 1 has not been started in this delivery.
