# Part 4 closure: controlled Part 3 Release replay

CPU: AMD EPYC 9V74 80-Core Processor; Release; 16,384 events per case; 1/2/4/7 workers.
Seed 1, project seed 42, logical-blocks-v2, 2,048 events per block. Both engines use the same installed SDK/compiler/Python and CPU quota.

The preserved Part 3 source and current Part 4 source execute the unchanged original benchmark scripts and collider example. The historical Intel host was unavailable, so no cross-hardware regression claim is made.

| Case | Workers | Part 3 events/s | Part 4 events/s | Wall change | CPU % | Peak RSS MiB | Merge ms | Control KiB |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| generation | 1 | 169.6 | 168.4 | +0.69% | 99.8 | 465.5 | 14.16 | 671.4 |
| generation | 2 | 337.6 | 339.6 | -0.59% | 199.0 | 699.6 | 14.10 | 669.7 |
| generation | 4 | 667.5 | 668.0 | -0.06% | 391.6 | 1165.4 | 12.04 | 670.1 |
| generation | 7 | 667.3 | 681.5 | -2.08% | 399.7 | 1866.7 | 12.11 | 670.3 |
| generation-fastjet | 1 | 162.3 | 163.4 | -0.66% | 99.7 | 467.7 | 14.96 | 758.9 |
| generation-fastjet | 2 | 323.1 | 322.3 | +0.27% | 198.6 | 700.9 | 15.06 | 760.1 |
| generation-fastjet | 4 | 624.9 | 635.7 | -1.70% | 394.2 | 1166.2 | 13.61 | 761.3 |
| generation-fastjet | 7 | 647.9 | 640.4 | +1.18% | 396.0 | 1865.8 | 13.80 | 760.8 |
| full-histogram | 1 | 161.2 | 162.0 | -0.48% | 99.8 | 467.6 | 14.42 | 775.5 |
| full-histogram | 2 | 320.7 | 322.8 | -0.68% | 198.7 | 704.4 | 15.36 | 775.7 |
| full-histogram | 4 | 638.2 | 638.2 | +0.00% | 395.8 | 1169.3 | 13.88 | 777.0 |
| full-histogram | 7 | 650.4 | 644.7 | +0.88% | 404.8 | 1877.4 | 14.41 | 778.4 |
| full-persisted | 1 | 108.4 | 109.1 | -0.65% | 99.9 | 467.5 | 13.91 | 842.5 |
| full-persisted | 2 | 211.7 | 210.3 | +0.64% | 195.6 | 705.1 | 14.94 | 846.9 |
| full-persisted | 4 | 403.0 | 410.4 | -1.78% | 378.7 | 1179.8 | 13.68 | 844.6 |
| full-persisted | 7 | 398.5 | 414.2 | -3.79% | 386.3 | 1885.4 | 14.48 | 847.1 |

Median wall-time change: -0.54%; individual changes range from -3.79% to +1.18%.
These are single trials, not a confidence interval. Positive values mean slower Part 4 wall time. The full JSON reports retain startup/setup, CPU, memory, environment fingerprints and physical output sizes.
100% CPU means one occupied CPU. RSS includes shared pages more than once; 50 ms sampling can miss short-lived peaks. Baseline PSS is retained, but the Part 4 sampler returned zero PSS, which is unavailable rather than zero physical memory. Eight workers are rejected to preserve the UI CPU. Eight fixed logical blocks explain the four/seven-worker plateau.
Persisted HepMC cases write approximately 3.5 GiB as deterministic shards, without serial eager merging or bulk event IPC. This is disk output, not GUI transfer.
No build or regression jobs ran alongside the measurements. Routine status queries and requested three-minute source checkpoints remained active. A launcher invoked without its SDK environment exited before admission; its separate diagnostic log contains no benchmark row.
Windows/WSL storage/control overhead and macOS performance remain UNVERIFIED.
