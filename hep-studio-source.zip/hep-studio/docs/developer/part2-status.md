# HEP Studio — Part 2: ROOT Studio Core

Part 2 implementation is complete for the initial 1D visual analysis workflow.
Final source verification is recorded below. The original master specification
is preserved verbatim in `docs/MASTER_SPECIFICATION.txt` and remains authoritative.
Phase 0 foundations and mock lifecycle tests were retained. No later-part physics
backends, ML, HPC, marketplace or cloud collaboration were started.

## Implemented

- Worker transport hardening: bounded frames, incomplete-message deadlines,
  authenticated mock handshake, progress, cancellation, shutdown, crash/restart,
  and explicit native-socket/pipe selection. ROOT has its own isolated persistent
  worker with private framed pipes, heartbeats, bounded waits and kill fallback.
- Multiple workflows, switching, rename, duplication, confirmed deletion and
  persisted active workflow. Dataset references are shared at Project scope.
- Per-workflow command undo/redo for node/edge create/delete, movement, parameter
  and scientific configuration edits. Runs and execution are not undoable.
- Independent scientific/layout hashes and ancestor-aware stale propagation.
  Presentation changes do not rerun or invalidate science.
- Optional real ROOT detection (version, interpreter and runtime location).
  No ROOT linkage in UI or core; no synthetic replacement when ROOT is absent.
- TFile/directory/key browser, TTree/RNTuple schema, original/core types, nested
  paths, entry counts and explicit units. Stored 1D histogram inspection.
- Async virtualized PREVIEW with configurable bounded rows; indexed TTree and
  RNTuple access. Preview creates no scientific Run.
- Structured visual AST editor, pT preset, unit/type inference, Define and nested
  AND/OR/NOT filters. Numeric expressions promote operands to Float64.
- Lazy RDataFrame Source/Define/Filter/Count/Mean/Sum/Min/Max/Histo1D; tested adapter
  Histo2D. Shared actions are booked before execution and share an event loop.
- Fixed/explicit histogram edges, weights, flow handling and normalization.
- Native step/bar plots, points/error bars, axes/labels, legend, statistics,
  zoom/pan, log/linear Y, presentation settings, PNG/PDF export.
- ROOT Gaussian/exponential/polynomial fits with initial values, enforced bounds,
  fit range, parameters/errors, covariance, goodness of fit and explicit failure
  diagnostics. Poor model adequacy is distinct from minimizer convergence.
- Immutable ROOT Runs: snapshot, scientific hash/revision, input identity and
  hashing strategy, ASTs/cuts/configurations, environment/backend, timing,
  resources, diagnostics and embedded result records.
- Compatible histogram overlays, configuration differences, full provenance and
  informational/exportable equivalent PyROOT.
- Save/reopen and recovery preserve graphs, units, expressions, references,
  layout/presentation and Runs/results. Missing/changed datasets are explicit;
  relinking refreshes current state without rewriting historical provenance.

## Tests and platform status

- Linux x86_64 / Ubuntu 24.04, GCC 13.3, Qt 6.4.2: Debug build with warnings as
  errors succeeds. ROOT 6.40.00 was executed, not simulated.
- Six CTest suites: core, analysis-core, root-backend, runtime,
  studio-integration, desktop-smoke. Raw final log: `docs/developer/test-results.txt`.
- 12 real ROOT regression cases cover known pT/filter/histogram values, one
  shared loop, TTree/RNTuple metadata/preview, Gaussian/exponential/polynomial
  fitting, enforced bounds, failure status, integer arithmetic promotion,
  weights/normalization/flows/Histo2D and input-change detection.
- Desktop integration exercises the full scientific sequence, save/reload,
  stale edits, immutable history, comparison, export, crash/restart, cancellation
  and relinking. Actual QML Define/Filter dialogs are opened and accepted in tests.
- Qt-free core build/tests pass. Without ROOT, core/GUI remain usable; ROOT tests
  explicitly skip and capability is unavailable.
- Native listening sockets are prohibited here: that test explicitly skips.
  Inherited-pipe lifecycle, fragmented/malformed messages, bad authentication,
  incomplete frames and startup timeout are tested. Native socket verification
  remains a CI/other-host gate; it is not claimed locally.
- Windows/macOS CI remains configured. Linux CI now installs an optional pinned
  ROOT development runtime. Remote CI was not run; Windows/macOS are UNVERIFIED.
  No Windows 11 or Apple Silicon native build is claimed.

## Performance

One-million-row deterministic TTree, one scientific thread. File inspection,
schema, preview, histogram/aggregates, event throughput and peak RSS are measured
in `docs/developer/root-benchmark.json`; methodology/results are in
`docs/developer/performance.md`. Actions share one event loop. Timings exclude
IPC and are not representative of arbitrary production HEP datasets.

## Known limitations

- Developer source handoff, not a signed/self-contained installer. PyROOT must be
  provisioned separately. The verified PyPI ROOT 0.1a12 distribution identifies
  itself as alpha; production deployment needs an appropriate ROOT environment.
- One source per workflow and one scientific thread. ROOT API compatibility was
  exercised on 6.40.00; older RNTuple Python interfaces may be unavailable.
- Visual histogram editing/rendering is 1D. Histo2D is adapter-only. Snapshot,
  ratio panels and SVG export were optional and deferred. PNG/PDF export works.
- Fits use bin-center chi-square; likelihood fits, full statistical inference
  and systematic uncertainty propagation belong to later scope.
- Expressions use Float64 numeric arithmetic; integer identity calculations above
  2^53 are not exact. Opaque record operations/collection transforms are not
  supported; known nested numeric leaves and constant indexing are supported.
- Preview caps: 500 rows, 32 selected columns (12 in the initial UI), 16 displayed
  collection elements. An individual ROOT entry may still contain large payloads.
- Project/result cap 16 MiB, IPC cap 1 MiB, 4096 1D bins, 65,536 2D cells, 1000
  ROOT plan nodes. Large external result storage/caching is not implemented.
- Large files use sampled first/last-block hashing plus size/mtime; this is not a
  proof of byte identity for every interior change. The strategy is recorded.
- Native cancellation may terminate the worker and require restart. Resource
  reservations are admission accounting, not enforced memory limits.
- Undo history and interactive plot zoom/pan are session-local. Other plot
  presentation controls persist. Results remain embedded immutable Run records.
- Headless QML and API integration tests do not replace interactive usability QA
  on all supported operating systems. Native socket behavior remains unverified
  in this restricted environment.

## Architectural changes and continuation

Existing architecture documents were updated in place. ADR-008 covers commands
and scientific/layout identity, ADR-009 the optional isolated ROOT worker, and
ADR-010 structured ASTs and neutral result/plot data. The expression schema is
in `sdk/schemas/expression-v1.schema.json`.

Continue directly from this repository for Part 3. Read this file, README,
`docs/MASTER_SPECIFICATION.txt`, architecture docs and ADRs first. Preserve the
ROOT/core/GUI separation and the regression fixtures. Resolve any real CI
failures on target platforms when results become available. Later-part features
have not been preimplemented. Historical Phase 0 verification is retained in
`docs/developer/phase0-status.md`; it does not describe current capabilities.
