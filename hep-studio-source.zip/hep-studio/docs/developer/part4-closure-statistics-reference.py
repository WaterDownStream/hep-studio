# Standalone PyROOT reference: immutable template arrays and explicit assumptions.
# VPIR remains canonical. Use the recorded ROOT version/environment for comparison.
import array,copy,hashlib,json,math,re,types,uuid
import ROOT
ROOT.gROOT.SetBatch(True)
FIT_HELPER=False
ROOT.EnableThreadSafety()
def key(value):return hashlib.sha256(json.dumps(value,sort_keys=True,separators=(",",":"),allow_nan=False).encode()).hexdigest()
def check_cancel(cancel):pass
def fit_native(pdf,data,options,ROOT):
    global FIT_HELPER
    if not FIT_HELPER:
        if not ROOT.gInterpreter.Declare('''
#include <RooAbsPdf.h>
#include <RooFitResult.h>
#include <RooLinkedList.h>
#include <memory>
namespace hep_research_stats {
RooFitResult* own(RooFitResult* p){return p;}
RooFitResult* own(std::unique_ptr<RooFitResult> p){return p.release();}
RooFitResult* fit(RooAbsPdf& p,RooAbsData& d,const RooLinkedList& c){return own(p.fitTo(d,c));}
}
'''):raise RuntimeError('RooFit worker helper compilation failed')
        ROOT.hep_research_stats.fit.__release_gil__=True;FIT_HELPER=True
    commands=ROOT.RooLinkedList()
    for option in options:commands.Add(option)
    result=ROOT.hep_research_stats.fit(pdf,data,commands)
    if result:ROOT.SetOwnership(result,True)
    return result

statistical=types.SimpleNamespace(fit_native=fit_native)
def _name(value):
    if not isinstance(value,str) or not re.fullmatch(r'[A-Za-z][A-Za-z0-9_]{0,63}',value):
        raise ValueError('Statistical identities require 1..64 ASCII letters, digits or underscores, starting with a letter')
    return value


def _validate_hist(h,edges=None,observed=False):
    if h.get('kind')!='Histogram1D' or h.get('normalization')!='counts':
        raise ValueError('Likelihood templates require absolute Histogram1D counts')
    v=h['values'];e=h['errors'];b=h['edges']
    if not 1<=len(v)<=4096 or len(e)!=len(v) or len(b)!=len(v)+1:
        raise ValueError('Incompatible statistical template shape')
    if any(not math.isfinite(float(x)) for x in b+v+e) or any(x<0 for x in v+e) or any(a>=c for a,c in zip(b,b[1:])):
        raise ValueError('Templates require finite nonnegative values/errors and increasing edges')
    if edges is not None and b!=edges:raise ValueError('Nominal/systematic template binning differs')
    if observed and any(abs(x-round(x))>1e-8 or not math.isclose(s*s,x,rel_tol=1e-6,abs_tol=1e-8) for x,s in zip(v,e)):
        raise ValueError('Observed templates must contain integer Poisson counts with counting variances')
    return copy.deepcopy(h)


def template_set(config,inputs):
    samples=config.get('samples',[])
    if not 2<=len(samples)<=16:raise ValueError('Choose signal and background templates (at most 16 samples)')
    result=[];identities=set();references=set();channels={}
    explicit_channels=any('channel' in spec for spec in samples)
    for spec in samples:
        identity=_name(spec['id']);role=spec['role'];ref=spec['reference']
        if identity in identities or role not in ('signal','background','observed'):raise ValueError('Duplicate sample identity or unsupported role')
        identities.add(identity);rid=ref['runId']+'/'+ref['nodeId']
        if rid in references:raise ValueError('One immutable histogram cannot silently be counted as two independent samples')
        references.add(rid);row=inputs[rid]
        if row.get('runStatus')!='Completed' or row.get('runValid') is not True:raise ValueError('Template input Run is incomplete or invalid')
        if ref.get('inputIdentity') and ref['inputIdentity']!=row.get('inputIdentity'):raise ValueError('Immutable input histogram identity differs')
        if not row.get('inputIdentity'):raise ValueError('Template input identity is missing')
        channel=_name(spec.get('channel','analysis'))
        if channel not in channels:
            if len(channels)>=8:raise ValueError('At most eight explicit analysis channels')
            channels[channel]={'id':channel,'edges':None,'dimension':None,'sampleIds':[]}
        category=channels[channel]
        h=_validate_hist(row['histogram'],category['edges'],role=='observed')
        if role!='observed' and h.get('yieldMode')!='luminosity' and spec.get('interpretation')!='expected-event-counts':
            raise ValueError('Signal/background must be expected event yields; raw MC weights or cross sections are not Poisson expectations')
        current=h.get('dimension',[])
        if category['edges'] is not None and current!=category['dimension']:raise ValueError('Template observable physical dimensions differ within one channel')
        category.update(edges=h['edges'],dimension=current);category['sampleIds'].append(identity)
        item={'id':identity,'role':role,'reference':copy.deepcopy(ref),'inputIdentity':row['inputIdentity'],'histogram':h,'systematics':copy.deepcopy(row.get('systematics',{})),'sourceRun':copy.deepcopy(row.get('sourceRun',{}))}
        if explicit_channels:item['channel']=channel
        result.append(item)
    if not any(s['role']=='signal' for s in result):raise ValueError('Require at least one signal sample')
    for category in channels.values():
        members=[s for s in result if s['id'] in category['sampleIds']]
        if not any(s['role']=='background' for s in members) or sum(s['role']=='observed' for s in members)>1:
            raise ValueError('Every channel requires background and at most one observed sample')
    if len(channels)>1 and config.get('channelIndependence')!='disjoint-event-categories':
        raise ValueError('Combined Poisson channels require an explicit disjoint-event-categories assumption; histogram arrays cannot establish event independence')
    if explicit_channels:
        return {'kind':'HistogramSet','version':2,'samples':result,'channels':list(channels.values()),
                'channelIndependence':config.get('channelIndependence','single-channel'),'flowPolicy':config['flowPolicy'],
                'identity':key({'samples':result,'channelIndependence':config.get('channelIndependence','single-channel')})}
    category=channels['analysis']
    # Preserve the exact legacy one-channel representation and input identity.
    return {'kind':'HistogramSet','version':1,'samples':result,'edges':category['edges'],'dimension':category['dimension'],
            'flowPolicy':config['flowPolicy'],'identity':key(result)}


def _hist(h,ROOT):
    # Zero observed bins (including an empty observed dataset) are legitimate.
    import array,uuid
    out=ROOT.TH1D('template_'+uuid.uuid4().hex,'',len(h['values']),array.array('d',h['edges']));out.SetDirectory(0);out.Sumw2()
    for i,(v,e) in enumerate(zip(h['values'],h['errors']),1):out.SetBinContent(i,v);out.SetBinError(i,e)
    return out


def likelihood(histograms,config,root):
    ROOT=root.ROOT;HF=ROOT.RooStats.HistFactory;samples=histograms['samples']
    categories=histograms.get('channels',[{'id':'analysis','edges':histograms.get('edges'),
        'dimension':histograms.get('dimension'),'sampleIds':[s['id'] for s in samples]}])
    if sum(len(c['edges'])-1 for c in categories)>256:raise ValueError('Template likelihood supports at most 256 fitted bins across all channels; rebin explicitly upstream')
    if histograms['flowPolicy']!='exclude-unfolded-flows':raise ValueError('Fold flows upstream, or explicitly exclude unfolded flow bins')
    role=config['datasetRole'];maximum=float(config['muMax']);mc=config['mcStat']
    if role not in ('background-asimov','observed-counts') or not math.isfinite(maximum) or maximum<=1:
        raise ValueError('Choose dataset role and a signal-strength range containing mu=1')
    if mc not in ('none','poisson-gamma') or config['interpolation']!='histfactory-default':raise ValueError('Choose explicit MC-statistics and HistFactory interpolation policies')
    if mc=='poisson-gamma' and config.get('mcStatAssumption')!='independent-effective-counts':
        raise ValueError('MC-statistics gamma constraints require explicit independent-effective-counts assumption')
    channel_metadata=[];signal=[];background=[]
    for category in categories:
        members=[s for s in samples if s['id'] in category['sampleIds']]
        expected=lambda r:[sum(s['histogram']['values'][i] for s in members if s['role']==r) for i in range(len(category['edges'])-1)]
        cs=expected('signal');cb=expected('background');signal.extend(cs);background.extend(cb)
        channel_metadata.append({**copy.deepcopy(category),'expectedSignal':cs,'expectedBackground':cb})
    if sum(signal)<=0 or any(v<=0 for v in background):raise ValueError('This likelihood subset requires nonzero signal and positive expected background in every fitted bin')
    known={s['id'] for s in samples if s['role']!='observed'};bindings=set();nuisances=config['nuisances']
    if len(nuisances)>64:raise ValueError('At most 64 explicit nuisance descriptors')
    for n in nuisances:
        group=_name(n['correlationGroup']);targets=n['samples']
        if not targets or len(set(targets))!=len(targets) or not set(targets)<=known:raise ValueError('Nuisance sample binding is unknown, duplicate or empty')
        if n.get('constraint')!='gaussian-standard-normal' or n.get('variationMeaning')!='minus-plus-one-sigma':raise ValueError('An explicit Gaussian auxiliary constraint and minus/plus one-sigma meaning are required')
        if n['kind'] not in ('normalization','shape'):raise ValueError('Unsupported explicit template nuisance')
        for target in targets:
            binding=(target,group)
            if binding in bindings:raise ValueError('Duplicate nuisance group for one sample; combine its declared effect explicitly')
            bindings.add(binding)
    measurement=HF.Measurement('measurement','Explicit HEP Studio template model');measurement.SetPOI('mu');measurement.SetLumi(1.);measurement.AddConstantParam('Lumi')
    owners=[measurement]
    for category in channel_metadata:
        channel=HF.Channel(category['id']);channel.SetStatErrorConfig(0.,'Poisson');owners.append(channel)
        edges=category['edges'];members=[s for s in samples if s['id'] in category['sampleIds']]
        if role=='observed-counts':
            observed=[s for s in members if s['role']=='observed']
            if len(observed)!=1:raise ValueError('Observed inference requires an identified observed-count histogram in every channel')
            data_hist=observed[0]['histogram']
        else:data_hist={'edges':edges,'values':category['expectedBackground'],'errors':[math.sqrt(v) for v in category['expectedBackground']]}
        data=_hist(data_hist,ROOT);channel.SetData(data);ROOT.SetOwnership(data,False);owners.append(data)
        for source in members:
            if source['role']=='observed':continue
            sample=HF.Sample(source['id']);sample.SetNormalizeByTheory(False);h=_hist(source['histogram'],ROOT)
            sample.SetHisto(h);ROOT.SetOwnership(h,False);owners.extend([sample,h])
            if source['role']=='signal':sample.AddNormFactor('mu',1.,0.,maximum)
            if mc=='poisson-gamma':sample.ActivateStatError()
            for n in nuisances:
                if source['id'] not in n['samples']:continue
                group=n['correlationGroup']
                if n['kind']=='normalization':
                    low=float(n['down']);high=float(n['up'])
                    if not math.isfinite(low+high) or not 0<low<=1<=high or low==high:raise ValueError('Normalization endpoints must positively bracket the nominal scale')
                    sample.AddOverallSys(group,low,high)
                else:
                    variations=source['systematics']['templates'][n['systematicId']]['variations'];node=source['reference']['nodeId']
                    def variation(label):
                        matches=[v['results'][node] for v in variations if v['label']==label and node in v['results'] and v.get('valid',True)]
                        if len(matches)!=1:raise ValueError('Missing/ambiguous systematic histogram endpoint')
                        h=_validate_hist(matches[0],edges)
                        if h.get('yieldMode')!=source['histogram'].get('yieldMode') or h.get('dimension',[])!=category['dimension']:raise ValueError('Systematic template units/yield convention differs from nominal')
                        if sum(h['values'])<=0:raise ValueError('Systematic template has zero expected integral')
                        return _hist(h,ROOT)
                    low=variation(n['downLabel']);high=variation(n['upLabel']);systematic=HF.HistoSys();systematic.SetName(group)
                    systematic.SetHistoLow(low);ROOT.SetOwnership(low,False);systematic.SetHistoHigh(high);ROOT.SetOwnership(high,False)
                    sample.AddHistoSys(systematic);owners.extend([low,high,systematic])
            channel.AddSample(sample)
        measurement.AddChannel(channel)
    workspace=HF.HistoToWorkspaceFactoryFast.MakeCombinedModel(measurement)
    if not workspace:raise RuntimeError('HistFactory did not produce a likelihood workspace')
    model=workspace.obj('ModelConfig');data=workspace.data('obsData');mu=workspace.var('mu')
    if not model or not data or not mu:raise RuntimeError('HistFactory workspace is missing a scientific contract')
    mu.setVal(1.);model.SetSnapshot(model.GetParametersOfInterest());background_model=model.Clone('background_only');mu.setVal(0.);background_model.SetSnapshot(model.GetParametersOfInterest());mu.setVal(1.)
    warnings=['Asymptotic sparse-bin/boundary coverage is unverified.','Shared correlation-group identities mean shared nuisance parameters.']
    warnings.append('Finite template MC uncertainty explicitly excluded.' if mc=='none' else 'Poisson gamma MC constraints assume independent effective counts; source-event independence is not established by histogram arrays.')
    if role=='background-asimov' and any(s['role']=='observed' for s in samples):warnings.append('Observed template is unused under explicitly selected background-Asimov role.')
    if len(categories)>1:warnings.append('Channel event categories explicitly assumed disjoint; independence is not established by histogram arrays.')
    metadata={'kind':'LikelihoodModel','backend':'ROOT-HistFactory','backendVersion':str(ROOT.gROOT.GetVersion()),'configuration':copy.deepcopy(config),
              'inputIdentity':histograms['identity'],'datasetRole':role,'expectedSignal':signal,'expectedBackground':background,
              'nuisanceParameters':[str(p.GetName()) for p in model.GetNuisanceParameters()] if model.GetNuisanceParameters() else [],
              'constraints':copy.deepcopy(nuisances),'warnings':warnings,'interpolation':'HistFactory version-default; backend version frozen'}
    if 'channels' in histograms:metadata.update(channels=channel_metadata,channelIndependence=histograms['channelIndependence'])
    metadata['identity']=key(metadata)
    return workspace,model,background_model,data,owners,metadata


def infer(native,config,root,cancel=None):
    check_cancel(cancel);ROOT=root.ROOT;workspace,model,background_model,data,owners,metadata=native
    if config.get('method')!='asymptotic-profile-likelihood' or config.get('testStatistic')!='one-sided-qmu' or config.get('useCLs') is not True:
        raise ValueError('Choose explicit asymptotic one-sided q_mu with CLs')
    level=float(config['confidenceLevel']);points=config['points'];maximum=float(metadata['configuration']['muMax'])
    if not .5<level<1 or type(points)!=int or not 10<=points<=200:raise ValueError('Invalid confidence level or scan size')
    options=[ROOT.RooFit.Save(True),ROOT.RooFit.PrintLevel(-1)]
    if model.GetGlobalObservables():options.append(ROOT.RooFit.GlobalObservables(model.GetGlobalObservables()))
    fit=statistical.fit_native(model.GetPdf(),data,options,ROOT);check_cancel(cancel)
    if not fit or int(fit.status())!=0 or int(fit.covQual())<2:raise RuntimeError('Template likelihood fit failed or covariance is unreliable; no valid limit is presented')
    ROOT.RooStats.AsymptoticCalculator.SetPrintLevel(-1)
    calculator=ROOT.RooStats.AsymptoticCalculator(data,background_model,model,True);calculator.SetOneSided(True)
    inverter=ROOT.RooStats.HypoTestInverter(calculator);inverter.SetConfidenceLevel(level);inverter.UseCLs(True);inverter.SetVerbose(False);inverter.SetFixedScan(points,0.,maximum)
    ROOT.RooStats.HypoTestInverter.GetInterval.__release_gil__=True
    interval=inverter.GetInterval();check_cancel(cancel)
    if not interval:raise RuntimeError('RooStats template hypothesis calculation failed')
    upper=float(interval.UpperLimit());curve=[{'mu':float(interval.GetXValue(i)),'CLs':float(interval.GetResult(i).CLs())} for i in range(interval.ArraySize())]
    # RooStats returns CLs=-1 when CLb underflows. Finite is insufficient:
    # those failed scan points must never make a published limit look valid.
    invalid_points=[p for p in curve if not math.isfinite(p['CLs']) or p['CLs']<0 or p['CLs']>1+1e-6]
    valid=math.isfinite(upper) and 0<upper<maximum and bool(curve) and not invalid_points and curve[-1]['CLs']<1-level
    parameters=[{'name':str(p.GetName()),'value':float(p.getVal()),'error':float(p.getError())} for p in fit.floatParsFinal()]
    covariance=[[float(fit.covarianceMatrix()[i][j]) for j in range(len(parameters))] for i in range(len(parameters))]
    warnings=list(metadata['warnings'])
    if invalid_points:warnings.append('RooStats returned invalid CLs values at '+str(len(invalid_points))+' scan points; the limit is invalid. Narrow the POI range or inspect the numerical diagnostics.')
    if not valid:warnings.append('POI scan does not bracket a reliable limit; extend its range.')
    return {'kind':'HypothesisResult','backend':'RooStats-HistFactory','backendVersion':str(ROOT.gROOT.GetVersion()),'valid':valid,
            'upperLimit':upper,'expectedMedianLimit':float(interval.GetExpectedUpperLimit(0)),'expectedLimits':{str(k):float(interval.GetExpectedUpperLimit(k)) for k in (-2,-1,0,1,2)},
            'scan':curve,'configuration':copy.deepcopy(config),'model':metadata,'modelIdentity':metadata['identity'],'datasetRole':metadata['datasetRole'],
            'parameterOfInterest':'mu','fitStatus':int(fit.status()),'covarianceStatus':int(fit.covQual()),'parameters':parameters,'covariance':covariance,'warnings':warnings}

plan=json.loads('{"backend": "hep.research/1", "nodes": [{"config": {"flowPolicy": "exclude-unfolded-flows", "samples": [{"id": "signal", "reference": {"inputIdentity": "c5d46543bde37d273a1d2724a0342322b5d2f9c7a24e028d7091b9cb6652a5f6", "nodeId": "example-background-7", "runId": "closure-signal"}, "role": "signal"}, {"id": "background", "reference": {"inputIdentity": "a86a0e9457756e1bf9e4e9eeac5e7ee0208aba6d617b41ea4e34027c5f8ca9ec", "nodeId": "example-signal-7", "runId": "closure-background"}, "role": "background"}]}, "id": "example-model-0", "kind": "TemplateSet"}, {"config": {"datasetRole": "background-asimov", "interpolation": "histfactory-default", "mcStat": "poisson-gamma", "mcStatAssumption": "independent-effective-counts", "muMax": 2.0, "nuisances": [{"constraint": "gaussian-standard-normal", "correlationGroup": "closure_luminosity", "downLabel": "down", "kind": "shape", "samples": ["signal", "background"], "systematicId": "closure_luminosity", "upLabel": "up", "variationMeaning": "minus-plus-one-sigma"}]}, "id": "example-model-1", "input": "example-model-0", "kind": "BinnedLikelihood"}, {"config": {"confidenceLevel": 0.95, "method": "asymptotic-profile-likelihood", "points": 200, "testStatistic": "one-sided-qmu", "useCLs": true}, "id": "example-model-2", "input": "example-model-1", "kind": "Inference"}], "requiredLibraries": ["HistFactory", "ROOT", "RooFit", "RooStats"], "requiredThreads": 1, "version": 1}')
inputs=json.loads('{"closure-background/example-signal-7": {"histogram": {"dimension": [1, 0, 0, 0], "edges": [0.0, 120.0], "entries": 9.0, "errors": [0.27838800430297833], "flowPolicy": "separate", "kind": "Histogram1D", "mean": 43.22473924372629, "normalization": "counts", "overflow": 0.0, "overflowError": 0.0, "rms": 9.326308952786267, "statistics": [0.8351640129089349, 0.07749988093979507, 36.09974668373277, 1633.0447353182412], "sumWeights": 0.8351640129089349, "sumWeightsSquared": 0.07749988093979507, "title": "", "underflow": 0.0, "underflowError": 0.0, "values": [0.8351640129089349], "yieldMode": "luminosity"}, "inputIdentity": "a86a0e9457756e1bf9e4e9eeac5e7ee0208aba6d617b41ea4e34027c5f8ca9ec", "runStatus": "Completed", "runValid": true, "sourceRun": {"backend": "hep.research/1", "ended": "2026-10-04T04:17:38.803208+00:00", "environmentId": "hep-env://research/795a41999fd4735e235b49ec", "id": "closure-background", "seed": "42", "started": "2026-10-04T04:17:26.150674+00:00", "workflowScientificHash": "7336303be291162a70f0b0d762b6f7e7c233fc0e879d9469ceccb53b3532a10d"}, "systematics": {"combination": "None: per-variation templates only. No prior or correlation combination is inferred.", "nominalIdentity": "7336303be291162a70f0b0d762b6f7e7c233fc0e879d9469ceccb53b3532a10d", "templates": {"closure_luminosity": {"descriptor": {"affectedNodes": ["example-signal-7"], "correlation": {"group": "closure_luminosity"}, "id": "closure_luminosity", "interpretation": "Explicit Gaussian auxiliary constraint; endpoints are minus/plus one sigma, not a prior inferred from labels.", "kind": "normalization", "name": "Explicit two-percent luminosity endpoints", "nominal": 1.0, "variations": [{"factor": 0.98, "label": "down"}, {"factor": 1.02, "label": "up"}]}, "variations": [{"identity": "33c7b56c5b5148348d2b2a789f066b6ace28c90df25732cfcfa38cb28dedb45a", "label": "down", "results": {"example-signal-7": {"dimension": [1, 0, 0, 0], "edges": [0.0, 120.0], "entries": 9.0, "errors": [0.27282024421691875], "flowPolicy": "separate", "kind": "Histogram1D", "mean": 43.22473924372629, "normalization": "counts", "overflow": 0.0, "overflowError": 0.0, "rms": 9.326308952786267, "statistics": [0.8184607326507563, 0.07443088565457917, 35.37775175005811, 1600.3838406118764], "sumWeights": 0.8184607326507563, "sumWeightsSquared": 0.07443088565457918, "title": "", "underflow": 0.0, "underflowError": 0.0, "values": [0.8184607326507563], "yieldMode": "luminosity"}}, "stageReuse": [{"id": "example-signal-0", "reused": true}, {"id": "example-signal-1", "reused": true}, {"id": "example-signal-2", "reused": true}], "valid": true}, {"identity": "953b25604083e6f5168258fb5e8286cf7bcdd706f4a4d4e8594c646ade3f9ee9", "label": "up", "results": {"example-signal-7": {"dimension": [1, 0, 0, 0], "edges": [0.0, 120.0], "entries": 9.0, "errors": [0.2839557643890379], "flowPolicy": "separate", "kind": "Histogram1D", "mean": 43.22473924372629, "normalization": "counts", "overflow": 0.0, "overflowError": 0.0, "rms": 9.326308952786267, "statistics": [0.8518672931671136, 0.08063087612976279, 36.821741617407426, 1665.705630024606], "sumWeights": 0.8518672931671136, "sumWeightsSquared": 0.08063087612976279, "title": "", "underflow": 0.0, "underflowError": 0.0, "values": [0.8518672931671136], "yieldMode": "luminosity"}}, "stageReuse": [{"id": "example-signal-0", "reused": true}, {"id": "example-signal-1", "reused": true}, {"id": "example-signal-2", "reused": true}], "valid": true}]}}, "version": 1}}, "closure-signal/example-background-7": {"histogram": {"dimension": [1, 0, 0, 0], "edges": [0.0, 120.0], "entries": 851.0, "errors": [2.7131329341609574], "flowPolicy": "separate", "kind": "Histogram1D", "mean": 100.02088591863905, "normalization": "counts", "overflow": 0.0, "overflowError": 0.0, "rms": 1.0683063347171715, "statistics": [79.14725428581333, 7.361090318428847, 7916.378491694851, 791893.519060277], "sumWeights": 79.14725428581333, "sumWeightsSquared": 7.361090318428847, "title": "", "underflow": 0.0, "underflowError": 0.0, "values": [79.14725428581333], "yieldMode": "luminosity"}, "inputIdentity": "c5d46543bde37d273a1d2724a0342322b5d2f9c7a24e028d7091b9cb6652a5f6", "runStatus": "Completed", "runValid": true, "sourceRun": {"backend": "hep.research/1", "ended": "2026-10-04T04:17:26.150644+00:00", "environmentId": "hep-env://research/795a41999fd4735e235b49ec", "id": "closure-signal", "seed": "42", "started": "2026-10-04T04:17:11.206640+00:00", "workflowScientificHash": "40cc994446e0ab53f037a445e3bfba7691a3e287e4c60cd9478bb93fcbbc4d17"}, "systematics": {"combination": "None: per-variation templates only. No prior or correlation combination is inferred.", "nominalIdentity": "40cc994446e0ab53f037a445e3bfba7691a3e287e4c60cd9478bb93fcbbc4d17", "templates": {"closure_luminosity": {"descriptor": {"affectedNodes": ["example-background-7"], "correlation": {"group": "closure_luminosity"}, "id": "closure_luminosity", "interpretation": "Explicit Gaussian auxiliary constraint; endpoints are minus/plus one sigma, not a prior inferred from labels.", "kind": "normalization", "name": "Explicit two-percent luminosity endpoints", "nominal": 1.0, "variations": [{"factor": 0.98, "label": "down"}, {"factor": 1.02, "label": "up"}]}, "variations": [{"identity": "2305f4088dd329d16142226047f8184fb04bfabf0d722785ab465e73e7014742", "label": "down", "results": {"example-background-7": {"dimension": [1, 0, 0, 0], "edges": [0.0, 120.0], "entries": 851.0, "errors": [2.6588702754777382], "flowPolicy": "separate", "kind": "Histogram1D", "mean": 100.02088591863905, "normalization": "counts", "overflow": 0.0, "overflowError": 0.0, "rms": 1.0683063347171715, "statistics": [77.56430920009707, 7.069591141819064, 7758.050921860953, 776055.6486790715], "sumWeights": 77.56430920009707, "sumWeightsSquared": 7.069591141819064, "title": "", "underflow": 0.0, "underflowError": 0.0, "values": [77.56430920009707], "yieldMode": "luminosity"}}, "stageReuse": [{"id": "example-background-0", "reused": true}, {"id": "example-background-1", "reused": true}, {"id": "example-background-2", "reused": true}], "valid": true}, {"identity": "1b23d6c4b56de74dc392f3f2c0dab84733a4d5186f6963524e6347b198bbcab8", "label": "up", "results": {"example-background-7": {"dimension": [1, 0, 0, 0], "edges": [0.0, 120.0], "entries": 851.0, "errors": [2.7673955928441765], "flowPolicy": "separate", "kind": "Histogram1D", "mean": 100.02088591863905, "normalization": "counts", "overflow": 0.0, "overflowError": 0.0, "rms": 1.0683063347171715, "statistics": [80.7301993715296, 7.658478367293372, 8074.706061528748, 807731.3894414826], "sumWeights": 80.7301993715296, "sumWeightsSquared": 7.658478367293372, "title": "", "underflow": 0.0, "underflowError": 0.0, "values": [80.7301993715296], "yieldMode": "luminosity"}}, "stageReuse": [{"id": "example-background-0", "reused": true}, {"id": "example-background-1", "reused": true}, {"id": "example-background-2", "reused": true}], "valid": true}]}}, "version": 1}}}')
root=types.SimpleNamespace(ROOT=ROOT)
states={}
results={}
for node in plan['nodes']:
    kind=node['kind'];config=node['config'];nid=node['id']
    if kind=='TemplateSet':states[nid]=template_set(config,inputs);results[nid]=states[nid]
    elif kind=='BinnedLikelihood':states[nid]=likelihood(states[node['input']],config,root);results[nid]=states[nid][-1]
    elif kind=='Inference':results[nid]=infer(states[node['input']],config,root)
    else:raise ValueError('Unsupported template export node')
with open('reference-inference.json','w') as stream:json.dump(results,stream,indent=2,allow_nan=False)
