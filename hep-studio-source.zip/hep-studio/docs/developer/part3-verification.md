# Part 3 verification record

Historical pre-hardening evidence. Current stream/persistence semantics and tests:
`part3-hardening-validation.md`, STATUS.md and ADRs 020–022.

Linux is the only executed host platform. Actual scientific libraries:
PYTHIA 8.318, HepMC3 3.02.05, FastJet 3.5.1, ROOT 6.40.00, LHAPDF 6.5.6; CT14lo
member 0 data version 1. ROOT's PyPI distribution is alpha. No installed external
libraries or binaries are included in the source archive.

The scientific build passed all nine CTest suites in 55.90 seconds. The engine
uses the installed ROOT SDK's C++17 standard; core/VPIR stays C++23 through the
JSON lowering boundary.

A separate clean configuration with `HEP_BUILD_COLLIDER_ENGINE=OFF` and system
Python (no ROOT) compiled the core, runtime and desktop. Seven CTest suites
passed in 12.23 seconds; the ROOT/collider backend suites explicitly skipped.
GUI lifecycle and unavailable-capability handling still ran.

CTest covers the preserved Part 2 foundation plus collider graph contracts,
scientific/layout/seed hashing, resource relocation/placement, library detection,
manual-vector jet clustering, fixed-seed generation, preview, real PDF evaluation,
external PDFs, HepMC write/read/corruption, standalone generated C++ equivalence,
PDF installation policy, shared budgets, GUI workflow save/reload/staleness,
worker crash/restart/cancel and sample relinking/change detection. Missing external
libraries/sets are explicitly skipped, not passed as mocked science.

The native local-socket test is skipped when this host prohibits listeners;
private inherited pipes are exercised. WSL list/launch/health parsing is tested
with an explicitly labelled process fixture on Linux. This is not a Windows or
WSL end-to-end test. macOS/Windows CI definitions are retained; no remote CI
results are available in this workspace. No Docker/Podman is installed, so the
runtime image recipe has not been executed or imported.

Benchmark configuration and raw results are in collider-benchmark.json and its
case logs. One scientific thread; fresh process per case; Xeon Platinum 8573C, Debug build.
Wall time includes initialization; loop rate excludes initialization; RSS includes
libraries/Python. The figures are workload-specific, not a promise for another
CPU. Windows/WSL control/large-transfer timings are explicitly unmeasured.

Latest measurements (2026-09-26; this host only):

| Case | Events | Wall time | Loop rate | Peak RSS |
| --- | ---: | ---: | ---: | ---: |
| PYTHIA | 2,000 | 13.20 s | 156.3 events/s | 221.3 MiB |
| PYTHIA + FastJet | 2,000 | 14.18 s | 145.3 events/s | 221.0 MiB |
| Full histogram pipeline | 2,000 | 14.43 s | 142.6 events/s | 221.2 MiB |
| Preview | 10 | 2.11 s | 8.8 events/s | 311.8 MiB |
| HepMC write including generation | 100 | 1.61 s | 82.9 events/s | 220.7 MiB |
| HepMC read and analysis | 100 | 0.52 s | 213.5 events/s | 208.8 MiB |

HepMC write/read wall throughput: 13.50 / 41.89 MiB/s for a 22,757,359-byte
fixture. This does not isolate raw filesystem I/O. Bulk event transfer through
IPC remains zero; bounded inspection data is returned separately. No direct
backend-only throughput baseline has been measured, so negligible abstraction
overhead is an architectural objective, not a quantified result.

Parallel checkpoint: real two-process generation reproduces independently run
serial partitions and repeated same-environment results. Tests cover weighted
errors, flow folding and density normalization after reduction, Count/Mean/Sum/
Min/Max reduction, seed wrap, budget refusal, serial Preview, source hash
invalidation, exact planner budgets, child initialization failure/cancellation,
and Linux parent-death cleanup. The desktop Run/save/reload/comparison/crash test
uses two workers where at least three logical CPUs are available.

`collider-parallel-benchmark.json` records the same-host 2,000-event full pipeline:
one worker 13.818 s (144.74 events/s wall); two workers 7.736 s (258.53 events/s
wall), a 1.79× speedup. These Debug measurements include process startup and
initialization, and changing worker count changes the random sample. Summed
individual process peak RSS is an upper bound: 221.5 / 642.0 MiB, not simultaneous
peak RSS. The recorded environment hashes identify the exact measured adapter;
a subsequent handshake guard rejects changed child environments without altering
the native event loop. No Windows/macOS timing is inferred.

The final environment-handshake guard passed the collider-backend and desktop
integration suites (37.50 s); see part3-parallel-environment-test-results.txt.
