# Release collider benchmark evidence

CPU: INTEL(R) XEON(R) PLATINUM 8573C; exposed logical CPUs: 9; effective broker CPUs: 8; reported physical cores: 9 (virtualized topology); quota: 800000 100000.
Release; 16,384 requested events per case; master seed 1; logical-blocks-v2, 2048 events per stream.

Single trials on a shared VM; interrupted cases were resumed. CPU/load/frequency variation and the eight logical blocks limit scaling; no cross-hardware or negligible-overhead claim is made. The JSON retains each environment/version/hash and all raw timings.

| Case | Workers | Wall s | Events/s | Speedup | Efficiency | CPU %¹ | Peak PSS MiB | Merge ms | IPC KiB |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| generation | 1 | 171.68 | 95.4 | 1.00 | 100.0% | 100.0 | 260.5 | 18.12 | 767.1 |
| generation | 2 | 94.21 | 173.9 | 1.82 | 91.1% | 192.8 | 266.7 | 22.75 | 779.4 |
| generation | 4 | 56.28 | 291.1 | 3.05 | 76.3% | 353.1 | 368.7 | 16.05 | 799.5 |
| generation | 7 | 30.12 | 543.9 | 5.70 | 81.4% | 493.6 | 536.6 | 13.47 | 738.5 |
| generation-fastjet | 1 | 120.42 | 136.1 | 1.00 | 100.0% | 99.9 | 264.0 | 21.84 | 785.9 |
| generation-fastjet | 2 | 71.33 | 229.7 | 1.69 | 84.4% | 198.6 | 309.1 | 14.69 | 813.2 |
| generation-fastjet | 4 | 31.32 | 523.1 | 3.84 | 96.1% | 387.2 | 402.9 | 14.96 | 787.8 |
| generation-fastjet | 7 | 36.32 | 451.1 | 3.32 | 47.4% | 417.9 | 539.1 | 15.18 | 826.7 |
| full-histogram | 1 | 121.48 | 134.9 | 1.00 | 100.0% | 99.9 | 263.0 | 14.23 | 802.5 |
| full-histogram | 2 | 67.05 | 244.4 | 1.81 | 90.6% | 193.7 | 310.8 | 15.80 | 813.8 |
| full-histogram | 4 | 40.60 | 403.5 | 2.99 | 74.8% | 366.7 | 403.0 | 16.80 | 838.6 |
| full-histogram | 7 | 37.13 | 441.2 | 3.27 | 46.7% | 442.8 | 541.0 | 17.97 | 859.2 |
| full-persisted | 1 | 188.00 | 87.1 | 1.00 | 100.0% | 99.9 | 265.2 | 16.75 | 891.1 |
| full-persisted | 2 | 95.12 | 172.3 | 1.98 | 98.8% | 194.4 | 315.1 | 13.84 | 887.7 |
| full-persisted | 4 | 66.37 | 246.9 | 2.83 | 70.8% | 349.6 | 410.6 | 14.03 | 948.6 |
| full-persisted | 7 | 58.31 | 281.0 | 3.22 | 46.1% | 407.3 | 550.9 | 18.35 | 956.2 |

¹ 100% means one fully occupied CPU; sampled process-tree CPU time. RSS includes shared pages multiple times; PSS is reported separately. Sampling is every 50 ms and can miss short-lived peaks. Startup totals sum per-stream process overhead. Setup/initialization estimates and RSS are in JSON.

Completed 16/16 admitted cases. Eight workers are skipped because the eight-CPU effective quota reserves one CPU for the UI; seven is the largest admitted budget.

The recorded adapter predates a timing-only correction that includes sample manifest commit in the reported parallelWallSeconds and exposes sampleCommitSeconds. The table uses externally measured end-to-end wall time, which already includes commit; scientific execution is unchanged.

Windows/WSL control overhead, native-vs-mounted storage, large transfers, and macOS performance remain unmeasured. No platform inference is drawn from these Linux cases.
