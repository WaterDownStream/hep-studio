# Frozen Part 4 closure

**PART 4 COMPLETE.** Frozen release candidate: `part4-rc1`. Consolidated machine
evidence is `part4-closure.json`; the controlled benchmark comparison is
`part4-closure-performance.md`. Part 5 requires new authorization.

The 2026-10-04 scope freeze is authoritative. General UFO coverage, NLO generation
and matching/merging are explicitly deferred advanced collider features. They
are not completion blockers. Windows/WSL and macOS are **UNVERIFIED external
acceptance**, with their existing harnesses preserved. No Part 5 work is included.

## Scientific acceptance

`part4-closure-workflow.json` records two real, separately seeded 1,000-event
MadGraph samples, isolated PYTHIA showering, genuine Delphes CMS response,
reconstructed dimuon selection and expected-yield histograms. Each sample
materializes explicit 0.98/1.02 normalization templates with audited bins, errors
and sumw2. One shared, explicitly Gaussian luminosity effect binds those identified
endpoints through HistFactory HistoSys. There is no second luminosity constraint
counting the same effect twice. Poisson-gamma MC constraints retain their explicit
independent-effective-counts assumption. These are software references, not an
experimental analysis or a statistical coverage claim.

The complete project is `part4-closure-workflow.hep.json`. Native `saveProject` /
`loadProject` preserves all three workflows, all three immutable Runs, scientific
hashes, expression ASTs, systematics, environment descriptions and result references.
Equality is checked through two consecutive saves. The existing desktop regression
also checks example reopen, comparison, graph editing, stale propagation and plots.

The two-axis scan varies signal-strength range and confidence level. Two points
complete; the third genuinely fails because its range excludes mu=1; cancellation
leaves the fourth missing. Recovery checks the committed checksums and frozen
environment. Neither failed nor missing results become valid scientific points.
The scan is honestly labelled **interrupted**, not completed. Existing native
two-axis plot acceptance additionally verifies the displayed state distinctions.

`part4-closure-statistics-reference.py` is independently executable with the recorded
ROOT/PyROOT SDK and no HEP Studio imports or GUI. It embeds identified compact
templates and explicit assumptions. Its CLs scan and limits match worker output
exactly in this environment; the test tolerance is 1e-8. The complete regression
also executes standalone reconstructed ROOT/RooFit/RooStats exports and verifies
their input checksums and numerical results.

A real wide-range scan exposed RooStats CLb underflow returning CLs=-1. Closure
fixes the existing validity predicate to reject negative/nonfinite/unphysical CLs
points. A real backend regression verifies invalid status and retained warnings;
the supported bounded reference scan remains valid. This adds no model capability.
Historical immutable development Runs are not rewritten. Wide-range limits saved
before this fix can contain invalid negative CLs points despite their old validity
flag; inspect their scan diagnostics and rerun with the corrected adapter and an
appropriate POI range. They are not closure reference results.

## Replaying scientific acceptance

Configure the existing real SDK as described in `research-dependencies.json` and
the backend documentation. Build the explicit acceptance helper:

```sh
cmake --build build --target hep-part4-closure-project
build/bin/hep-benchmark-budget 2 python3 tests/research/closure.py \
  --project-helper build/bin/hep-part4-closure-project \
  --directory /absolute/path/to/new-closure-directory \
  --output /absolute/path/to/closure-receipt.json
```

Use a new directory for the intentionally interrupted scan. All inputs are lowered
by the existing C++ core. The helper is excluded from normal application builds;
it only exercises existing persistence and scientific contracts.

## Release performance comparison

The original Part 3 scripts, collider example, seed, project seed, 16,384 events,
2,048-event logical blocks and 1/2/4/7 worker matrix are unchanged. Eight workers
remain rejected by the UI-reserved broker budget. Both preserved Part 3 and current
Part 4 engines are built in Release against exactly the same installed SDK on this
host. Benchmark commands and source identities are in
`part4-closure-benchmark-run.json`; full measurements, versions, CPU, memory,
startup, merge and control traffic are recorded in the two Release JSON reports.

The historical Intel Xeon Platinum 8573C host is unavailable. The current machine
is AMD EPYC 9V74. Historical absolute timings cannot be used as a same-hardware
regression comparison. The controlled archived-source replay provides the direct
code comparison on the current host instead. These are single trials on a shared
VM, not a statistical performance confidence interval or a cross-hardware claim.

The closure does not claim a production SDK: the installed ROOT wheel remains
alpha, and dependency/compiler/source identities and known limitations remain
recorded. Existing immutable historical Runs are preserved without rewriting.

The current PSS sampler returned zero throughout the Part 4 matrix, despite valid
RSS and CPU measurements. Those PSS values are unavailable, not physical zero.
The comparison reports measured process-tree RSS (which double-counts shared
pages), native worker RSS and the retained baseline PSS honestly. No additional
benchmark matrix was substituted or optimized around this monitoring limitation.
