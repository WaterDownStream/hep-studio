# HEP Studio — Part 3: Collider Engine (in progress)

Master specification remains authoritative. Part 2 history:
`docs/developer/part2-status.md`. No Part 4 work has started.

## Hardening checkpoint — 2026-09-30

- External acceptance package: native coordinator probe, Windows/WSL PowerShell
  wrapper, macOS wrapper, machine-readable receipts, explicit import/repair tests
  and filesystem/native-transfer measurements. See `docs/WINDOWS_WSL_ACCEPTANCE.md`
  and `docs/MACOS_ACCEPTANCE.md`. Linux probe passes all 15 checks; actual Windows
  and macOS remain **UNVERIFIED**, including PowerShell execution/image bootstrap.
- Current scientific build: all 13 CTest suites pass (80.67 s). Dependency-free
  build: 11 applicable suites pass (13.22 s), two scientific suites explicitly
  skip. Logs: `docs/developer/external-acceptance*-tests.txt`. Portable argument,
  receipt/error contracts and a shutdown/restart closing-pipe regression are added.
- Worker restart now enters Stopping synchronously and refuses new requests until
  the replacement handshake. Real parallel-child crash/restart/re-execution passes.
  Worker-count results remain exact; HepMC uncertainties/moments are checked at
  absolute/relative 1e-12 rather than requiring square-root/ASCII bit equality.
  Linux evidence: `docs/developer/external-host-linux-receipt.json`. The 25-event
  locality control uses two directories on one Linux overlay filesystem; it is
  explicitly not WSL storage/Windows-transfer evidence.
- Complete native wrapper also passes on Linux: 15 worker checks and 11 Qt desktop
  cases, no desktop skips. Evidence: `docs/developer/external-wrapper-linux-receipt.json`
  and `external-desktop-linux-tests.txt`. Historical benchmark/test evidence is
  retained separately. Local socket testing skips because this sandbox prohibits
  sockets; private pipes and failure isolation are tested.
- New generator randomness uses fixed logical event blocks independent of
  physical worker count. Legacy projects retain their original logical stream
  count; historical Run snapshots/hashes remain untouched. Run comparison
  distinguishes requested worker budgets from scientific parameter changes.
- Parallel persisted HepMC publishes one Sample manifest after every logical
  shard has verified counts/checksums. Analysis streams shards without eager
  merging. Explicit single-file export is asynchronous and transactional.
- Runtime payload manifests, health/version checks and offline repair/update
  retain old releases and preserve user data; portable bundle tests pass.
- Real optional PYTHIA 8.318, HepMC3 3.02.05, FastJet 3.5.1, ROOT 6.40.00 and
  LHAPDF 6.5.6 adapters, with CT14lo discovery/evaluation/external generation.
  Fused event processing returns compact results and bounded inspection records.
- Immutable provenance/environment snapshots, sample reuse/relink, no-code
  configuration, plot overlays, stale propagation and reference C++ export work
  in automated Linux Qt acceptance. Per-job IPC byte counters are recorded.

The inspector preserves unchanged canonical JSON values across Qt numeric
conversion. Portable undo/redo and real 2→1 worker tests verify unchanged hashes,
no stale outputs and identical histogram results. Active-job recovery reopens as
Interrupted with invalid partial results; historical completed Runs remain intact.

Part 4 dependency acquisition is blocked pending explicit authorization: automatic
approval review rejected the MadGraph/Delphes/compiler download because of the
earlier no-Part-4 instruction and external source archives. No research backend or
AI functionality was implemented; the external Part 3 acceptance work continues.

## Release performance evidence

`docs/developer/release-benchmark.md` and JSON retain 16 cases: generation,
generation + FastJet, full histogram and persisted HepMC, at 1/2/4/7 workers;
16,384 events per case. CPU: Xeon Platinum 8573C, nine exposed CPUs, eight-CPU
quota, seven-worker broker maximum after UI reservation. Eight workers are
explicitly refused. Full-pipeline throughput: 134.9 → 441.2 events/s (3.27×);
persisted: 87.1 → 281.0 events/s (3.22×). Stored samples are 3.54 GiB with eight
logical shards. CPU, memory, startup, merge and IPC metrics are retained.
Shared-VM single trials do not establish dedicated-host scaling or GUI overhead.
Previous Debug smoke measurements remain separately labelled evidence.

## Remaining release gates / limitations

- **Part 3 is not complete:** actual native Windows 11 → WSL2 collider/UI acceptance
  is mandatory and unperformed. No Windows host or Docker/Podman is available
  here. Maintainer image/import/repair recipes exist; no tested runtime image ships.
- macOS is unverified: neither an executed build/CI result nor hardware acceptance
  is available. CI configuration alone is not platform verification.
- Windows/WSL control overhead, WSL-native versus `/mnt/c` storage and large-output
  behavior remain unmeasured. Linux IPC counters are not a substitute.
- The validated PyPI ROOT SDK is alpha. A production SDK/runtime distribution is
  still required. Scientific SDK translation units use ROOT's C++17; core/VPIR
  remains C++23 through the narrow JSON boundary (ADR-018).
- Reproducibility is within the same scientific environment and logical stream
  policy, not across arbitrary compiler/library/platform changes or one continuous
  PYTHIA RNG stream. See ADR-020; manifests and repair use ADRs 021–022.
- Abrupt interruption can leave private orphan staging files; they are never
  labelled complete samples. Disk estimates are conservative heuristics, not caps.
- Runtime bundle hashes verify integrity; publisher signatures/update distribution
  infrastructure are not implemented. Repair preserves the OS layer rather than
  reinstalling or deleting user projects/samples/PDFs.

Host-validation requirements and evidence interpretation:
`docs/developer/part3-hardening-validation.md`. The user's Windows 11 Ryzen 7 /
RTX 4060 system is available for later host tests. Part 4 readiness is gated on
remaining Part 3 acceptance; no Part 4 implementation has begun.
