# ROOT path measurements

Measured locally on Linux x86_64, ROOT 6.40.00, Python 3.12.14, one scientific
thread. The fixture has 1,000,000 rows of deterministic repeating px/py/eta/weight
values and is highly compressible (403,041 bytes). These numbers are evidence for
this development environment, not production-file or other-platform guarantees.
Raw measurements and environment details: [root-benchmark.json](root-benchmark.json).

| Operation | First call | Median of recorded calls |
| --- | ---: | ---: |
| File inspection | 128.21 ms | 0.32 ms |
| Schema extraction | 378.76 ms | 1.32 ms |
| 50-entry preview | 22.35 ms | 2.26 ms |
| Histogram + Count + Mean + Sum | 3201.95 ms | 330.38 ms |

Last warm RDataFrame event loop: 0.3096 s, **3.23 million source entries/s**.
All actions share **one event loop** per Run. First execution includes Cling/JIT.
Peak process RSS: **615.0 MiB**, including ROOT import, JIT and repeated measurements.
The memory reservation is admission accounting, not an OS memory cap.

The benchmark runs the adapter directly, excluding IPC and GUI rendering.
Desktop integration tests separately exercise actual worker requests, completion,
previews, crash/cancel, plots and persistence. No claim is made about network
files, arbitrary nested collections, enormous schemas or cold disk throughput.

Reproduce:

```sh
python tests/root/fixtures.py benchmark.root 1000000
python tests/root/benchmark.py benchmark.root
```

Obvious scaling traps avoided: metadata-only schema extraction; indexed bounded
previews; no whole-column serialization; one persistent worker/TFile cache; all
lazy actions booked before execution. Limits and future optimization work are
recorded in STATUS.md, not hidden behind misleading benchmark extrapolation.
