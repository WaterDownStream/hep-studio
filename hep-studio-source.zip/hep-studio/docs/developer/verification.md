# Verification and continuation

Use the top-level CMake commands in README. CTest has `core`, `analysis-core`, `root-backend`, `runtime`,
`studio-integration` and `desktop-smoke` targets. Core tests can run without Qt. Runtime tests need a
sibling `hep-worker` executable. The desktop smoke test uses offscreen Qt Quick
software rendering and exercises the actual worker process.

CI defines Ubuntu, hosted Windows x64 and Apple Silicon jobs with Qt 6.8.3.
It is intentionally distinct from local evidence (Qt 6.4.2). Remote CI was not
run as part of this source-only delivery. The Windows 11-specific gate is opt-in
because hosted Windows x64 runners use Windows Server. See the
[GitHub runner reference](https://docs.github.com/en/actions/reference/runners/github-hosted-runners)
and [Qt installation action](https://github.com/jurplel/install-qt-action).

The implementation now covers Part 2 ROOT Studio Core. Read `STATUS.md`, architecture docs and
ADRs before continuing. Keep mock results clearly marked and preserve the original master specification. Do not bolt real
ROOT calls into QML or replace VPIR with generated source strings.

When investigating a failure, distinguish configuration failures, compiler
errors, transport restrictions, child launch failures and scientific validation.
Structured runtime logs record timestamps, subsystem, severity, job/node IDs and
messages. Reproduce missing permissions on the built file itself before changing
the application or its security policy.


Part 2 regression evidence includes deterministic px/py → pT → cut → histogram,
shared event-loop counts, Gaussian/exponential/polynomial fits and failed-fit
status, weighted normalization/flow, Histo2D, TTree/RNTuple metadata and previews.
The C++ desktop integration test follows creation → execution → plotting →
reopen → stale edit → rerun → comparison → crash/cancel → missing-file relink.
It uses the same bridge methods invoked by QML. The QML builder test also opens and accepts real Define/Filter dialogs and
checks the resulting ASTs. A separate smoke test loads the actual QML. Headless checks do not substitute for interactive usability testing.

ROOT tests return CTest skip code 77 when PyROOT is absent; the desktop integration
test skips only its scientific sequence. Native socket tests explicitly skip if
the OS denies listening. Pipe transport still receives fragmentation, malformed
frame, bad handshake, timeout, cancellation, shutdown and restart coverage.

The raw benchmark report in `root-benchmark.json` includes all measured samples,
ROOT/Python/platform versions and peak RSS. Synthetic highly compressible data is
not representative of complex production HEP files. First execution includes JIT;
warm throughput and OS cache effects are reported separately. No performance
threshold is asserted for other machines.
