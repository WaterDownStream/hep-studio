# Part 4 reference performance

Executed Linux reference measurements, not production-scale throughput or
comparisons across hardware. Receipt: `part4-release-hardening-benchmark.json`.
AMD EPYC 9V74 host; broker sees 8 logical CPUs / 8 GiB, reserves a UI CPU and
grants 2 scientific threads. Release native engine; ROOT 6.40.00 alpha,
PYTHIA 8.318, HepMC3 3.02.05, FastJet 3.5.1, LHAPDF 6.5.6,
MadGraph 3.6.7 and Delphes 3.5.1. Exact environment/pins/seed configuration
are retained in the JSON. Root JIT and process startup dominate small cases.

| Measurement | Wall time |
| --- | ---: |
| Capability initialization | 0.769 s |
| Cold 1,000-event full pipeline | 15.480 s |
| MadGraph process + integration + LHE publication | 8.775 s |
| Stable four-block shower / HepMC publication | 0.526 s |
| Four serial Delphes blocks / verified publication | 2.548 s |
| ROOT analysis, initial helper JIT and histogram | 3.493 s |
| Complete checksum-verified cache reuse + analysis | 0.180 s |
| RooFit Gaussian over the resulting histogram | 0.465 s |
| RooStats known-background one-bin CLs | 0.370 s |
| Two normalization variations, upstream reuse | 0.188 s |
| Three histogram-binning scan points, upstream reuse | 0.584 s |

Cold throughput is 64.6 input events/s for this small configuration. Cache reuse
is latency, not generation throughput. Peak sampled process-tree PSS is
642.65 MiB; RSS 764.04 MiB double-counts shared pages. Sampled CPU time is
14.82 s over 18.25 s including startup, or 81.2% of one logical CPU aggregated
across the process tree. This is not 81.2% of the whole eight-CPU allocation.
Process sampling can miss short-lived peaks. The low average utilization is
consistent with serial matrix-element/detector work and startup/JIT in this case;
it does not establish large-sample scaling. The Debug configuration check ran
concurrently only during early setup; the scientific benchmark preceded the
full regression suite. Host/background workload isolation is not guaranteed.

A previous Release reference in `part4-release-benchmark.json` remains historical
with its different adapter/environment identity and concurrent-work limitation.
Do not treat the difference as an optimization claim. Part 3's larger worker-count
matrix remains in `release-benchmark.json`; no new 1/2/4/N comparison is inferred
from this Part 4 latency measurement.

Reproduction (with the installed SDK environment and `psutil`):

```sh
cmake --build build-release --target hep-collider-engine hep-benchmark-budget
build-release/bin/hep-benchmark-budget 2 python3 tests/research/benchmark.py \
  --build build-release --events 1000 --workers 2 \
  --directory /path/to/fresh-reference-cache \
  --output docs/developer/local-research-benchmark.json
```

Use a fresh directory for the cold case. Review the recorded budget and library
versions before comparing measurements. Large MadGraph/Delphes production tuning,
Windows/WSL locality and macOS hardware benchmarks remain outstanding.

## Current adapter reference — 2026-10-03

Receipt: `part4-current-release-benchmark.json`. A newly built Release native
engine and broker runner execute the current adapters. This run follows the final
regression suite; no build/test workload ran concurrently with the scientific
measurement. Background host isolation is still not guaranteed. The same bounded
1,000-event, two-worker reference and seed configuration apply.

| Measurement | Wall time |
| --- | ---: |
| Capability initialization | 0.741 s |
| Cold full research pipeline | 15.209 s |
| Checksum-verified reuse and analysis | 0.198 s |
| RooFit Gaussian | 0.482 s |
| RooStats one-bin CLs | 0.425 s |
| two normalization variations with reused event stages | 0.201 s |
| three-point analysis scan with reused event stages | 0.625 s |

Cold rate: 65.8 input events/s. Peak sampled
process-tree PSS: 646.8 MiB; RSS: 766.7 MiB
(shared pages may be double counted). Sampled CPU time is 14.68 s
over 18.11 s including startup, or
81.1% of one CPU. Broker allocation remains two threads
on eight available logical CPUs with an UI reservation. These small-case measurements
do not establish production throughput, cross-machine equivalence, or an optimization
relative to historical receipts. The restored process-monitor wheel and official
PyPI checksum evidence are in `part4-benchmark-dependency.json`.
