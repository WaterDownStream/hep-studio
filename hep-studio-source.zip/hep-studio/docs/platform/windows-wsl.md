# Native Windows with a managed WSL2 worker

The desktop remains native Qt. ManagedRuntime asynchronously detects WSL and the
fixed HEPStudioRuntime distribution, requires generation 2, then runs a bounded
health check. The explicit Enable WSL2 action invokes Windows setup through the
OS elevation prompt. A reboot or declined approval remains a visible user action.
Install Runtime Image imports a user-selected rootfs archive; it never overwrites
an existing distribution. Verify Runtime can be rerun after OS setup/restart.

Workers launch with structured `wsl.exe --distribution HEPStudioRuntime --exec`
arguments, a fixed /opt/hep Python launcher and private inherited pipes. The
runtime ID is explicitly passed; no shell expression or unauthenticated TCP
service is used. The same scientific v1 handshake, progress, chunks, cancellation,
EOF/crash handling and restart rules apply. Heavy generated samples stay under
/home/hep/HEPStudio/samples; compact results return to the native renderer.

## Image and host verification status

`packaging/wsl/Dockerfile` and `export-image.py` are maintainer recipes. They build
the pinned validation SDK, preserve source archives, copy the worker and launcher,
create an unprivileged user and run health detection before export. They do not
constitute a shipped or Windows-tested runtime image. Docker/Podman and an actual
Windows host are unavailable in the current development environment. The recipe
has not been executed here. A production image needs a validated ROOT distribution,
license/source redistribution review, published checksum and actual host gates.

The Linux process-adapter test verifies parsing/launch/health contracts only.
Windows CI configuration is not proof of Windows execution. Pending host gates:
WSL disabled/setup/reboot, image import, health handshake, 100-event no-code Run,
preview, kill/restart/cancel, save/reload, runtime-local HepMC reuse, PDF offline
use, control latency and large-file locality. The user's Windows 11 machine can
provide these checks once an installable test image/native build is available.

Command contracts follow Microsoft's [WSL commands](https://learn.microsoft.com/en-us/windows/wsl/basic-commands).

## Versioned repair/update (Part 3 hardening)

`runtime/environment/admin.py` defines the offline bundle contract. The image
build creates a content-addressed manifest and versioned layout using
`initialize_layout.py`. A maintainer bundle must contain the release payload
(including `runtime-manifest.json`) as regular files at archive root; dereference
SDK links when packaging. Do not include user home data. The desktop's explicit
**Repair / Update** action imports a local-drive bundle, verifies it and retains
older releases. Health checks report `runtimeVersion` and `manifestVerified`.
A bundle cannot repair a missing/corrupt WSL OS or bootstrap administrator script.
Publisher signatures and automated download/update distribution remain outstanding.

Portable tests exercise repair, corruption rejection, atomic activation and data
preservation. They do not emulate a Windows scientific run. Windows 11 + WSL2
startup/run/preview/cancel/crash/reload/comparison/repair acceptance and native-vs-
`/mnt/c` measurements are **not yet performed**. No Windows executable or verified
runtime image is included in the source checkpoint.

The external host harness is documented in
[`WINDOWS_WSL_ACCEPTANCE.md`](../WINDOWS_WSL_ACCEPTANCE.md). It uses a native Qt
coordinator probe, real WSL worker and machine-readable receipts; it separately
measures WSL-native versus Windows-mounted samples and explicit native export.
Linux contract/probe tests do not validate Windows. The PowerShell parser check is
configured in Windows CI but no executed Windows CI result is available here.
