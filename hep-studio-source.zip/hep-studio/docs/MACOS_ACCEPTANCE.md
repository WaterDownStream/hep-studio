# macOS external acceptance

Status: **UNVERIFIED**. No macOS CI result or physical host run has been observed.

On an actual macOS host (preferably Apple Silicon), build the existing native Qt
desktop/runtime against the installed scientific SDK. Missing optional libraries
are reported explicitly; do not replace numerical tests with mocked output.
After building, run:

```sh
scripts/macos/acceptance.sh /path/to/build/bin /path/to/evidence-directory
```

The Python wrapper refuses to label a Linux execution as macOS. It records
`sw_vers`, CPU, RAM, GPU metadata where available, worker versions, native protocol
checks and required real Qt collider acceptance in `macos-acceptance.json`.
The strict scientific probe requires ROOT/PYTHIA/HepMC3/FastJet/LHAPDF and an
explicitly installed PDF set; missing components remain visible failures.
Source/binary versions and scientific environment are frozen in the receipt.

Complete the native UI workflow in `WINDOWS_WSL_ACCEPTANCE.md`, using local
macOS storage rather than WSL. Validate save/reload, worker-count invariance,
Run comparison, sharded sample reuse, cancellation/crash/restart, PDF selection,
reference C++/configuration and figure export. Record architecture and every
backend version; do not infer Apple Silicon behavior from an x86-64 build.

Top-level status stays UNVERIFIED pending reviewed interactive evidence. The
shell/Python harness is prepared and tested as code on Linux; macOS execution
is outstanding. CI configuration alone is not CI/build-tested evidence.
