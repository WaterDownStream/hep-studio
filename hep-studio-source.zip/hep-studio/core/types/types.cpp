#include "core/types/types.hpp"
#include <algorithm>
#include <atomic>
#include <chrono>
#include <iomanip>
#include <random>
#include <sstream>
#include <stdexcept>
namespace hep {
Id::Id(std::string text) : value(std::move(text)) {
    if (value.empty() || value.size() > 96 || !std::all_of(value.begin(), value.end(), [](unsigned char c) {
        return (c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z') || (c >= '0' && c <= '9') || c == '-' || c == '_' || c == '.';
    })) throw std::invalid_argument("Identifier must contain 1-96 ASCII letters, digits, _, . or -");
}
Id newId() {
    std::random_device entropy;
    std::ostringstream s;
    s << std::hex << std::setfill('0');
    for (int i=0; i<4; ++i) s << std::setw(8) << entropy();
    return Id(s.str());
}
static constexpr std::array names{"Bool","Int8","Int16","Int32","Int64","UInt8","UInt16","UInt32","UInt64","Float32","Float64","String","Enum","Timestamp","Identifier"};
std::string primitiveName(Primitive p) { return names.at(static_cast<std::size_t>(p)); }
Primitive primitiveFromName(std::string_view name) {
    for (std::size_t i=0; i<names.size(); ++i) if (names[i] == name) return static_cast<Primitive>(i);
    throw std::invalid_argument("Unknown primitive type: " + std::string(name));
}
bool compatible(const Type& a, const Type& b) { return a == b; }
Type scalar(Dimension d) { return {"Scalar",Primitive::Float64,d}; }
Type domain(std::string n) { return {std::move(n),Primitive::Identifier,{}}; }
}
