#pragma once
#include <array>
#include <string>
#include <string_view>
namespace hep {
struct Id {
    std::string value;
    explicit Id(std::string text);
    auto operator<=>(const Id&) const = default;
};
Id newId(); // Identity entropy only; never used for scientific randomness.
enum class Primitive { Bool, Int8, Int16, Int32, Int64, UInt8, UInt16, UInt32, UInt64,
                       Float32, Float64, String, Enum, Timestamp, Identifier };
std::string primitiveName(Primitive);
Primitive primitiveFromName(std::string_view);
// E, L, T, angle. Natural-unit equivalences require explicit future conversions.
struct Dimension {
    std::array<int, 4> powers{};
    auto operator<=>(const Dimension&) const = default;
};
inline constexpr Dimension dimensionless{}, energy{{1,0,0,0}}, length{{0,1,0,0}},
    timeDimension{{0,0,1,0}}, angle{{0,0,0,1}}, area{{0,2,0,0}}, inverseArea{{0,-2,0,0}};
struct Type {
    std::string name;
    Primitive primitive{Primitive::Float64};
    Dimension dimension{};
    auto operator<=>(const Type&) const = default;
};
bool compatible(const Type& output, const Type& input);
Type scalar(Dimension dimension);
Type domain(std::string name);
}
