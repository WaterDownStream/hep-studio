#pragma once
#include "core/vpir/model.hpp"
namespace hep {
// Location is deployment metadata, never the logical scientific identity.
struct ResourceLocation {
    std::string runtimeId,kind,path; bool available{false};
    std::uint64_t sizeBytes{};
};
struct WorkerCandidate {
    std::string id,platform; Json libraries=Json::object(),environment=Json::object();
    unsigned availableThreads{1}; bool healthy{false};
};
struct PlacementPlan {
    std::string workerId; Json stages=Json::array(),transfers=Json::array(),reasons=Json::array();
    Json json()const;
};
PlacementPlan placeWorkflow(const Json& lowering,const std::vector<WorkerCandidate>&,
                            const std::vector<ResourceLocation>&,const std::string& overrideWorker="");
Json environmentDifferences(const Json& preferred,const Json& actual);
}
