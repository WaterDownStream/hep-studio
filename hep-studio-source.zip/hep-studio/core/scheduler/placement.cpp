#include "core/scheduler/placement.hpp"
#include <limits>
#include <stdexcept>
namespace hep {
Json PlacementPlan::json()const{return {{"version",1},{"worker",workerId},{"stages",stages},{"transfers",transfers},{"reasons",reasons},{"renderer","native-desktop"}};}
PlacementPlan placeWorkflow(const Json& plan,const std::vector<WorkerCandidate>& workers,const std::vector<ResourceLocation>& locations,const std::string& overrideWorker){
    const unsigned requiredThreads=plan.value("requiredThreads",1U);
    if(requiredThreads==0)throw std::invalid_argument("Positive execution thread budget required");
    const WorkerCandidate* chosen=nullptr;long double best=std::numeric_limits<long double>::max();
    for(const auto& w:workers){
        if(!w.healthy||w.availableThreads<requiredThreads||(!overrideWorker.empty()&&w.id!=overrideWorker))continue;
        bool capable=true;
        for(const auto& lib:plan.at("requiredLibraries"))if(!w.libraries.contains(lib.get<std::string>())||!w.libraries.at(lib.get<std::string>()).value("available",false))capable=false;
        if(!capable)continue;
        long double cost=0;
        // The initial executor cannot implicitly transfer datasets. Require an accessible
        // existing location. Different runtime IDs may still represent an explicitly
        // mounted, accessible resource; callers list that as its own location.
        if(!locations.empty()){
            bool local=false;
            for(const auto& l:locations)if(l.available&&l.runtimeId==w.id){local=true;cost+=l.kind=="mounted-windows"?static_cast<long double>(l.sizeBytes):0;}
            if(!local)continue;
        }
        if(cost<best){best=cost;chosen=&w;}
    }
    if(!chosen)throw std::invalid_argument("No healthy runtime has the required libraries and accessible data. Install/repair the runtime or relink the sample; no data was transferred.");
    PlacementPlan out;out.workerId=chosen->id;
    out.reasons.push_back("Required libraries are available; heavy event data stays in this runtime");
    Json ids=Json::array();
    for(const auto& node:plan.at("nodes"))ids.push_back(node.at("id"));
    out.stages.push_back({{"worker",chosen->id},{"nodes",ids},{"mode","co-located-stream"},{"threads",requiredThreads},{"materializationsPreserved",true}});
    return out;
}
Json environmentDifferences(const Json& preferred,const Json& actual){
    Json diffs=Json::array();if(preferred.empty())return diffs;
    const auto old=preferred.value("libraries",Json::object()),now=actual.value("libraries",Json::object());
    for(const auto& [key,value]:old.items())if(!now.contains(key)||value.value("version","")!=now.at(key).value("version","")||value.value("available",false)!=now.at(key).value("available",false))
        diffs.push_back({{"library",key},{"preferred",value},{"actual",now.value(key,Json::object())}});
    for(const auto* key:{"compiler","platform","architecture","python","cppStandard","engineSha256","adapterSha256","id"})if(preferred.contains(key)&&preferred.at(key)!=actual.value(key,Json()))diffs.push_back({{"field",key},{"preferred",preferred.at(key)},{"actual",actual.value(key,Json())}});
    return diffs;
}
}
