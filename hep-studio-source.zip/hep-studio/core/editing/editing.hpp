#pragma once
#include "core/project/project.hpp"
#include <variant>
namespace hep {
Workflow& activeWorkflow(Project&);
const Workflow& activeWorkflow(const Project&);
void switchWorkflow(Project&,const Id&);
Id duplicateWorkflow(Project&,const Id&);
void deleteWorkflow(Project&,const Id&);
struct NodeEdit {std::optional<Node> before,after;std::vector<Connection> removed;};
struct EdgeEdit {Connection edge;bool add;};
struct MoveEdit {Id node;double oldX,oldY,newX,newY;};
struct ConfigEdit {Id node;Json before,after;};
struct ParameterEdit {Id node;std::size_t index;Parameter before,after;};
struct WorkflowExtensionEdit {Json before,after;};
using Edit=std::variant<NodeEdit,EdgeEdit,MoveEdit,ConfigEdit,ParameterEdit,WorkflowExtensionEdit>;
class History {
public:
    void execute(Workflow&,Edit);
    void executeBatch(Workflow&,std::vector<Edit>);
    bool undo(Workflow&);bool redo(Workflow&);
    bool canUndo()const{return position_>0;}bool canRedo()const{return position_<commands_.size();}
private:
    static void apply(Workflow&,const Edit&,bool forward);
    std::vector<std::vector<Edit>> commands_;std::size_t position_{0};
};
// Whitelisted presentation fields are excluded; unknown metadata remains scientific.
Json scientificJson(const Workflow&,const std::string& projectSeed="");
Json layoutJson(const Workflow&);
Json dependencyJson(const Workflow&,const Id&,const std::string& projectSeed="");
}
