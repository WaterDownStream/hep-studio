#include "core/editing/editing.hpp"
#include "core/graph/graph.hpp"
#include <algorithm>
#include <map>
#include <set>
#include <stdexcept>
namespace hep {
Workflow& activeWorkflow(Project& p){
    auto id=p.extensions.value("activeWorkflow",p.workflows.front().id.value);
    for(auto& w:p.workflows)if(w.id.value==id)return w;
    return p.workflows.front();
}
const Workflow& activeWorkflow(const Project& p){return activeWorkflow(const_cast<Project&>(p));}
void switchWorkflow(Project& p,const Id& id){for(const auto& w:p.workflows)if(w.id==id){p.extensions["activeWorkflow"]=id.value;return;}throw std::invalid_argument("Workflow not found");}
Id duplicateWorkflow(Project& p,const Id& id){
    for(const auto& w:p.workflows)if(w.id==id){
        Workflow copy=w;copy.id=newId();copy.name+=" copy";std::map<Id,Id> ids;
        for(auto& n:copy.nodes){auto fresh=newId();ids.emplace(n.id,fresh);n.id=fresh;}
        for(auto& c:copy.connections){c.fromNode=ids.at(c.fromNode);c.toNode=ids.at(c.toNode);}
        const auto result=copy.id;p.workflows.push_back(std::move(copy));switchWorkflow(p,result);return result;
    }throw std::invalid_argument("Workflow not found");
}
void deleteWorkflow(Project& p,const Id& id){if(p.workflows.size()<=1)throw std::invalid_argument("Keep at least one workflow");std::erase_if(p.workflows,[&](const auto& w){return w.id==id;});p.extensions["activeWorkflow"]=activeWorkflow(p).id.value;}
static Node& mutableNode(Workflow& w,const Id& id){for(auto& n:w.nodes)if(n.id==id)return n;throw std::invalid_argument("Edited node no longer exists");}
void History::apply(Workflow& w,const Edit& edit,bool forward){
    std::visit([&](const auto& e){
        using T=std::decay_t<decltype(e)>;
        if constexpr(std::is_same_v<T,NodeEdit>){
            const auto& remove=forward?e.before:e.after;const auto& add=forward?e.after:e.before;
            if(remove){std::erase_if(w.nodes,[&](const auto& n){return n.id==remove->id;});std::erase_if(w.connections,[&](const auto& c){return c.fromNode==remove->id||c.toNode==remove->id;});}
            if(add)w.nodes.push_back(*add);
            if(!forward)for(const auto& c:e.removed)w.connections.push_back(c);
        }else if constexpr(std::is_same_v<T,EdgeEdit>){
            if(e.add==forward){auto issue=hep::connect(w,e.edge);if(issue)throw std::invalid_argument(issue->message);}
            else std::erase_if(w.connections,[&](const auto& c){return c.fromNode==e.edge.fromNode&&c.fromPort==e.edge.fromPort&&c.toNode==e.edge.toNode&&c.toPort==e.edge.toPort;});
        }else if constexpr(std::is_same_v<T,MoveEdit>){auto& n=mutableNode(w,e.node);n.x=forward?e.newX:e.oldX;n.y=forward?e.newY:e.oldY;
        }else if constexpr(std::is_same_v<T,ConfigEdit>){mutableNode(w,e.node).extensions=forward?e.after:e.before;
        }else if constexpr(std::is_same_v<T,ParameterEdit>){mutableNode(w,e.node).parameters.at(e.index)=forward?e.after:e.before;}
        else if constexpr(std::is_same_v<T,WorkflowExtensionEdit>){w.extensions=forward?e.after:e.before;}
    },edit);
}
void History::execute(Workflow& w,Edit e){executeBatch(w,{std::move(e)});}
void History::executeBatch(Workflow& w,std::vector<Edit> edits){
    if(edits.empty())return;
    std::size_t applied=0;
    try{for(const auto& e:edits){apply(w,e,true);++applied;}}
    catch(...){while(applied)apply(w,edits[--applied],false);throw;}
    commands_.erase(commands_.begin()+static_cast<std::ptrdiff_t>(position_),commands_.end());commands_.push_back(std::move(edits));
    if(commands_.size()>200)commands_.erase(commands_.begin());
    position_=commands_.size();
}
bool History::undo(Workflow& w){if(!canUndo())return false;const auto& edits=commands_[position_-1];for(auto i=edits.rbegin();i!=edits.rend();++i)apply(w,*i,false);--position_;return true;}
bool History::redo(Workflow& w){if(!canRedo())return false;for(const auto& e:commands_[position_])apply(w,e,true);++position_;return true;}
Json scientificJson(const Workflow& w,const std::string& projectSeed){
    auto j=workflowJson(w);j.erase("name");j.erase("presentation");j.erase("comments");
    for(auto& n:j["nodes"]){n.erase("name");n.erase("position");n.erase("presentation");n.erase("comments");n.erase("collapsed");if(!projectSeed.empty()&&n.value("typeId","")=="hep.collider.Pythia"&&n.value("config",Json::object()).value("seedStrategy","")=="project-derived")n["resolvedProjectSeed"]=projectSeed;}
    for(auto& n:j["nodes"])if(n.value("typeId","")=="hep.collider.Pythia"){
        auto& c=n["config"];if(!c.contains("streamPolicy")){c["streamPolicy"]="legacy-streams-v1";c["logicalStreams"]=c.value("workers",1);}
        c.erase("workers");
    }
    for(auto& n:j["nodes"])if(n.value("typeId","")=="hep.research.Shower"){
        auto& c=n["config"];c.erase("workers");
        if(!projectSeed.empty()&&c.value("seedStrategy","")=="project-derived")n["resolvedProjectSeed"]=projectSeed;
    }
    for(auto& n:j["nodes"])if(n.value("typeId","")=="hep.research.Delphes"&&n.value("config",Json::object()).value("card",Json::object()).is_object()){
        auto& card=n["config"]["card"];if(card.value("resourceVersion",0)==1&&card.contains("resourceId")&&card.contains("sha256"))card.erase("path");
    }
    return j;
}
Json layoutJson(const Workflow& w){
    auto j=workflowJson(w);Json result={{"name",w.name},{"nodes",Json::array()}};
    for(const auto& n:j["nodes"])result["nodes"].push_back({{"id",n.at("id")},{"name",n.at("name")},{"position",n.at("position")},{"presentation",n.value("presentation",Json::object())},{"comments",n.value("comments",Json::array())},{"collapsed",n.value("collapsed",false)}});
    result["presentation"]=j.value("presentation",Json::object());result["comments"]=j.value("comments",Json::array());return result;
}
Json dependencyJson(const Workflow& w,const Id& id,const std::string& projectSeed){
    std::set<Id> parents;std::vector<Id> todo{id};
    while(!todo.empty()){auto cur=todo.back();todo.pop_back();if(!parents.insert(cur).second)continue;for(const auto& c:w.connections)if(c.toNode==cur)todo.push_back(c.fromNode);}
    auto j=scientificJson(w,projectSeed);j.erase("id");
    std::erase_if(j["nodes"].get_ref<Json::array_t&>(),[&](const auto& n){return !parents.contains(Id(n.at("id")));});
    std::erase_if(j["connections"].get_ref<Json::array_t&>(),[&](const auto& c){return !parents.contains(Id(c.at("toNode")));});
    if(j.contains("systematics")){
        std::erase_if(j["systematics"].get_ref<Json::array_t&>(),[&](const auto& s){
            for(const auto& affected:s.at("affectedNodes"))if(parents.contains(Id(affected)))return false;
            return true;
        });
        if(j["systematics"].empty())j.erase("systematics");
    }
    return j;
}
}
