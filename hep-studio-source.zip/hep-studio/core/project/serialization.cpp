#include "core/project/project.hpp"
#include <algorithm>
#include <set>
#include <stdexcept>
namespace hep {
namespace {
Json base(const Json& j) { if (!j.is_object()) throw std::invalid_argument("Extensions must be an object"); return j; }
void shape(const Json& j, std::initializer_list<const char*> fields) {
    if (!j.is_object()) throw std::invalid_argument("Expected an object");
    for (const auto* f : fields) if (!j.contains(f)) throw std::invalid_argument(std::string("Missing field: ")+f);
}
void bounded(const Json& j, std::size_t max) {
    if (!j.is_array() || j.size()>max) throw std::invalid_argument("Invalid or oversized array");
}
Json typeJson(const Type& t) { return {{"name",t.name},{"primitive",primitiveName(t.primitive)},{"dimension",t.dimension.powers}}; }
Type readType(const Json& j) {
    shape(j,{"name","primitive","dimension"});
    if (!j.at("dimension").is_array() || j.at("dimension").size()!=4) throw std::invalid_argument("Dimension requires four exponents");
    for(const auto& power:j.at("dimension")) {
        if(!power.is_number_integer() || power.get<double>() < -16 || power.get<double>() > 16)throw std::invalid_argument("Dimension exponents must be small integers");
    }
    auto powers=j.at("dimension").get<std::array<int,4>>();
    for (int p : powers) if (p < -16 || p > 16) throw std::invalid_argument("Dimension exponent outside supported range");
    return {j.at("name").get<std::string>(),primitiveFromName(j.at("primitive").get<std::string>()),{powers}};
}
// Preserve extension fields even inside type objects.
Json mergedType(const Json& old, const Type& type) {
    auto j=old.is_object()?old:Json::object();
    j.update(typeJson(type)); return j;
}
std::string semanticsName(Semantics s) {
    switch (s) {
    case Semantics::EventLocal: return "event-local";
    case Semantics::GlobalAggregation: return "global-aggregation";
    case Semantics::Randomized: return "randomized";
    case Semantics::Stateful: return "stateful";
    case Semantics::SideEffecting: return "side-effecting";
    } throw std::invalid_argument("Invalid semantics");
}
Semantics readSemantics(const std::string& s) {
    for (auto v : {Semantics::EventLocal,Semantics::GlobalAggregation,Semantics::Randomized,Semantics::Stateful,Semantics::SideEffecting})
        if (semanticsName(v)==s) return v;
    throw std::invalid_argument("Unsupported node semantics");
}
Json portJson(const Port& p) {
    auto j=base(p.extensions);
    j.update({{"id",p.id.value},{"name",p.name},{"direction",p.direction==Direction::Input?"input":"output"},
      {"type",mergedType(j.value("type",Json::object()),p.type)},{"optional",p.optional},{"streaming",p.streaming},{"cardinality","one"}});
    return j;
}
Port readPort(const Json& j) {
    shape(j,{"id","name","direction","type","optional","streaming","cardinality"});
    const auto dir=j.at("direction").get<std::string>();
    if (dir!="input" && dir!="output") throw std::invalid_argument("Unknown port direction");
    if (j.at("cardinality")!="one") throw std::invalid_argument("Unsupported port cardinality");
    return {Id(j.at("id")),j.at("name"),dir=="input"?Direction::Input:Direction::Output,
      readType(j.at("type")),j.at("optional"),j.at("streaming"),j};
}
Json parameterJson(const Parameter& p) {
    auto j=base(p.extensions);
    j.update({{"name",p.name},{"type",mergedType(j.value("type",Json::object()),p.type)},{"value",p.value},{"default",p.defaultValue},
      {"units",p.units},{"role",p.role},{"origin",p.origin},{"documentation",p.documentation},
      {"minimum",p.minimum?Json(*p.minimum):Json(nullptr)},{"maximum",p.maximum?Json(*p.maximum):Json(nullptr)}});
    return j;
}
Parameter readParameter(const Json& j) {
    shape(j,{"name","type","value","default","units","role","origin","documentation","minimum","maximum"});
    Parameter p{j.at("name"),readType(j.at("type")),j.at("value"),j.at("default"),j.at("units"),j.at("role"),j.at("origin"),j.at("documentation"),{},{},j};
    if (!j.at("minimum").is_null()) p.minimum=j.at("minimum").get<double>();
    if (!j.at("maximum").is_null()) p.maximum=j.at("maximum").get<double>();
    return p;
}
Json nodeJson(const Node& n) {
    auto j=base(n.extensions); Json ports=Json::array(),params=Json::array();
    auto ps=n.ports; std::sort(ps.begin(),ps.end(),[](const auto& a,const auto& b){ return a.id<b.id; });
    for (const auto& p : ps) ports.push_back(portJson(p));
    auto pars=n.parameters; std::sort(pars.begin(),pars.end(),[](const auto& a,const auto& b){ return a.name<b.name; });
    for (const auto& p : pars) params.push_back(parameterJson(p));
    auto pos=j.value("position",Json::object()); pos.update({{"x",n.x},{"y",n.y}});
    j.update({{"id",n.id.value},{"typeId",n.typeId},{"version",n.version},{"name",n.name},{"ports",ports},{"parameters",params},
      {"semantics",semanticsName(n.semantics)},{"deterministic",n.deterministic},{"threadSafe",n.threadSafe},{"position",pos}});
    return j;
}
Node readNode(const Json& j) {
    shape(j,{"id","typeId","version","name","ports","parameters","semantics","deterministic","threadSafe","position"});
    bounded(j.at("ports"),128); bounded(j.at("parameters"),1024);
    if (!j.at("version").is_number_unsigned() || j.at("version").get<unsigned long long>()>100000) throw std::invalid_argument("Invalid node version");
    Node n{Id(j.at("id")),j.at("typeId"),j.at("version"),j.at("name"),{}, {},readSemantics(j.at("semantics")),j.at("deterministic"),j.at("threadSafe"),j.at("position").at("x"),j.at("position").at("y"),j};
    if(n.typeId=="hep.collider.Pythia"&&!n.extensions.at("config").contains("streamPolicy")){
        auto& c=n.extensions["config"];c["streamPolicy"]="legacy-streams-v1";c["logicalStreams"]=c.value("workers",1);
    }
    for (const auto& p : j.at("ports")) n.ports.push_back(readPort(p));
    for (const auto& p : j.at("parameters")) n.parameters.push_back(readParameter(p));
    return n;
}
Json runJson(const Run& r) {
    auto j=base(r.extensions);
    j.update({{"id",r.id.value},{"status",r.status},{"workflow",r.workflowSnapshot},{"workflowHash",r.workflowHash},
      {"environment",r.environment},{"backend",r.backend},{"seed",r.seed},{"started",r.started},{"ended",r.ended},
      {"resources",r.resources},{"result",r.result},{"logs",r.logs}}); return j;
}
}
Json workflowJson(const Workflow& w) {
    auto j=base(w.extensions); Json nodes=Json::array(),edges=Json::array();
    auto ns=w.nodes; std::sort(ns.begin(),ns.end(),[](const auto& a,const auto& b){return a.id<b.id;});
    for (const auto& n : ns) nodes.push_back(nodeJson(n));
    for (const auto& c : w.connections) {
        auto edge=base(c.extensions);
        edge.update({{"fromNode",c.fromNode.value},{"fromPort",c.fromPort.value},{"toNode",c.toNode.value},{"toPort",c.toPort.value}});
        edges.push_back(edge);
    }
    std::sort(edges.begin(),edges.end(),[](const auto& a,const auto& b){return a.dump()<b.dump();});
    j.update({{"schemaVersion",1},{"id",w.id.value},{"name",w.name},{"nodes",nodes},{"connections",edges}}); return j;
}
Workflow workflowFromJson(const Json& j) {
    shape(j,{"schemaVersion","id","name","nodes","connections"});
    if (j.at("schemaVersion")!=1) throw std::invalid_argument("Unsupported workflow schema; original file was not modified");
    bounded(j.at("nodes"),10000); bounded(j.at("connections"),50000);
    Workflow w{Id(j.at("id")),j.at("name"),{}, {},j};
    for (const auto& n : j.at("nodes")) w.nodes.push_back(readNode(n));
    for (const auto& c : j.at("connections")) {
        shape(c,{"fromNode","fromPort","toNode","toPort"});
        w.connections.push_back({Id(c.at("fromNode")),Id(c.at("fromPort")),Id(c.at("toNode")),Id(c.at("toPort")),c});
    } return w;
}
Json projectJson(const Project& p) {
    auto j=base(p.extensions); Json ws=Json::array(),rs=Json::array();
    auto workflows=p.workflows; std::sort(workflows.begin(),workflows.end(),[](const auto& a,const auto& b){return a.id<b.id;});
    for (const auto& w : workflows) ws.push_back(workflowJson(w));
    for (const auto& r : p.runs) rs.push_back(runJson(r)); // Historical append order is meaningful.
    j.update({{"format","hep-studio-project"},{"schemaVersion",1},{"id",p.id.value},{"name",p.name},
      {"workflows",ws},{"runs",rs},{"environment",p.environment},{"seed",p.seed}}); return j;
}
Project projectFromJson(const Json& j) {
    shape(j,{"format","schemaVersion","id","name","workflows","runs","environment","seed"});
    if (j.at("format")!="hep-studio-project" || j.at("schemaVersion")!=1) throw std::invalid_argument("Unsupported project schema; original file was not modified");
    bounded(j.at("workflows"),100); bounded(j.at("runs"),10000);
    Project p{Id(j.at("id")),j.at("name"),{}, {},j.at("environment"),j.at("seed"),j};
    for (const auto& w : j.at("workflows")) p.workflows.push_back(workflowFromJson(w));
    for (const auto& r : j.at("runs")) {
        shape(r,{"id","status","workflow","workflowHash","environment","backend","seed","started","ended","resources","result","logs"});
        const auto status=r.at("status").get<std::string>();
        if (status!="Completed" && status!="Failed" && status!="Cancelled" && status!="Interrupted") throw std::invalid_argument("Saved runs must be terminal");
        p.runs.push_back({Id(r.at("id")),status,r.at("workflow"),r.at("workflowHash"),r.at("environment"),r.at("backend"),r.at("seed"),r.at("started"),r.at("ended"),r.at("resources"),r.at("result"),r.at("logs"),r});
    }
    std::set<Id> workflowIds,runIds;
    for (const auto& w : p.workflows) if (!workflowIds.insert(w.id).second) throw std::invalid_argument("Duplicate workflow ID");
    for (const auto& r : p.runs) if (!runIds.insert(r.id).second) throw std::invalid_argument("Duplicate run ID");
    if (p.workflows.empty()) throw std::invalid_argument("Project needs a workflow");
    return p;
}
std::string serialize(const Workflow& w) { return workflowJson(w).dump(2)+"\n"; }
std::string serialize(const Project& p) { return projectJson(p).dump(2)+"\n"; }
Project parseProject(std::string_view text) {
    if (text.size()>16*1024*1024) throw std::invalid_argument("Project exceeds the Phase 0 16 MiB limit");
    std::vector<std::set<std::string>> objectKeys;
    auto callback=[&](int depth,Json::parse_event_t event,Json& value) {
        if (depth>64) throw std::invalid_argument("Project nesting limit exceeded");
        if(event==Json::parse_event_t::object_start)objectKeys.emplace_back();
        if(event==Json::parse_event_t::key && !objectKeys.back().insert(value.get<std::string>()).second)throw std::invalid_argument("Duplicate JSON object key");
        if(event==Json::parse_event_t::object_end)objectKeys.pop_back();
        return true;
    };
    return projectFromJson(Json::parse(text,callback));
}
}
