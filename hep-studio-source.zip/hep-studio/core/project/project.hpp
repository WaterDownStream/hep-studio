#pragma once
#include "core/run_model/run.hpp"
namespace hep {
struct Project {
    Id id;
    std::string name;
    std::vector<Workflow> workflows;
    std::vector<Run> runs; // Append finalized records; active jobs live in the coordinator.
    std::string environment{"hep-env://mock/1"};
    std::string seed{"0"};
    Json extensions=Json::object();
};
Json workflowJson(const Workflow&);
Workflow workflowFromJson(const Json&);
Json projectJson(const Project&);
Project projectFromJson(const Json&);
std::string serialize(const Workflow&);
std::string serialize(const Project&);
Project parseProject(std::string_view);
}
