#include "core/vpir/model.hpp"
#include <stdexcept>
namespace hep {
Node mockNode(std::string_view kind, Id id, double x, double y) {
    Node n{std::move(id), "hep.mock." + std::string(kind), 1, "Mock " + std::string(kind), {}, {}};
    n.x=x; n.y=y;
    auto in = [&](Type t) { n.ports.push_back({Id("in"),"Input",Direction::Input,std::move(t)}); };
    auto out = [&](Type t) { n.ports.push_back({Id("out"),"Output",Direction::Output,std::move(t)}); };
    if (kind == "ParticleSource" || kind == "ParticleCollection") out(domain("ParticleCollection"));
    else if (kind == "Filter") { in(domain("ParticleCollection")); out(domain("ParticleCollection")); }
    else if (kind == "Histogram") { in(domain("ParticleCollection")); out(domain("Histogram1D")); n.semantics=Semantics::GlobalAggregation; }
    else if (kind == "JetCluster") { in(domain("ParticleCollection")); out(domain("JetCollection")); }
    else if (kind == "JetCollection") { in(domain("JetCollection")); out(domain("JetCollection")); }
    else throw std::invalid_argument("Unknown mock node kind");
    return n;
}
Workflow mockWorkflow(bool jets) {
    Workflow w{newId(), jets ? "Mock jet pipeline" : "Mock particle pipeline", {}, {}};
    const std::vector<std::string> kinds = jets ? std::vector<std::string>{"ParticleCollection","JetCluster","JetCollection"}
                                               : std::vector<std::string>{"ParticleSource","Filter","Histogram"};
    for (std::size_t i=0; i<kinds.size(); ++i) w.nodes.push_back(mockNode(kinds[i],newId(),40 + static_cast<double>(i)*260,85));
    for (std::size_t i=1; i<w.nodes.size(); ++i) w.connections.push_back({w.nodes[i-1].id,Id("out"),w.nodes[i].id,Id("in")});
    return w;
}
}
