#pragma once
#include "core/types/types.hpp"
#include "core/json.hpp"
#include <optional>
#include <vector>
namespace hep {
enum class Direction { Input, Output };
enum class Semantics { EventLocal, GlobalAggregation, Randomized, Stateful, SideEffecting };
struct Port {
    Id id; std::string name; Direction direction; Type type;
    bool optional{false}; bool streaming{true};
    Json extensions = Json::object();
};
struct Parameter {
    std::string name; Type type; Json value; Json defaultValue;
    std::string units{"1"}; std::string role{"constant"}; std::string origin{"default"};
    std::string documentation; std::optional<double> minimum, maximum;
    Json extensions = Json::object();
    bool changed() const { return value != defaultValue; }
};
struct Node {
    Id id; std::string typeId; unsigned version{1}; std::string name;
    std::vector<Port> ports; std::vector<Parameter> parameters;
    Semantics semantics{Semantics::EventLocal}; bool deterministic{true}; bool threadSafe{true};
    double x{}, y{};
    Json extensions = Json::object();
};
struct Connection {
    Id fromNode, fromPort, toNode, toPort;
    Json extensions = Json::object();
};
struct Workflow {
    Id id; std::string name; std::vector<Node> nodes; std::vector<Connection> connections;
    Json extensions = Json::object();
};
Node mockNode(std::string_view kind, Id id, double x = 0, double y = 0);
Workflow mockWorkflow(bool jets = false);
}
