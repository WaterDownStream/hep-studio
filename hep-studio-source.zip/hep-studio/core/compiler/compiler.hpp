#pragma once
#include "core/graph/graph.hpp"
namespace hep {
struct ExecutionPlan {
    std::string backend{"hep.mock/1"};
    std::vector<Id> orderedNodes;
    Json snapshot;
};
// The interface is a pass boundary. Phase 0 validates; it performs no unsafe optimizations.
class BackendLowerer {
public:
    virtual ~BackendLowerer()=default;
    virtual ExecutionPlan lower(const Workflow&) const=0;
};
class MockLowerer final : public BackendLowerer {
public:
    ExecutionPlan lower(const Workflow&) const override;
};
}
