#include "core/compiler/compiler.hpp"
#include "core/project/project.hpp"
#include <stdexcept>
namespace hep {
ExecutionPlan MockLowerer::lower(const Workflow& w) const {
    const auto issues=validate(w);
    for (const auto& issue : issues) if (issue.severity==Severity::Error) throw std::invalid_argument(issue.message);
    for (const auto& n : w.nodes) {
        if (!n.typeId.starts_with("hep.mock.") || n.version!=1) throw std::invalid_argument("Backend does not support node: "+n.typeId);
        const auto spec=mockNode(n.typeId.substr(9),n.id);
        if (n.ports.size()!=spec.ports.size() || !n.parameters.empty() || n.semantics!=spec.semantics || !n.deterministic || !n.threadSafe)
            throw std::invalid_argument("Unsupported mock descriptor or parameters");
        for (const auto& p : spec.ports) {
            const auto* actual=findPort(n,p.id);
            if (!actual || actual->type!=p.type || actual->direction!=p.direction || actual->streaming!=p.streaming || actual->optional!=p.optional)
                throw std::invalid_argument("Mock port descriptor has been altered");
        }
    }
    return {"hep.mock/1",topologicalOrder(w),workflowJson(w)};
}
}
