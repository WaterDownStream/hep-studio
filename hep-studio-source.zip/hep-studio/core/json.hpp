#pragma once
#include <nlohmann/json.hpp>
namespace hep { using Json = nlohmann::json; }
