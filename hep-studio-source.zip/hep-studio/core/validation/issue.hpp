#pragma once
#include <optional>
#include "core/types/types.hpp"
namespace hep {
enum class Severity { Info, Warning, Error };
struct ValidationIssue {
    Severity severity; std::string code; std::string message; std::optional<Id> node;
};
}
