#include "core/collider/collider.hpp"
#include "core/graph/graph.hpp"
#include <stdexcept>
#include <set>
namespace hep {
DatasetSchema jetSchema(){
    DatasetSchema s{"Jets","EventTable",0,{}};
    for(const auto* name:{"pt","eta","phi","mass","energy","value","weight"}){
        const std::string key=name;const auto d=key=="eta"||key=="weight"?dimensionless:key=="phi"?angle:energy;
        s.columns.push_back({key,"double",d==energy?"GeV":d==angle?"rad":"1",true,false,scalar(d)});
    }return s;
}
Node colliderNode(std::string_view kind,Id id,double x,double y){
    Node n{std::move(id),"hep.collider."+std::string(kind),1,std::string(kind),{}, {}};n.x=x;n.y=y;
    auto in=[&](const char* t){n.ports.push_back({Id("in"),"Input",Direction::Input,domain(t)});};
    auto out=[&](const char* t){n.ports.push_back({Id("out"),"Output",Direction::Output,domain(t)});};
    Json c=Json::object();
    if(kind=="Pythia"){
        out("EventStream");n.name="PYTHIA Generator";n.semantics=Semantics::Randomized;n.threadSafe=false;
        c={{"beamA",2212},{"beamB",2212},{"energyGeV",13600.},{"events",1000},{"process","qcd"},{"pTHatMinGeV",20.},
           {"streamPolicy","logical-blocks-v2"},{"partitionEvents",4096},{"isr",true},{"fsr",true},{"mpi",true},{"hadronisation",true},{"seedStrategy","fixed"},{"seed","1"},{"tune",14},
           {"advanced",Json::object()},{"rawOverrides",Json::array()},{"pdf",Json::object()},{"decays",Json::array()}};
    }else if(kind=="HepMCSource"){out("EventStream");c={{"resourceId",""}};}
    else if(kind=="StoreHepMC"){in("EventStream");out("EventStream");n.semantics=Semantics::SideEffecting;c={{"resourceId",""}};}
    else if(kind=="ClusterJets"){
        in("EventStream");out("JetCollection");n.name="Cluster Jets";
        c={{"algorithm","antikt"},{"R",0.4},{"minimumPtGeV",0.},{"recombination","E"},{"includeInvisible",false},{"extensions",Json::object()}};
    }else if(kind=="CollectionFilter"){
        in("JetCollection");out("JetCollection");c={{"expression",{{"op","gt"},{"args",Json::array({columnExpression("pt"),literalExpression(30,"GeV")})}}}};
    }else if(kind=="CollectionSort"){in("JetCollection");out("JetCollection");c={{"property","pt"},{"descending",true}};}
    else if(kind=="CollectionTake"){in("JetCollection");out("JetCollection");c={{"count",1}};}
    else if(kind=="CollectionCount"){in("JetCollection");out("EventTable");}
    else if(kind=="Property"){in("JetCollection");out("EventTable");c={{"property","pt"}};}
    else throw std::invalid_argument("Unsupported collider node");
    n.extensions["config"]=c;return n;
}
Json lowerCollider(const Workflow& w){
    for(const auto& i:validate(w))if(i.severity==Severity::Error)throw std::invalid_argument(i.message);
    Json plan={{"version",1},{"backend","hep.collider/1"},{"nodes",Json::array()},{"requiredLibraries",Json::array()}};
    std::set<std::string> required;std::map<Id,DatasetSchema> schemas;int sources=0;
    for(const auto& id:topologicalOrder(w)){
        const auto& n=*findNode(w,id);const bool root=n.typeId.starts_with("hep.root.");
        if(!root&&!n.typeId.starts_with("hep.collider."))throw std::invalid_argument("Unsupported collider node contract");
        const auto kind=n.typeId.substr(root?9:13);const auto expected=root?rootNode(kind,id):colliderNode(kind,id);
        if(n.version!=1||n.ports.size()!=expected.ports.size())throw std::invalid_argument("Altered collider contract");
        for(const auto& p:expected.ports){const auto* a=findPort(n,p.id);if(!a||a->type!=p.type||a->direction!=p.direction||!a->streaming||a->optional)throw std::invalid_argument("Altered collider port contract");}
        auto c=n.extensions.at("config");Json item={{"id",id.value},{"kind",kind},{"config",c}};DatasetSchema s=jetSchema();
        for(const auto& edge:w.connections)if(edge.toNode==id){item["input"]=edge.fromNode.value;s=schemas.at(edge.fromNode);}
        if(kind=="Pythia"){
            const auto workers=c.value("workers",Json(1));
            if(!workers.is_number_integer()||workers.get<int>()<1||workers.get<int>()>32)throw std::invalid_argument("Generator workers must be an integer in [1,32]");
            plan["requiredThreads"]=workers;
            ++sources;required.insert("PYTHIA");if(!c.value("pdf",Json::object()).value("set",std::string()).empty())required.insert("LHAPDF");}
        if(kind=="HepMCSource"){++sources;required.insert("HepMC3");}
        if(kind=="StoreHepMC")required.insert("HepMC3");
        if(kind=="ClusterJets")required.insert("FastJet");
        if(kind=="CollectionFilter"||kind=="Filter"){
            const auto t=inferExpression(c.at("expression"),s);if(!t.boolean||t.collection)throw std::invalid_argument("Selection requires a Boolean expression");
        }
        if(kind=="CollectionSort"||kind=="Property"){
            const auto prop=c.at("property").get<std::string>();
            if(prop!="pt"&&prop!="eta"&&prop!="phi"&&prop!="mass"&&prop!="energy")throw std::invalid_argument("Unsupported jet property");
            if(kind=="Property")for(auto& col:s.columns)if(col.name=="value")col.type=inferExpression(columnExpression(prop),s).dimension==energy?scalar(energy):scalar(prop=="phi"?angle:dimensionless);
        }
        if(kind=="CollectionCount")for(auto& col:s.columns)if(col.name=="value")col.type=scalar(dimensionless);
        if(root){
            required.insert("ROOT");
            if(kind=="Source")throw std::invalid_argument("A collider pipeline has one generator or HepMC source");
            if(kind=="Define"){
                auto t=inferExpression(c.at("expression"),s);const auto name=c.at("name").get<std::string>();
                if(t.boolean||t.collection||name.empty()||name.starts_with("__hep"))throw std::invalid_argument("Invalid scalar observable");
                for(const auto& col:s.columns)if(col.name==name)throw std::invalid_argument("Observable already exists");
                s.columns.push_back({name,"double","1",true,false,scalar(t.dimension)});
            }else if(kind!="Count"&&kind!="Fit"&&kind!="Filter"){
                const auto t=inferExpression(c.at("expression"),s);if(t.boolean||t.collection)throw std::invalid_argument("Action requires scalar expression");
                item["dimension"]=t.dimension.powers;
            }
        }
        if(c.contains("weight")&&!c["weight"].is_null()){
            const auto t=inferExpression(c["weight"],s);if(t.boolean||t.collection||t.dimension!=dimensionless)throw std::invalid_argument("Weight must be dimensionless");
        }
        schemas.emplace(id,std::move(s));plan["nodes"].push_back(item);
    }
    if(sources!=1)throw std::invalid_argument("Collider workflows require exactly one generator or HepMC source");
    for(const auto& lib:required)plan["requiredLibraries"].push_back(lib);
    return plan;
}
}
