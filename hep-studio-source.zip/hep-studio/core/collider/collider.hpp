#pragma once
#include "core/analysis/analysis.hpp"
#include <cstdint>
namespace hep {
// Canonical event semantics; adapters retain their native records during bulk execution.
struct FourMomentum { double px{},py{},pz{},energy{}; }; // GeV
struct EventParticle {
    int index{},pdgId{},status{}; FourMomentum momentum; double mass{};
    std::vector<int> mothers,daughters;
    std::array<double,4> productionVertex{}; // mm, ct in mm
};
struct EventRecord {
    std::uint64_t number{}; std::vector<EventParticle> particles;
    std::vector<double> weights; Json metadata=Json::object();
};
struct JetRecord { FourMomentum momentum; std::vector<int> constituents; };
Node colliderNode(std::string_view kind,Id id,double x=0,double y=0);
Json lowerCollider(const Workflow&);
DatasetSchema jetSchema();
}
