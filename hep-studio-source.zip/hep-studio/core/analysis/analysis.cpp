#include "core/analysis/analysis.hpp"
#include "core/graph/graph.hpp"
#include "core/units/units.hpp"
#include "core/project/project.hpp"
#include <cmath>
#include <stdexcept>
#include <algorithm>
namespace hep {
DatasetSchema datasetSchema(const Json& j){
    DatasetSchema s{j.value("object",""),j.value("format","TTree"),j.value("entries",std::uint64_t(0)),{}};
    for(const auto& c:j.at("columns")){
        const auto u=c.value("unit","1");const auto d=unit(u).dimension;
        auto t=scalar(d);const auto core=c.value("coreType","Float64");if(core=="Opaque")t=domain("Opaque");else if(core!="NumericCollection")t.primitive=primitiveFromName(core);
        s.columns.push_back({c.at("name"),c.at("backendType"),u,c.value("unitKnown",false),c.value("collection",false),t,c});
    }s.metadata=j.value("metadata",Json::object());return s;
}
Json columnExpression(const std::string& n){return {{"op","column"},{"name",n}};}
Json literalExpression(double v,const std::string& u){return {{"op","literal"},{"value",v},{"unit",u}};}
static ExpressionType infer(const Json& e,const DatasetSchema& schema,int depth){
    if(depth>32||!e.is_object())throw std::invalid_argument("Invalid or excessively nested expression");
    const auto op=e.at("op").get<std::string>();
    if(op=="property"){if(!e.contains("args")||e.at("args").size()!=1||e.at("args")[0].value("op","")!="column")throw std::invalid_argument("Property requires a named record");return infer(columnExpression(e.at("args")[0].at("name").get<std::string>()+"."+e.at("name").get<std::string>()),schema,depth+1);}
    if(op=="column"){
        for(const auto& c:schema.columns)if(c.name==e.at("name").get<std::string>()){if(c.type.name=="Opaque")throw std::invalid_argument("Unsupported opaque column: "+c.name);return {c.type.dimension,c.backendType=="bool"||c.backendType=="Bool_t",c.collection};}
        throw std::invalid_argument("Unknown column: "+e.at("name").get<std::string>());
    }
    if(op=="literal"){const auto v=e.at("value").get<double>();if(!std::isfinite(v))throw std::invalid_argument("Literal must be finite");return {unit(e.value("unit","1")).dimension,false,false};}
    const auto& args=e.at("args");if(!args.is_array()||args.empty()||args.size()>32)throw std::invalid_argument("Invalid expression arguments");
    std::vector<ExpressionType> ts;for(const auto& a:args)ts.push_back(infer(a,schema,depth+1));
    if(op=="deltaPhi"||op=="deltaR"||op=="transverseMass"){
        const auto count=op=="deltaPhi"?2U:4U;if(ts.size()!=count)throw std::invalid_argument("Physics observable arity");
        for(const auto& t:ts)if(t.boolean||t.collection)throw std::invalid_argument("Index objects before combining their scalar properties");
        if(op=="deltaPhi"){for(const auto& t:ts)if(t.dimension!=angle)throw std::invalid_argument("deltaPhi requires angles in radians");return {angle,false,false};}
        const auto momentum=op=="transverseMass"?energy:dimensionless;
        if(ts[0].dimension!=momentum||ts[2].dimension!=momentum||ts[1].dimension!=angle||ts[3].dimension!=angle)throw std::invalid_argument("Physics observable dimension mismatch");
        return {op=="transverseMass"?energy:dimensionless,false,false};
    }
    if(op=="and"||op=="or"||op=="not"){
        if((op=="not"&&ts.size()!=1)||(op!="not"&&ts.size()<2))throw std::invalid_argument("Boolean arity");
        for(const auto& t:ts)if(!t.boolean||t.collection)throw std::invalid_argument("Boolean group requires scalar conditions");
        return {{},true,false};
    }
    if(op=="index"){if(ts.size()!=2||!ts[0].collection||ts[1].dimension!=dimensionless)throw std::invalid_argument("Invalid collection index");
        if(args[1].value("op","")!="literal")throw std::invalid_argument("Collection index must be a constant integer");
        const auto index=args[1].at("value").get<double>();if(index<0||index>100000||std::floor(index)!=index)throw std::invalid_argument("Invalid collection index");
        auto t=ts[0];t.collection=false;return t;}
    for(const auto& t:ts)if(t.boolean||t.collection)throw std::invalid_argument("Numeric scalar operands required; index a collection explicitly");
    if(op=="abs"||op=="neg"||op=="sqrt"||op=="square"||op=="sin"||op=="cos"||op=="exp"||op=="log"){
        if(ts.size()!=1)throw std::invalid_argument("Unary operation requires one argument");
        auto t=ts[0];
        if(op=="sqrt")for(auto& power:t.dimension.powers){if(power%2)throw std::invalid_argument("sqrt requires even dimension exponents");power/=2;}
        if(op=="square")for(auto& power:t.dimension.powers)power*=2;
        if(op=="sin"||op=="cos"){if(t.dimension!=dimensionless&&t.dimension!=angle)throw std::invalid_argument("Trigonometric input must be dimensionless or angle");t.dimension=dimensionless;}
        if(op=="log"||op=="exp"){if(t.dimension!=dimensionless)throw std::invalid_argument("log/exp requires dimensionless input");}
        return t;
    }
    if(ts.size()!=2)throw std::invalid_argument("Binary operation requires two arguments");
    auto a=ts[0];const auto b=ts[1];
    if(op=="mul"||op=="div"){for(std::size_t i=0;i<4;++i)a.dimension.powers[i]+=(op=="mul"?1:-1)*b.dimension.powers[i];return a;}
    if(a.dimension!=b.dimension)throw std::invalid_argument("Incompatible expression dimensions; assign column units explicitly");
    if(op=="add"||op=="sub"||op=="min"||op=="max")return a;
    if(op=="gt"||op=="ge"||op=="lt"||op=="le"||op=="eq"||op=="ne")return {{},true,false};
    throw std::invalid_argument("Unsupported expression operation: "+op);
}
ExpressionType inferExpression(const Json& e,const DatasetSchema& s){return infer(e,s,0);}
Node rootNode(std::string_view kind,Id id,double x,double y){
    Node n{std::move(id),"hep.root."+std::string(kind),1,std::string(kind),{}, {}};n.x=x;n.y=y;
    auto in=[&](const std::string& type){n.ports.push_back({Id("in"),"Input",Direction::Input,domain(type)});};
    auto out=[&](const std::string& type){n.ports.push_back({Id("out"),"Output",Direction::Output,domain(type)});};
    if(kind=="Source")out("EventTable");
    else if(kind=="Define"||kind=="Filter"){in("EventTable");out("EventTable");}
    else if(kind=="Histo1D"||kind=="Histo2D"){in("EventTable");out(kind=="Histo1D"?"Histogram1D":"Histogram2D");n.semantics=Semantics::GlobalAggregation;}
    else if(kind=="Fit"){in("Histogram1D");out("FitResult");n.semantics=Semantics::GlobalAggregation;}
    else if(kind=="Count"||kind=="Mean"||kind=="Sum"||kind=="Min"||kind=="Max"){in("EventTable");out("ScalarResult");n.semantics=Semantics::GlobalAggregation;}
    else throw std::invalid_argument("Unsupported ROOT operation");
    n.extensions["config"]=Json::object();return n;
}
Json lowerRoot(const Workflow& w){
    for(const auto& issue:validate(w))if(issue.severity==Severity::Error)throw std::invalid_argument(issue.message);
    Json plan={{"version",1},{"nodes",Json::array()}};std::map<Id,DatasetSchema> schemas;int sources=0;
    for(const auto& id:topologicalOrder(w)){
        const auto& n=*findNode(w,id);if(!n.typeId.starts_with("hep.root.")||n.version!=1)throw std::invalid_argument("Unsupported ROOT node contract");
        const auto kind=n.typeId.substr(9);const auto expected=rootNode(kind,n.id);
        if(n.ports.size()!=expected.ports.size())throw std::invalid_argument("Altered ROOT port contract");
        for(const auto& p:expected.ports){const auto* actual=findPort(n,p.id);if(!actual||actual->type!=p.type||actual->direction!=p.direction)throw std::invalid_argument("Altered ROOT port contract");}
        auto config=n.extensions.at("config");Json item={{"id",id.value},{"kind",kind},{"config",config}};DatasetSchema schema;
        for(const auto& c:w.connections)if(c.toNode==id){item["input"]=c.fromNode.value;if(schemas.contains(c.fromNode))schema=schemas.at(c.fromNode);}
        if(kind=="Source"){++sources;schema=datasetSchema(config.at("schema"));}
        else if(kind=="Define"){
            const auto t=inferExpression(config.at("expression"),schema);if(t.boolean||t.collection)throw std::invalid_argument("Observable must be scalar numeric");
            const auto name=config.at("name").get<std::string>();if(name.empty()||name.starts_with("__hep"))throw std::invalid_argument("Invalid observable name");
            for(const auto& c:schema.columns)if(c.name==name)throw std::invalid_argument("Observable name already exists");
            schema.columns.push_back({name,"double","1",true,false,scalar(t.dimension)});
        }else if(kind=="Filter"){if(!inferExpression(config.at("expression"),schema).boolean)throw std::invalid_argument("Filter must produce a Boolean");}
        else if(kind!="Count"&&kind!="Fit"){
            if(inferExpression(config.at("expression"),schema).boolean)throw std::invalid_argument("Action requires a numeric observable");
            if(config.contains("weight")&&!config["weight"].is_null()){auto t=inferExpression(config["weight"],schema);if(t.boolean||t.collection||t.dimension!=dimensionless)throw std::invalid_argument("Weight must be dimensionless scalar");}
        }
        schemas.emplace(id,std::move(schema));plan["nodes"].push_back(item);
    }
    if(sources!=1)throw std::invalid_argument("Part 2 executes one dataset source per workflow");
    return plan;
}
}
