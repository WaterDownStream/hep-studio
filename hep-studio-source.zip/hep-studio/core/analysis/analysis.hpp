#pragma once
#include "core/vpir/model.hpp"
#include <map>
namespace hep {
struct ColumnSchema {std::string name,backendType,units{"1"};bool unitKnown{false},collection{false};Type type;Json metadata=Json::object();};
struct DatasetSchema {std::string object,format;std::uint64_t entries{};std::vector<ColumnSchema> columns;Json metadata=Json::object();};
DatasetSchema datasetSchema(const Json&);
struct ExpressionType {Dimension dimension{};bool boolean{false};bool collection{false};};
ExpressionType inferExpression(const Json&,const DatasetSchema&);
Json columnExpression(const std::string&);
Json literalExpression(double,const std::string& unit="1");
Node rootNode(std::string_view kind,Id id,double x=0,double y=0);
Json lowerRoot(const Workflow&);
}
