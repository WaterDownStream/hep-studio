#pragma once
#include "core/vpir/model.hpp"
#include "core/validation/issue.hpp"
namespace hep {
const Node* findNode(const Workflow&, const Id&);
const Port* findPort(const Node&, const Id&);
std::vector<ValidationIssue> validate(const Workflow&);
std::optional<ValidationIssue> connect(Workflow&, Connection);
std::vector<Id> topologicalOrder(const Workflow&);
}
