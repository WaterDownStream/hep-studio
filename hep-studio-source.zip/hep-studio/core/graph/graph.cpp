#include "core/graph/graph.hpp"
#include "core/units/units.hpp"
#include <algorithm>
#include <map>
#include <set>
#include <cmath>
#include <stdexcept>
namespace hep {
const Node* findNode(const Workflow& w, const Id& id) {
    for (const auto& n : w.nodes) if (n.id==id) return &n;
    return nullptr;
}
const Port* findPort(const Node& n, const Id& id) {
    for (const auto& p : n.ports) if (p.id==id) return &p;
    return nullptr;
}
std::vector<Id> topologicalOrder(const Workflow& w) {
    std::map<Id,int> degree;
    std::map<Id,std::vector<Id>> children;
    for (const auto& n : w.nodes) degree.emplace(n.id,0);
    for (const auto& c : w.connections) {
        if (!degree.contains(c.fromNode) || !degree.contains(c.toNode)) throw std::invalid_argument("Dangling connection");
        ++degree.at(c.toNode); children[c.fromNode].push_back(c.toNode);
    }
    std::set<Id> ready;
    for (const auto& [id,d] : degree) if (d==0) ready.insert(id);
    std::vector<Id> ordered;
    while (!ready.empty()) {
        auto id=*ready.begin(); ready.erase(ready.begin()); ordered.push_back(id);
        for (const auto& next : children[id]) if (--degree.at(next)==0) ready.insert(next);
    }
    if (ordered.size()!=w.nodes.size()) throw std::invalid_argument("Graph contains a cycle or duplicate node IDs");
    return ordered;
}
std::vector<ValidationIssue> validate(const Workflow& w) {
    std::vector<ValidationIssue> issues;
    auto error=[&](std::string code,std::string msg,std::optional<Id> id=std::nullopt) {
        issues.push_back({Severity::Error,std::move(code),std::move(msg),std::move(id)});
    };
    if (w.nodes.empty()) error("empty_graph","Add a node before running the workflow.");
    std::set<Id> ids;
    for (const auto& n : w.nodes) {
        if (!ids.insert(n.id).second) error("duplicate_node","Node IDs must be unique.",n.id);
        if (n.version==0 || n.typeId.empty()) error("node_descriptor","Node type and a positive version are required.",n.id);
        if (!std::isfinite(n.x) || !std::isfinite(n.y)) error("position","Node position must be finite.",n.id);
        std::set<Id> ports;
        for (const auto& p : n.ports) {
            if (!ports.insert(p.id).second) error("duplicate_port","Port IDs must be unique within a node.",n.id);
            if (p.type.name.empty()) error("port_type","A port requires a type.",n.id);
        }
        std::set<std::string> params;
        for (const auto& p : n.parameters) {
            if (!params.insert(p.name).second) error("duplicate_parameter","Parameter names must be unique.",n.id);
            if (p.type.name=="Scalar") {
                try {
                    if (!p.value.is_number() || !p.defaultValue.is_number()) throw std::invalid_argument("Scalar values must be numeric.");
                    const auto value=p.value.get<double>();
                    if (!std::isfinite(value) || !std::isfinite(p.defaultValue.get<double>())) throw std::invalid_argument("Values must be finite.");
                    if (unit(p.units).dimension != p.type.dimension) throw std::invalid_argument("Parameter units do not match its type.");
                    if ((p.minimum && value<*p.minimum) || (p.maximum && value>*p.maximum) || (p.minimum && p.maximum && *p.minimum>*p.maximum))
                        throw std::invalid_argument("Parameter is outside its allowed range.");
                } catch (const std::exception& e) { error("parameter",e.what(),n.id); }
            }
        }
    }
    std::set<std::pair<Id,Id>> occupied;
    for (const auto& c : w.connections) {
        const auto* a=findNode(w,c.fromNode); const auto* b=findNode(w,c.toNode);
        if (!a || !b) { error("missing_node","Connection references a missing node."); continue; }
        const auto* out=findPort(*a,c.fromPort); const auto* in=findPort(*b,c.toPort);
        if (!out || !in) { error("missing_port","Connection references a missing port."); continue; }
        if (out->direction!=Direction::Output || in->direction!=Direction::Input) error("direction","Connect an output to an input.",b->id);
        if (!compatible(out->type,in->type)) error("type_mismatch",out->type.name+" cannot connect to "+in->type.name+".",b->id);
        if (out->streaming!=in->streaming) error("streaming_mismatch","Streaming and materialized ports require an explicit adapter.",b->id);
        if (!occupied.insert({b->id,in->id}).second) error("input_cardinality","An input accepts one connection.",b->id);
    }
    for (const auto& n : w.nodes) for (const auto& p : n.ports)
        if (p.direction==Direction::Input && !p.optional && !occupied.contains({n.id,p.id}))
            error("required_input","Connect the required input of "+n.name+".",n.id);
    try { (void)topologicalOrder(w); } catch (const std::exception& e) { error("dependency",e.what()); }
    return issues;
}
std::optional<ValidationIssue> connect(Workflow& w, Connection c) {
    auto candidate=w; candidate.connections.push_back(std::move(c));
    for (const auto& issue : validate(candidate)) if (issue.code!="required_input" && issue.severity==Severity::Error) return issue;
    w=std::move(candidate); return std::nullopt;
}
}
