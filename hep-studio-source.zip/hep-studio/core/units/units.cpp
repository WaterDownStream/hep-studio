#include "core/units/units.hpp"
#include <cmath>
#include <stdexcept>
namespace hep {
const Unit& unit(std::string_view symbol) {
    static const Unit units[]{ {"1",dimensionless,1}, {"GeV",energy,1}, {"MeV",energy,0.001},
      {"mm",length,1}, {"cm",length,10}, {"ns",timeDimension,1}, {"rad",angle,1},
      {"eV",energy,1e-9}, {"keV",energy,1e-6}, {"TeV",energy,1000}, {"m",length,1000}, {"s",timeDimension,1e9},
      {"pb",area,1e-34}, {"fb^-1",inverseArea,1e37} };
    for (const auto& u : units) if (u.symbol == symbol) return u;
    throw std::invalid_argument("Unknown unit: " + std::string(symbol));
}
Quantity::Quantity(double v, Unit u) : value(v), units(std::move(u)) {
    if (!std::isfinite(value) || !std::isfinite(units.scale) || units.scale <= 0)
        throw std::invalid_argument("Quantity must be finite and unit scale positive");
}
Quantity Quantity::convertedTo(const Unit& target) const {
    if (units.dimension != target.dimension) throw std::invalid_argument("Incompatible physical dimensions");
    return {value * units.scale / target.scale, target};
}
Quantity Quantity::operator+(const Quantity& other) const { return {value + other.convertedTo(units).value, units}; }
}
