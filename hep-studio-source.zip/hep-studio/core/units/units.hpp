#pragma once
#include "core/types/types.hpp"
namespace hep {
struct Unit { std::string symbol; Dimension dimension; double scale; };
const Unit& unit(std::string_view symbol);
struct Quantity {
    double value;
    Unit units;
    Quantity(double v, Unit u);
    Quantity convertedTo(const Unit&) const;
    Quantity operator+(const Quantity&) const;
};
}
