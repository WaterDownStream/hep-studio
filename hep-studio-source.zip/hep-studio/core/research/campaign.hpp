#pragma once
#include "core/research/research.hpp"
namespace hep {
// Stable bindings reuse canonical node config; no full copied project per point.
struct ParameterBinding {Id node;std::string pointer;std::string units{"1"};};
std::vector<Parameter> parameterBindings(const Node&);
Workflow varyParameter(const Workflow&,const ParameterBinding&,const Json& value);
std::vector<Workflow> scanWorkflows(const Workflow&,const Json& specification);
Json validateSystematics(const Workflow&,const Json& specifications);
}
