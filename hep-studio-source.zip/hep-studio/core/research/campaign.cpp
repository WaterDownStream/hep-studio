#include "core/research/campaign.hpp"
#include "core/units/units.hpp"
#include "core/graph/graph.hpp"
#include <cmath>
#include <algorithm>
#include <limits>
#include <set>
#include <stdexcept>
namespace hep {
static std::string bindingUnit(const Node& n,const std::string& pointer){
    if(pointer.ends_with("/value")){
        const auto parent=n.extensions.value("config",Json::object()).at(Json::json_pointer(pointer.substr(0,pointer.size()-6)));
        if(parent.is_object()&&parent.contains("unit"))return parent.at("unit");
    }
    if(pointer.starts_with("/beam/energiesGeV/")||pointer=="/energyGeV"||pointer=="/pTHatMinGeV"||pointer=="/minimumPtGeV")return "GeV";
    if(n.typeId=="hep.research.MadGraph"&&(pointer=="/runCard/ptl"||pointer=="/runCard/ptj"||pointer=="/runCard/mmll"||pointer.starts_with("/parameters/mass:")||pointer.starts_with("/parameters/decay:")))return "GeV";
    return "1";
}
std::vector<Parameter> parameterBindings(const Node& n){
    std::vector<Parameter> result;const auto c=n.extensions.value("config",Json::object());
    const auto flattened=c.flatten();
    for(const auto& [pointer,value]:flattened.items()){
        if(!value.is_number()&&!value.is_boolean())continue;
        if(pointer=="/workers")continue;
        const auto units=bindingUnit(n,pointer);Parameter p{};p.name=pointer;p.type=value.is_boolean()?Type{"Bool",Primitive::Bool,dimensionless}:scalar(unit(units).dimension);p.value=value;p.defaultValue=nullptr;p.units=units;
        p.role="scan-capable";p.origin="node-config";p.extensions={{"bindingVersion",1},{"nodeId",n.id.value},{"jsonPointer",pointer},{"backendKey",pointer},{"defaultKnown",false}};result.push_back(std::move(p));
    }return result;
}
Workflow varyParameter(const Workflow& w,const ParameterBinding& binding,const Json& value){
    Workflow result=w;Node* node=nullptr;for(auto& n:result.nodes)if(n.id==binding.node){node=&n;break;}
    if(!node)throw std::invalid_argument("Unknown scan/systematic node binding");
    if(binding.pointer.empty()||binding.pointer.front()!='/'||binding.pointer=="/workers")throw std::invalid_argument("Scientific variations cannot bind execution budgets");
    const auto expected=unit(bindingUnit(*node,binding.pointer));const auto supplied=unit(binding.units);
    if(expected.dimension!=supplied.dimension)throw std::invalid_argument("Scan/variation binding has incompatible units");
    auto& destination=node->extensions.at("config").at(Json::json_pointer(binding.pointer));
    if(destination.is_boolean()){if(!value.is_boolean())throw std::invalid_argument("Boolean variation required");destination=value;}
    else if(destination.is_number()){
        const double number=value.get<double>()*supplied.scale/expected.scale;if(!std::isfinite(number))throw std::invalid_argument("Finite numeric variation required");
        if(destination.is_number_integer()){if(std::floor(number)!=number||number<-9223372036854775808.0||number>=9223372036854775808.0)throw std::invalid_argument("Representable integer parameter variation required");destination=static_cast<std::int64_t>(number);}else destination=number;
    }else if(destination.is_string()){if(!value.is_string())throw std::invalid_argument("String variation required");destination=value;}
    else throw std::invalid_argument("Bind a scalar parameter, not an entire configuration object");
    return result;
}
std::vector<Workflow> scanWorkflows(const Workflow& nominal,const Json& specification){
    const auto& axes=specification.at("axes");if(!axes.is_array()||axes.empty()||axes.size()>3)throw std::invalid_argument("Scan requires one to three axes");
    std::vector<Workflow> points{nominal};std::set<std::string> seen;
    for(const auto& axis:axes){
        ParameterBinding binding{Id(axis.at("nodeId")),axis.at("pointer"),axis.value("unit","1")};
        if(!seen.insert(binding.node.value+binding.pointer).second)throw std::invalid_argument("Duplicate scan axis binding");
        Json values=axis.value("values",Json::array());const auto mode=axis.value("spacing","explicit");
        if(mode!="explicit"){
            const int count=axis.at("count");const double lo=axis.at("lower"),hi=axis.at("upper");
            if(count<2||count>64||!std::isfinite(lo+hi)||lo>=hi||(mode=="log"&&lo<=0)||(mode!="log"&&mode!="linear"))throw std::invalid_argument("Invalid scan range");
            for(int i=0;i<count;++i){const auto fraction=static_cast<double>(i)/(count-1);values.push_back(mode=="log"?std::exp(std::log(lo)+(std::log(hi)-std::log(lo))*fraction):lo+(hi-lo)*fraction);}
        }
        if(!values.is_array()||values.empty()||values.size()*points.size()>64)throw std::invalid_argument("Interactive research scans are limited to 64 explicit points");
        std::vector<Workflow> next;for(const auto& point:points)for(const auto& value:values)next.push_back(varyParameter(point,binding,value));points=std::move(next);
    }return points;
}
Json validateSystematics(const Workflow& w,const Json& specifications){
    if(!specifications.is_array()||specifications.size()>32)throw std::invalid_argument("Systematic descriptor limit");
    std::set<std::string> ids;const std::set<std::string> kinds{"normalization","shape","parameter","weight","alternative-sample","detector","generator"};
    for(const auto& s:specifications){
        const auto id=s.at("id").get<std::string>();if(id.empty()||!ids.insert(id).second||!kinds.contains(s.at("kind")))throw std::invalid_argument("Invalid systematic identity/kind");
        if(!s.contains("correlation")||!s.contains("interpretation")||!s.contains("nominal")||!s.at("variations").is_array()||s.at("variations").empty()||s.at("variations").size()>8)throw std::invalid_argument("Systematics require explicit nominal, variations, correlation and interpretation");
        if(!s.at("affectedNodes").is_array()||s.at("affectedNodes").empty()||!s.at("correlation").is_object()||s.at("correlation").value("group",std::string()).empty()||s.at("interpretation").get<std::string>().empty())throw std::invalid_argument("Systematics require affected identities, a correlation group and an explicit interpretation");
        for(const auto& affected:s.at("affectedNodes"))if(!findNode(w,Id(affected)))throw std::invalid_argument("Unknown affected systematic node");
        std::set<std::string> labels;
        for(const auto& variation:s.at("variations")){
            const auto label=variation.at("label").get<std::string>();if(label.empty()||!labels.insert(label).second)throw std::invalid_argument("Systematic variation labels must be nonempty and unique");
            const auto kind=s.at("kind").get<std::string>();
            if(kind=="normalization"){const double factor=variation.at("factor");if(!std::isfinite(factor)||factor<0)throw std::invalid_argument("Finite nonnegative normalization factor required");}
            if(kind=="parameter"||kind=="detector"||kind=="generator"||kind=="alternative-sample"){
                if(!variation.at("bindings").is_array()||variation.at("bindings").empty())throw std::invalid_argument("Explicit systematic parameter bindings required");
                for(const auto& binding:variation.at("bindings")){
                    if(std::find(s.at("affectedNodes").begin(),s.at("affectedNodes").end(),binding.at("nodeId"))==s.at("affectedNodes").end())throw std::invalid_argument("Systematic binding changes an undeclared node");
                    const auto* node=findNode(w,Id(binding.at("nodeId")));const auto pointer=binding.at("pointer").get<std::string>();
                    (void)varyParameter(w,{node->id,pointer,binding.value("unit",bindingUnit(*node,pointer))},binding.at("value"));
                }
            }
        }
    }return specifications;
}
}
