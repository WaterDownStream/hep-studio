#include "core/research/research.hpp"
#include "core/research/campaign.hpp"
#include "core/graph/graph.hpp"
#include <set>
#include <cmath>
#include <stdexcept>
namespace hep {
DatasetSchema reconstructedSchema(bool collection,const std::string& semanticType){
    DatasetSchema s{"Reconstructed objects","ReconstructedEventDataset",0,{}};
    for(const auto* key:{"pt","eta","phi","mass","energy","charge","weight","value"}){
        const std::string name=key;const auto dim=name=="eta"||name=="charge"||name=="weight"?dimensionless:name=="phi"?angle:energy;
        s.columns.push_back({name,"double",dim==energy?"GeV":dim==angle?"rad":"1",true,collection&&name!="weight",scalar(dim)});
    }
    if(semanticType=="RecoMuonCollection"||semanticType=="RecoElectronCollection"||semanticType=="RecoLeptonCollection"||semanticType=="RecoPhotonCollection")s.columns.push_back({"isolation","double","1",true,collection,scalar(dimensionless)});
    if(semanticType=="RecoJetCollection")s.columns.push_back({"btag","unsigned int","1",true,collection,scalar(dimensionless)});
    s.metadata["semanticType"]=semanticType;return s;
}
Node researchNode(std::string_view kind,Id id,double x,double y,const std::string& collectionType,const std::string& referenceType){
    Node n{std::move(id),"hep.research."+std::string(kind),1,std::string(kind),{}, {}};n.x=x;n.y=y;
    auto in=[&](const std::string& t){n.ports.push_back({Id("in"),"Input",Direction::Input,domain(t)});};
    auto out=[&](const std::string& t){n.ports.push_back({Id("out"),"Output",Direction::Output,domain(t)});};Json c=Json::object();
    if(kind=="MadGraph"){
        out("LHEEventSample");n.name="MadGraph Process";n.semantics=Semantics::Randomized;n.threadSafe=false;
        c={{"model","sm"},{"accuracy","LO"},{"process",{{"incoming",Json::array({-11,11})},{"outgoing",Json::array({-13,13})},{"exclude",Json::array({23})}}},
           {"beam",{{"ids",Json::array({-11,11})},{"energiesGeV",Json::array({50.,50.})}}},{"events",100},{"seed",24680},
           {"runCard",{{"ptl",0.},{"etal",-1.},{"drll",0.}}},{"parameters",Json::object()}};
    }else if(kind=="LHESource"){out("LHEEventSample");c={{"resourceId",""}};}
    else if(kind=="Shower"){
        in("LHEEventSample");out("EventStream");n.name="PYTHIA Shower";n.semantics=Semantics::Randomized;
        c={{"isr",true},{"fsr",true},{"mpi",true},{"hadronisation",true},{"tune",14},{"seedStrategy","fixed"},{"seed","1"},
           {"streamPolicy","lhe-logical-blocks-v1"},{"partitionEvents",4096},{"advanced",Json::object()},{"rawOverrides",Json::array()},{"pdf",Json::object()},{"decays",Json::array()}};
    }else if(kind=="Delphes"){
        in("EventStream");out("ReconstructedEventDataset");n.name="Delphes Detector";n.semantics=Semantics::Randomized;
        c={{"card",{{"builtin","CMS"}}},{"seed",24680},{"streamPolicy","detector-logical-blocks-v1"}};
    }else if(kind=="RecoSource"){out("ReconstructedEventDataset");c={{"resourceId",""},{"object","Delphes"}};}
    else if(kind=="TemplateSet"){
        out("HistogramSet");n.name="Statistical Templates";
        c={{"samples",Json::array()},{"flowPolicy","exclude-unfolded-flows"}};
    }else if(kind=="BinnedLikelihood"){
        in("HistogramSet");out("LikelihoodModel");n.name="Binned Likelihood";n.semantics=Semantics::GlobalAggregation;
        c={{"datasetRole","background-asimov"},{"muMax",5.},{"mcStat","none"},{"interpolation","histfactory-default"},{"nuisances",Json::array()}};
    }else if(kind=="Inference"){
        in("LikelihoodModel");out("HypothesisResult");n.name="Template CLs";n.semantics=Semantics::GlobalAggregation;
        c={{"method","asymptotic-profile-likelihood"},{"testStatistic","one-sided-qmu"},{"useCLs",true},{"confidenceLevel",0.95},{"points",40}};
    }else if(kind=="RooFit"){
        in("Histogram1D");out("FitResult");n.semantics=Semantics::GlobalAggregation;
        c={{"model",{{"kind","Gaussian"},{"mean",{{"value",100.},{"lower",80.},{"upper",120.}}},{"sigma",{{"value",1.},{"lower",0.01},{"upper",20.}}}}},{"errorModel","sumw2"},{"constraints",Json::array()}};
    }else if(kind=="RooStats"){
        in("Histogram1D");out("HypothesisResult");n.semantics=Semantics::GlobalAggregation;
        c={{"signalSource","histogram-integral"},{"background",20.},{"observed",20.},{"datasetRole","asimov"},{"method","asymptotic-profile-likelihood"},
           {"testStatistic","one-sided-qmu"},{"useCLs",true},{"confidenceLevel",0.95},{"muMax",5.},{"points",40}};
    }
    else if(kind=="Muons"||kind=="Electrons"||kind=="Jets"||kind=="MissingET"||kind=="Photons"||kind=="Tracks"){
        in("ReconstructedEventDataset");out(kind=="Muons"?"RecoMuonCollection":kind=="Electrons"?"RecoElectronCollection":kind=="Jets"?"RecoJetCollection":kind=="Photons"?"RecoPhotonCollection":kind=="Tracks"?"RecoTrackCollection":"RecoMissingETCollection");
    }else{
        static const std::set<std::string> collections{"RecoMuonCollection","RecoElectronCollection","RecoLeptonCollection","RecoJetCollection","RecoMissingETCollection","RecoPairCollection","RecoPhotonCollection","RecoTrackCollection"};
        if(!collections.contains(collectionType))throw std::invalid_argument("Unsupported reconstructed collection semantic type");
        c["collectionType"]=collectionType;in(collectionType);
        if(kind=="CollectionFilter"){out(collectionType);c["expression"]={{"op","gt"},{"args",Json::array({columnExpression("pt"),literalExpression(10,"GeV")})}};}
        else if(kind=="CollectionSort"){out(collectionType);c["property"]="pt";c["descending"]=true;}
        else if(kind=="CollectionTake"){out(collectionType);c["count"]=2;}
        else if(kind=="OverlapRemoval"||kind=="CollectionCombine"){
            const std::set<std::string> physical{"RecoMuonCollection","RecoElectronCollection","RecoLeptonCollection","RecoJetCollection","RecoPhotonCollection","RecoTrackCollection"};
            if(!physical.contains(collectionType)||!physical.contains(referenceType))throw std::invalid_argument("Binary object operations require reconstructed particle/jet collections");
            n.ports.push_back({Id("reference"),"Reference objects",Direction::Input,domain(referenceType)});c["referenceType"]=referenceType;
            if(kind=="OverlapRemoval"){out(collectionType);c["radius"]=0.4;c["boundary"]="strict-less-than";}
            else{
                const std::set<std::string> leptons{"RecoMuonCollection","RecoElectronCollection","RecoLeptonCollection"};
                if(collectionType!=referenceType&&(!leptons.contains(collectionType)||!leptons.contains(referenceType)))throw std::invalid_argument("Combine compatible object types or explicitly combine electrons/muons as reconstructed leptons");
                out(collectionType==referenceType?collectionType:"RecoLeptonCollection");c["order"]="primary-then-reference";c["duplicates"]="source-object-once";
            }
        }
        else if(kind=="Pairs"){if(collectionType!="RecoMuonCollection"&&collectionType!="RecoElectronCollection"&&collectionType!="RecoLeptonCollection")throw std::invalid_argument("Pair builder requires a charged lepton collection");out("RecoPairCollection");c["oppositeSign"]=true;c["sameFlavour"]=true;}
        else if(kind=="Property"){out("EventTable");c["property"]=collectionType=="RecoPairCollection"?"mass":"pt";}
        else if(kind=="CollectionCount"||kind=="HT"){out("EventTable");}
        else throw std::invalid_argument("Unsupported research node");
    }
    n.extensions["config"]=c;return n;
}
Json lowerResearch(const Workflow& w){
    for(const auto& issue:validate(w))if(issue.severity==Severity::Error)throw std::invalid_argument(issue.message);
    Json plan={{"version",1},{"backend","hep.research/1"},{"nodes",Json::array()},{"requiredLibraries",Json::array()},{"requiredThreads",1}};
    std::set<std::string> required;std::map<Id,DatasetSchema> schemas;int sources=0;
    for(const auto& id:topologicalOrder(w)){
        const auto& n=*findNode(w,id);const bool root=n.typeId.starts_with("hep.root.");
        if(!root&&!n.typeId.starts_with("hep.research."))throw std::invalid_argument("Unsupported research node contract");
        const auto kind=n.typeId.substr(root?9:13);auto c=n.extensions.at("config");
        const auto expected=root?rootNode(kind,id):researchNode(kind,id,0,0,c.value("collectionType","RecoMuonCollection"),c.value("referenceType","RecoMuonCollection"));
        if(n.version!=1||n.ports.size()!=expected.ports.size())throw std::invalid_argument("Altered research node contract");
        for(const auto& p:expected.ports){const auto* a=findPort(n,p.id);if(!a||a->type!=p.type||a->direction!=p.direction||!a->streaming||a->optional)throw std::invalid_argument("Altered research semantic port contract");}
        Json item={{"id",id.value},{"kind",kind},{"config",c}};auto s=reconstructedSchema(true);
        for(const auto& edge:w.connections)if(edge.toNode==id){
            if(edge.toPort==Id("reference"))item["reference"]=edge.fromNode.value;
            else{item["input"]=edge.fromNode.value;s=schemas.at(edge.fromNode);}
        }
        if(kind=="OverlapRemoval"){
            const auto radius=c.at("radius").get<double>();
            if(!std::isfinite(radius)||radius<0||radius>10||c.value("boundary","")!="strict-less-than")throw std::invalid_argument("Overlap radius must be finite in [0,10]; boundary is deltaR < radius");
            if(item.at("input")==item.at("reference"))throw std::invalid_argument("Choose a distinct overlap reference branch");
        }
        if(kind=="CollectionCombine"&&(c.value("order","")!="primary-then-reference"||c.value("duplicates","")!="source-object-once"))throw std::invalid_argument("Collection combination requires explicit ordered union without duplicated source objects");
        if(kind=="MadGraph"||kind=="LHESource"||kind=="RecoSource"||kind=="TemplateSet")++sources;
        if(kind=="MadGraph"){
            required.insert("MadGraph");const auto model=c.value("model",std::string("sm"));
            if(model!="sm"&&model!="sm-full")throw std::invalid_argument("Supported identified MadGraph LO models are sm and sm-full; external UFO resources are not supported");
            if(c.value("accuracy",std::string("LO"))!="LO")throw std::invalid_argument("Only verified LO model generation is supported");
        }
        if(kind=="Shower"){
            required.insert("PYTHIA");required.insert("HepMC3");
            const auto workers=c.value("workers",Json(1));if(!workers.is_number_integer()||workers.get<int>()<1||workers.get<int>()>32)throw std::invalid_argument("Shower worker budget must be in [1,32]");
            plan["requiredThreads"]=workers;
            if(!c.value("pdf",Json::object()).value("set",std::string()).empty())required.insert("LHAPDF");
        }
        if(kind=="Delphes")required.insert("Delphes");
        if(kind=="RooFit"||kind=="RooStats")required.insert(kind);
        if(kind=="TemplateSet"||kind=="BinnedLikelihood"||kind=="Inference"){
            required.insert("ROOT");required.insert("RooFit");required.insert("RooStats");required.insert("HistFactory");
        }
        for(const auto& port:expected.ports)if(port.direction==Direction::Output&&port.type.name.starts_with("Reco")&&port.type.name.ends_with("Collection"))s=reconstructedSchema(true,port.type.name);
        if(kind=="CollectionFilter"){
            auto t=inferExpression(c.at("expression"),reconstructedSchema(false,c.at("collectionType")));if(!t.boolean||t.collection)throw std::invalid_argument("Object selection must be a scalar Boolean");
        }
        if(kind=="Property"||kind=="CollectionSort"){
            const auto name=c.at("property").get<std::string>();const auto type=inferExpression(columnExpression(name),reconstructedSchema(false,c.at("collectionType")));
            if(name=="weight"||name=="value")throw std::invalid_argument("Select a reconstructed object property");
            if(kind=="Property")for(auto& col:s.columns)if(col.name=="value")col.type=scalar(type.dimension);
        }
        if(kind=="CollectionCount"||kind=="HT")for(auto& col:s.columns)if(col.name=="value"){col.collection=false;col.type=scalar(kind=="HT"?energy:dimensionless);}
        if(root){
            required.insert("ROOT");
            if(kind=="Source")throw std::invalid_argument("Use a reconstructed dataset source for a research workflow");
            if(kind=="Filter"){
                const auto t=inferExpression(c.at("expression"),s);if(!t.boolean||t.collection)throw std::invalid_argument("Event filter must be scalar Boolean");
            }else if(kind=="Define"){
                const auto t=inferExpression(c.at("expression"),s);const auto name=c.at("name").get<std::string>();
                if(t.boolean||t.collection||name.empty()||name.starts_with("__hep"))throw std::invalid_argument("Invalid scalar event observable");
                for(const auto& col:s.columns)if(col.name==name)throw std::invalid_argument("Observable already exists");
                s.columns.push_back({name,"double","1",true,false,scalar(t.dimension)});
            }else if(kind!="Count"&&kind!="Fit"){
                const auto t=inferExpression(c.at("expression"),s);if(t.boolean)throw std::invalid_argument("Numeric observable required");item["dimension"]=t.dimension.powers;
            }
            if(c.contains("weight")&&!c["weight"].is_null()){const auto t=inferExpression(c["weight"],s);if(t.boolean||t.collection||t.dimension!=dimensionless)throw std::invalid_argument("Histogram weight must be dimensionless scalar");}
        }
        schemas.emplace(id,std::move(s));plan["nodes"].push_back(item);
    }
    if(sources!=1)throw std::invalid_argument("Research workflows require one identified source");
    for(const auto& lib:required)plan["requiredLibraries"].push_back(lib);
    if(w.extensions.contains("systematics")){
        plan["systematics"]=validateSystematics(w,w.extensions.at("systematics"));
        // Scientific quantities are converted at the typed core boundary. The
        // worker receives canonical values rather than guessing display units.
        for(auto& descriptor:plan["systematics"])for(auto& variation:descriptor["variations"])if(variation.contains("bindings"))for(auto& binding:variation["bindings"]){
            auto units=binding.value("unit",std::string("1"));if(!binding.contains("unit"))for(const auto& p:parameterBindings(*findNode(w,Id(binding.at("nodeId")))))if(p.name==binding.at("pointer").get<std::string>())units=p.units;
            const auto changed=varyParameter(w,{Id(binding.at("nodeId")),binding.at("pointer"),units},binding.at("value"));
            const auto* changedNode=findNode(changed,Id(binding.at("nodeId")));binding["value"]=changedNode->extensions.at("config").at(Json::json_pointer(binding.at("pointer")));binding["representation"]="canonical";
        }
    }
    return plan;
}
Workflow researchExample(){
    Workflow w{newId(),"Reconstructed dimuon mass",{}, {}};
    for(const auto* kind:{"MadGraph","Shower","Delphes","Muons","CollectionFilter","Pairs"})w.nodes.push_back(researchNode(kind,newId()));
    w.nodes.push_back(researchNode("Property",newId(),0,0,"RecoPairCollection"));
    auto h=rootNode("Histo1D",newId());h.extensions["config"]={{"expression",columnExpression("value")},{"bins",40},{"lower",80.},{"upper",120.},{"normalization","counts"},{"flow","separate"}};w.nodes.push_back(h);
    for(std::size_t i=1;i<w.nodes.size();++i)w.connections.push_back({w.nodes[i-1].id,Id("out"),w.nodes[i].id,Id("in")});
    return w;
}
}
