#pragma once
#include "core/analysis/analysis.hpp"
namespace hep {
// Semantic collection identities are separate from generator particles/jets.
Node researchNode(std::string_view kind,Id id,double x=0,double y=0,
                  const std::string& collectionType="RecoMuonCollection",
                  const std::string& referenceType="RecoMuonCollection");
DatasetSchema reconstructedSchema(bool collection=false,const std::string& semanticType="");
Json lowerResearch(const Workflow&);
Workflow researchExample();
}
