#pragma once
#include "core/vpir/model.hpp"
namespace hep {
enum class JobState { Queued, Preparing, Compiling, Running, Finalizing, Completed, Failed, Cancelled, Interrupted };
struct Run {
    Id id;
    std::string status;
    Json workflowSnapshot;
    std::string workflowHash;
    std::string environment{"hep-env://mock/1"};
    std::string backend{"hep.mock/1"};
    std::string seed{"0"}; // Decimal string retains all 64 bits through JSON consumers.
    std::string started{}, ended{};
    Json resources=Json::object();
    Json result=Json::object();
    Json logs=Json::array();
    Json extensions=Json::object();
};
}
