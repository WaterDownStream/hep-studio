#include "plugins/pythia/adapter.hpp"
#include <algorithm>
#include <cctype>
#include <cmath>
#include <set>
#include <sstream>
#include <type_traits>
#if defined(HEP_HAS_LHAPDF) && PYTHIA_VERSION_INTEGER >= 8318
#include <Pythia8Plugins/LHAPDF6.h>
#endif
namespace hep::pythia {
bool externalPdfAvailable(){
#if defined(HEP_HAS_LHAPDF) && PYTHIA_VERSION_INTEGER >= 8318
    return true;
#else
    return false;
#endif
}
std::unique_ptr<Pythia8::Pythia> create(const std::string& path){return std::make_unique<Pythia8::Pythia>(path,false);}
Json processes(){return Json::array({
    {{"id","qcd"},{"label","QCD — hard parton scattering"},{"setting","HardQCD:all"}},
    {{"id","dy"},{"label","Drell–Yan / Z / gamma*"},{"setting","WeakSingleBoson:ffbar2gmZ"}},
    {{"id","w"},{"label","W boson"},{"setting","WeakSingleBoson:ffbar2W"}},
    {{"id","higgs"},{"label","Higgs — Standard Model"},{"setting","HiggsSM:all"}},
    {{"id","top"},{"label","Top pair"},{"setting","Top:gg2ttbar"}},
    {{"id","minimum-bias"},{"label","Minimum bias — non-diffractive QCD"},{"setting","SoftQCD:nonDiffractive"}}});}
static std::string lower(std::string s){std::transform(s.begin(),s.end(),s.begin(),[](unsigned char c){return static_cast<char>(std::tolower(c));});return s;}
Json metadata(Pythia8::Pythia& p,const std::string& search,bool changedOnly,unsigned limit){
    Json rows=Json::array();unsigned total=0;
    auto add=[&](const auto& v,const char* kind){
        if(!search.empty()&&lower(v.name).find(lower(search))==std::string::npos)return;
        if(changedOnly&&v.valNow==v.valDefault)return;
        ++total;if(rows.size()>=limit)return;
        Json row={{"key",v.name},{"type",kind},{"value",v.valNow},{"default",v.valDefault},{"changed",v.valNow!=v.valDefault},
                  {"documentation","Installed PYTHIA manual: "+v.name.substr(0,v.name.find(':'))},{"source","installed-library"}};
        if constexpr(std::is_same_v<std::decay_t<decltype(v)>,Pythia8::Mode>||std::is_same_v<std::decay_t<decltype(v)>,Pythia8::Parm>){if(v.hasMin)row["minimum"]=v.valMin;if(v.hasMax)row["maximum"]=v.valMax;}
        rows.push_back(row);
    };
    for(const auto& [k,v]:p.settings.getFlagMap(""))add(v,"Bool");
    for(const auto& [k,v]:p.settings.getModeMap(""))add(v,"Integer");
    for(const auto& [k,v]:p.settings.getParmMap(""))add(v,"Float");
    for(const auto& [k,v]:p.settings.getWordMap(""))add(v,"String");
    return {{"settings",rows},{"total",total},{"truncated",total>rows.size()}};
}
static Json configureImpl(Pythia8::Pythia& p,const Json& c,int seed,const std::string& lhe){
    if(seed<1||seed>900000000)throw std::invalid_argument("PYTHIA seed must be between 1 and 900000000");
    Json settings=Json::array();std::set<std::string> graphical;
    auto set=[&](const std::string& key,const Json& value,bool primary=true){
        std::string text=value.is_string()?value.get<std::string>():value.is_boolean()?(value.get<bool>()?"on":"off"):value.dump();
        if(text.find_first_of("\r\n")!=std::string::npos)throw std::invalid_argument("One value per PYTHIA setting");
        // PYTHIA may clamp out-of-range input. Reject it before applying so the
        // saved graphical value always describes the actual scientific setting.
        if(p.settings.isMode(key)||p.settings.isParm(key)){
            std::istringstream input(text);double number{};input>>number;
            if(input.fail()||!std::isfinite(number))throw std::invalid_argument("Invalid numeric setting: "+key);
            input>>std::ws;if(!input.eof())throw std::invalid_argument("Trailing text in numeric setting: "+key);
            auto check=[&](const auto& values){for(const auto& [unused,v]:values)if(lower(v.name)==lower(key)){
                if((v.hasMin&&number<v.valMin)||(v.hasMax&&number>v.valMax))throw std::invalid_argument("Setting outside installed PYTHIA range: "+key);
            }};
            if(p.settings.isMode(key)){if(number!=std::floor(number))throw std::invalid_argument("Integer setting required: "+key);check(p.settings.getModeMap(key));}
            else check(p.settings.getParmMap(key));
        }
        if(!p.readString(key+" = "+text))throw std::invalid_argument("PYTHIA rejected setting: "+key);
        settings.push_back(key+" = "+text);if(primary)graphical.insert(lower(key));
    };
    const double energy=c.value("energyGeV",13600.);if(!std::isfinite(energy)||energy<=0)throw std::invalid_argument("Positive centre-of-mass energy required");
    set("Tune:pp",c.value("tune",14));
    if(lhe.empty()){
        set("Beams:idA",c.value("beamA",2212));set("Beams:idB",c.value("beamB",2212));set("Beams:frameType",1);set("Beams:eCM",energy);
    }else{set("Beams:frameType",4);set("Beams:LHEF",lhe);}
    bool processFound=false;
    for(const auto& proc:processes()){
        const bool enabled=lhe.empty()&&proc.at("id")==c.value("process","qcd");
        set(proc.at("setting"),enabled);if(enabled)processFound=true;
    }
    if(lhe.empty()&&!processFound)throw std::invalid_argument("Unknown process selection");
    set("Top:qqbar2ttbar",lhe.empty()&&c.value("process","qcd")=="top");
    const auto pthat=c.value("pTHatMinGeV",20.);if(pthat<0||!std::isfinite(pthat))throw std::invalid_argument("Invalid hard-process minimum pT");
    if(lhe.empty())set("PhaseSpace:pTHatMin",pthat);
    set("PartonLevel:ISR",c.value("isr",true));set("PartonLevel:FSR",c.value("fsr",true));set("PartonLevel:MPI",c.value("mpi",true));set("HadronLevel:all",c.value("hadronisation",true));
    set("Random:setSeed",true);set("Random:seed",seed);
    for(const auto* key:{"Next:numberShowInfo","Next:numberShowProcess","Next:numberShowEvent","Next:numberCount"})set(key,0);
    const auto pdf=c.value("pdf",Json::object());
    if(!pdf.empty()&&!pdf.value("set","").empty()){
#if defined(HEP_HAS_LHAPDF) && PYTHIA_VERSION_INTEGER >= 8318
        const auto name=pdf.at("set").get<std::string>();const int member=pdf.value("member",0);
        if(member<0)throw std::invalid_argument("Invalid PDF member");
        auto a=std::make_shared<Pythia8::LHAPDF6>(&p,&p.settings,&p.logger),b=std::make_shared<Pythia8::LHAPDF6>(&p,&p.settings,&p.logger);
        if(!a->init(c.value("beamA",2212),name,member,&p.logger)||!b->init(c.value("beamB",2212),name,member,&p.logger)||!p.setPDFPtr(a,b))throw std::invalid_argument("LHAPDF set/member could not be attached to PYTHIA");
#else
        throw std::invalid_argument("This PYTHIA build does not support this adapter's external LHAPDF interface; no PDF was substituted");
#endif
    }
    for(const auto& decay:c.value("decays",Json::array()))set(std::to_string(decay.at("pdgId").get<int>())+":mayDecay",decay.at("enabled"));
    std::set<std::string> expertKeys;
    auto extra=[&](const std::string& key,const Json& value){
        if(graphical.find(lower(key))!=graphical.end())throw std::invalid_argument("Expert override conflicts with graphical parameter: "+key+". Change the graphical value instead.");
        if(!expertKeys.insert(lower(key)).second)throw std::invalid_argument("Duplicate/conflicting expert override: "+key);
        if(!pdf.value("set",std::string()).empty()&&lower(key).rfind("pdf:",0)==0)throw std::invalid_argument("Expert PDF override conflicts with the selected external PDF");
        if(!p.settings.isFlag(key)&&!p.settings.isMode(key)&&!p.settings.isParm(key)&&!p.settings.isWord(key))throw std::invalid_argument("Unknown/unsupported expert setting: "+key);
        set(key,value,false);
    };
    const auto advanced=c.value("advanced",Json::object());
    for(const auto& [key,value]:advanced.items())extra(key,value);
    for(const auto& raw:c.value("rawOverrides",Json::array())){
        const auto line=raw.get<std::string>();const auto eq=line.find('=');if(eq==std::string::npos)throw std::invalid_argument("Raw setting requires key = value");
        auto key=line.substr(0,eq);key.erase(std::remove_if(key.begin(),key.end(),[](unsigned char ch){return std::isspace(ch);}),key.end());
        if(c.value("advanced",Json::object()).contains(key))throw std::invalid_argument("Raw override conflicts with Advanced setting: "+key);
        extra(key,line.substr(eq+1));
    }
    auto result=metadata(p,"",true,10000);result["equivalentSettings"]=settings;result["actualSeed"]=seed;result["parallelStrategy"]="single isolated generator";result["threads"]=1;
    result["reproducibility"]="Fixed seed and configuration with the same library/build/runtime and serial event order; no cross-version or cross-platform bitwise guarantee";
    result["pdf"]=pdf;
    if(!lhe.empty())result["source"]="LHE external hard process; beams and cross section from LHE init";
    return result;
}
Json configure(Pythia8::Pythia& p,const Json& c,int seed){return configureImpl(p,c,seed,{});}
Json configureLhe(Pythia8::Pythia& p,const Json& c,int seed,const std::string& input){
    if(input.empty())throw std::invalid_argument("LHE input required");
    return configureImpl(p,c,seed,input);
}
}
