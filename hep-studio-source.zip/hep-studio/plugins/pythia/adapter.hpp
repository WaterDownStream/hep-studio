#pragma once
#include "core/json.hpp"
#include <Pythia8/Pythia.h>
#include <memory>
namespace hep::pythia {
std::unique_ptr<Pythia8::Pythia> create(const std::string& dataPath);
Json configure(Pythia8::Pythia&,const Json& config,int seed);
Json configureLhe(Pythia8::Pythia&,const Json& config,int seed,const std::string& input);
Json metadata(Pythia8::Pythia&,const std::string& search,bool changedOnly,unsigned limit=250);
Json processes();
bool externalPdfAvailable();
}
