#pragma once
#include "core/json.hpp"
#include <HepMC3/GenEvent.h>
namespace hep::hepmc {
Json inspect(const HepMC3::GenEvent&,unsigned maximum=10000);
}
