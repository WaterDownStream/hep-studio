#include "plugins/hepmc/adapter.hpp"
#include <HepMC3/GenParticle.h>
#include <HepMC3/GenVertex.h>
#include <cmath>
namespace hep::hepmc {
Json inspect(const HepMC3::GenEvent& event,unsigned maximum){
    Json particles=Json::array(),vertices=Json::array();
    for(const auto& p:event.particles()){
        if(particles.size()>=maximum)break;const auto& m=p->momentum();
        Json mothers=Json::array(),daughters=Json::array();
        if(p->production_vertex())for(const auto& a:p->production_vertex()->particles_in())mothers.push_back(a->id());
        if(p->end_vertex())for(const auto& a:p->end_vertex()->particles_out())daughters.push_back(a->id());
        const auto eta=m.eta();
        particles.push_back({{"index",p->id()},{"pdgId",p->pid()},{"status",p->status()},{"px",m.px()},{"py",m.py()},{"pz",m.pz()},{"energy",m.e()},
            {"pt",m.pt()},{"eta",std::isfinite(eta)?Json(eta):Json()},{"phi",m.phi()},{"mass",p->generated_mass()},{"mothers",mothers},{"daughters",daughters},
            {"productionVertex",p->production_vertex()?p->production_vertex()->id():0},{"decayVertex",p->end_vertex()?p->end_vertex()->id():0}});
    }
    for(const auto& v:event.vertices()){
        if(vertices.size()>=maximum)break;const auto& p=v->position();vertices.push_back({{"id",v->id()},{"position",{p.x(),p.y(),p.z(),p.t()}},{"status",v->status()}});
    }
    return {{"eventNumber",event.event_number()},{"particles",particles},{"vertices",vertices},{"weights",event.weights()},{"momentumUnit","GeV"},{"lengthUnit","mm"},
            {"totalParticles",event.particles().size()},{"truncated",event.particles().size()>maximum}};
}
}
