#include "plugins/fastjet/adapter.hpp"
#include <cmath>
namespace hep::fastjet_adapter {
fastjet::JetDefinition definition(const Json& c){
    const auto a=c.value("algorithm","antikt"),r=c.value("recombination","E");const double radius=c.value("R",0.4);
    if(!std::isfinite(radius)||radius<=0||radius>10)throw std::invalid_argument("Jet radius must be in (0,10]");
    fastjet::JetAlgorithm algorithm;
    if(a=="antikt")algorithm=fastjet::antikt_algorithm;else if(a=="kt")algorithm=fastjet::kt_algorithm;else if(a=="cambridge")algorithm=fastjet::cambridge_algorithm;else throw std::invalid_argument("Unknown FastJet algorithm");
    fastjet::RecombinationScheme scheme;
    if(r=="E")scheme=fastjet::E_scheme;else if(r=="pt")scheme=fastjet::pt_scheme;else if(r=="pt2")scheme=fastjet::pt2_scheme;else throw std::invalid_argument("Unknown FastJet recombination scheme");
    return {algorithm,radius,scheme};
}
Json jetData(const fastjet::PseudoJet& j){
    Json constituents=Json::array();if(j.has_constituents())for(const auto& p:j.constituents())constituents.push_back(p.user_index());
    return {{"px",j.px()},{"py",j.py()},{"pz",j.pz()},{"energy",j.e()},{"pt",j.pt()},{"eta",j.eta()},{"phi",j.phi_std()},{"mass",j.m()},{"constituents",constituents}};
}
Json fixture(const Json& request){
    std::vector<fastjet::PseudoJet> particles;int index=0;
    for(const auto& p:request.at("particles")){
        if(p.size()!=4)throw std::invalid_argument("Four components required");
        particles.emplace_back(p[0].get<double>(),p[1].get<double>(),p[2].get<double>(),p[3].get<double>());particles.back().set_user_index(index++);
    }
    fastjet::ClusterSequence sequence(particles,definition(request.value("config",Json::object())));Json jets=Json::array();
    for(const auto& j:fastjet::sorted_by_pt(sequence.inclusive_jets(request.value("minimumPtGeV",0.))))jets.push_back(jetData(j));
    return {{"jets",jets}};
}
}
