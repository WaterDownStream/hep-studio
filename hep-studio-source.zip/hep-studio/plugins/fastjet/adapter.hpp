#pragma once
#include "core/json.hpp"
#include <fastjet/ClusterSequence.hh>
namespace hep::fastjet_adapter {
fastjet::JetDefinition definition(const Json&);
Json jetData(const fastjet::PseudoJet&);
Json fixture(const Json&);
}
