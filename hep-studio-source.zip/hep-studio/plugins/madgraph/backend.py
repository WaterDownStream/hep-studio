"""Structured LO MadGraph adapter; generated cards are transparency artifacts."""
from __future__ import annotations
import gzip,math,os,re,shlex,shutil,subprocess,sys
from pathlib import Path
try:from artifacts import run_process,digest,check_cancel
except ImportError:
    sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'research'))
    from artifacts import run_process,digest,check_cancel

PARTICLES={2212:'p',11:'e-',-11:'e+',13:'mu-',-13:'mu+',15:'ta-',-15:'ta+',22:'a',23:'z',24:'w+',-24:'w-',25:'h',6:'t',-6:'t~',21:'g',1:'d',-1:'d~',2:'u',-2:'u~',3:'s',-3:'s~',4:'c',-4:'c~',5:'b',-5:'b~',12:'ve',-12:'ve~',14:'vm',-14:'vm~',16:'vt',-16:'vt~'}
MODELS={'sm':{'label':'Standard Model — default restrictions','restriction':'restrict_default.dat'},
        'sm-full':{'label':'Standard Model — unrestricted parameters','restriction':None}}
def selected_model(config):
    name=config.get('model','sm')
    if not isinstance(name,str) or name not in MODELS:raise ValueError('Supported identified LO models are sm and sm-full; external UFO resources are not yet supported')
    return name

def process_text(config):
    process=config['process']
    if len(process['incoming'])!=2 or not 1<=len(process['outgoing'])<=8:raise ValueError('A process requires two incoming and one to eight outgoing particles')
    if any(type(p)!=int or p not in PARTICLES for p in process['incoming']+process['outgoing']+process.get('exclude',[])):raise ValueError('Process particles must be supported integer PDG identities')
    try:line=' '.join(PARTICLES[int(p)] for p in process['incoming'])+' > '+' '.join(PARTICLES[int(p)] for p in process['outgoing'])
    except (KeyError,ValueError):raise ValueError('Particle is not supported by the installed Standard Model process builder')
    if process.get('exclude'):line+=' / '+' '.join(PARTICLES[int(p)] for p in process['exclude'])
    for coupling,order in sorted(process.get('orders',{}).items()):
        if coupling not in ('QCD','QED') or not isinstance(order,int) or not 0<=order<=99:raise ValueError('Invalid perturbative coupling order')
        line+=' '+coupling+'='+str(order)
    selected_model(config)
    return line

def capability():
    root=Path(os.environ.get('HEP_MADGRAPH_PATH',''))
    if not os.environ.get('HEP_MADGRAPH_PATH') or not (root/'bin/mg5_aMC').is_file():return {'available':False,'status':'Needs installation','version':'','reason':'Configure a verified MadGraph scientific SDK'}
    version=dict(re.findall(r'^([A-Za-z_]+)\s*=\s*(.+)$',(root/'VERSION').read_text(),re.M)) if (root/'VERSION').exists() else {}
    source=__import__('hashlib').sha256()
    for folder in ('madgraph','aloha','models/sm','Template/LO','Template/Common'):
        for p in sorted((root/folder).rglob('*')):
            if p.is_file() and '__pycache__' not in p.parts and p.suffix not in ('.pyc','.pkl','.o','.a','.so'):
                source.update(str(p.relative_to(root)).encode());source.update(bytes.fromhex(digest(p)))
    sources=[];manifest=root.parent/'research-sdk.json'
    if manifest.is_file():sources=[s for s in __import__('json').loads(manifest.read_text()).get('sources',[]) if s.get('name')=='madgraph']
    compiler=os.environ.get('HEP_FORTRAN_COMPILER',shutil.which('gfortran') or '')
    installed=bool(compiler and Path(compiler).is_file());ready=installed
    compiler_version='';compiler_hash=''
    if ready:
        try:
            report=subprocess.run([compiler,'--version'],capture_output=True,text=True,timeout=5,check=True)
            compiler_version=report.stdout.splitlines()[0];compiler_hash=digest(compiler)
        except (OSError,subprocess.SubprocessError,IndexError):ready=False
    models=[dict(id=name,**info,available=(root/'models/sm/parameters.py').is_file() and (info['restriction'] is None or (root/'models/sm'/info['restriction']).is_file())) for name,info in MODELS.items()]
    return {'available':ready,'status':'Available' if ready else 'Incompatible' if installed else 'Needs installation','version':version.get('version','unknown'),'location':str(root.resolve()),'modelScope':'SM LO (sm / sm-full)','models':models,
            'entrypointSha256':digest(root/'bin/mg5_aMC'),'scientificSourceSha256':source.hexdigest(),'sourceFingerprintScope':'Python, SM model and LO/Common templates; compiled SDK closure is not claimed','sourceProvenance':sources,'compilerVersion':compiler_version,'compilerEntrypointSha256':compiler_hash,'reason':'' if ready else 'Install/select a working scientific SDK Fortran compiler'}

def lhe_metadata(path,cancel=None):
    init=[];in_init=False;events=0;weights=0.;weights2=0.;read_weight=False;in_event=False;closed=False
    opener=gzip.open if str(path).endswith('.gz') else open
    with opener(path,'rt',errors='strict') as stream:
        for line in stream:
            if len(line)>1024*1024:raise ValueError('LHE line exceeds safety limit')
            if '<init>' in line:in_init=True;continue
            if '</init>' in line:in_init=False;continue
            if in_init and line.strip() and not line.lstrip().startswith(('<','#')):init.append(line.split('#',1)[0].strip())
            if re.match(r'\s*<event(?:\s|>)',line):
                if in_event:raise ValueError('Nested LHE event')
                events+=1;read_weight=True;in_event=True;check_cancel(cancel);continue
            if '</event>' in line:in_event=False
            if '</LesHouchesEvents>' in line:closed=True
            if read_weight and line.strip() and not line.lstrip().startswith('#'):
                fields=line.split()
                if len(fields)<6:raise ValueError('Malformed LHE event header')
                weight=float(fields[2]);weights+=weight;weights2+=weight*weight;read_weight=False
                if not math.isfinite(weights+weights2):raise ValueError('Nonfinite LHE event weights')
        if not events or len(init)<2 or in_event or not closed:raise ValueError('Empty, incomplete or malformed LHE sample')
    h=init[0].split();processes=[line.split() for line in init[1:]]
    if len(h)!=10 or len(processes)!=int(h[9]):raise ValueError('Malformed LHE initialization block')
    return {'eventCount':events,'beamIds':[int(x) for x in h[:2]],'beamEnergyGeV':[float(x) for x in h[2:4]],
            'weightStrategy':int(h[8]),'pdfGroups':[int(x) for x in h[4:6]],'pdfSetIds':[int(x) for x in h[6:8]],'crossSectionPb':sum(float(p[0]) for p in processes),
            'integrationErrorPb':math.sqrt(sum(float(p[1])**2 for p in processes)),
            'sumWeights':weights,'sumWeightsSquared':weights2,'sha256':digest(path),'sizeBytes':Path(path).stat().st_size}

def parameter_metadata(text):
    """Read effective generated-card entries without executing UFO Python.

    Upstream marks dependent entries explicitly: editing these changes the
    shower card but not the matrix element. Never accept that as a model change.
    """
    rows=[];block='';dependent=False;seen=set()
    for line in text.splitlines():
        if line.startswith('## INFORMATION FOR '):dependent=False
        if line.startswith('## Dependent parameters'):dependent=True
        fields=line.split('#',1)[0].split()
        if fields and fields[0].lower()=='block':block=fields[1].lower();dependent=False;continue
        decay=len(fields)>=3 and fields[0].lower()=='decay'
        if decay:block='decay';indices=fields[1:2];value=fields[2]
        elif block and block!='decay' and len(fields)>=2:indices=fields[:-1];value=fields[-1]
        else:continue
        if not all(re.fullmatch(r'[1-9][0-9]*',i) for i in indices):continue
        binding=block+':'+':'.join(indices)
        if binding in seen:raise ValueError('Duplicate SLHA parameter binding: '+binding)
        seen.add(binding)
        try:number=float(value.replace('D','e').replace('d','e'))
        except ValueError:continue
        if not math.isfinite(number):raise ValueError('Nonfinite generated model parameter')
        description=line.split('#',1)[1].strip() if '#' in line else ''
        fixed=dependent or bool(re.match(r'^\S+\s*:\s*',description))
        rows.append({'binding':binding,'value':number,'editable':not fixed,'description':description,
                     'source':'model-dependent' if fixed else 'external parameter'})
    return rows

def parameter_card(text,bindings):
    for name,value in bindings.items():
        if not re.fullmatch(r'[a-z][a-z0-9_]*(?::[1-9][0-9]*)+',name) or type(value) not in (int,float) or not math.isfinite(value):raise ValueError('Model parameters require finite numeric SLHA block:index bindings')
        if name.startswith(('mass:','decay:')) and value<0:raise ValueError('Masses and decay widths must be nonnegative')
    metadata={p['binding']:p for p in parameter_metadata(text)}
    for name in bindings:
        if name in metadata and not metadata[name]['editable']:raise ValueError('SLHA parameter '+name+' is fixed or derived by this model; select sm-full for unrestricted external parameters. Derived parameters cannot be overridden.')
    block='';remaining=dict(bindings)
    lines=[]
    for line in text.splitlines():
        fields=line.split('#',1)[0].split()
        if fields and fields[0].lower()=='block':block=fields[1].lower()
        if fields and fields[0].lower()=='decay':block=''
        binding='decay:'+fields[1] if len(fields)>=3 and fields[0].lower()=='decay' else block+':'+':'.join(fields[:-1]) if len(fields)>=2 else ''
        if binding in remaining:
            value=float(remaining.pop(binding))
            if not math.isfinite(value):raise ValueError('Nonfinite model parameter')
            comment=' #'+line.split('#',1)[1] if '#' in line else ''
            line=' '+' '.join(fields[:-1])+' '+format(value,'.16e')+comment
        lines.append(line)
    if remaining:raise ValueError('Unknown SLHA parameter binding: '+', '.join(remaining))
    return '\n'.join(lines)+'\n'

def generate(config,directory,cancel=None,progress=None):
    cap=capability()
    if not cap['available']:raise ValueError(cap['reason'])
    directory=Path(directory);events=config.get('events',100);seed=config.get('seed',24680)
    if type(events)!=int or not 1<=events<=100000000 or type(seed)!=int or not 1<=seed<=30081:raise ValueError('MadGraph event count or integration seed outside supported range (seed 1–30081)')
    if config.get('accuracy','LO')!='LO':raise ValueError('NLO generation is not yet verified by this adapter')
    if config.get('runCard',{}).get('ickkw',0)!=0 or config.get('runCard',{}).get('xqcut',0)>0:raise ValueError('Matched/merged ME–PS generation needs an explicit supported matching adapter; unmatched output is not substituted')
    if shutil.disk_usage(directory).free<256*1024*1024+events*32*1024:raise ValueError('Insufficient disk space for conservative LHE/process estimate (32 KiB per event plus 256 MiB)')
    process=process_text(config);model=selected_model(config);generated=directory/'process'
    # MadGraph selects/compiles with its compiler during `output`, before the
    # generated run configuration is read. Use a job-private, shell-safe alias
    # at both stages and verify the exporter honored it. MADGRAPH_DATA prevents
    # its exporter from rewriting the shared SDK Template/LO compiler settings.
    fortran=str(Path(os.environ.get('HEP_FORTRAN_COMPILER',shutil.which('gfortran') or '')).absolute())
    tools=directory/'tools';tools.mkdir()
    compiler=tools/'gfortran'
    compiler.write_text('#!/bin/sh\nexec '+shlex.quote(fortran)+' "$@"\n');compiler.chmod(0o700)
    environment=dict(os.environ,PATH=str(tools.absolute())+os.pathsep+os.environ.get('PATH',''),
                     MADGRAPH_DATA=str(directory.absolute()),FC='gfortran',F77='gfortran')
    for name in ('MAKEFLAGS','MFLAGS','MAKEOVERRIDES'):environment.pop(name,None)
    commands=directory/'commands.mg5'
    commands.write_text('set auto_update 0 --no_save\nset automatic_html_opening False --no_save\nset notification_center False --no_save\nset fortran_compiler gfortran --no_save\nimport model '+model+'\ngenerate '+process+'\noutput process -f\nquit\n')
    run_process([sys.executable,'-O',str(Path(cap['location'])/'bin/mg5_aMC'),str(commands)],directory,directory/'process.log',cancel,progress,env=environment)
    make_options=(generated/'Source/make_opts').read_text()
    if re.findall(r'^\s*DEFAULT_F_COMPILER\s*=\s*(\S+)\s*$',make_options,re.M)!=['gfortran']:
        raise RuntimeError('MadGraph did not honor the selected Fortran compiler; refusing output with misleading compiler provenance')
    (directory/'compiler-make-options.txt').write_text(make_options)
    (generated/'Cards/me5_configuration.txt').write_text('run_mode = 0\nnb_core = 1\nautomatic_html_opening = False\nfortran_compiler = gfortran\n')
    beam=config.get('beam',{'ids':[-11,11],'energiesGeV':[50.,50.]})
    if len(beam['ids'])!=2 or len(beam['energiesGeV'])!=2 or list(beam['ids'])!=config['process']['incoming']:raise ValueError('Beam IDs must match the structured incoming process')
    energies=[float(v) for v in beam['energiesGeV']]
    if not all(math.isfinite(v) and v>0 for v in energies):raise ValueError('Positive finite beam energies required')
    values={'nevents':events,'iseed':seed,'lpp1':1 if beam['ids'][0]==2212 else 0,'lpp2':1 if beam['ids'][1]==2212 else 0,
            'ebeam1':energies[0],'ebeam2':energies[1],'use_syst':False,'systematics_program':'none','gridpack':False}
    allowed={'ptj','ptb','pta','ptl','etaj','etab','etaa','etal','drjj','drbb','drll','drjl','drbl','mmll','mmjj','xqcut','maxjetflavor','ickkw','pdlabel','lhaid'}
    for k,v in config.get('runCard',{}).items():
        if k not in allowed:raise ValueError('Unsupported run-card binding: '+k)
        if isinstance(v,str) and not re.fullmatch(r'[A-Za-z0-9_.+-]{1,64}',v):raise ValueError('Invalid run-card value')
        if not isinstance(v,(str,int,float,bool)) or isinstance(v,float) and not math.isfinite(v):raise ValueError('Invalid run-card value')
        values[k]=v
    card=generated/'Cards/run_card.dat';text=card.read_text()
    for k,v in values.items():
        rendered='True' if v is True else 'False' if v is False else str(v)
        text,count=re.subn(r'^\s*[^!\n=]+\s*=\s*'+re.escape(k)+r'(\s*(?:!.*)?)$',lambda m:' '+rendered+' = '+k+m[1],text,flags=re.M)
        if count!=1:raise ValueError('Installed run card does not have one binding for '+k)
    card.write_text(text)
    # Parameter card bindings identify SLHA blocks and indices, never source code.
    param=generated/'Cards/param_card.dat';defaults={p['binding']:p['value'] for p in parameter_metadata(param.read_text())};param.write_text(parameter_card(param.read_text(),config.get('parameters',{})))
    # MG's forced noninteractive generation may skip its interactive dependent
    # parameter updater. Refresh with the installed model's own equations before
    # compiling/generating so LHE and the shower receive consistent masses.
    refresh=directory/'refresh-parameters.py'
    refresh.write_text('import sys\nsys.path.insert(0,'+repr(cap['location'])+')\nfrom models import import_ufo,check_param_card\nmodel=import_ufo.import_model('+repr(model)+')\ncard=check_param_card.ParamCard('+repr(str(param.absolute()))+')\ncard.update_dependent(model,None,20)\ncard.write('+repr(str(param.absolute()))+',precision="16")\nprint("HEP parameter refresh complete",flush=True)\n')
    run_process([sys.executable,'-O',str(refresh)],directory,directory/'parameter-refresh.log',cancel,progress,timeout=120,env=environment)
    if 'HEP parameter refresh complete' not in (directory/'parameter-refresh.log').read_text():raise RuntimeError('MadGraph dependent parameter refresh did not complete')
    for filename in ('run_card.dat','param_card.dat','proc_card_mg5.dat','me5_configuration.txt'):shutil.copyfile(generated/'Cards'/filename,directory/filename)
    run_process([sys.executable,'-O','bin/generate_events','reference','-f'],generated,directory/'generation.log',cancel,progress,timeout=3600,env=environment)
    if digest(fortran)!=cap['compilerEntrypointSha256']:raise RuntimeError('Fortran compiler changed during generation; output is not published')
    source=generated/'Events/reference/unweighted_events.lhe.gz'
    if not source.is_file():raise RuntimeError('MadGraph generation/compilation produced no complete LHE sample; inspect retained process and generation logs')
    with gzip.open(source,'rb') as stream,(directory/'events.lhe').open('wb') as output:shutil.copyfileobj(stream,output)
    metadata=lhe_metadata(directory/'events.lhe',cancel)
    if metadata['eventCount']!=events:raise ValueError('MadGraph produced an incomplete requested sample')
    # The generator can refresh derived entries (e.g. MW) from external inputs.
    # Retain the effective post-generation card, not merely the submitted one.
    effective_parameters=parameter_metadata(param.read_text())
    effective={p['binding']:p for p in effective_parameters}
    for name,value in config.get('parameters',{}).items():
        if name not in effective or not math.isclose(effective[name]['value'],value,rel_tol=1e-6,abs_tol=1e-12):raise ValueError('MadGraph changed requested SLHA parameter '+name+'; output is not published')
    for p in effective_parameters:p.update(default=defaults[p['binding']],changedFromDefault=p['value']!=defaults[p['binding']])
    shutil.copyfile(param,directory/'param_card.dat')
    shutil.rmtree(generated)
    metadata.update(configuration=config,process=process,version=cap['version'],threads=1,
                    model={'id':model,'restriction':MODELS[model]['restriction'],'effectiveParameters':effective_parameters,
                           'sourceIdentity':cap.get('scientificSourceSha256',''),'scope':'Installed identified Standard Model LO source; no external UFO/NLO claim'},
                    compiler={'version':cap['compilerVersion'],'entrypointSha256':cap['compilerEntrypointSha256'],
                              'selection':'Verified job-private compiler alias during process export and event generation'},
                    reproducibility='Fixed integration seed and same build/runtime; cross-version byte identity is not guaranteed')
    return metadata
