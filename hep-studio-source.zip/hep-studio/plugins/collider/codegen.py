"""Readable standalone reference for supported generator/jet/histogram graphs.

This is an export of validated VPIR, never an input language or execution path.
"""
import json,copy,re

SCALES={'1':1,'GeV':1,'MeV':.001,'eV':1e-9,'keV':1e-6,'TeV':1000,
        'mm':1,'cm':10,'m':1000,'ns':1,'s':1e9,'rad':1,'pb':1e-34,'fb^-1':1e37}
FIELDS={'pt':'pt()','eta':'eta()','phi':'phi_std()','mass':'m()','energy':'e()'}

def expression(ast,row='row'):
    op=ast['op']
    if op=='literal':return repr(float(ast['value'])*SCALES[ast.get('unit','1')])
    if op=='column':return row+'.at('+json.dumps(ast['name'])+')'
    a=[expression(x,row) for x in ast['args']]
    binary={'add':'+','sub':'-','mul':'*','div':'/','gt':'>','ge':'>=','lt':'<','le':'<=','eq':'==','ne':'!=','and':'&&','or':'||'}
    if op in binary:return '('+(' '+binary[op]+' ').join(a)+')'
    if op in ('not','neg'):return '('+('!' if op=='not' else '-')+a[0]+')'
    if op=='square':return '('+a[0]+' * '+a[0]+')'
    if op in ('sqrt','abs','sin','cos','exp','log','min','max'):return 'std::'+op+'('+', '.join(a)+')'
    raise ValueError('Reference exporter does not support expression '+op)

def generate(result):
    nodes=result['executionPlan']['nodes'];supported={'Pythia','ClusterJets','CollectionFilter','CollectionSort','CollectionTake','Property','CollectionCount','Define','Filter','Histo1D'}
    unsupported=sorted({n['kind'] for n in nodes}-supported)

    if unsupported:
        return '// Standalone export unavailable for: '+', '.join(unsupported)+'.\n// Equivalent generator configuration:\n'+'\n'.join('// '+s for s in result.get('generator',{}).get('equivalentSettings',[]))+'\n// Partition plan: '+json.dumps(result.get('generator',{}).get('partitions',[]))+'\n// Validated plan:\n'+'\n'.join('// '+s for s in json.dumps(result['executionPlan'],indent=2).splitlines())
    if result.get('generator',{}).get('partitions'):return partition_reference(result)
    ids={n['id']:'n'+str(i) for i,n in enumerate(nodes)}
    source=next(n for n in nodes if n['kind']=='Pythia');pdf=source['config'].get('pdf',{})
    lines=['// HEP Studio standalone reference. VPIR remains canonical.',
           '// Use the exact scientific environment recorded with the Run.',
           '// Output: ROOT histograms (default collider-histograms.root).',
           '#include <Pythia8/Pythia.h>','#include <fastjet/ClusterSequence.hh>',
           '#include <TH1D.h>','#include <TFile.h>','#include <algorithm>','#include <cmath>',
           '#include <map>','#include <string>','#include <vector>','#include <stdexcept>',
           'using Row = std::map<std::string, double>;',
           'Row jetRow(const fastjet::PseudoJet& j, double weight) {',
           '  return {{"pt",j.pt()},{"eta",j.eta()},{"phi",j.phi_std()},{"mass",j.m()},{"energy",j.e()},{"value",j.pt()},{"weight",weight}};',
           '}']
    if pdf.get('set'):lines+=['#include <Pythia8Plugins/LHAPDF6.h>']
    lines+=['int main(int argc, char** argv) {','  Pythia8::Pythia pythia;']
    for setting in result['generator']['equivalentSettings']:
        lines.append('  if (!pythia.readString('+json.dumps(setting)+')) return 2;')
    if pdf.get('set'):
        lines+=['  // External PDF adapter requires the matching PYTHIA >= 8.318 interface.',
                '  auto pdfA=std::make_shared<Pythia8::LHAPDF6>(&pythia,&pythia.settings,&pythia.logger);',
                '  auto pdfB=std::make_shared<Pythia8::LHAPDF6>(&pythia,&pythia.settings,&pythia.logger);']
        for key,beam in [('A','beamA'),('B','beamB')]:
            lines.append(f'  if (!pdf{key}->init({source["config"][beam]}, {json.dumps(pdf["set"])}, {pdf.get("member",0)}, &pythia.logger)) return 3;')
        lines+=['  if (!pythia.setPDFPtr(pdfA,pdfB)) return 3;']
    lines+=['  if (!pythia.init()) return 4;']
    for node in nodes:
        v=ids[node['id']];c=node['config'];kind=node['kind']
        if kind=='ClusterJets':
            algorithm={'antikt':'antikt_algorithm','kt':'kt_algorithm','cambridge':'cambridge_algorithm'}[c.get('algorithm','antikt')]
            scheme={'E':'E_scheme','pt':'pt_scheme','pt2':'pt2_scheme'}[c.get('recombination','E')]
            lines.append(f'  fastjet::JetDefinition {v}_definition(fastjet::{algorithm}, {c.get("R",.4)}, fastjet::{scheme});')
        elif kind=='Histo1D':
            if c.get('edges'):
                lines.append(f'  const double {v}_edges[] = {{'+', '.join(repr(float(x)) for x in c['edges'])+'};')
                args=f'{len(c["edges"])-1}, {v}_edges'
            else:args=f'{c.get("bins",50)}, {float(c.get("lower",0))}, {float(c.get("upper",500))}'
            lines+=[f'  TH1D {v}({json.dumps(node["id"])}, "", {args});',f'  {v}.SetDirectory(nullptr); {v}.Sumw2();']
    # Preview exports reproduce the event count actually previewed.
    target=result.get('metrics',{}).get('accepted',source['config'].get('events',1000))
    lines+=[f'  const unsigned long long target = {target};','  unsigned long long accepted=0, attempts=0, failures=0;',
            '  while (accepted < target) {','    ++attempts;',
            '    if (!pythia.next()) { if (++failures > 100 && failures*10 > attempts) return 5; continue; }',
            '    const double weight=pythia.info.weight();']
    for node in nodes:
        v=ids[node['id']];c=node['config'];kind=node['kind'];up=ids.get(node.get('input'))
        if kind=='Pythia':continue
        lines.append('    // '+kind+' (node '+node['id'].replace('\n',' ')+')')
        if kind=='ClusterJets':
            lines+=[f'    std::vector<fastjet::PseudoJet> {v}_particles;',
                    '    for (int i=1; i<pythia.event.size(); ++i) {','      const auto& p=pythia.event[i];','      if (!p.isFinal()) continue;']
            if not c.get('includeInvisible',False):lines+=['      const int id=std::abs(p.id()); if (id==12 || id==14 || id==16 || id==18) continue;']
            lines+=[f'      {v}_particles.emplace_back(p.px(),p.py(),p.pz(),p.e());',f'      {v}_particles.back().set_user_index(i);','    }',
                    f'    fastjet::ClusterSequence {v}_sequence({v}_particles,{v}_definition);',
                    f'    auto {v}=fastjet::sorted_by_pt({v}_sequence.inclusive_jets({float(c.get("minimumPtGeV",0))}));']
        elif kind.startswith('Collection') and kind!='CollectionCount':
            lines.append(f'    auto {v}={up};')
            if kind=='CollectionFilter':lines.append(f'    {v}.erase(std::remove_if({v}.begin(),{v}.end(),[&](const auto& jet){{const auto row=jetRow(jet,weight); return !({expression(c["expression"])});}}),{v}.end());')
            elif kind=='CollectionSort':lines.append(f'    std::stable_sort({v}.begin(),{v}.end(),[](const auto& a,const auto& b){{return a.{FIELDS[c["property"]]} '+('>' if c.get('descending',True) else '<')+f' b.{FIELDS[c["property"]]};}});')
            elif kind=='CollectionTake':lines.append(f'    if ({v}.size()>{c.get("count",1)}) {v}.resize({c.get("count",1)});')
        elif kind=='Property':
            lines+=[f'    std::vector<Row> {v};',f'    for (const auto& jet:{up}) {{auto row=jetRow(jet,weight);row["value"]=row.at({json.dumps(c["property"])});{v}.push_back(row);}}']
        elif kind=='CollectionCount':lines.append(f'    std::vector<Row> {v}={{{{{{"value",static_cast<double>({up}.size())}},{{"weight",weight}}}}}};')
        elif kind in ('Define','Filter'):
            lines.append(f'    std::vector<Row> {v};')
            if kind=='Define':lines.append(f'    for (auto row:{up}) {{row[{json.dumps(c["name"])}]={expression(c["expression"])};{v}.push_back(row);}}')
            else:lines.append(f'    for (const auto& row:{up}) if ({expression(c["expression"])}) {v}.push_back(row);')
        elif kind=='Histo1D':
            w=expression(c['weight']) if c.get('weight') else 'weight'
            lines.append(f'    for (const auto& row:{up}) {v}.Fill({expression(c["expression"])}, {w});')
    lines+=['    ++accepted;','  }','  TFile output(argc>1?argv[1]:"collider-histograms.root","RECREATE");','  if (output.IsZombie()) return 6;']
    for node in nodes:
        if node['kind']!='Histo1D':continue
        v=ids[node['id']];c=node['config']
        if c.get('flow')=='fold':
            lines+=[f'  const double {v}_entries={v}.GetEntries();',f'  for (int flow : {{0,{v}.GetNbinsX()+1}}) {{',f'    const int bin=flow==0?1:{v}.GetNbinsX();',
                    f'    {v}.SetBinContent(bin,{v}.GetBinContent(bin)+{v}.GetBinContent(flow));',
                    f'    {v}.SetBinError(bin,std::hypot({v}.GetBinError(bin),{v}.GetBinError(flow)));','  }',f'  {v}.SetEntries({v}_entries);']
        if c.get('normalization','counts')!='counts':
            lines.append(f'  if ({v}.Integral()<=0) return 7;')
            lines.append(f'  {v}.Scale(1./{v}.Integral(),'+('"width"' if c['normalization']=='density' else '""')+');')
        lines.append(f'  {v}.Write();')
    return '\n'.join(lines+['  output.Close();','  return 0;','}'])+'\n'


def partition_reference(result):
    """Portable sequential reference for a logically partitioned sample."""
    child=copy.deepcopy(result);parts=child['generator'].pop('partitions')
    child['metrics']['workerProcesses']=1
    for node in child['executionPlan']['nodes']:
        if node['kind']=='Histo1D':node['config'].update(normalization='counts',flow='separate')
    code=generate(child)
    code=code.replace('int main(int argc, char** argv)', 'int runPartition(const char* destination, int seed, unsigned long long target)')
    code=code.replace('  if (!pythia.init())', '  if (!pythia.readString("Random:seed = "+std::to_string(seed))) return 2;\n  if (!pythia.init())')
    code=re.sub(r'  const unsigned long long target = [0-9]+;\n','',code)
    code=code.replace('argc>1?argv[1]:"collider-histograms.root"','destination')
    code='#include <memory>\n#include <filesystem>\n'+code
    nodes=[n for n in result['executionPlan']['nodes'] if n['kind']=='Histo1D']
    lines=['// Logical streams are scientific configuration; physical scheduling is irrelevant.',
           '// This reference executes the same streams sequentially and merges in index order.',
           'int main(int argc, char** argv) {',
           '  const std::string destination=argc>1?argv[1]:"collider-histograms.root";',
           '  if (std::filesystem::exists(destination)) return 9;',
           '  const std::pair<int,unsigned long long> streams[] = {'+','.join('{'+str(p['seed'])+','+str(p['events'])+'}' for p in parts)+'};',
           '  std::map<std::string,std::unique_ptr<TH1D>> sums;',
           '  int index=0;', '  for (const auto& stream:streams) {',
           '    const auto path=destination+".part-"+std::to_string(index++)+".root";',
           '    if (std::filesystem::exists(path)) return 9;',
           '    const int status=runPartition(path.c_str(),stream.first,stream.second); if(status) return status;',
           '    TFile input(path.c_str(),"READ"); if(input.IsZombie()) return 6;']
    for node in nodes:
        name=json.dumps(node['id']);lines+=[f'    {{ auto* h=dynamic_cast<TH1D*>(input.Get({name})); if(!h) return 6;',f'      if(!sums.count({name})) {{sums[{name}].reset(static_cast<TH1D*>(h->Clone()));sums[{name}]->SetDirectory(nullptr);}}',f'      else sums[{name}]->Add(h); }}']
    lines+=['    input.Close();std::filesystem::remove(path);','  }','  TFile output(destination.c_str(),"RECREATE");if(output.IsZombie()) return 6;']
    for node in nodes:
        c=node['config'];name=json.dumps(node['id']);lines+=['  {',f'    auto& h=*sums.at({name});']
        if c.get('flow')=='fold':lines+=['    const double entries=h.GetEntries();','    for(int flow:{0,h.GetNbinsX()+1}) {int bin=flow==0?1:h.GetNbinsX();h.SetBinContent(bin,h.GetBinContent(bin)+h.GetBinContent(flow));h.SetBinError(bin,std::hypot(h.GetBinError(bin),h.GetBinError(flow)));}','    h.SetEntries(entries);']
        if c.get('normalization','counts')!='counts':lines+=['    if(h.Integral()<=0) return 7;','    h.Scale(1./h.Integral(),'+('"width"' if c['normalization']=='density' else '""')+');']
        lines+=['    h.Write();','  }']
    return code+'\n'+'\n'.join(lines+['  output.Close();return 0;','}'])+'\n'
