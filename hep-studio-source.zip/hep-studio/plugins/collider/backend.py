"""Collider adapter orchestration. Native bulk loops never cross the Python/IPC boundary."""
from __future__ import annotations
import array, ctypes, hashlib, importlib.util, json, math, os, platform, sys
from pathlib import Path

ENGINE=None
CAPABILITY={}
PROGRESS=ctypes.CFUNCTYPE(None,ctypes.c_char_p)
CANCEL=ctypes.CFUNCTYPE(ctypes.c_int)

def _json(pointer):
    if not pointer:raise MemoryError('Collider engine could not allocate its response')
    try:return json.loads(ctypes.string_at(pointer))
    finally:ENGINE.hep_collider_free(pointer)

def pdf_manager():
    path=Path(__file__).parent/'pdf_manager.py'
    if not path.exists():path=Path(__file__).resolve().parents[1]/'lhapdf'/'manager.py'
    spec=importlib.util.spec_from_file_location('hep_pdf_manager',path);module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module);return module

def initialize():
    global ENGINE,CAPABILITY
    home=str(pdf_manager().data_home())
    existing=os.environ.get('LHAPDF_DATA_PATH','')
    if home not in existing.split(os.pathsep):os.environ['LHAPDF_DATA_PATH']=home+(os.pathsep+existing if existing else '')
    candidates=[Path(os.environ['HEP_COLLIDER_ENGINE'])] if os.environ.get('HEP_COLLIDER_ENGINE') else [Path(__file__).parent/name for name in ('libhep-collider-engine.so','libhep-collider-engine.dylib','hep-collider-engine.dll')]
    location=next((p for p in candidates if p.is_file()),None)
    libraries={name:{'available':False,'status':'Needs installation','version':''} for name in ('PYTHIA','HepMC3','FastJet','ROOT','LHAPDF')}
    cap={'available':False,'backend':'hep.collider/1','libraries':libraries,'reason':'Install a scientific runtime containing the collider engine'}
    if location:
        try:
            ENGINE=ctypes.CDLL(str(location))
            ENGINE.hep_collider_capabilities.restype=ctypes.c_void_p
            ENGINE.hep_collider_execute.argtypes=[ctypes.c_char_p,PROGRESS,CANCEL];ENGINE.hep_collider_execute.restype=ctypes.c_void_p
            ENGINE.hep_collider_free.argtypes=[ctypes.c_void_p]
            cap.update(_json(ENGINE.hep_collider_capabilities()));cap['location']=str(location)
            if cap.get('available'):cap.pop('reason',None)
            if cap.get('pythiaData') and not os.environ.get('PYTHIA8DATA'):os.environ['PYTHIA8DATA']=cap['pythiaData']
            cap['libraries'].setdefault('LHAPDF',libraries['LHAPDF'])
        except Exception as e:
            cap['reason']='Collider runtime incompatible: '+str(e)
            for lib in libraries.values():lib['status']='Incompatible'
    if cap.get('available'):
        cap['libraries']['PYTHIA']['parallel_generation']=True
        cap['libraries']['PYTHIA']['parallelStrategy']='isolated-process-partitions-v1'
    env={'libraries':{k:{a:b for a,b in v.items() if a not in ('paths','location')} for k,v in cap['libraries'].items()},'platform':platform.system(),'architecture':platform.machine(),
         'compiler':cap.get('compiler','unknown'),'cppStandard':cap.get('cppStandard'),'python':platform.python_version(),'adapterVersion':1}
    if location:
        digest=hashlib.sha256()
        with location.open('rb') as stream:
            while block:=stream.read(1024*1024):digest.update(block)
        env['engineSha256']=digest.hexdigest()
    env['adapterSha256']={Path(__file__).name:hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
    for filename in ('codegen.py','parallel.py','samples.py','pdf_manager.py','root_backend.py'):
        path=Path(__file__).parent/filename
        if not path.exists() and filename=='pdf_manager.py':path=Path(__file__).resolve().parents[1]/'lhapdf'/'manager.py'
        if not path.exists() and filename=='root_backend.py':path=Path(__file__).resolve().parents[1]/'root'/'backend.py'
        if path.exists():env['adapterSha256'][filename]=hashlib.sha256(path.read_bytes()).hexdigest()
    env['id']='hep-env://installed/'+hashlib.sha256(json.dumps(env,sort_keys=True,separators=(',',':')).encode()).hexdigest()[:24]
    cap.update(environment=env,python=sys.executable,runtimeId=os.environ.get('HEP_RUNTIME_ID','native'),
               supportedParallelStrategy='logical-blocks-v2',maximumGeneratorWorkers=32)
    cap['sampleRoot']=str(Path(os.environ.get('HEP_SAMPLE_HOME',str(Path.home()/'HEPStudio'/'samples'))))
    CAPABILITY=cap
    return cap

def derive_seed(project_seed,config,node_id):
    strategy=config.get('seedStrategy','fixed')
    if strategy=='fixed':
        value=str(config.get('seed','1'))
        if not value.isdecimal() or not 1<=int(value)<=900000000:raise ValueError('Seed must be an integer from 1 to 900000000')
        return int(value),{'strategy':strategy,'configuredSeed':value,'actualSeed':int(value)}
    if strategy!='project-derived':raise ValueError('Unsupported seed strategy')
    identity='hep-studio-seed-v1\0'+str(project_seed)+'\0'+str(node_id)
    seed=1+int.from_bytes(hashlib.sha256(identity.encode()).digest()[:8],'big')%900000000
    return seed,{'strategy':strategy,'projectSeed':str(project_seed),'nodeId':node_id,'derivation':'SHA256 first uint64 big-endian modulo 900000000 + 1','actualSeed':seed}

def _root_adapter():
    path=Path(__file__).parent/'root_backend.py'
    if not path.exists():path=Path(__file__).resolve().parents[1]/'root'/'backend.py'
    spec=importlib.util.spec_from_file_location('hep_root_adapter',path);module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
    module.initialize()
    if str(module.ROOT.gROOT.GetVersion())!=CAPABILITY['libraries']['ROOT']['version']:raise ValueError('PyROOT and collider ROOT versions differ; repair the environment')
    return module

def _finalize_histograms(result):
    # Reuse the established ROOT normalization and fit adapter, only for compact bins.
    plan=result.get('executionPlan',{}).get('nodes',[])
    fits=any(n['kind']=='Fit' for n in plan)
    root=_root_adapter() if fits else None
    hists={}
    for node in plan:
        if node['kind']!='Histo1D':continue
        nid=node['id'];h=result['results'][nid];c=node['config'];values=h['values'];errors=h['errors'];edges=h['edges']
        flow=c.get('flow','separate');norm=c.get('normalization','counts')
        if flow not in ('separate','fold') or norm not in ('counts','unit-area','density'):raise ValueError('Unknown histogram flow or normalization')
        if flow=='fold':
            for index,which in ((0,'underflow'),(-1,'overflow')):values[index]+=h[which];errors[index]=math.hypot(errors[index],h[which+'Error'])
        if norm!='counts':
            integral=sum(values)
            if integral<=0:raise ValueError('Normalization requires a positive histogram integral')
            for i in range(len(values)):
                factor=integral*(edges[i+1]-edges[i] if norm=='density' else 1);values[i]/=factor;errors[i]/=factor
        if root:
            th=root.ROOT.TH1D('collider_'+nid,'',len(values),array.array('d',edges));th.SetDirectory(0);th.Sumw2()
            for i,(v,e) in enumerate(zip(values,errors),1):th.SetBinContent(i,v);th.SetBinError(i,e)
            th.SetBinContent(0,h['underflow']);th.SetBinError(0,h['underflowError']);th.SetBinContent(len(values)+1,h['overflow']);th.SetBinError(len(values)+1,h['overflowError']);th.SetEntries(h['entries']);hists[nid]=th
        h['normalization']=norm;h['flowPolicy']=flow
    for node in plan:
        if node['kind']=='Fit':
            fit=root.fit_histogram(hists[node['input']],node['config']);fit['histogramId']=node['input'];result['results'][node['id']]=fit

def dispatch(request,cancel,progress):
    if ENGINE is None or not CAPABILITY.get('available'):raise ValueError(CAPABILITY.get('reason','Collider runtime unavailable'))
    payload=dict(request.get('payload',{}));operation=request['operation']
    partition=operation=='executePartition'
    if partition:operation='execute'
    if operation=='inspectSample':
        path=Path(payload['path'])
        from samples import load
        load(path,cancel)
        identity=file_identity(path,cancel,full=payload.get('fullChecksum',False))
        return {'sampleIdentity':identity,'path':str(path)}
    if operation=='exportSample':
        from samples import load
        manifest=load(payload['path'],cancel)
        payload['shards']=[s['resolvedPath'] for s in manifest['shards']] if manifest else [payload['path']]
        if manifest:payload['eventCount']=manifest['eventCount']
    if operation=='prepareSample':
        name=str(payload['resourceId'])
        if not name or any(c not in 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789-' for c in name):raise ValueError('Invalid sample identity')
        root=Path(CAPABILITY['sampleRoot']);root.mkdir(parents=True,exist_ok=True)
        path=root/(name+'.hepsample.json')
        if path.exists():raise ValueError('Sample already exists')
        return {'sampleDestination':{'resourceId':name,'path':str(path),'runtimeId':CAPABILITY['runtimeId']}}
    if operation=='pdfInstall':
        if not CAPABILITY['libraries']['LHAPDF']['available']:raise ValueError('LHAPDF unavailable')
        return pdf_manager().install(payload,cancel,progress)
    payload['jobId']=request.get('id','job')
    seed_info={}
    inputs={}
    shard_identities={}
    pdf_identity={}
    if operation in ('execute','eventPreview'):
        for node in payload['workflow']['nodes']:
            if node['typeId']=='hep.collider.Pythia':
                payload['actualSeed'],seed_info=derive_seed(payload.get('projectSeed','0'),node['config'],node['id'])
                pdf=node['config'].get('pdf',{})
                if pdf.get('set'):
                    name=pdf['set'];member=int(pdf.get('member',0))
                    for base in CAPABILITY['libraries']['LHAPDF'].get('paths',[]):
                        folder=Path(base)/name
                        if not (folder/(name+'.info')).is_file():continue
                        pdf_identity={'set':name,'member':member,'files':{}}
                        for f in (folder/(name+'.info'),folder/(name+'_'+str(member).zfill(4)+'.dat')):
                            pdf_identity['files'][f.name]=file_identity(f,cancel,full=True)
                        break
                    if not pdf_identity:raise ValueError('Selected LHAPDF set/member unavailable; no substitute was used')
            if node['typeId']=='hep.collider.HepMCSource':
                rid=node['config']['resourceId'];resource=payload['resources'][rid]
                identity=file_identity(Path(resource['path']),cancel,full=bool(resource.get('sha256')) or resource.get('identity',{}).get('hashStrategy')=='sha256-full')
                if resource.get('sha256') and resource['sha256']!=identity['sha256']:raise ValueError('Sample changed since its recorded checksum. Relink/accept the new input before running.')
                previous=resource.get('identity',{})
                if not resource.get('sha256') and previous.get('sha256') and previous['sha256']!=identity['sha256']:raise ValueError('Sample changed since inspection. Relink/accept the new input before running.')
                inputs[rid]=identity
                from samples import load
                manifest=load(resource['path'],cancel)
                if manifest:
                    resource['shards']=[s['resolvedPath'] for s in manifest['shards']];resource['manifestEventCount']=manifest['eventCount']
                    for file in resource['shards']:shard_identities[file]=(Path(file).stat().st_size,Path(file).stat().st_mtime_ns)
        payload.setdefault('actualSeed',1)
    if os.environ.get('PYTHIA8DATA'):payload['pythiaData']=os.environ['PYTHIA8DATA']
    @PROGRESS
    def report(data):
        try:progress(json.loads(data))
        except Exception:cancel.set()
    @CANCEL
    def stopping():return int(cancel.is_set())
    data=json.dumps({'operation':operation,'payload':payload},allow_nan=False,separators=(',',':')).encode()
    workers=1
    if operation=='execute' and not partition:
        for node in payload['workflow']['nodes']:
            if node['typeId']=='hep.collider.Pythia':workers=node['config'].get('workers',1)
        if type(workers) is not int or not 1<=workers<=32:raise ValueError('Generator workers must be an integer in [1,32]')
    generator_config=next((n['config'] for n in payload.get('workflow',{}).get('nodes',[]) if n['typeId']=='hep.collider.Pythia'),None)
    scheduled=operation=='execute' and not partition and generator_config is not None and (generator_config.get('streamPolicy')=='logical-blocks-v2' or generator_config.get('logicalStreams',workers)>1)
    if scheduled:
        from parallel import execute
        result=execute(payload,workers,cancel,progress,Path(__file__).resolve().parent,Path(CAPABILITY['location']).resolve(),CAPABILITY['environment']['id'])
        seed_info['partitions']=result['generator']['partitions']
        seed_info['parallelStrategy']=result['generator']['parallelStrategy']
    else:result=_json(ENGINE.hep_collider_execute(data,report,stopping))
    if cancel.is_set() or result.get('error')=='Cancelled':raise InterruptedError('Collider job cancelled')
    if 'error' in result:raise ValueError(result['error'])
    if partition:return result
    if operation in ('execute','eventPreview'):
        for rid,before in inputs.items():
            now=Path(payload['resources'][rid]['path']).stat()
            if now.st_size!=before['sizeBytes'] or now.st_mtime_ns!=before['mtimeNs']:raise ValueError('Sample changed during execution; results discarded')
        for file,before in shard_identities.items():
            now=Path(file).stat()
            if (now.st_size,now.st_mtime_ns)!=before:raise ValueError('Sample shard changed during execution; results discarded')
        _finalize_histograms(result)
        result['inputResources']=inputs
        if pdf_identity:result['generator']['pdfIdentity']=pdf_identity
        result['seed']=seed_info;result['environment']=CAPABILITY['environment'];result['backend']='hep.collider/1'
        result['runtimeId']=CAPABILITY['runtimeId'];result['preferredEnvironmentDifference']=payload.get('environmentDifference',[])
        for sample in result.get('samples',[]):
            path=Path(sample['path']);h=hashlib.sha256()
            with path.open('rb') as stream:
                while block:=stream.read(1024*1024):
                    if cancel.is_set():raise InterruptedError('Cancelled while checksumming materialized sample')
                    h.update(block)
            sample['sha256']=h.hexdigest();sample['hashStrategy']='sha256-full';sample['seed']=seed_info;sample['generator']=result['generator'];sample['environment']=result['environment']
        result['generatedConfiguration']='\n'.join(result.get('generator',{}).get('equivalentSettings',[]))+'\n'
        if scheduled:
            result['generatedConfiguration']='! Logical-stream Run: use each recorded seed and event count; one execution of this base configuration does not reproduce the merged sample.\n'+'\n'.join('! partition {index}: seed={seed}, events={events}'.format(**p) for p in result['generator']['partitions'])+'\n'+result['generatedConfiguration']
        result['generatedCode']=equivalent_code(result)
    return result

def file_identity(path,cancel,full=False):
    stat=path.stat();digest=hashlib.sha256()
    with path.open('rb') as stream:
        if full:
            while block:=stream.read(1024*1024):
                if cancel.is_set():raise InterruptedError('Cancelled while checking scientific input')
                digest.update(block)
        else:
            digest.update(str(stat.st_size).encode()+b'\0');digest.update(stream.read(65536))
            if stat.st_size>65536:stream.seek(max(65536,stat.st_size-65536));digest.update(stream.read(65536))
    return {'sizeBytes':stat.st_size,'mtimeNs':stat.st_mtime_ns,'sha256':digest.hexdigest(),'hashStrategy':'sha256-full' if full else 'sha256-size-first-last-64KiB-v1'}

def equivalent_code(result):
    from codegen import generate
    return generate(result)
