"""Transactional sharded HepMC samples. The manifest is the commit record."""
import hashlib,json,os,shutil,uuid
from pathlib import Path

FORMAT='hep-studio-hepmc-shards-v1'

def checksum(path,cancel):
    digest=hashlib.sha256()
    with Path(path).open('rb') as source:
        while block:=source.read(1024*1024):
            if cancel.is_set():raise InterruptedError('Cancelled during HepMC checksumming')
            digest.update(block)
    return digest.hexdigest()

def load(path,cancel):
    path=Path(path)
    with path.open('rb') as source:
        if source.read(1)!=b'{':return None
        if path.stat().st_size>4*1024*1024:raise ValueError('Oversized sample manifest')
    manifest=json.loads(path.read_text())
    if manifest.get('format')!=FORMAT or manifest.get('complete') is not True:raise ValueError('Incomplete/unsupported sample manifest')
    shards=manifest.get('shards',[])
    if not shards or len(shards)>4096:raise ValueError('Invalid sample shard count')
    offset=0;seen=set()
    for index,shard in enumerate(shards):
        relative=Path(shard['location'])
        if relative.is_absolute() or '..' in relative.parts:raise ValueError('Unsafe shard location')
        file=(path.parent/relative).resolve()
        if not file.is_relative_to(path.parent.resolve()) or file in seen:raise ValueError('Invalid/duplicate shard location')
        seen.add(file)
        if shard['index']!=index or shard['firstEvent']!=offset or shard['events']<1:raise ValueError('Invalid shard event ranges')
        offset+=shard['events']
        if not file.is_file() or file.stat().st_size!=shard['sizeBytes'] or checksum(file,cancel)!=shard['sha256']:raise ValueError('Sample shard unavailable or corrupt')
        with file.open('rb') as stream:
            stream.seek(max(0,file.stat().st_size-4096))
            if b'HepMC::Asciiv3-END_EVENT_LISTING' not in stream.read():raise ValueError('Incomplete HepMC shard')
        shard['resolvedPath']=str(file)
    if offset!=manifest['eventCount']:raise ValueError('Sample event count mismatch')
    return manifest

class Transaction:
    def __init__(self,payload,parts,cancel):
        self.cancel=cancel;self.outputs={};self.committed=False
        try:
            for node in payload['workflow']['nodes']:
                if node['typeId']!='hep.collider.StoreHepMC':continue
                rid=node['config']['resourceId'];path=Path(payload['resources'][rid]['path'])
                if path.exists():raise ValueError('Sample output already exists')
                if not path.parent.is_dir():raise ValueError('Sample destination folder unavailable')
                if shutil.disk_usage(path.parent).free<sum(p['events'] for p in parts)*1024*1024+64*1024*1024:raise ValueError('Insufficient disk space for sharded HepMC estimate')
                token=uuid.uuid4().hex;stage=path.parent/(path.name+'.incomplete-'+token);stage.mkdir(mode=0o700)
                self.outputs[rid]={'path':path,'stage':stage,'final':path.parent/(path.name+'.shards-'+token)}
        except Exception:
            self.close();raise
    def child_payload(self,payload,part):
        import copy
        child=copy.deepcopy(payload)
        for rid,out in self.outputs.items():child['resources'][rid]['path']=str(out['stage']/('shard-%06d.hepmc'%part['index']))
        return child
    def commit(self,parts,results,environment):
        samples=[]
        # Validate/checksum all shards before publishing any manifest.
        manifests={}
        for rid,out in self.outputs.items():
            shards=[]
            for part,result in zip(parts,results):
                if self.cancel.is_set():raise InterruptedError('Cancelled during HepMC persistence')
                sample=next(s for s in result['samples'] if s['resourceId']==rid)
                file=Path(sample['path'])
                if sample['eventCount']!=part['events']:raise ValueError('Incomplete shard event count')
                with file.open('rb') as stream:
                    stream.seek(max(0,file.stat().st_size-4096))
                    if b'HepMC::Asciiv3-END_EVENT_LISTING' not in stream.read():raise ValueError('Incomplete HepMC shard before commit')
                shards.append(dict(part,format='HepMC3-Asciiv3',sizeBytes=file.stat().st_size,sha256=checksum(file,self.cancel),location=out['final'].name+'/'+file.name))
            manifest={'format':FORMAT,'complete':True,'eventCount':sum(p['events'] for p in parts),'environment':environment,'shards':shards}
            canonical=[{k:v for k,v in s.items() if k!='location'} for s in shards]
            manifest['contentSha256']=hashlib.sha256(json.dumps(canonical,sort_keys=True,separators=(',',':')).encode()).hexdigest()
            manifests[rid]=manifest
        try:
            for rid,out in self.outputs.items():
                if self.cancel.is_set():raise InterruptedError('Cancelled before sample commit')
                manifest=manifests[rid];os.rename(out['stage'],out['final']);temp=out['final']/'manifest.pending'
                with temp.open('w') as stream:json.dump(manifest,stream,sort_keys=True,indent=2);stream.flush();os.fsync(stream.fileno())
                os.link(temp,out['path']);temp.unlink()
                samples.append({'resourceId':rid,'path':str(out['path']),'format':FORMAT,'eventCount':manifest['eventCount'],'sizeBytes':sum(s['sizeBytes'] for s in manifest['shards']),'contentSha256':manifest['contentSha256'],'shardCount':len(parts)})
            self.committed=True
            return samples
        except Exception:
            for out in self.outputs.values():
                # Only remove a manifest we created, never a competing writer's.
                if any(s['path']==str(out['path']) for s in samples):out['path'].unlink(missing_ok=True)
            raise
    def close(self):
        if not self.committed:
            for out in self.outputs.values():
                shutil.rmtree(out['stage'],ignore_errors=True);shutil.rmtree(out['final'],ignore_errors=True)
