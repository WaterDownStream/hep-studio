"""Deterministic process partitions over the existing version-1 worker protocol.

Only compact accumulators return to the parent. Child stdin EOF terminates native
work if the parent dies; every normal/error/cancel path also reaps its children.
"""
import concurrent.futures,copy,json,math,os,queue,struct,subprocess,sys,threading,time
from pathlib import Path

MAX_FRAME=1024*1024
MAX_RESULT=16*1024*1024

def partitions(seed,events,workers):
    if type(workers) is not int or not 1<=workers<=32:raise ValueError('Generator workers must be an integer in [1,32]')
    if type(events) is not int or events<workers:raise ValueError('Event count must be at least the worker count')
    # A versioned injective seed assignment within a job; no random collisions.
    return [{'index':i,'seed':1+(seed-1+i)%900000000,'events':events//workers+(i<events%workers),'firstEvent':i*(events//workers)+min(i,events%workers)} for i in range(workers)]

def logical_partitions(seed,events,config):
    policy=config.get('streamPolicy','legacy-streams-v1')
    if policy=='legacy-streams-v1':
        result=partitions(seed,events,config.get('logicalStreams',config.get('workers',1)))
        offset=0
        for part in result:part['firstEvent']=offset;offset+=part['events']
        return result
    if policy!='logical-blocks-v2':raise ValueError('Unknown random stream policy')
    block=config.get('partitionEvents',4096)
    if type(block) is not int or not 1<=block<=1000000:raise ValueError('Invalid logical partition size')
    if type(events) is not int or not 1<=events<=1000000000:raise ValueError('Invalid event target')
    count=(events+block-1)//block
    if count>4096:raise ValueError('More than 4096 logical blocks; choose a larger partitionEvents value')
    return [{'index':i,'seed':1+(seed-1+i)%900000000,'events':min(block,events-i*block),'firstEvent':i*block} for i in range(count)]

def _send(process,message):
    data=json.dumps(dict(protocolVersion=1,**message),allow_nan=False,separators=(',',':')).encode()
    if len(data)>MAX_FRAME:raise ValueError('Partition request exceeds control-frame limit')
    packet=memoryview(struct.pack('!I',len(data))+data)
    while packet:
        written=process.stdin.write(packet)
        if not written:raise BrokenPipeError('Partition input closed')
        packet=packet[written:]
    process.stdin.flush()

def _reader(stream,messages):
    def exact(size):
        value=b''
        while len(value)<size:
            block=stream.read(size-len(value))
            if not block:raise EOFError('Collider partition exited or sent an incomplete frame')
            value+=block
        return value
    try:
        while True:
            size=struct.unpack('!I',exact(4))[0]
            if not 0<size<=MAX_FRAME:raise ValueError('Invalid partition frame length')
            message=json.loads(exact(size));message['_frameBytes']=size+4
            if message.get('protocolVersion')!=1:raise ValueError('Partition protocol mismatch')
            messages.put(message)
    except Exception as error:messages.put(error)

def run_partition(payload,part,cancel,progress,backend_path,engine_path):
    worker=backend_path/'worker.py'
    if not worker.exists():worker=backend_path.parent/'root'/'worker.py'
    if not worker.is_file():raise ValueError('Collider worker script unavailable')
    bootstrap='import sys,runpy;sys.path.insert(0,sys.argv[1]);runpy.run_path(sys.argv[2],run_name="__main__")'
    env=dict(os.environ,HEP_COLLIDER_ENGINE=str(engine_path),OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',MKL_NUM_THREADS='1')
    process=subprocess.Popen([sys.executable,'-u','-c',bootstrap,str(backend_path),str(worker)],stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE,env=env,bufsize=0)
    messages=queue.Queue();logs=bytearray()
    def diagnostics():
        while True:
            block=process.stderr.read(4096)
            if not block:return
            logs.extend(block)
            if len(logs)>65536:del logs[:-65536]
    readers=[threading.Thread(target=_reader,args=(process.stdout,messages),daemon=True),threading.Thread(target=diagnostics,daemon=True)]
    for reader in readers:reader.start()
    chunks=[];size=0;wire_bytes=0;ready=False;last=time.monotonic();began=last
    try:
        while True:
            if cancel.is_set():raise InterruptedError('Collider job cancelled')
            try:message=messages.get(timeout=.1)
            except queue.Empty:
                if time.monotonic()-last>30 or not ready and time.monotonic()-began>30:raise TimeoutError('Collider partition handshake/heartbeat timed out')
                continue
            if isinstance(message,Exception):raise message
            last=time.monotonic();wire_bytes+=message.get('_frameBytes',0);kind=message.get('kind')
            if kind=='hello':
                if ready or message.get('capability',{}).get('backend')!='hep.collider/1' or not message.get('capability',{}).get('available'):raise ValueError('Collider partition unavailable/incompatible')
                if message['capability'].get('environment',{}).get('id')!=payload['_partitionEnvironmentId']:raise ValueError('Partition environment differs from the frozen parent environment; restart the runtime')
                child=copy.deepcopy(payload)
                for node in child['workflow']['nodes']:
                    if node['typeId']=='hep.collider.Pythia':node['config'].update(events=part['events'],workers=1,seedStrategy='fixed',seed=str(part['seed']))
                child['eventOffset']=part.get('firstEvent',0);child['allocatedThreads']=1;child['inspectEvents']=1 if part['index']==0 else 0
                progress(part['index'],{'pid':process.pid,'stage':'Partition ready'})
                _send(process,{'kind':'request','id':'partition','operation':'executePartition','payload':child,'resultTransport':'chunks'});ready=True
            elif kind=='heartbeat':pass
            elif kind=='progress':progress(part['index'],message.get('metrics',{}))
            elif kind=='resultChunk':
                if message.get('id')!='partition' or message.get('sequence')!=len(chunks):raise ValueError('Invalid partition result sequence')
                chunk=message['data'];size+=len(chunk.encode())
                if size>MAX_RESULT:raise ValueError('Partition result exceeds limit')
                chunks.append(chunk)
            elif kind=='failed':raise ValueError(message.get('message','Collider partition failed'))
            elif kind=='completed':
                if message.get('id')!='partition' or message.get('chunks')!=len(chunks) or not chunks:raise ValueError('Incomplete partition result')
                result=json.loads(''.join(chunks));result['partition']=part;result['controlBytes']=wire_bytes;result['startupSeconds']=max(0,time.monotonic()-began-result.get('operationSeconds',0));result['diagnostics']=logs.decode(errors='replace');return result
            else:raise ValueError('Unexpected collider partition message')
    except Exception as error:
        detail=logs.decode(errors='replace')
        if detail and not isinstance(error,InterruptedError):raise RuntimeError(str(error)+'\nPartition diagnostics:\n'+detail) from error
        raise
    finally:
        # Closing stdin also stops a child busy inside native code. Never wait
        # indefinitely, including when cancellation happens during initialization.
        try:process.stdin.close()
        except OSError:pass
        try:process.wait(timeout=1)
        except subprocess.TimeoutExpired:
            process.kill();process.wait(timeout=2)
        for reader in readers:reader.join(timeout=1)
        process.stdout.close();process.stderr.close()

def merge(results,payload,parts,elapsed,cancel=None):
    if cancel and cancel.is_set():raise InterruptedError("Cancelled during result merge")
    result=copy.deepcopy(results[0]);result.pop('partition',None);result.pop('diagnostics',None);result['executionPlan']['requiredThreads']=len(parts)
    for node in result['executionPlan']['nodes']:
        if node['kind']=='Pythia':node['config']=next(n['config'] for n in payload['workflow']['nodes'] if n['id']==node['id'])
    for key,out in result['results'].items():
        if cancel and cancel.is_set():raise InterruptedError('Cancelled during result merge')
        values=[r['results'][key] for r in results]
        if out['kind']=='Histogram1D':
            if any(v['edges']!=out['edges'] or v['dimension']!=out['dimension'] for v in values):raise ValueError('Incompatible partition histograms')
            out['values']=[math.fsum(v['values'][i] for v in values) for i in range(len(out['values']))]
            out['errors']=[math.sqrt(math.fsum(v['errors'][i]**2 for v in values)) for i in range(len(out['errors']))]
            for name in ('entries','underflow','overflow'):out[name]=math.fsum(v[name] for v in values)
            for name in ('underflowError','overflowError'):out[name]=math.sqrt(math.fsum(v[name]**2 for v in values))
            stats=[math.fsum(v['statistics'][i] for v in values) for i in range(4)];out['statistics']=stats
            out['mean']=stats[2]/stats[0] if stats[0] else 0
            out['rms']=math.sqrt(abs(stats[3]/stats[0]-out['mean']**2)) if stats[0] else 0
        elif out['kind']=='ScalarResult':
            count=sum(v['count'] for v in values);total=math.fsum(v['sum'] for v in values);op=out['operation']
            out.update(count=count,sum=total)
            out['value']=count if op=='Count' else total if op=='Sum' else None if not count else total/count if op=='Mean' else (min if op=='Min' else max)(v['value'] for v in values if v['count'])
        else:raise ValueError('Unsupported parallel result type')
    metrics=result['metrics']
    for key in ('generated','accepted','attempts','failed'):metrics[key]=sum(r['metrics'][key] for r in results)
    metrics['sumWeightsSquared']=math.fsum(r['metrics'].get('sumWeightsSquared',0) for r in results)
    metrics['sumWeights']=math.fsum(r['metrics']['sumWeights'] for r in results)
    metrics.update(threads=len(parts),workerProcesses=len(parts),eventLoopSeconds=max(r['metrics']['eventLoopSeconds'] for r in results),parallelWallSeconds=elapsed,eventsPerSecond=metrics['accepted']/elapsed,rateBasis='parallel wall time including startup and merge',bulkEventsThroughIPC=0)
    result['partitionRuns']=[dict(p,metrics=r['metrics'],peakRssBytes=r.get('peakRssBytes'),diagnostics=r['diagnostics'],cpuSeconds=r.get('cpuSeconds',0),startupSeconds=r.get('startupSeconds',0),initializationAndSetupSeconds=max(0,r.get('operationSeconds',0)-r['metrics']['eventLoopSeconds']),controlBytes=r.get('controlBytes',0)) for p,r in zip(parts,results)]
    result['generator'].update(parallelStrategy='isolated-process-partitions-v1',threads=len(parts),actualSeeds=[p['seed'] for p in parts],partitions=parts,
        reproducibility='Fixed logical streams and ordered reduction; see recorded stream policy. No cross-platform bitwise guarantee.')
    return result

def execute(payload,workers,cancel,progress,backend_path,engine_path,environment_id):
    payload=dict(payload,_partitionEnvironmentId=environment_id)
    nodes=payload['workflow']['nodes'];sources=[n for n in nodes if n['typeId']=='hep.collider.Pythia']
    if len(sources)!=1:raise ValueError('Parallel generation requires one PYTHIA source')
    if workers>payload.get('allocatedThreads',1):raise ValueError('Parallel generation exceeds the Resource Broker allocation')
    parts=logical_partitions(payload['actualSeed'],sources[0]['config'].get('events',1000),sources[0]['config'])
    from samples import Transaction
    transaction=Transaction(payload,parts,cancel)
    state={};lock=threading.Lock();started=time.monotonic()
    def report(index,metrics):
        with lock:
            state.setdefault(index,{}).update(metrics);accepted=sum(s.get('accepted',0) for s in state.values())
            progress(dict(stage='Parallel generation / clustering',accepted=accepted,generated=accepted,target=sum(p['events'] for p in parts),workers=workers,workerPids=[s['pid'] for s in state.values() if 'pid' in s],eventsPerSecond=accepted/max(.001,time.monotonic()-started)))
    try:
        with concurrent.futures.ThreadPoolExecutor(max_workers=workers) as pool:
            pending={};results=[];accumulator_bytes=0
            def submit(index):
                part=parts[index];pending[index]=pool.submit(run_partition,transaction.child_payload(payload,part),part,cancel,report,backend_path,engine_path)
            for i in range(min(workers,len(parts))):submit(i)
            try:
                for i in range(len(parts)):
                    while not pending[i].done():
                        if cancel.wait(.05):raise InterruptedError('Cancelled while waiting for a logical block')
                        for future in pending.values():
                            if future.done() and future.exception():future.result()
                    result=pending.pop(i).result();accumulator_bytes+=len(json.dumps(result))
                    if accumulator_bytes>128*1024*1024:raise ValueError('Compact accumulator budget exceeded; increase logical block size or reduce histogram output')
                    results.append(result)
                    if i+workers<len(parts):submit(i+workers)
            except Exception:
                cancel.set();raise
        progress({'stage':'Merging compact results','activeScientificThreads':1})
        merge_start=time.monotonic();result=merge(results,payload,parts,time.monotonic()-started,cancel)
        result['metrics'].update(threads=workers,workerProcesses=min(workers,len(parts)),logicalPartitions=len(parts),mergeSeconds=time.monotonic()-merge_start)
        result['executionPlan']['requiredThreads']=workers
        result['generator'].update(parallelStrategy=sources[0]['config'].get('streamPolicy','legacy-streams-v1'),threads=workers,reproducibility='Fixed logical streams and index-ordered reduction; physical worker count affects scheduling only. Same installed environment required; no cross-platform bitwise guarantee.')
        progress({'stage':'Committing sample shards','activeScientificThreads':1})
        commit_start=time.monotonic();result['samples']=transaction.commit(parts,results,environment_id)
        elapsed=time.monotonic()-started
        result['metrics'].update(sampleCommitSeconds=time.monotonic()-commit_start,parallelWallSeconds=elapsed,eventsPerSecond=result['metrics']['accepted']/elapsed,rateBasis='generation, clustering, compact merge and sample commit; post-fit excluded')
        return result
    finally:transaction.close()
