"""Typed reconstructed analysis lowered once into native RDataFrame operations."""
from __future__ import annotations
import array,json,math,tempfile,threading,time,uuid
import statistical
from pathlib import Path
from artifacts import check_cancel

DECLARED=False
HELPERS=r'''
#include <ROOT/RVec.hxx>
#include <Math/Vector4D.h>
#include <algorithm>
#include <cmath>
#include <fstream>
#include <limits>
#include <set>
#include <stdexcept>
namespace hep_reco {
struct Object {double pt,eta,phi,mass,charge;int flavour;double isolation=std::numeric_limits<double>::quiet_NaN(),btag=std::numeric_limits<double>::quiet_NaN();int origin=0;size_t index=0;};
using Objects=ROOT::VecOps::RVec<Object>;
template<class P,class E,class F,class C,class M>
Objects make(const P& pt,const E& eta,const F& phi,const C& charge,const M& mass,int flavour,int origin){
 if(pt.size()!=eta.size()||pt.size()!=phi.size()||pt.size()!=charge.size()||pt.size()!=mass.size())throw std::runtime_error("Inconsistent reconstructed branch sizes");
 Objects out;out.reserve(pt.size());for(size_t i=0;i<pt.size();++i){Object o{double(pt[i]),double(eta[i]),double(phi[i]),double(mass[i]),double(charge[i]),flavour};o.origin=origin;o.index=i;out.push_back(o);}return out;
}
template<class V> Objects attach(Objects in,const V& values,bool isolation){
 if(in.size()!=values.size())throw std::runtime_error("Inconsistent reconstructed capability branch sizes");
 for(size_t i=0;i<in.size();++i){if(isolation)in[i].isolation=double(values[i]);else in[i].btag=double(values[i]);}return in;
}
double energy(const Object& o){return std::sqrt(o.mass*o.mass+o.pt*o.pt*std::cosh(o.eta)*std::cosh(o.eta));}
ROOT::VecOps::RVec<double> properties(const Objects& in,const std::string& key){
 ROOT::VecOps::RVec<double> out;out.reserve(in.size());for(const auto& o:in){
 if(key=="pt")out.push_back(o.pt);else if(key=="eta")out.push_back(o.eta);else if(key=="phi")out.push_back(o.phi);else if(key=="mass")out.push_back(o.mass);else if(key=="charge")out.push_back(o.charge);else if(key=="energy")out.push_back(energy(o));else if(key=="isolation")out.push_back(o.isolation);else if(key=="btag")out.push_back(o.btag);else throw std::runtime_error("Unknown reconstructed property");}return out;
}
template<class Predicate> Objects select(const Objects& in,Predicate accept){Objects out;for(const auto& o:in)if(accept(o))out.push_back(o);return out;}
Objects sort(Objects in,const std::string& property,bool descending){std::stable_sort(in.begin(),in.end(),[&](const auto& a,const auto& b){Objects pair{a,b};auto v=properties(pair,property);return descending?v[0]>v[1]:v[0]<v[1];});return in;}
Objects take(Objects in,size_t n){if(in.size()>n)in.resize(n);return in;}
Objects combine(const Objects& primary,const Objects& reference){
 Objects out;std::set<std::pair<int,size_t>> seen;
 for(const auto* input:{&primary,&reference})for(const auto& o:*input)if(seen.emplace(o.origin,o.index).second)out.push_back(o);
 return out;
}
Objects remove_overlaps(const Objects& in,const Objects& reference,double radius){
 Objects out;for(const auto& a:in){bool overlap=false;for(const auto& b:reference){
  const double de=a.eta-b.eta,dp=std::remainder(a.phi-b.phi,2*std::acos(-1.));
  if(!std::isfinite(de)||!std::isfinite(dp))throw std::runtime_error("Nonfinite reconstructed overlap coordinates");
  if(std::hypot(de,dp)<radius){overlap=true;break;}
 }if(!overlap)out.push_back(a);}return out;
}
Objects pairs(const Objects& in,bool opposite,bool same){
 Objects out;for(size_t i=0;i<in.size();++i)for(size_t j=i+1;j<in.size();++j){const auto& a=in[i];const auto& b=in[j];if(opposite&&a.charge*b.charge>=0)continue;if(same&&a.flavour!=b.flavour)continue;
 ROOT::Math::PtEtaPhiMVector sum=ROOT::Math::PtEtaPhiMVector(a.pt,a.eta,a.phi,a.mass)+ROOT::Math::PtEtaPhiMVector(b.pt,b.eta,b.phi,b.mass);
 out.push_back({sum.Pt(),sum.Eta(),sum.Phi(),sum.M(),a.charge+b.charge,0});}return out;
}
double ht(const Objects& in){double result=0;for(const auto& o:in)result+=o.pt;return result;}
bool guard(const std::string& cancellation){static thread_local unsigned checks=0;if((checks++%1024)==0){std::ifstream f(cancellation);if(f.good())throw std::runtime_error("Research analysis cancelled");}return true;}
}
'''

COLLECTION_KINDS={'Muons','Electrons','Jets','MissingET','Photons','Tracks','CollectionFilter','CollectionSort','CollectionTake','Pairs','OverlapRemoval','CollectionCombine'}
def object_columns(root,caps):
    return {k:('o.'+k if k!='energy' else 'hep_reco::energy(o)',(1,0,0,0) if k in ('pt','mass','energy') else (0,0,0,1) if k=='phi' else root.ZERO,False,False)
            for k in ('pt','eta','phi','mass','energy','charge','isolation','btag') if k not in ('isolation','btag') or k in caps}

def lower_collections(plan,available,root,define,cancel=None):
    """Define pure collection branches before event filters/actions.

    Both inputs of a binary collection operation must be columns on the same
    event row. This prepass avoids joining independently filtered RDataFrames.
    The callback is shared by native execution and standalone code export.
    """
    lowered={}
    for index,node in enumerate(plan['nodes']):
        check_cancel(cancel);kind=node['kind']
        if kind not in COLLECTION_KINDS:continue
        nid=node['id'];c=node['config'];prefix='__hep_r'+str(index)
        if kind in ('Muons','Electrons','Jets','MissingET','Photons','Tracks'):
            branch={'Muons':'Muon','Electrons':'Electron','Jets':'Jet','MissingET':'MissingET','Photons':'Photon','Tracks':'Track'}[kind]
            pt=branch+('.MET' if kind=='MissingET' else '.PT');eta=branch+'.Eta';phi=branch+'.Phi'
            if any(k not in available for k in (pt,eta,phi)):raise ValueError('Detector card does not produce '+kind)
            charge=branch+'.Charge' if branch+'.Charge' in available else 'ROOT::VecOps::RVec<double>('+pt+'.size(),0.)'
            mass=branch+'.Mass' if branch+'.Mass' in available else 'ROOT::VecOps::RVec<double>('+pt+'.size(),'+('0.105658' if kind=='Muons' else '0.000511' if kind=='Electrons' else '0.')+')'
            flavour=13 if kind=='Muons' else 11 if kind=='Electrons' else 0
            origin={'Muons':13,'Electrons':11,'Jets':100,'MissingET':101,'Photons':22,'Tracks':102}[kind];semantic={'Muons':'RecoMuonCollection','Electrons':'RecoElectronCollection','Jets':'RecoJetCollection','MissingET':'RecoMissingETCollection','Photons':'RecoPhotonCollection','Tracks':'RecoTrackCollection'}[kind]
            col=prefix;define(col,f'hep_reco::make({pt},{eta},{phi},{charge},{mass},{flavour},{origin})');caps=set()
            for prop,field in (('isolation','IsolationVar'),('btag','BTag')):
                if branch+'.'+field in available:
                    nextcol=col+'_'+prop;define(nextcol,f'hep_reco::attach({col},{branch}.{field},{str(prop=="isolation").lower()})');col=nextcol;caps.add(prop)
        else:
            parent=lowered.get(node.get('input'))
            if not parent:raise ValueError('A pure reconstructed collection branch is required')
            col,caps,semantic=parent['column'],set(parent['capabilities']),parent['semanticType'];cols=object_columns(root,caps)
            if kind=='CollectionFilter':
                code,dim,boolean,collected=root.expression(c['expression'],cols)
                if not boolean or collected:raise ValueError('Object filter requires a Boolean scalar')
                code=f'hep_reco::select({col},[](const hep_reco::Object& o){{return {code};}})'
            elif kind=='CollectionSort':
                if c['property'] not in cols:raise ValueError('Unknown sort property')
                code=f'hep_reco::sort({col},{json.dumps(c["property"])},{str(bool(c.get("descending",True))).lower()})'
            elif kind=='CollectionTake':
                count=c.get('count',1)
                if type(count)!=int or not 1<=count<=100000:raise ValueError('Invalid collection take count')
                code=f'hep_reco::take({col},{count})'
            elif kind in ('OverlapRemoval','CollectionCombine'):
                reference=lowered.get(node.get('reference'));radius=c.get('radius')
                physical={'RecoMuonCollection','RecoElectronCollection','RecoLeptonCollection','RecoJetCollection','RecoPhotonCollection','RecoTrackCollection'}
                if not reference or semantic not in physical or reference['semanticType'] not in physical:raise ValueError('Binary operations require reconstructed particle/jet collection branches')
                if kind=='OverlapRemoval':
                    if node['input']==node.get('reference'):raise ValueError('Choose a distinct reconstructed overlap reference branch')
                    if type(radius) not in (int,float) or not math.isfinite(radius) or not 0<=radius<=10 or c.get('boundary')!='strict-less-than':raise ValueError('Overlap radius must be finite in [0,10]; boundary is deltaR < radius')
                    code=f'hep_reco::remove_overlaps({col},{reference["column"]},{float(radius)!r})'
                else:
                    leptons={'RecoMuonCollection','RecoElectronCollection','RecoLeptonCollection'}
                    if semantic!=reference['semanticType']:
                        if semantic not in leptons or reference['semanticType'] not in leptons:raise ValueError('Cannot combine incompatible reconstructed semantic types')
                        semantic='RecoLeptonCollection'
                    if c.get('order')!='primary-then-reference' or c.get('duplicates')!='source-object-once':raise ValueError('Collection combination requires explicit ordered union without duplicated source objects')
                    code=f'hep_reco::combine({col},{reference["column"]})';caps.intersection_update(reference['capabilities'])
            else:
                if semantic not in {'RecoMuonCollection','RecoElectronCollection','RecoLeptonCollection'}:raise ValueError('Pair builder requires a charged lepton collection')
                code=f'hep_reco::pairs({col},{str(bool(c.get("oppositeSign",True))).lower()},{str(bool(c.get("sameFlavour",True))).lower()})';caps=set();semantic='RecoPairCollection'
            define(prefix,'return '+code+';');col=prefix
        lowered[nid]={'column':col,'capabilities':caps,'semanticType':semantic}
    return lowered

def analyze(plan,paths,metadata,root,cancel,progress):
    global DECLARED
    ROOT=root.ROOT
    if not DECLARED:
        if not ROOT.gInterpreter.Declare(HELPERS):raise RuntimeError('Reconstructed RDataFrame helper compilation failed')
        DECLARED=True
    frames={};collections={};columns={};capabilities={};actions={};results={};histograms={};owners=[];started=time.monotonic()
    files=ROOT.std.vector('string')()
    for p in paths:files.push_back(str(p))
    df=ROOT.RDataFrame('Delphes',files);available={str(c) for c in df.GetColumnNames()}
    total=df.Count()
    if 'Event.Weight' not in available:raise ValueError('Reconstructed dataset has no nominal event weight; no unit weights were substituted')
    df=df.Define('__hep_weight','double(Event.Weight.at(0))')
    stop=threading.Event();folder=Path(tempfile.mkdtemp(prefix='hep-reco-cancel-'));marker=folder/'cancel'
    def watch():
        while not stop.wait(.05):
            if cancel and cancel.is_set():marker.touch();return
    watcher=threading.Thread(target=watch,daemon=True);watcher.start()
    df=df.Filter('hep_reco::guard('+json.dumps(str(marker))+')','HEP Studio cancellation guard')
    basecols={'weight':('__hep_weight',root.ZERO,False,False)}
    itemcols={k:('o.'+k if k!='energy' else 'hep_reco::energy(o)',(1,0,0,0) if k in ('pt','mass','energy') else (0,0,0,1) if k=='phi' else root.ZERO,False,False) for k in ('pt','eta','phi','mass','energy','charge','isolation','btag')}
    try:
        def define_collection(name,code):
            nonlocal df
            df=df.Define(name,code)
        lowered=lower_collections(plan,available,root,define_collection,cancel)
        for index,node in enumerate(plan['nodes']):
            check_cancel(cancel);kind=node['kind'];nid=node['id'];c=node['config'];parent=node.get('input')
            frame=frames.get(parent,df);cols=dict(columns.get(parent,basecols));col=collections.get(parent);prefix='__hep_r'+str(index);caps=set(capabilities.get(parent,()))
            objectcols={k:v for k,v in itemcols.items() if k not in ('isolation','btag') or k in caps}
            if kind in ('MadGraph','LHESource','Shower','Delphes','RecoSource'):frames[nid]=df;columns[nid]=basecols;continue
            if nid in lowered:
                col=lowered[nid]['column'];caps=lowered[nid]['capabilities'];cols=dict(basecols)
                for prop,info in object_columns(root,caps).items():cols[prop]=(f'hep_reco::properties({col},{json.dumps(prop)})',info[1],False,True)
                frames[nid]=df;collections[nid]=col;capabilities[nid]=caps;columns[nid]=cols
                continue
            if kind in ('Property','CollectionCount','HT'):
                if col is None:raise ValueError('Reconstructed collection required')
                if kind=='Property':
                    prop=c['property']
                    if prop not in objectcols:raise ValueError('Unknown reconstructed property')
                    code=f'hep_reco::properties({col},{json.dumps(prop)})';dimension=objectcols[prop][1];is_collection=True
                else:code=f'double({col}.size())' if kind=='CollectionCount' else f'hep_reco::ht({col})';dimension=root.ZERO if kind=='CollectionCount' else (1,0,0,0);is_collection=False
                frame=frame.Define(prefix,code);cols['value']=(prefix,dimension,False,is_collection)
            elif kind in ('Filter','Define'):
                code,dimension,boolean,collection=root.expression(c['expression'],cols)
                if kind=='Filter':
                    if not boolean or collection:raise ValueError('Event selection requires a Boolean scalar')
                    frame=frame.Filter(code,nid)
                else:
                    name=c['name']
                    if boolean or collection or name in cols or not name or name.startswith('__hep'):raise ValueError('Invalid scalar derived observable')
                    frame=frame.Define(prefix,code);cols[name]=(prefix,dimension,False,False)
            elif kind=='Histo1D':
                code,dimension,boolean,collection=root.expression(c['expression'],cols)
                if boolean:raise ValueError('Histogram observable must be numeric')
                frame=frame.Define(prefix+'_x',code);edges=root.edges(c);edge_array=array.array('d',edges);owners.append(edge_array)
                weight=cols['weight'][0]
                if c.get('weight') is not None:
                    code,dim,boolean,collected=root.expression(c['weight'],cols)
                    if dim!=root.ZERO or boolean or collected:raise ValueError('Histogram weight must be a dimensionless scalar')
                    weight=prefix+'_w';frame=frame.Define(weight,code)
                # Explicit yield convention: raw weights, cross section, or
                # luminosity. Divisor includes all input events, before cuts.
                mode=c.get('yieldMode','raw-weights');factor=1.
                if mode in ('cross-section-pb','luminosity'):
                    count=metadata.get('eventCount',0);sumweights=metadata.get('sumWeights',0.);cross=metadata.get('crossSectionPb')
                    if not count or cross is None or abs(sumweights)<1e-15:raise ValueError('Absolute yield requires identified cross section and nonzero input sum of weights')
                    factor=float(cross)/float(sumweights)
                    if mode=='luminosity':
                        luminosity=float(c['luminosityFb'])
                        if not math.isfinite(luminosity) or luminosity<=0:raise ValueError('Positive luminosity in fb^-1 required')
                        factor*=1000*luminosity
                elif mode!='raw-weights':raise ValueError('Unknown yield convention')
                if factor!=1:
                    frame=frame.Define(prefix+'_yield',f'({weight})*{factor!r}');weight=prefix+'_yield'
                model=ROOT.RDF.TH1DModel('hep_'+uuid.uuid4().hex,'',len(edges)-1,edge_array)
                actions[nid]=(kind,frame.Histo1D(model,prefix+'_x',weight),c,dimension,mode)
            elif kind=='Count':actions[nid]=(kind,frame.Count(),c,root.ZERO,'events')
            elif kind in ('Fit','RooFit','RooStats'):pass
            else:raise ValueError('Unsupported reconstructed analysis action: '+kind)
            frames[nid]=frame;columns[nid]=cols
            if col is not None:
                collections[nid]=col;capabilities[nid]=caps
        progress({'stage':'Executing reconstructed RDataFrame graph','actions':len(actions)})
        # All compatible branches share the same loop manager. Booking above is
        # complete before the first result access; no per-node eager event loops.
        for nid,(kind,handle,c,dimension,mode) in actions.items():
            check_cancel(cancel)
            handle.GetValue.__release_gil__=True
            if kind=='Histo1D':
                h=handle.GetValue();histograms[nid]=h;data=root.histogram_data(h,c);stats=array.array('d',[0]*4);h.GetStats(stats)
                data.update(dimension=list(dimension),yieldMode=mode,sumWeights=float(stats[0]),sumWeightsSquared=float(stats[1]),
                            underflowError=float(h.GetBinError(0)),overflowError=float(h.GetBinError(h.GetNbinsX()+1)),statistics=list(stats))
                results[nid]=data
            else:results[nid]={'kind':'ScalarResult','operation':'Count','value':int(handle.GetValue())}
        for node in plan['nodes']:
            if node['kind']=='Fit':
                result=root.fit_histogram(histograms[node['input']],node['config']);result['histogramId']=node['input'];results[node['id']]=result
            elif node['kind']=='RooFit':
                result=statistical.fit(results[node['input']],node['config'],root,cancel);result['histogramId']=node['input'];results[node['id']]=result
            elif node['kind']=='RooStats':
                config=dict(node['config']);hist=results[node['input']]
                if config.get('signalSource')!='histogram-integral' or hist.get('yieldMode')!='luminosity' or hist.get('normalization')!='counts':raise ValueError('Counting inference requires explicit expected event yields from a luminosity-normalized signal histogram')
                config['signal']=sum(hist['values']);results[node['id']]=statistical.counting(config,root,cancel)
        check_cancel(cancel)
        return {'results':results,'metrics':{'inputEvents':int(total.GetValue()),'analysisSeconds':time.monotonic()-started,'rdfEventLoops':int(df.GetNRuns()),'bulkEventsThroughIPC':0,'threads':1}}
    finally:
        stop.set();watcher.join(timeout=1)
        if marker.exists():marker.unlink()
        folder.rmdir()
