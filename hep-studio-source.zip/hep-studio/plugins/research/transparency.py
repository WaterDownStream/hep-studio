"""Readable, standalone PyROOT analysis plus the frozen upstream configuration.

This export consumes the identified reconstructed files; it does not claim to
regenerate matrix elements or a detector from an approximate expression string.
VPIR and frozen Run provenance remain canonical.
"""
from __future__ import annotations
import inspect,json
import reconstruction,statistical

def analysis(plan,paths,metadata,root,configuration):
    lines=['#!/usr/bin/env python3',
           '# Equivalent research analysis. Requires PyROOT and the recorded Delphes SDK.',
           '# Upstream generation/shower/detector settings below are a transparency ledger.',
           '# Execute on the identified reconstructed files; relink INPUT_FILES explicitly.',
           'import array,hashlib,json,math,os,sys,time,types,uuid', 'from pathlib import Path', 'import ROOT',
           'ROOT.gROOT.SetBatch(True)', 'ROOT.DisableImplicitMT()', 'ROOT.EnableThreadSafety()',
           'SCIENTIFIC_CONFIGURATION=json.loads('+repr(json.dumps(configuration,sort_keys=True))+')',
           'INPUT_FILES='+repr([str(p) for p in paths]),
           '''# Relinking changes locations only; identified file contents must agree.
recorded=SCIENTIFIC_CONFIGURATION.get('artifacts',[])
if recorded:
    if len(recorded)!=len(INPUT_FILES):raise RuntimeError('Reconstructed input count differs from recorded artifacts')
    for path,artifact in zip(INPUT_FILES,recorded):
        checksum=hashlib.sha256()
        with open(path,'rb') as stream:
            for chunk in iter(lambda:stream.read(1024*1024),b''):checksum.update(chunk)
        if checksum.hexdigest()!=artifact['sha256']:raise RuntimeError('Reconstructed input checksum differs from recorded Run')
''',
           "DELPHES_HOME=os.environ.get('HEP_DELPHES_PATH','')",
           "if not DELPHES_HOME:raise RuntimeError('Select the recorded Delphes SDK with HEP_DELPHES_PATH')",
           "ROOT.gInterpreter.AddIncludePath(DELPHES_HOME)",
           "ROOT.gInterpreter.AddIncludePath(str(Path(DELPHES_HOME)/'external'))",
           "if ROOT.gSystem.Load(str(Path(DELPHES_HOME)/'libDelphes.so'))<0:raise RuntimeError('Delphes dictionary unavailable')",
           'ROOT.gInterpreter.Declare('+repr(reconstruction.HELPERS)+')',
           "files=ROOT.std.vector('string')()",'for path in INPUT_FILES:files.push_back(path)',
           "source=ROOT.RDataFrame('Delphes',files)",
           "source=source.Define('__hep_weight','double(Event.Weight.at(0))')",'counts=source.Count()','available={str(c) for c in source.GetColumnNames()}','histograms={}','owners=[]','reference_results={}',
           inspect.getsource(root.histogram_data)]
    frames={};collections={};columns={};actions=[]
    base={'weight':('__hep_weight',root.ZERO,False,False)}
    item={k:('o.'+k if k!='energy' else 'hep_reco::energy(o)',(1,0,0,0) if k in ('pt','mass','energy') else (0,0,0,1) if k=='phi' else root.ZERO,False,False) for k in ('pt','eta','phi','mass','energy','charge','isolation','btag')}
    def define(frame,name,code):
        target='f'+str(len(lines));lines.append(target+'='+frame+'.Define('+repr(name)+','+repr('return '+code+';')+')');return target
    schema_files=root.ROOT.std.vector('string')()
    for path in paths:schema_files.push_back(str(path))
    available={str(c) for c in root.ROOT.RDataFrame('Delphes',schema_files).GetColumnNames()}
    def define_collection(name,code):lines.append('source=source.Define('+repr(name)+','+repr(code)+')')
    lowered=reconstruction.lower_collections(plan,available,root,define_collection)
    for index,node in enumerate(plan['nodes']):
        nid=node['id'];kind=node['kind'];c=node['config'];parent=node.get('input');frame=frames.get(parent,'source');cols=dict(columns.get(parent,base));col=collections.get(parent);prefix='ref'+str(index)
        if kind in ('MadGraph','LHESource','Shower','Delphes','RecoSource'):frames[nid]='source';columns[nid]=base;continue
        if nid in lowered:
            col=lowered[nid]['column'];frames[nid]='source';cols=dict(base)
            for prop,info in reconstruction.object_columns(root,lowered[nid]['capabilities']).items():cols[prop]=('hep_reco::properties('+col+','+json.dumps(prop)+')',info[1],False,True)
            columns[nid]=cols;collections[nid]=col;continue
        if kind in ('Property','CollectionCount','HT'):
            if col is None:raise ValueError('Reconstructed collection required for export')
            if kind=='Property':
                if c['property'] not in cols or c['property'] in ('weight','value'):raise ValueError('Unknown reconstructed property')
                code='hep_reco::properties('+col+','+json.dumps(c['property'])+')';dimension=item[c['property']][1];collected=True
            else:code='double('+col+'.size())' if kind=='CollectionCount' else 'hep_reco::ht('+col+')';dimension=root.ZERO if kind=='CollectionCount' else (1,0,0,0);collected=False
            frame=define(frame,prefix,code);cols['value']=(prefix,dimension,False,collected)
        elif kind in ('Define','Filter'):
            code,dimension,boolean,collected=root.expression(c['expression'],cols)
            if kind=='Define':frame=define(frame,prefix,code);cols[c['name']]=(prefix,dimension,boolean,collected)
            else:
                target='f'+str(len(lines));lines.append(target+'='+frame+'.Filter('+repr(code)+','+repr(nid)+')');frame=target
        elif kind=='Count':
            lines.append('count'+str(index)+'='+frame+'.Count()');actions.append((nid,'count'+str(index),c,root.ZERO))
        elif kind=='Histo1D':
            expression,dimension,_,_=root.expression(c['expression'],cols);frame=define(frame,prefix+'_x',expression);weight=cols['weight'][0]
            if c.get('weight') is not None:frame=define(frame,prefix+'_w',root.expression(c['weight'],cols)[0]);weight=prefix+'_w'
            mode=c.get('yieldMode','raw-weights');factor=1.
            if mode!='raw-weights':
                factor=float(metadata['crossSectionPb'])/float(metadata['sumWeights'])
                if mode=='luminosity':factor*=1000*float(c['luminosityFb'])
                frame=define(frame,prefix+'_yield',weight+'*'+repr(factor));weight=prefix+'_yield'
            edges=root.edges(c);lines.extend(['edges'+str(index)+'=array.array("d",'+repr(edges)+')','owners.append(edges'+str(index)+')',
                'h'+str(index)+'='+frame+'.Histo1D(('+repr(nid)+',"",'+str(len(edges)-1)+',edges'+str(index)+'),'+repr(prefix+'_x')+','+repr(weight)+')'])
            actions.append((nid,'h'+str(index),c,dimension))
        elif kind in ('Fit','RooFit','RooStats'):pass
        else:raise ValueError('No equivalent analysis export for '+kind)
        frames[nid]=frame;columns[nid]=cols
        if col:
            collections[nid]=col
    lines.extend(['# All actions are booked before the first event loop.','print("Input events:",int(counts.GetValue()))',"output=ROOT.TFile('reference-histograms.root','RECREATE')"])
    for nid,handle,c,dimension in actions:
        if handle.startswith('count'):lines.append('reference_results['+repr(nid)+']={"kind":"ScalarResult","operation":"Count","value":int('+handle+'.GetValue())}');continue
        lines.append('histograms['+repr(nid)+']='+handle+'.GetValue().Clone('+repr(nid)+')')
        lines.append('histograms['+repr(nid)+'].SetDirectory(0)')
        lines.extend(['h=histograms['+repr(nid)+']','reference_results['+repr(nid)+']=histogram_data(h,'+repr(c)+')',
            'stats=array.array("d",[0]*4);h.GetStats(stats)',
            'reference_results['+repr(nid)+'].update(dimension='+repr(list(dimension))+',yieldMode='+repr(c.get('yieldMode','raw-weights'))+',sumWeights=float(stats[0]),sumWeightsSquared=float(stats[1]),underflowError=float(h.GetBinError(0)),overflowError=float(h.GetBinError(h.GetNbinsX()+1)),statistics=list(stats))',
            '# Keep the unmodified ROOT histogram for native fit semantics.',
            'h=h.Clone('+repr(nid+'_display')+');h.SetDirectory(0)'])
        if c.get('flow','separate')=='fold':
            lines.extend(['n=h.GetNbinsX()',
                'h.SetBinContent(1,h.GetBinContent(1)+h.GetBinContent(0))','h.SetBinError(1,math.hypot(h.GetBinError(1),h.GetBinError(0)))',
                'h.SetBinContent(n,h.GetBinContent(n)+h.GetBinContent(n+1))','h.SetBinError(n,math.hypot(h.GetBinError(n),h.GetBinError(n+1)))',
                'h.SetBinContent(0,0)','h.SetBinError(0,0)','h.SetBinContent(n+1,0)','h.SetBinError(n+1,0)'])
        if c.get('normalization','counts') in ('unit-area','density'):
            lines.extend(['integral=h.Integral()',"if integral>0:h.Scale(1./integral"+(',"width")' if c['normalization']=='density' else ')')])
        lines.append('h.Write('+repr(nid)+')')
    lines.append('output.Close()')
    if any(n['kind'] in ('Fit','RooFit','RooStats') for n in plan['nodes']):
        lines.append('# Statistical model declarations: exact settings, bounds, errors and assumptions.')
        lines.append('STATISTICAL_MODELS='+repr([n for n in plan['nodes'] if n['kind'] in ('Fit','RooFit','RooStats')]))
        lines.extend(['FIT_HELPER=False',
            'def key(value):return hashlib.sha256(json.dumps(value,sort_keys=True,separators=(",",":"),allow_nan=False).encode()).hexdigest()',
            'def check_cancel(cancel):pass',
            inspect.getsource(root.fit_histogram),inspect.getsource(statistical.fit_native),
            inspect.getsource(statistical.histogram),inspect.getsource(statistical.fit),inspect.getsource(statistical.counting),
            'root=types.SimpleNamespace(ROOT=ROOT)',
            '''for node in STATISTICAL_MODELS:
    kind=node['kind'];config=dict(node['config']);parent=node['input'];nid=node['id']
    if kind=='Fit':
        result=fit_histogram(histograms[parent],config);result['histogramId']=parent
    elif kind=='RooFit':
        result=fit(reference_results[parent],config,root);result['histogramId']=parent
    elif kind=='RooStats':
        hist=reference_results[parent]
        if config.get('signalSource')!='histogram-integral' or hist.get('yieldMode')!='luminosity' or hist.get('normalization')!='counts':raise ValueError('Counting inference requires explicit expected event yields from a luminosity-normalized signal histogram')
        config['signal']=sum(hist['values']);result=counting(config,root)
    else:raise ValueError('Unsupported statistical reference node')
    reference_results[nid]=result
'''])
    lines.append('Path("reference-results.json").write_text(json.dumps(reference_results,sort_keys=True,allow_nan=False))')
    lines.append('print("ROOT event loops:",source.GetNRuns())')
    return '\n'.join(lines)+'\n'
