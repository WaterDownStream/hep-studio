"""Structured RooFit/RooStats lowering, explicit statistical assumptions."""
from __future__ import annotations
import array,math,uuid
from artifacts import key,check_cancel
FIT_HELPER=False

def fit_native(pdf,data,options,ROOT):
    global FIT_HELPER
    if not FIT_HELPER:
        if not ROOT.gInterpreter.Declare('''
#include <RooAbsPdf.h>
#include <RooFitResult.h>
#include <RooLinkedList.h>
#include <memory>
namespace hep_research_stats {
RooFitResult* own(RooFitResult* p){return p;}
RooFitResult* own(std::unique_ptr<RooFitResult> p){return p.release();}
RooFitResult* fit(RooAbsPdf& p,RooAbsData& d,const RooLinkedList& c){return own(p.fitTo(d,c));}
}
'''):raise RuntimeError('RooFit worker helper compilation failed')
        ROOT.hep_research_stats.fit.__release_gil__=True;FIT_HELPER=True
    commands=ROOT.RooLinkedList()
    for option in options:commands.Add(option)
    result=ROOT.hep_research_stats.fit(pdf,data,commands)
    if result:ROOT.SetOwnership(result,True)
    return result

def histogram(histogram,ROOT):
    edges=histogram['edges'];values=histogram['values'];errors=histogram['errors']
    if len(edges)!=len(values)+1 or len(errors)!=len(values) or not values:raise ValueError('Incompatible histogram template shape')
    if any(not math.isfinite(float(v)) for v in edges+values+errors) or any(v<0 for v in values+errors):raise ValueError('Statistical templates require finite nonnegative contents/errors')
    if any(a>=b for a,b in zip(edges,edges[1:])) or sum(values)<=0:raise ValueError('Statistical template has empty integral or invalid bins')
    h=ROOT.TH1D('stat_'+uuid.uuid4().hex,'',len(values),array.array('d',edges));h.SetDirectory(0);h.Sumw2()
    for i,(v,e) in enumerate(zip(values,errors),1):h.SetBinContent(i,v);h.SetBinError(i,e)
    return h

def fit(hist,config,root,cancel=None):
    check_cancel(cancel);ROOT=root.ROOT;h=histogram(hist,ROOT);owners=[];parameters={};edges=hist['edges']
    bounds=config.get('range',[edges[0],edges[-1]])
    if len(bounds)!=2 or not edges[0]<=bounds[0]<bounds[1]<=edges[-1]:raise ValueError('Fit range must lie within the identified histogram')
    if any(not any(math.isclose(float(bound),float(edge),rel_tol=1e-10,abs_tol=1e-12) for edge in edges) for bound in bounds):raise ValueError('A binned fit range must coincide with histogram bin edges')
    x=ROOT.RooRealVar('x','Observable',float(edges[0]),float(edges[-1]));owners.append(x)
    def parameter(spec,role):
        name=spec.get('name',role)
        if name in parameters:raise ValueError('Duplicate RooFit parameter identity: '+name)
        value=float(spec['value']);lo=float(spec['lower']);hi=float(spec['upper'])
        if not all(math.isfinite(v) for v in (value,lo,hi)) or not lo<hi or not lo<=value<=hi:raise ValueError('Invalid RooFit initial parameter/bounds')
        p=ROOT.RooRealVar(name,name,value,lo,hi);p.setConstant(bool(spec.get('constant',False)));owners.append(p);parameters[name]=p;return p
    def model(spec,depth=0):
        if depth>12:raise ValueError('Statistical model nesting limit')
        name='model_'+uuid.uuid4().hex;kind=spec['kind']
        if kind=='Gaussian':
            mean=parameter(spec['mean'],'mean');sigma=parameter(spec['sigma'],'sigma')
            if sigma.getMin()<=0:raise ValueError('Gaussian width must remain positive')
            result=ROOT.RooGaussian(name,name,x,mean,sigma)
        elif kind=='BreitWigner':
            mean=parameter(spec['mean'],'mean');width=parameter(spec['width'],'width')
            if width.getMin()<=0:raise ValueError('Breit-Wigner width must remain positive')
            result=ROOT.RooBreitWigner(name,name,x,mean,width)
        elif kind=='Exponential':result=ROOT.RooExponential(name,name,x,parameter(spec['slope'],'slope'))
        elif kind=='Polynomial':
            coefficients=spec['coefficients']
            if not 1<=len(coefficients)<=5:raise ValueError('Polynomial order must be from one to five')
            args=ROOT.RooArgList()
            for i,c in enumerate(coefficients):args.add(parameter(c,'c'+str(i+1)))
            result=ROOT.RooPolynomial(name,name,x,args)
        elif kind=='Histogram':
            template=spec['template']
            if template['edges']!=edges:raise ValueError('Histogram PDF binning differs from its observable dataset')
            th=histogram(template,ROOT);data=ROOT.RooDataHist(name+'_data',name+'_data',ROOT.RooArgList(x),th);owners.extend([th,data])
            result=ROOT.RooHistPdf(name,name,ROOT.RooArgSet(x),data,0)
        elif kind in ('Sum','Product'):
            children=spec['components']
            if not 2<=len(children)<=8:raise ValueError('Model composition requires two to eight components')
            pdfs=ROOT.RooArgList()
            for child in children:pdfs.add(model(child,depth+1))
            if kind=='Product':result=ROOT.RooProdPdf(name,name,ROOT.RooArgSet(pdfs))
            else:
                if len(spec['fractions'])!=len(children)-1:raise ValueError('Mixture requires one fewer fractions than components')
                fractions=ROOT.RooArgList()
                for i,f in enumerate(spec['fractions']):
                    if f['lower']<0 or f['upper']>1:raise ValueError('Mixture fractions must lie between zero and one')
                    fractions.add(parameter(f,'fraction'+str(i)))
                # Recursive fractions ensure positive, normalized mixtures.
                result=ROOT.RooAddPdf(name,name,pdfs,fractions,True)
        else:raise ValueError('Unsupported structured RooFit model: '+kind)
        owners.append(result);return result
    pdf=model(config['model']);constraints=ROOT.RooArgSet()
    if not any(not p.isConstant() for p in parameters.values()):raise ValueError('This fit has no floating parameters; use a fixed PDF as a component of a model or compare its predictions without claiming an optimizer fit')
    for spec in config.get('constraints',[]):
        if spec.get('kind')!='Gaussian' or spec['parameter'] not in parameters:raise ValueError('Unsupported explicit fit constraint')
        sigma=float(spec['sigma']);mean=float(spec['mean'])
        if not math.isfinite(mean+sigma) or sigma<=0:raise ValueError('Constraint requires finite mean and positive width')
        center=ROOT.RooConstVar('constraint_mean_'+str(len(owners)),'',mean);width=ROOT.RooConstVar('constraint_sigma_'+str(len(owners)),'',sigma)
        constraint=ROOT.RooGaussian('constraint_'+str(len(owners)),'',parameters[spec['parameter']],center,width);owners.extend([center,width,constraint]);constraints.add(constraint)
    mode=config.get('errorModel')
    if mode not in ('poisson','sumw2'):raise ValueError('Choose Poisson counts or explicitly weighted SumW2 fit errors')
    if mode=='poisson' and (hist.get('normalization','counts')!='counts' or any(abs(v-round(v))>1e-8 or not math.isclose(e*e,v,rel_tol=1e-6,abs_tol=1e-8) for v,e in zip(hist['values'],hist['errors']))):raise ValueError('Poisson fit requires identified unscaled integer counts with counting variances')
    data=ROOT.RooDataHist('fit_data','',ROOT.RooArgList(x),h);owners.append(data);x.setRange('fit',float(bounds[0]),float(bounds[1]))
    options=[ROOT.RooFit.Save(True),ROOT.RooFit.PrintLevel(-1),ROOT.RooFit.Range('fit'),ROOT.RooFit.IntegrateBins(1e-5),ROOT.RooFit.SumW2Error(mode=='sumw2')]
    if 'maximumCalls' in config:
        limit=config['maximumCalls']
        if type(limit)!=int or not 1<=limit<=10000000:raise ValueError('Optimizer maximumCalls must be an integer in [1,10000000]')
        options.append(ROOT.RooFit.MaxCalls(limit))
    if constraints.getSize():options.append(ROOT.RooFit.ExternalConstraints(constraints))
    result=fit_native(pdf,data,options,ROOT);check_cancel(cancel)
    if not result:raise RuntimeError('RooFit returned no fit result')
    final=result.floatParsFinal();names=[str(final[i].GetName()) for i in range(final.getSize())];matrix=result.covarianceMatrix();correlation=result.correlationMatrix()
    covariance=[[float(matrix[i][j]) for j in range(len(names))] for i in range(len(names))]
    status=int(result.status());quality=int(result.covQual());edm=float(result.edm());nll=float(result.minNll())
    valid=status==0 and quality==3 and all(math.isfinite(v) for v in (edm,nll)) and all(math.isfinite(v) for row in covariance for v in row)
    warnings=[]
    if not valid:warnings.append('Optimizer status/covariance is unreliable; this fit is not scientifically valid')
    for p in final:
        if p.hasMin() and abs(p.getVal()-p.getMin())<1e-5*max(1.,abs(p.getVal())) or p.hasMax() and abs(p.getVal()-p.getMax())<1e-5*max(1.,abs(p.getVal())):warnings.append('Parameter '+str(p.GetName())+' is at a bound')
    expected=[];pulls=[];norm=ROOT.RooArgSet(x);integral=0.
    x.setRange('fit_total',float(bounds[0]),float(bounds[1]));full=pdf.createIntegral(norm,ROOT.RooFit.NormSet(norm),ROOT.RooFit.Range('fit_total'));denominator=float(full.getVal())
    if not math.isfinite(denominator) or denominator<=0:raise RuntimeError('Fitted PDF has no finite positive integral in the fit range')
    total=sum(v for i,v in enumerate(hist['values']) if edges[i]>=bounds[0] and edges[i+1]<=bounds[1])
    for i,v in enumerate(hist['values']):
        x.setRange('bin_'+str(i),float(edges[i]),float(edges[i+1]));prob=pdf.createIntegral(norm,ROOT.RooFit.NormSet(norm),ROOT.RooFit.Range('bin_'+str(i)))
        prediction=total*float(prob.getVal())/denominator
        if not math.isfinite(prediction) or prediction<0:raise RuntimeError('Fitted PDF produces a negative or nonfinite bin expectation; no valid fit is published')
        expected.append(prediction)
        included=edges[i]>=bounds[0] and edges[i+1]<=bounds[1]
        pulls.append((v-prediction)/hist['errors'][i] if included and hist['errors'][i]>0 else None)
    curve=[[(edges[i]+edges[i+1])/2,expected[i]] for i in range(len(expected))]
    return {'kind':'FitResult','backend':'RooFit','backendVersion':str(ROOT.gROOT.GetVersion()),'model':config['model'],'modelIdentity':key(config),
            'inputIdentity':key(hist),'status':status,'converged':valid,'valid':valid,'covarianceStatus':quality,'edm':edm,'minNll':nll,'errorModel':mode,
            'parameters':[{'name':str(p.GetName()),'value':float(p.getVal()),'error':float(p.getError())} for p in final],
            'covariance':covariance,'correlation':[[float(correlation[i][j]) for j in range(len(names))] for i in range(len(names))],
            'curve':curve,'expectedBins':expected,'pulls':pulls,'range':bounds,'binIntegrationPrecision':1e-5,'warnings':warnings,'warning':'; '.join(warnings),
            'objective':'Binned likelihood with exact PDF bin integrals; '+('weighted SumW2 covariance correction' if mode=='sumw2' else 'Poisson counts'),
            'constraints':config.get('constraints',[]),'goodnessOfFit':'Pulls are diagnostics; no asymptotic goodness-of-fit p-value is silently assigned'}

def counting(config,root,cancel=None):
    """One-channel positive-mean Poisson model with optional explicit Gaussian background measurement."""
    check_cancel(cancel);ROOT=root.ROOT;signal=float(config['signal']);background=float(config['background']);observed=float(config['observed'])
    if any(not math.isfinite(v) for v in (signal,background,observed)) or signal<=0 or background<=0 or observed<0:raise ValueError('Counting model requires positive finite signal/background and nonnegative observation')
    role=config['datasetRole']
    if role not in ('observed-counts','asimov') or role=='observed-counts' and not observed.is_integer():raise ValueError('Explicit observed integer counts or labelled Asimov data required')
    if config.get('method')!='asymptotic-profile-likelihood' or config.get('testStatistic')!='one-sided-qmu' or config.get('useCLs') is not True:raise ValueError('This verified limit adapter requires explicit asymptotic, one-sided q_mu and CLs settings')
    level=float(config['confidenceLevel']);maximum=float(config['muMax']);points=config.get('points',40)
    if not .5<level<1 or not math.isfinite(maximum) or maximum<=0 or type(points)!=int or not 10<=points<=200:raise ValueError('Invalid confidence level or POI scan')
    workspace=ROOT.RooWorkspace('counting_'+uuid.uuid4().hex)
    n=ROOT.RooRealVar('n','Observed count',observed,0.,max(100.,observed+20*math.sqrt(max(1.,observed))))
    mu=ROOT.RooRealVar('mu','Signal strength',1.,0.,maximum);s=ROOT.RooConstVar('s','Expected signal',signal);b=ROOT.RooRealVar('b','Expected background',background,max(1e-9,background/1000),max(10*background,background+100))
    uncertainty=config.get('backgroundConstraint');owners=[n,mu,s,b];nuisances=ROOT.RooArgSet();globals=ROOT.RooArgSet()
    mean=ROOT.RooFormulaVar('mean','@0*@1+@2',ROOT.RooArgList(mu,s,b));poisson=ROOT.RooPoisson('poisson','',n,mean,True);pdf=poisson;owners.extend([mean,poisson])
    if uncertainty:
        if uncertainty.get('kind')!='Gaussian' or float(uncertainty['sigma'])<=0:raise ValueError('Only an explicitly requested positive Gaussian background measurement is supported')
        observed_b=ROOT.RooRealVar('b_observed','Auxiliary background measurement',background);observed_b.setConstant(True)
        sigma=ROOT.RooConstVar('b_sigma','',float(uncertainty['sigma']));constraint=ROOT.RooGaussian('b_constraint','',observed_b,b,sigma)
        pdf=ROOT.RooProdPdf('likelihood','',ROOT.RooArgSet(poisson,constraint));owners.extend([observed_b,sigma,constraint,pdf]);nuisances.add(b);globals.add(observed_b)
    else:b.setConstant(True)
    getattr(workspace,'import')(pdf)
    obs=ROOT.RooArgSet(workspace.var('n'));data=ROOT.RooDataSet('observed','',obs);data.add(obs)
    sb=ROOT.RooStats.ModelConfig('signal_background',workspace);sb.SetPdf(workspace.pdf(pdf.GetName()));sb.SetObservables(obs);sb.SetParametersOfInterest(ROOT.RooArgSet(workspace.var('mu')))
    if uncertainty:sb.SetNuisanceParameters(ROOT.RooArgSet(workspace.var('b')));sb.SetGlobalObservables(ROOT.RooArgSet(workspace.var('b_observed')))
    workspace.var('mu').setVal(1.);sb.SetSnapshot(sb.GetParametersOfInterest());background_model=sb.Clone('background_only');workspace.var('mu').setVal(0.);background_model.SetSnapshot(sb.GetParametersOfInterest());workspace.var('mu').setVal(1.)
    fit_result=fit_native(sb.GetPdf(),data,[ROOT.RooFit.Save(True),ROOT.RooFit.PrintLevel(-1)],ROOT)
    if not fit_result or int(fit_result.status())!=0:raise RuntimeError('Counting likelihood fit failed; no limit is presented')
    ROOT.RooStats.AsymptoticCalculator.SetPrintLevel(-1)
    calculator=ROOT.RooStats.AsymptoticCalculator(data,background_model,sb,True);calculator.SetOneSided(True)
    inverter=ROOT.RooStats.HypoTestInverter(calculator);inverter.SetConfidenceLevel(level);inverter.UseCLs(True);inverter.SetVerbose(False);inverter.SetFixedScan(points,0.,maximum)
    ROOT.RooStats.HypoTestInverter.GetInterval.__release_gil__=True
    interval=inverter.GetInterval();check_cancel(cancel)
    if not interval:raise RuntimeError('RooStats failed to calculate a confidence limit')
    upper=float(interval.UpperLimit());curve=[]
    for i in range(interval.ArraySize()):
        point=interval.GetResult(i);curve.append({'mu':float(interval.GetXValue(i)),'CLs':float(point.CLs()),'CLsb':float(point.CLsplusb()),'CLb':float(point.CLb())})
    valid=math.isfinite(upper) and 0<upper<maximum and curve[-1]['CLs']<1-level
    warning='Asymptotic approximation; validate coverage/toys for sparse data. Finite template Monte Carlo uncertainty is not included.'
    if not valid:warning+=' POI range does not bracket a reliable limit; extend the range.'
    significance=None
    if not uncertainty and observed>=background:
        # This independent analytic diagnostic audits the exact one-bin Poisson
        # likelihood. It is labelled separately from the RooStats CLs result.
        significance=math.sqrt(max(0.,2*(observed*math.log(observed/background)-observed+background)))
    discovery=None;profile_interval=None
    if config.get('calculateDiscovery',False):
        check_cancel(cancel)
        discovery_calculator=ROOT.RooStats.AsymptoticCalculator(data,sb,background_model,True);discovery_calculator.SetOneSidedDiscovery(True)
        ROOT.RooStats.AsymptoticCalculator.GetHypoTest.__release_gil__=True
        test=discovery_calculator.GetHypoTest();check_cancel(cancel)
        if not test:raise RuntimeError('RooStats discovery hypothesis calculation failed')
        pvalue=float(test.NullPValue());z=float(test.Significance())
        if not math.isfinite(pvalue+z) or not 0<=pvalue<=1:raise RuntimeError('Invalid RooStats discovery result')
        discovery={'null':'background-only mu=0','alternative':'mu>=0','testStatistic':'one-sided-q0','pValue':pvalue,'significanceSigma':z,'method':'RooStats AsymptoticCalculator; boundary at zero'}
    if config.get('calculateInterval',False):
        check_cancel(cancel);interval_calculator=ROOT.RooStats.ProfileLikelihoodCalculator(data,sb);interval_calculator.SetConfidenceLevel(level)
        ROOT.RooStats.ProfileLikelihoodCalculator.GetInterval.__release_gil__=True
        profile=interval_calculator.GetInterval();check_cancel(cancel)
        if not profile:raise RuntimeError('RooStats profile-likelihood interval failed')
        poi=workspace.var('mu');lower=float(profile.LowerLimit(poi));upper_profile=float(profile.UpperLimit(poi))
        interval_valid=math.isfinite(lower+upper_profile) and 0<=lower<upper_profile<maximum
        profile_interval={'lower':lower,'upper':upper_profile,'confidenceLevel':level,'valid':interval_valid,'method':'Two-sided Wilks profile-likelihood interval; mu>=0 boundary','warning':'Boundary/sparse-sample coverage is unverified'+('; extend the POI range' if not interval_valid else '')}
    return {'kind':'HypothesisResult','valid':valid,'backend':'RooStats','backendVersion':str(ROOT.gROOT.GetVersion()),'method':config['method'],
            'testStatistic':config['testStatistic'],'useCLs':True,'confidenceLevel':level,'parameterOfInterest':'mu','upperLimit':upper,
            'expectedMedianLimit':float(interval.GetExpectedUpperLimit(0)),'expectedLimits':{str(k):float(interval.GetExpectedUpperLimit(k)) for k in (-2,-1,0,1,2)},
            'scan':curve,'model':config,'modelIdentity':key(config),'datasetRole':role,'nuisanceParameters':['b'] if uncertainty else [],
            'constraints':[uncertainty] if uncertainty else [],'discovery':discovery,'profileInterval':profile_interval,'analyticKnownBackgroundSignificance':significance,'warning':warning,
            'fitStatus':int(fit_result.status()),'assumptions':['Independent Poisson count','Positive yields','Signal strength bounded at zero','Nominal Asimov expected limits','CLs, one-sided profile likelihood','No automatic systematic prior']}
