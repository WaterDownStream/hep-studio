"""Immutable histogram templates -> explicit HistFactory model -> RooStats.

No prior is inferred from a systematic label. Heavy/native model objects remain
inside this worker; only template arrays, identities and diagnostics are returned.
"""
from __future__ import annotations
import copy,inspect,json,math,re,types
from artifacts import key,check_cancel
import statistical


def _name(value):
    if not isinstance(value,str) or not re.fullmatch(r'[A-Za-z][A-Za-z0-9_]{0,63}',value):
        raise ValueError('Statistical identities require 1..64 ASCII letters, digits or underscores, starting with a letter')
    return value


def _validate_hist(h,edges=None,observed=False):
    if h.get('kind')!='Histogram1D' or h.get('normalization')!='counts':
        raise ValueError('Likelihood templates require absolute Histogram1D counts')
    v=h['values'];e=h['errors'];b=h['edges']
    if not 1<=len(v)<=4096 or len(e)!=len(v) or len(b)!=len(v)+1:
        raise ValueError('Incompatible statistical template shape')
    if any(not math.isfinite(float(x)) for x in b+v+e) or any(x<0 for x in v+e) or any(a>=c for a,c in zip(b,b[1:])):
        raise ValueError('Templates require finite nonnegative values/errors and increasing edges')
    if edges is not None and b!=edges:raise ValueError('Nominal/systematic template binning differs')
    if observed and any(abs(x-round(x))>1e-8 or not math.isclose(s*s,x,rel_tol=1e-6,abs_tol=1e-8) for x,s in zip(v,e)):
        raise ValueError('Observed templates must contain integer Poisson counts with counting variances')
    return copy.deepcopy(h)


def template_set(config,inputs):
    samples=config.get('samples',[])
    if not 2<=len(samples)<=16:raise ValueError('Choose signal and background templates (at most 16 samples)')
    result=[];identities=set();references=set();channels={}
    explicit_channels=any('channel' in spec for spec in samples)
    for spec in samples:
        identity=_name(spec['id']);role=spec['role'];ref=spec['reference']
        if identity in identities or role not in ('signal','background','observed'):raise ValueError('Duplicate sample identity or unsupported role')
        identities.add(identity);rid=ref['runId']+'/'+ref['nodeId']
        if rid in references:raise ValueError('One immutable histogram cannot silently be counted as two independent samples')
        references.add(rid);row=inputs[rid]
        if row.get('runStatus')!='Completed' or row.get('runValid') is not True:raise ValueError('Template input Run is incomplete or invalid')
        if ref.get('inputIdentity') and ref['inputIdentity']!=row.get('inputIdentity'):raise ValueError('Immutable input histogram identity differs')
        if not row.get('inputIdentity'):raise ValueError('Template input identity is missing')
        channel=_name(spec.get('channel','analysis'))
        if channel not in channels:
            if len(channels)>=8:raise ValueError('At most eight explicit analysis channels')
            channels[channel]={'id':channel,'edges':None,'dimension':None,'sampleIds':[]}
        category=channels[channel]
        h=_validate_hist(row['histogram'],category['edges'],role=='observed')
        if role!='observed' and h.get('yieldMode')!='luminosity' and spec.get('interpretation')!='expected-event-counts':
            raise ValueError('Signal/background must be expected event yields; raw MC weights or cross sections are not Poisson expectations')
        current=h.get('dimension',[])
        if category['edges'] is not None and current!=category['dimension']:raise ValueError('Template observable physical dimensions differ within one channel')
        category.update(edges=h['edges'],dimension=current);category['sampleIds'].append(identity)
        item={'id':identity,'role':role,'reference':copy.deepcopy(ref),'inputIdentity':row['inputIdentity'],'histogram':h,'systematics':copy.deepcopy(row.get('systematics',{})),'sourceRun':copy.deepcopy(row.get('sourceRun',{}))}
        if explicit_channels:item['channel']=channel
        result.append(item)
    if not any(s['role']=='signal' for s in result):raise ValueError('Require at least one signal sample')
    for category in channels.values():
        members=[s for s in result if s['id'] in category['sampleIds']]
        if not any(s['role']=='background' for s in members) or sum(s['role']=='observed' for s in members)>1:
            raise ValueError('Every channel requires background and at most one observed sample')
    if len(channels)>1 and config.get('channelIndependence')!='disjoint-event-categories':
        raise ValueError('Combined Poisson channels require an explicit disjoint-event-categories assumption; histogram arrays cannot establish event independence')
    if explicit_channels:
        return {'kind':'HistogramSet','version':2,'samples':result,'channels':list(channels.values()),
                'channelIndependence':config.get('channelIndependence','single-channel'),'flowPolicy':config['flowPolicy'],
                'identity':key({'samples':result,'channelIndependence':config.get('channelIndependence','single-channel')})}
    category=channels['analysis']
    # Preserve the exact legacy one-channel representation and input identity.
    return {'kind':'HistogramSet','version':1,'samples':result,'edges':category['edges'],'dimension':category['dimension'],
            'flowPolicy':config['flowPolicy'],'identity':key(result)}


def _hist(h,ROOT):
    # Zero observed bins (including an empty observed dataset) are legitimate.
    import array,uuid
    out=ROOT.TH1D('template_'+uuid.uuid4().hex,'',len(h['values']),array.array('d',h['edges']));out.SetDirectory(0);out.Sumw2()
    for i,(v,e) in enumerate(zip(h['values'],h['errors']),1):out.SetBinContent(i,v);out.SetBinError(i,e)
    return out


def likelihood(histograms,config,root):
    ROOT=root.ROOT;HF=ROOT.RooStats.HistFactory;samples=histograms['samples']
    categories=histograms.get('channels',[{'id':'analysis','edges':histograms.get('edges'),
        'dimension':histograms.get('dimension'),'sampleIds':[s['id'] for s in samples]}])
    if sum(len(c['edges'])-1 for c in categories)>256:raise ValueError('Template likelihood supports at most 256 fitted bins across all channels; rebin explicitly upstream')
    if histograms['flowPolicy']!='exclude-unfolded-flows':raise ValueError('Fold flows upstream, or explicitly exclude unfolded flow bins')
    role=config['datasetRole'];maximum=float(config['muMax']);mc=config['mcStat']
    if role not in ('background-asimov','observed-counts') or not math.isfinite(maximum) or maximum<=1:
        raise ValueError('Choose dataset role and a signal-strength range containing mu=1')
    if mc not in ('none','poisson-gamma') or config['interpolation']!='histfactory-default':raise ValueError('Choose explicit MC-statistics and HistFactory interpolation policies')
    if mc=='poisson-gamma' and config.get('mcStatAssumption')!='independent-effective-counts':
        raise ValueError('MC-statistics gamma constraints require explicit independent-effective-counts assumption')
    channel_metadata=[];signal=[];background=[]
    for category in categories:
        members=[s for s in samples if s['id'] in category['sampleIds']]
        expected=lambda r:[sum(s['histogram']['values'][i] for s in members if s['role']==r) for i in range(len(category['edges'])-1)]
        cs=expected('signal');cb=expected('background');signal.extend(cs);background.extend(cb)
        channel_metadata.append({**copy.deepcopy(category),'expectedSignal':cs,'expectedBackground':cb})
    if sum(signal)<=0 or any(v<=0 for v in background):raise ValueError('This likelihood subset requires nonzero signal and positive expected background in every fitted bin')
    known={s['id'] for s in samples if s['role']!='observed'};bindings=set();nuisances=config['nuisances']
    if len(nuisances)>64:raise ValueError('At most 64 explicit nuisance descriptors')
    for n in nuisances:
        group=_name(n['correlationGroup']);targets=n['samples']
        if not targets or len(set(targets))!=len(targets) or not set(targets)<=known:raise ValueError('Nuisance sample binding is unknown, duplicate or empty')
        if n.get('constraint')!='gaussian-standard-normal' or n.get('variationMeaning')!='minus-plus-one-sigma':raise ValueError('An explicit Gaussian auxiliary constraint and minus/plus one-sigma meaning are required')
        if n['kind'] not in ('normalization','shape'):raise ValueError('Unsupported explicit template nuisance')
        for target in targets:
            binding=(target,group)
            if binding in bindings:raise ValueError('Duplicate nuisance group for one sample; combine its declared effect explicitly')
            bindings.add(binding)
    measurement=HF.Measurement('measurement','Explicit HEP Studio template model');measurement.SetPOI('mu');measurement.SetLumi(1.);measurement.AddConstantParam('Lumi')
    owners=[measurement]
    for category in channel_metadata:
        channel=HF.Channel(category['id']);channel.SetStatErrorConfig(0.,'Poisson');owners.append(channel)
        edges=category['edges'];members=[s for s in samples if s['id'] in category['sampleIds']]
        if role=='observed-counts':
            observed=[s for s in members if s['role']=='observed']
            if len(observed)!=1:raise ValueError('Observed inference requires an identified observed-count histogram in every channel')
            data_hist=observed[0]['histogram']
        else:data_hist={'edges':edges,'values':category['expectedBackground'],'errors':[math.sqrt(v) for v in category['expectedBackground']]}
        data=_hist(data_hist,ROOT);channel.SetData(data);ROOT.SetOwnership(data,False);owners.append(data)
        for source in members:
            if source['role']=='observed':continue
            sample=HF.Sample(source['id']);sample.SetNormalizeByTheory(False);h=_hist(source['histogram'],ROOT)
            sample.SetHisto(h);ROOT.SetOwnership(h,False);owners.extend([sample,h])
            if source['role']=='signal':sample.AddNormFactor('mu',1.,0.,maximum)
            if mc=='poisson-gamma':sample.ActivateStatError()
            for n in nuisances:
                if source['id'] not in n['samples']:continue
                group=n['correlationGroup']
                if n['kind']=='normalization':
                    low=float(n['down']);high=float(n['up'])
                    if not math.isfinite(low+high) or not 0<low<=1<=high or low==high:raise ValueError('Normalization endpoints must positively bracket the nominal scale')
                    sample.AddOverallSys(group,low,high)
                else:
                    variations=source['systematics']['templates'][n['systematicId']]['variations'];node=source['reference']['nodeId']
                    def variation(label):
                        matches=[v['results'][node] for v in variations if v['label']==label and node in v['results'] and v.get('valid',True)]
                        if len(matches)!=1:raise ValueError('Missing/ambiguous systematic histogram endpoint')
                        h=_validate_hist(matches[0],edges)
                        if h.get('yieldMode')!=source['histogram'].get('yieldMode') or h.get('dimension',[])!=category['dimension']:raise ValueError('Systematic template units/yield convention differs from nominal')
                        if sum(h['values'])<=0:raise ValueError('Systematic template has zero expected integral')
                        return _hist(h,ROOT)
                    low=variation(n['downLabel']);high=variation(n['upLabel']);systematic=HF.HistoSys();systematic.SetName(group)
                    systematic.SetHistoLow(low);ROOT.SetOwnership(low,False);systematic.SetHistoHigh(high);ROOT.SetOwnership(high,False)
                    sample.AddHistoSys(systematic);owners.extend([low,high,systematic])
            channel.AddSample(sample)
        measurement.AddChannel(channel)
    workspace=HF.HistoToWorkspaceFactoryFast.MakeCombinedModel(measurement)
    if not workspace:raise RuntimeError('HistFactory did not produce a likelihood workspace')
    model=workspace.obj('ModelConfig');data=workspace.data('obsData');mu=workspace.var('mu')
    if not model or not data or not mu:raise RuntimeError('HistFactory workspace is missing a scientific contract')
    mu.setVal(1.);model.SetSnapshot(model.GetParametersOfInterest());background_model=model.Clone('background_only');mu.setVal(0.);background_model.SetSnapshot(model.GetParametersOfInterest());mu.setVal(1.)
    warnings=['Asymptotic sparse-bin/boundary coverage is unverified.','Shared correlation-group identities mean shared nuisance parameters.']
    warnings.append('Finite template MC uncertainty explicitly excluded.' if mc=='none' else 'Poisson gamma MC constraints assume independent effective counts; source-event independence is not established by histogram arrays.')
    if role=='background-asimov' and any(s['role']=='observed' for s in samples):warnings.append('Observed template is unused under explicitly selected background-Asimov role.')
    if len(categories)>1:warnings.append('Channel event categories explicitly assumed disjoint; independence is not established by histogram arrays.')
    metadata={'kind':'LikelihoodModel','backend':'ROOT-HistFactory','backendVersion':str(ROOT.gROOT.GetVersion()),'configuration':copy.deepcopy(config),
              'inputIdentity':histograms['identity'],'datasetRole':role,'expectedSignal':signal,'expectedBackground':background,
              'nuisanceParameters':[str(p.GetName()) for p in model.GetNuisanceParameters()] if model.GetNuisanceParameters() else [],
              'constraints':copy.deepcopy(nuisances),'warnings':warnings,'interpolation':'HistFactory version-default; backend version frozen'}
    if 'channels' in histograms:metadata.update(channels=channel_metadata,channelIndependence=histograms['channelIndependence'])
    metadata['identity']=key(metadata)
    return workspace,model,background_model,data,owners,metadata


def infer(native,config,root,cancel=None):
    check_cancel(cancel);ROOT=root.ROOT;workspace,model,background_model,data,owners,metadata=native
    if config.get('method')!='asymptotic-profile-likelihood' or config.get('testStatistic')!='one-sided-qmu' or config.get('useCLs') is not True:
        raise ValueError('Choose explicit asymptotic one-sided q_mu with CLs')
    level=float(config['confidenceLevel']);points=config['points'];maximum=float(metadata['configuration']['muMax'])
    if not .5<level<1 or type(points)!=int or not 10<=points<=200:raise ValueError('Invalid confidence level or scan size')
    options=[ROOT.RooFit.Save(True),ROOT.RooFit.PrintLevel(-1)]
    if model.GetGlobalObservables():options.append(ROOT.RooFit.GlobalObservables(model.GetGlobalObservables()))
    fit=statistical.fit_native(model.GetPdf(),data,options,ROOT);check_cancel(cancel)
    if not fit or int(fit.status())!=0 or int(fit.covQual())<2:raise RuntimeError('Template likelihood fit failed or covariance is unreliable; no valid limit is presented')
    ROOT.RooStats.AsymptoticCalculator.SetPrintLevel(-1)
    calculator=ROOT.RooStats.AsymptoticCalculator(data,background_model,model,True);calculator.SetOneSided(True)
    inverter=ROOT.RooStats.HypoTestInverter(calculator);inverter.SetConfidenceLevel(level);inverter.UseCLs(True);inverter.SetVerbose(False);inverter.SetFixedScan(points,0.,maximum)
    ROOT.RooStats.HypoTestInverter.GetInterval.__release_gil__=True
    interval=inverter.GetInterval();check_cancel(cancel)
    if not interval:raise RuntimeError('RooStats template hypothesis calculation failed')
    upper=float(interval.UpperLimit());curve=[{'mu':float(interval.GetXValue(i)),'CLs':float(interval.GetResult(i).CLs())} for i in range(interval.ArraySize())]
    # RooStats returns CLs=-1 when CLb underflows. Finite is insufficient:
    # those failed scan points must never make a published limit look valid.
    invalid_points=[p for p in curve if not math.isfinite(p['CLs']) or p['CLs']<0 or p['CLs']>1+1e-6]
    valid=math.isfinite(upper) and 0<upper<maximum and bool(curve) and not invalid_points and curve[-1]['CLs']<1-level
    parameters=[{'name':str(p.GetName()),'value':float(p.getVal()),'error':float(p.getError())} for p in fit.floatParsFinal()]
    covariance=[[float(fit.covarianceMatrix()[i][j]) for j in range(len(parameters))] for i in range(len(parameters))]
    warnings=list(metadata['warnings'])
    if invalid_points:warnings.append('RooStats returned invalid CLs values at '+str(len(invalid_points))+' scan points; the limit is invalid. Narrow the POI range or inspect the numerical diagnostics.')
    if not valid:warnings.append('POI scan does not bracket a reliable limit; extend its range.')
    return {'kind':'HypothesisResult','backend':'RooStats-HistFactory','backendVersion':str(ROOT.gROOT.GetVersion()),'valid':valid,
            'upperLimit':upper,'expectedMedianLimit':float(interval.GetExpectedUpperLimit(0)),'expectedLimits':{str(k):float(interval.GetExpectedUpperLimit(k)) for k in (-2,-1,0,1,2)},
            'scan':curve,'configuration':copy.deepcopy(config),'model':metadata,'modelIdentity':metadata['identity'],'datasetRole':metadata['datasetRole'],
            'parameterOfInterest':'mu','fitStatus':int(fit.status()),'covarianceStatus':int(fit.covQual()),'parameters':parameters,'covariance':covariance,'warnings':warnings}


def equivalent_code(plan,inputs):
    # Embed identified compact arrays, not paths to untracked mutable ROOT files.
    functions=(_name,_validate_hist,template_set,_hist,likelihood,infer)
    code='''# Standalone PyROOT reference: immutable template arrays and explicit assumptions.
# VPIR remains canonical. Use the recorded ROOT version/environment for comparison.
import array,copy,hashlib,json,math,re,types,uuid
import ROOT
ROOT.gROOT.SetBatch(True)
FIT_HELPER=False
ROOT.EnableThreadSafety()
def key(value):return hashlib.sha256(json.dumps(value,sort_keys=True,separators=(",",":"),allow_nan=False).encode()).hexdigest()
def check_cancel(cancel):pass
'''
    code+=inspect.getsource(statistical.fit_native)+'\nstatistical=types.SimpleNamespace(fit_native=fit_native)\n'
    code+='\n\n'.join(inspect.getsource(f) for f in functions)
    code+='\nplan=json.loads('+repr(json.dumps(plan,sort_keys=True,allow_nan=False))+')\ninputs=json.loads('+repr(json.dumps(inputs,sort_keys=True,allow_nan=False))+')\n'
    code+='root=types.SimpleNamespace(ROOT=ROOT)\nstates={}\nresults={}\n'
    code+='''for node in plan['nodes']:
    kind=node['kind'];config=node['config'];nid=node['id']
    if kind=='TemplateSet':states[nid]=template_set(config,inputs);results[nid]=states[nid]
    elif kind=='BinnedLikelihood':states[nid]=likelihood(states[node['input']],config,root);results[nid]=states[nid][-1]
    elif kind=='Inference':results[nid]=infer(states[node['input']],config,root)
    else:raise ValueError('Unsupported template export node')
with open('reference-inference.json','w') as stream:json.dump(results,stream,indent=2,allow_nan=False)
'''
    return code


def execute(payload,root,environment,cancel,progress):
    states={};results={};inputs=payload.get('templateInputs',{});plan=payload['plan']
    for node in plan['nodes']:
        check_cancel(cancel);kind=node['kind'];nid=node['id'];config=node['config'];progress({'stage':kind})
        if nid in states:raise ValueError('Duplicate template node identity')
        if kind=='TemplateSet':states[nid]=template_set(config,inputs);results[nid]=states[nid]
        elif kind=='BinnedLikelihood':states[nid]=likelihood(states[node['input']],config,root);results[nid]=states[nid][-1]
        elif kind=='Inference':results[nid]=infer(states[node['input']],config,root,cancel);states[nid]=results[nid]
        else:raise ValueError('Template models cannot be mixed with event-generation stages')
    return {'valid':True,'results':results,'environment':environment,'metrics':{'bulkEventsThroughIPC':0,'allocatedThreads':1},
            'provenance':{'environment':environment,'workflowScientificHash':payload.get('scientificHash'),'workflowRevision':payload.get('workflowRevision'),'inputRuns':[{k:s[k] for k in ('reference','inputIdentity','role','sourceRun')} for h in results.values() if h.get('kind')=='HistogramSet' for s in h['samples']]},
            'generatedCode':equivalent_code(plan,inputs)}
