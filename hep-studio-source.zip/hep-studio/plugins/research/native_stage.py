"""One isolated native shower process; never transfers bulk events over IPC."""
import ctypes,importlib.util,json,os,sys
from pathlib import Path

def main():
    engine=ctypes.CDLL(os.environ['HEP_COLLIDER_ENGINE'])
    progress_type=ctypes.CFUNCTYPE(None,ctypes.c_char_p);cancel_type=ctypes.CFUNCTYPE(ctypes.c_int)
    engine.hep_collider_execute.argtypes=[ctypes.c_char_p,progress_type,cancel_type];engine.hep_collider_execute.restype=ctypes.c_void_p
    engine.hep_collider_free.argtypes=[ctypes.c_void_p]
    source=Path(sys.argv[1]);result=Path(sys.argv[2]);status=Path(sys.argv[3])
    def report(raw):
        temporary=status.with_suffix('.partial');temporary.write_bytes(raw);temporary.replace(status)
    pointer=engine.hep_collider_execute(source.read_bytes(),progress_type(report),cancel_type(lambda:0))
    if not pointer:raise MemoryError('Native shower response allocation failed')
    try:data=json.loads(ctypes.string_at(pointer))
    finally:engine.hep_collider_free(pointer)
    if 'error' in data:raise RuntimeError(data['error'])
    result.write_text(json.dumps(data,allow_nan=False))

if __name__=='__main__':main()
