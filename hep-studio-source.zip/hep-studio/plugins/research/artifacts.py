"""Worker-local stage transactions. Only verified committed manifests are reusable."""
from __future__ import annotations
import contextlib,hashlib,json,os,shutil,signal,subprocess,sys,tempfile,time
from pathlib import Path

def digest(path,cancel=None):
    h=hashlib.sha256()
    with Path(path).open('rb') as stream:
        while block:=stream.read(1024*1024):check_cancel(cancel);h.update(block)
    return h.hexdigest()

def canonical(value):return json.dumps(value,sort_keys=True,separators=(',',':'),allow_nan=False)
def key(value):return hashlib.sha256(canonical(value).encode()).hexdigest()

def check_cancel(cancel):
    if cancel and cancel.is_set():raise InterruptedError('Research job cancelled; partial output is not published')

def run_process(command,cwd,log,cancel=None,progress=None,timeout=1800,env=None):
    if os.name!='posix':raise ValueError('Use the managed Linux scientific runtime for research subprocesses on Windows')
    guard=Path(__file__).with_name('process_guard.py')
    env=dict(os.environ if env is None else env)
    for name in ('OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','NUMEXPR_NUM_THREADS'):env[name]='1'
    with Path(log).open('wb') as output:
        child=subprocess.Popen([sys.executable,str(guard),*[str(x) for x in command]],cwd=str(cwd),env=env,
                               stdin=subprocess.PIPE,stdout=output,stderr=subprocess.STDOUT,start_new_session=True)
        start=time.monotonic();last=start
        try:
            while child.poll() is None:
                check_cancel(cancel)
                now=time.monotonic()
                if now-start>timeout:raise TimeoutError('Scientific subprocess timed out; inspect retained raw log')
                if progress and now-last>=.5:
                    progress({'stage':'Running '+Path(str(command[0])).name,'elapsedSeconds':now-start,'logBytes':Path(log).stat().st_size});last=now
                time.sleep(.05)
            if child.returncode:
                with Path(log).open('rb') as stream:
                    stream.seek(max(0,Path(log).stat().st_size-4096));tail=stream.read().decode(errors='replace')
                raise RuntimeError('Scientific subprocess failed (exit '+str(child.returncode)+'): '+tail)
            check_cancel(cancel)
        finally:
            if child.poll() is None:
                os.killpg(child.pid,signal.SIGTERM)
                try:child.wait(timeout=2)
                except subprocess.TimeoutExpired:os.killpg(child.pid,signal.SIGKILL);child.wait(timeout=2)
            child.stdin.close()

class ArtifactCache:
    def __init__(self,root):self.root=Path(root);self.root.mkdir(parents=True,exist_ok=True)
    def text_artifacts(self,cache_key,names):
        import re
        if not re.fullmatch(r'[a-f0-9]{64}',cache_key) or not 1<=len(names)<=16:raise ValueError('Invalid recorded-card request')
        directory=self.root/cache_key;manifest_path=directory/'manifest.json'
        if manifest_path.stat().st_size>1024*1024:raise ValueError('Artifact manifest exceeds inspection limit')
        manifest=json.loads(manifest_path.read_text())
        if manifest.get('format')!='hep-stage-artifact' or manifest.get('version')!=1 or manifest.get('state')!='complete' or manifest.get('key')!=cache_key or key(manifest.get('identity'))!=cache_key:
            raise ValueError('Recorded cards belong to an incomplete/incompatible artifact')
        rows=[];total=0
        for name in names:
            path=(directory/name).resolve();identity=manifest['files'][name]
            if not path.is_relative_to(directory.resolve()) or path.suffix not in ('.dat','.tcl','.mg5','.txt'):raise ValueError('Only recorded configuration text can be inspected')
            if identity['sizeBytes']>128*1024 or path.stat().st_size!=identity['sizeBytes']:raise ValueError('Recorded configuration exceeds inspection limit or changed size')
            data=path.read_bytes();total+=len(data)
            if total>512*1024 or hashlib.sha256(data).hexdigest()!=identity['sha256']:raise ValueError('Recorded configuration is corrupt or exceeds inspection limit')
            rows.append({'name':name,'text':data.decode('utf-8'),'sha256':identity['sha256'],'artifactKey':cache_key})
        return rows
    def validate(self,directory,cancel=None):
        directory=Path(directory);manifest=json.loads((directory/'manifest.json').read_text())
        if manifest.get('format')!='hep-stage-artifact' or manifest.get('version')!=1 or manifest.get('state')!='complete':raise ValueError('Incomplete or incompatible scientific artifact')
        if manifest.get('key')!=directory.name or key(manifest.get('identity'))!=directory.name or not manifest.get('files'):raise ValueError('Scientific artifact identity does not match its cache address')
        for relative,identity in manifest['files'].items():
            path=(directory/relative).resolve()
            if not path.is_relative_to(directory.resolve()):raise ValueError('Unsafe artifact path')
            if not path.is_file() or path.stat().st_size!=identity['sizeBytes'] or digest(path,cancel)!=identity['sha256']:raise ValueError('Scientific artifact is missing or corrupt: '+relative)
        return manifest
    def stage(self,identity,build,cancel=None):
        import fcntl
        cache_key=key(identity);destination=self.root/cache_key
        # Kernel-owned locks release on process death, unlike PID marker files.
        with (self.root/(cache_key+'.lock')).open('a+b') as lock:
            start=time.monotonic()
            while True:
                check_cancel(cancel)
                try:fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB);break
                except BlockingIOError:
                    if time.monotonic()-start>60:raise TimeoutError('Scientific artifact is busy in another job')
                    time.sleep(.05)
            if destination.exists():return destination,self.validate(destination,cancel),True
            pending=Path(tempfile.mkdtemp(prefix='.pending-',dir=self.root))
            try:
                metadata=build(pending);check_cancel(cancel)
                paths=sorted(pending.rglob('*'))
                if any(p.is_symlink() for p in paths):raise ValueError('Stage output contains an unpublishable symbolic link')
                files={str(p.relative_to(pending)):{'sizeBytes':p.stat().st_size,'sha256':digest(p,cancel)} for p in paths if p.is_file()}
                if not files:raise ValueError('Scientific stage produced no artifacts')
                for p in paths:
                    if p.is_file():
                        with p.open('rb') as output:os.fsync(output.fileno())
                manifest={'format':'hep-stage-artifact','version':1,'state':'complete','key':cache_key,'identity':identity,'files':files,'metadata':metadata}
                with (pending/'manifest.json').open('w') as output:
                    output.write(canonical(manifest)+'\n');output.flush();os.fsync(output.fileno())
                check_cancel(cancel);pending.rename(destination)
                fd=os.open(self.root,os.O_RDONLY)
                try:os.fsync(fd)
                finally:os.close(fd)
                return destination,manifest,False
            except BaseException as error:
                # Failed data stays unpublished, but raw diagnostics survive for
                # audit/recovery. Do not copy enormous partial event artifacts.
                try:
                    failure=self.root/'failures'/pending.name.removeprefix('.pending-');failure.mkdir(parents=True,exist_ok=True)
                    for log in pending.rglob('*.log'):
                        target=failure/log.relative_to(pending);target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(log,target)
                    (failure/'failure.json').write_text(canonical({'state':'failed','artifactKey':cache_key,'identity':identity,'error':str(error),'logs':[str(p.relative_to(failure)) for p in failure.rglob('*.log')]})+'\n')
                except OSError:pass # Disk exhaustion must not mask the original failure.
                raise
            finally:
                if pending.exists():shutil.rmtree(pending)
