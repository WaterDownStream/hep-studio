"""Research worker orchestration. Files and bulk event loops stay worker-local."""
from __future__ import annotations
import concurrent.futures,copy,hashlib,importlib.util,json,os,platform,shutil,sys,threading,time
from pathlib import Path
from artifacts import ArtifactCache,canonical,key,digest,check_cancel,run_process
import lhe,reconstruction,statistical,campaigns,transparency,templates

CAPABILITY={};ROOT_ADAPTER=None;COLLIDER=None
def module(name,path):
    spec=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m
def adapter_path(local,source):
    path=Path(__file__).with_name(local)
    return path if path.exists() else Path(__file__).resolve().parents[1]/source
MG=module('hep_madgraph',adapter_path('madgraph_backend.py','madgraph/backend.py'))
DELPHES=module('hep_delphes',adapter_path('delphes_backend.py','delphes/backend.py'))

def initialize():
    global CAPABILITY,ROOT_ADAPTER,COLLIDER
    ROOT_ADAPTER=module('hep_research_root',adapter_path('root_backend.py','root/backend.py'))
    libs={name:{'available':False,'status':'Needs installation','version':''} for name in ('ROOT','PYTHIA','HepMC3','FastJet','LHAPDF')}
    try:
        ROOT_ADAPTER.initialize();libs['ROOT']={'available':True,'status':'Available','version':str(ROOT_ADAPTER.ROOT.gROOT.GetVersion())}
    except Exception as error:libs['ROOT']['reason']=str(error)
    try:
        if not os.environ.get('HEP_COLLIDER_ENGINE'):
            engine=next((Path(__file__).parent.parent/'collider_worker'/n for n in ('libhep-collider-engine.so','libhep-collider-engine.dylib','hep-collider-engine.dll') if (Path(__file__).parent.parent/'collider_worker'/n).is_file()),None)
            if engine:os.environ['HEP_COLLIDER_ENGINE']=str(engine)
        collider_path=Path(os.environ.get('HEP_COLLIDER_WORKER_DIRECTORY',str(Path(__file__).parent.parent/'collider_worker')))/'backend.py'
        if not collider_path.exists():collider_path=adapter_path('collider_backend.py','collider/backend.py')
        COLLIDER=module('hep_research_collider',collider_path);collider=COLLIDER.initialize();libs.update(collider['libraries'])
        if libs['ROOT']['available'] and ROOT_ADAPTER.ROOT and str(ROOT_ADAPTER.ROOT.gROOT.GetVersion())!=libs['ROOT']['version']:raise ValueError('Research ROOT and collider ROOT versions differ')
    except Exception as error:libs['PYTHIA']['reason']=str(error)
    libs['MadGraph']=MG.capability();libs['Delphes']=DELPHES.capability()
    if ROOT_ADAPTER.ROOT:
        libs['ROOT']={'available':True,'status':'Available','version':str(ROOT_ADAPTER.ROOT.gROOT.GetVersion())}
    for name,cls in (('RooFit','RooGaussian'),('RooStats','RooStats')):
        ready=bool(ROOT_ADAPTER.ROOT and hasattr(ROOT_ADAPTER.ROOT,cls));libs[name]={'available':ready,'status':'Available' if ready else 'Needs installation','version':str(ROOT_ADAPTER.ROOT.gROOT.GetVersion()) if ready else ''}
    ready=bool(libs['RooStats']['available'] and hasattr(ROOT_ADAPTER.ROOT.RooStats,'HistFactory'))
    libs['HistFactory']={'available':ready,'status':'Available' if ready else 'Needs installation','version':libs['ROOT']['version'] if ready else ''}
    if ROOT_ADAPTER.ROOT and libs['Delphes']['available']:
        sdk=Path(libs['Delphes']['location']);ROOT_ADAPTER.ROOT.gInterpreter.AddIncludePath(str(sdk));ROOT_ADAPTER.ROOT.gInterpreter.AddIncludePath(str(sdk/'external'))
        if ROOT_ADAPTER.ROOT.gSystem.Load(str(sdk/'libDelphes.so'))<0:libs['Delphes'].update(available=False,status='Incompatible',reason='Delphes ROOT dictionary could not be loaded')
    env={'libraries':{k:{a:b for a,b in v.items() if a not in ('location','reason')} for k,v in libs.items()},
         'platform':platform.system(),'architecture':platform.machine(),'python':platform.python_version(),'adapterVersion':1,
         'adapters':{p.name:digest(p) for p in sorted(Path(__file__).parent.glob('*.py'))}}
    if COLLIDER and COLLIDER.CAPABILITY.get('environment'):env['colliderEnvironment']=COLLIDER.CAPABILITY['environment']
    compiler=os.environ.get('HEP_FORTRAN_COMPILER')
    if compiler and Path(compiler).is_file():env['fortranEntrypointSha256']=digest(compiler)
    env['id']='hep-env://research/'+key(env)[:24]
    CAPABILITY={'available':bool(libs['ROOT']['available']),'backend':'hep.research/1','libraries':libs,'environment':env,
                'runtimeId':os.environ.get('HEP_RUNTIME_ID','native'),'python':sys.executable,
                'cacheRoot':os.environ.get('HEP_RESEARCH_CACHE',str(Path.home()/'HEPStudio/research-artifacts')),
                'researchScope':'SM LO, LHE shower, Delphes, reconstructed RDataFrame'}
    return CAPABILITY

def frozen_config(c):
    result=copy.deepcopy(c);result.pop('workers',None)
    if result.get('card',{}).get('resourceVersion')==1 and result['card'].get('resourceId'):result['card'].pop('path',None)
    return result
def physical_resource(resource):
    path=Path(resource['path'])
    if not path.is_file():raise ValueError('Dataset/sample unavailable; relink its logical resource')
    actual=digest(path)
    if resource.get('sha256') and actual!=resource['sha256']:raise ValueError('Input resource changed since its recorded identity')
    return path,{'logicalUri':resource.get('logicalUri',resource.get('resourceId','')),'sha256':actual,'sizeBytes':path.stat().st_size}
def stream_seed(master,index,label):
    # Stable logical block seeds never depend on available CPU count.
    value=int.from_bytes(hashlib.sha256(('hep-research-stream-v1\0'+label+'\0'+str(master)+'\0'+str(index)).encode()).digest()[:8],'big')
    return 1+value%900000000

def execute(payload,cancel,progress):
    if not CAPABILITY:initialize()
    plan=payload['plan'];env=CAPABILITY['environment'];expected=payload.get('expectedEnvironmentId')
    if expected and expected!=env['id'] and payload.get('environmentPolicy','strict')=='strict':raise ValueError('Scientific environment mismatch; explicitly permit and record a new environment before execution')
    if plan.get('version')!=1 or plan.get('backend')!='hep.research/1':raise ValueError('Research execution contract/version mismatch')
    for name in plan.get('requiredLibraries',[]):
        if not CAPABILITY['libraries'].get(name,{}).get('available'):raise ValueError(name+' unavailable; repair or select a scientific environment that provides it')
    workers=plan.get('requiredThreads',1)
    if type(workers)!=int or not 1<=workers<=32 or workers>payload.get('allocatedThreads',1):raise ValueError('Research worker count exceeds central Resource Broker allocation')
    if any(n['kind']=='TemplateSet' for n in plan['nodes']):
        if payload.get('preview',False):raise ValueError('Template inference consumes identified scientific Runs; generate a full Run with explicitly labelled Asimov/observed data')
        return templates.execute(payload,ROOT_ADAPTER,env,cancel,progress)
    preview=bool(payload.get('preview',False));cache=ArtifactCache(CAPABILITY['cacheRoot']);resources=payload.get('resources',{})
    states={};stages=[];events=[];started=time.monotonic();nodes=plan['nodes'];seen=set()
    for node in nodes:
        if node['id'] in seen or any(node.get(p) and node[p] not in seen for p in ('input','reference')):raise ValueError('Invalid research DAG order/identity')
        seen.add(node['id'])
        nid=node['id'];kind=node['kind'];config=copy.deepcopy(node['config']);parent=states.get(node.get('input'));stage_started=time.monotonic()
        stage=None
        if kind=='MadGraph':
            if preview:config['events']=min(config.get('events',100),max(1,min(int(payload.get('previewEvents',10)),20)))
            identity={'stage':'MadGraph','config':config,'environment':env['id']}
            path,manifest,reused=cache.stage(identity,lambda folder:MG.generate(config,folder,cancel,progress),cancel)
            stage={'id':nid,'kind':kind,'artifactKey':manifest['key'],'cacheReused':reused,'metadata':manifest['metadata']}
            states[nid]={'path':path/'events.lhe','identity':manifest['key'],'metadata':manifest['metadata'],'semanticType':'LHEEventSample'}
        elif kind=='LHESource':
            resource=resources[config['resourceId']];path,identity=physical_resource(resource);metadata=MG.lhe_metadata(path,cancel)
            if str(path).endswith('.gz'):
                def unpack(folder):
                    import gzip
                    with gzip.open(path,'rb') as source,(folder/'events.lhe').open('wb') as out:shutil.copyfileobj(source,out)
                    return metadata
                folder,manifest,reused=cache.stage({'stage':'LHE decompression','input':identity},unpack,cancel);path=folder/'events.lhe'
            states[nid]={'path':path,'identity':key(identity),'metadata':metadata,'semanticType':'LHEEventSample'}
            stage={'id':nid,'kind':kind,'metadata':metadata,'inputIdentity':identity}
        elif kind=='Shower':
            if not parent or parent['semanticType']!='LHEEventSample':raise ValueError('Shower requires a typed LHE sample')
            if config.get('streamPolicy')!='lhe-logical-blocks-v1':raise ValueError('Unsupported LHE stream policy')
            seed,seed_info=COLLIDER.derive_seed(payload.get('projectSeed','1'),config,nid)
            logical_size=config.get('partitionEvents',4096);limit=min(20,int(payload.get('previewEvents',10))) if preview else None
            block_identity={'stage':'LHE logical blocks','input':parent['identity'],'partitionEvents':logical_size,'previewLimit':limit}
            folder,block_manifest,reused=cache.stage(block_identity,lambda folder:{'parts':[{**p,'path':Path(p['path']).name} for p in lhe.blocks(parent['path'],folder,logical_size,limit,cancel)]},cancel)
            parts=block_manifest['metadata']['parts'];results=[None]*len(parts);failed=threading.Event()
            seeds=[stream_seed(seed,p['index'],'shower') for p in parts]
            if len(set(seeds))!=len(seeds):raise ValueError('Logical shower seed collision; change the scientific master seed or partition size explicitly')
            class Stop:
                def is_set(self):return failed.is_set() or bool(cancel and cancel.is_set())
            def one(part):
                actual=stream_seed(seed,part['index'],'shower');identity={'stage':'Shower','inputBlock':digest(folder/part['path']),'config':frozen_config(config),'actualSeed':actual,'environment':env['id']}
                def build(destination):
                    command={'operation':'showerLhe','payload':{'input':str(folder/part['path']),'output':str(destination/'events.hepmc'),
                        'eventCount':part['eventCount'],'eventOffset':part['firstEvent'],'actualSeed':actual,'config':frozen_config(config),'inspectEvents':1 if part['index']==0 else 0}}
                    (destination/'request.json').write_text(canonical(command))
                    def report(metric):
                        status=destination/'progress.json'
                        if status.exists():
                            try:metric.update(json.loads(status.read_text()))
                            except (ValueError,OSError):pass
                        metric.update(logicalPartition=part['index'],workers=workers);progress(metric)
                    env_process=os.environ.copy()
                    env_process['HEP_COLLIDER_ENGINE']=COLLIDER.CAPABILITY['location']
                    run_process([sys.executable,str(Path(__file__).with_name('native_stage.py')),str(destination/'request.json'),str(destination/'result.json'),str(destination/'progress.json')],destination,destination/'shower.log',Stop(),report,env=env_process)
                    result=json.loads((destination/'result.json').read_text());result.pop('path',None)
                    (destination/'request.json').unlink();(destination/'result.json').unlink()
                    return result
                destination,manifest,reused=cache.stage(identity,build,Stop())
                return {'index':part['index'],'firstEvent':part['firstEvent'],'eventCount':part['eventCount'],'seed':actual,'path':destination/'events.hepmc','identity':manifest['key'],'metadata':manifest['metadata'],'cacheReused':reused}
            with concurrent.futures.ThreadPoolExecutor(max_workers=workers) as pool:
                futures={pool.submit(one,part):part['index'] for part in parts}
                try:
                    for future in concurrent.futures.as_completed(futures):results[futures[future]]=future.result()
                except BaseException:failed.set();raise
            check_cancel(cancel)
            metadata=copy.deepcopy(parent['metadata']);metadata['eventCount']=sum(p['eventCount'] for p in results)
            metadata['sumWeights']=sum(p['metadata']['metrics']['sumWeights'] for p in results)
            metadata['sumWeightsSquared']=sum(p['metadata']['metrics']['sumWeightsSquared'] for p in results)
            states[nid]={'parts':results,'metadata':metadata,'identity':key([p['identity'] for p in results]),'semanticType':'EventStream'}
            events=results[0]['metadata'].get('events',[]) if results else []
            stage={'id':nid,'kind':kind,'logicalPartitions':[{k:p[k] for k in ('index','firstEvent','eventCount','seed','identity','cacheReused')} for p in results],
                   'seed':seed_info,'physicalWorkers':workers,'metadata':metadata,'configuration':frozen_config(config),
                   'reproducibility':'Stable logical LHE ranges and index-derived seeds; physical worker count schedules blocks only. Same identified environment required; no cross-platform bitwise guarantee.'}
        elif kind=='Delphes':
            if not parent or parent['semanticType']!='EventStream':raise ValueError('Delphes requires a typed showered event stream')
            config=copy.deepcopy(config)
            if config['card'].get('resourceId'):
                resource=resources.get(config['card']['resourceId'])
                if not resource:raise ValueError('Detector card unavailable in this runtime; relink its logical resource')
                resolved,location=physical_resource(resource);config['card']['path']=str(resolved)
            card_path,card=DELPHES.detector_card(config);parts=[]
            seeds=[stream_seed(config.get('seed',24680),p['index'],'detector') for p in parent['parts']]
            if len(set(seeds))!=len(seeds):raise ValueError('Logical detector seed collision; change the scientific detector seed explicitly')
            for part in parent['parts']:
                check_cancel(cancel);actual=stream_seed(config.get('seed',24680),part['index'],'detector')
                effective=copy.deepcopy(config);effective['actualSeed']=actual
                identity={'stage':'Delphes','input':part['identity'],'config':frozen_config(effective),'card':card,'environment':env['id']}
                def build(destination):
                    metadata=DELPHES.reconstruct(effective,part['path'],destination,cancel,progress)
                    if metadata['eventCount']!=part['eventCount']:raise ValueError('Detector reconstruction has incomplete event count')
                    return metadata
                destination,manifest,reused=cache.stage(identity,build,cancel)
                parts.append({'index':part['index'],'path':destination/'reconstructed.root','identity':manifest['key'],'metadata':manifest['metadata'],'cacheReused':reused})
            states[nid]={'paths':[p['path'] for p in parts],'identity':key([p['identity'] for p in parts]),'metadata':parent['metadata'],'semanticType':'ReconstructedEventDataset'}
            stage={'id':nid,'kind':kind,'detectorCard':card,'configuration':frozen_config(config),'logicalPartitions':[{k:p[k] for k in ('index','identity','cacheReused','metadata')} for p in parts]}
        elif kind=='RecoSource':
            resource=resources[config['resourceId']];path,identity=physical_resource(resource)
            states[nid]={'paths':[path],'identity':key(identity),'metadata':resource,'semanticType':'ReconstructedEventDataset'}
            stage={'id':nid,'kind':kind,'inputIdentity':identity}
        else:
            if parent is None:raise ValueError('Analysis node has no input')
            states[nid]=parent
        if stage:stage['wallSeconds']=time.monotonic()-stage_started;stages.append(stage)
    datasets=[states[n['id']] for n in nodes if n['kind'] in ('Delphes','RecoSource')]
    if len(datasets)!=1:raise ValueError('This lowering requires one reconstructed dataset lineage')
    dataset=datasets[0];analysis=reconstruction.analyze(plan,dataset['paths'],dataset['metadata'],ROOT_ADAPTER,cancel,progress)
    check_cancel(cancel)
    result={'valid':True,'preview':preview,'results':analysis['results'],'events':events,'executionPlan':plan,'environment':env,'stages':stages,
            'artifactReferences':[{'format':'ROOT-TTree','object':'Delphes','path':str(path),'sha256':digest(path),'available':True} for path in dataset['paths']],
            'metrics':{**analysis['metrics'],'wallSeconds':time.monotonic()-started,'allocatedThreads':workers,'bulkEventsThroughIPC':0},
            'provenance':{'environment':env,'workflowScientificHash':payload.get('scientificHash'),'workflowRevision':payload.get('workflowRevision'),
                          'seed':payload.get('projectSeed','1'),'stages':stages,'analysis':nodes,'preview':preview,'variationIdentity':payload.get('planVariationIdentity'),
                          'environmentDifference':None if not expected or expected==env['id'] else {'expected':expected,'actual':env['id']}}}
    result['generatedCode']=transparency.analysis(plan,dataset['paths'],dataset['metadata'],ROOT_ADAPTER,{'plan':plan,'environment':env,'stages':stages,'seed':payload.get('projectSeed','1'),'artifacts':result['artifactReferences']})
    result['exportScope']='Standalone PyROOT reconstructed analysis and supported ROOT/RooFit/RooStats actions; checksum-identified inputs and frozen upstream generator/shower/detector ledger.'
    return result

def dispatch(request,cancel,progress):
    operation=request['operation'];payload=request.get('payload',{})
    if operation=='execute':
        if payload['plan'].get('systematics'):return campaigns.systematic_execute(payload,execute,ROOT_ADAPTER,cancel,progress)
        return execute(payload,cancel,progress)
    if operation=='scan':
        def execute_point(point,cancel,progress):
            backend=point['plan'].get('backend','hep.root/1')
            if backend=='hep.research/1':return dispatch({'operation':'execute','payload':point},cancel,progress)
            if backend=='hep.root/1':
                result=ROOT_ADAPTER.execute(point['plan'],point['datasets'],cancel,progress);result['environment']=CAPABILITY['environment'];result['valid']=True;return result
            if backend=='hep.collider/1':return COLLIDER.dispatch({'operation':'execute','payload':point},cancel,progress)
            raise ValueError('Unsupported scan backend placement')
        payload['scanRoot']=str(Path(CAPABILITY['cacheRoot'])/'scans')
        return campaigns.run_scan(payload,execute_point,cancel,progress)
    if operation=='recoverScans':return {'scanRecovery':campaigns.recover_scans(Path(CAPABILITY['cacheRoot'])/'scans'),'preview':True,'valid':True}
    if operation=='cards':
        requests=payload['artifacts']
        if not 1<=len(requests)<=4:raise ValueError('Inspect at most four recorded configuration artifacts per request')
        cache=ArtifactCache(CAPABILITY['cacheRoot']);rows=[]
        for request in requests:
            check_cancel(cancel);rows.extend(cache.text_artifacts(request['key'],request['names']))
        if sum(len(row['text'].encode()) for row in rows)>1024*1024:raise ValueError('Recorded cards exceed compact inspection limit')
        return {'preview':True,'valid':True,'runId':payload['runId'],'cards':rows,'scope':'Recorded generation cards and first logical detector partition; complete stream seeds remain in Run provenance'}
    if operation=='rooFit':return statistical.fit(payload['histogram'],payload['config'],ROOT_ADAPTER,cancel)
    if operation=='rooStats':return statistical.counting(payload['config'],ROOT_ADAPTER,cancel)
    if operation=='preview':payload={**payload,'preview':True};return execute(payload,cancel,progress)
    if operation in ('inspect','schema','dataPreview'):
        return ROOT_ADAPTER.dispatch({'operation':'preview' if operation=='dataPreview' else operation,'payload':payload},cancel,progress)
    raise ValueError('Unsupported research worker operation')
