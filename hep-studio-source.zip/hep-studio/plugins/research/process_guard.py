"""Subprocess lifeline: coordinator/worker death must not orphan scientific jobs."""
import os,signal,subprocess,sys,threading

def lost_parent():
    # Raw descriptor reads avoid a buffered-stdin lock at interpreter shutdown.
    while os.read(0,8192):pass
    # This helper is a new session leader. All compiler/backend descendants
    # inherit its process group; no user processes share that group.
    os.killpg(os.getpgrp(),signal.SIGKILL)

if __name__=='__main__':
    if os.name!='posix':raise SystemExit('Scientific subprocess execution requires a native Unix or managed Linux worker')
    threading.Thread(target=lost_parent,daemon=True).start()
    child=subprocess.Popen(sys.argv[1:],stdin=subprocess.DEVNULL)
    raise SystemExit(child.wait())
