"""Bounded streaming LHE records and stable logical block materialization."""
import re
from pathlib import Path
from artifacts import check_cancel

def blocks(path,directory,size,limit=None,cancel=None):
    if type(size)!=int or not 1<=size<=1000000:raise ValueError('Logical LHE block size must be in [1,1000000]')
    header=[];record=[];count=0;parts=[];output=None;closed=False;in_record=False
    try:
        with Path(path).open() as source:
            for line in source:
                if len(line)>1024*1024:raise ValueError('Oversized LHE record line')
                if re.match(r'\s*<event(?:\s|>)',line):
                    if in_record:raise ValueError('Nested LHE event')
                    in_record=True;record=[line];continue
                if in_record:
                    record.append(line)
                    if sum(map(len,record))>2*1024*1024:raise ValueError('LHE event exceeds bounded record limit')
                    if '</event>' in line:
                        check_cancel(cancel);in_record=False
                        if output is None:
                            if len(parts)>=4096:raise ValueError('At most 4096 stable LHE blocks are supported; increase logical block size')
                            index=len(parts);p=Path(directory)/('lhe-'+str(index)+'.lhe');output=p.open('w');output.writelines(header)
                            parts.append({'index':index,'firstEvent':count,'eventCount':0,'path':str(p)})
                        output.writelines(record);record=[];count+=1;parts[-1]['eventCount']+=1
                        if count%size==0 or limit is not None and count>=limit:
                            output.write('</LesHouchesEvents>\n');output.close();output=None
                        if limit is not None and count>=limit:return parts
                    continue
                if '</LesHouchesEvents>' in line:closed=True;break
                if count==0:
                    header.append(line)
                    if sum(map(len,header))>2*1024*1024:raise ValueError('LHE header exceeds safety limit')
        if in_record or not closed or not count:raise ValueError('Incomplete or empty LHE stream')
        if output is not None:output.write('</LesHouchesEvents>\n');output.close();output=None
        return parts
    finally:
        if output is not None:output.close()
