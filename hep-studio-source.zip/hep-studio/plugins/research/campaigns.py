"""First-class variations and sequential scans over canonical scientific plans."""
from __future__ import annotations
import copy,datetime,json,math,os,uuid
from pathlib import Path
from artifacts import key,canonical,check_cancel,digest

KINDS={'normalization','shape','parameter','weight','alternative-sample','detector','generator'}
def assign(plan,binding):
    matches=[n for n in plan['nodes'] if n['id']==binding['nodeId']]
    if len(matches)!=1:raise ValueError('Variation refers to an unknown scientific node')
    pointer=binding['pointer']
    if not pointer.startswith('/') or pointer=='/workers':raise ValueError('Execution budgets are not scientific variation parameters')
    tokens=[x.replace('~1','/').replace('~0','~') for x in pointer[1:].split('/')];parent=matches[0]['config']
    for token in tokens[:-1]:parent=parent[int(token)] if isinstance(parent,list) else parent[token]
    target=int(tokens[-1]) if isinstance(parent,list) else tokens[-1]
    old=parent[target];new=binding['value']
    if type(old) is bool and type(new) is not bool or isinstance(old,(int,float)) and (type(new) not in (int,float) or not math.isfinite(new)) or isinstance(old,str) and not isinstance(new,str):raise ValueError('Variation parameter type differs from its canonical binding')
    # Values supplied by core lowering have already been converted to canonical
    # units. Direct protocol callers must declare that same representation.
    if binding.get('representation','canonical')!='canonical':raise ValueError('Lower variation quantities to canonical units before execution')
    parent[target]=new

def scale_histogram(h,factor):
    if not math.isfinite(factor) or factor<0 or h.get('normalization','counts')!='counts':raise ValueError('Normalization variation requires a nonnegative scale on an absolute/count histogram')
    result=copy.deepcopy(h)
    for keyname in ('values','errors'):result[keyname]=[v*factor for v in h[keyname]]
    for keyname in ('underflow','overflow','underflowError','overflowError','sumWeights'):
        if keyname in h:result[keyname]=h[keyname]*factor
    if 'sumWeightsSquared' in h:result['sumWeightsSquared']=h['sumWeightsSquared']*factor*factor
    if 'statistics' in h:result['statistics']=[v*(factor*factor if i==1 else factor) for i,v in enumerate(h['statistics'])]
    return result

def systematic_execute(payload,execute,root,cancel,progress):
    nominal_payload=copy.deepcopy(payload);definitions=nominal_payload['plan'].pop('systematics',[])
    nominal=execute(nominal_payload,cancel,progress);templates={};identities=set()
    for descriptor in definitions:
        check_cancel(cancel);sid=descriptor['id']
        if sid in identities or descriptor['kind'] not in KINDS:raise ValueError('Duplicate or unsupported systematic identity')
        identities.add(sid)
        if not all(k in descriptor for k in ('nominal','correlation','interpretation','affectedNodes','variations')):raise ValueError('Systematic descriptor requires explicit assumptions and affected nodes')
        rows=[];labels=set()
        for variation in descriptor['variations']:
            check_cancel(cancel);label=variation['label']
            if label in labels:raise ValueError('Duplicate systematic variation label')
            labels.add(label);kind=descriptor['kind'];child=copy.deepcopy(nominal_payload)
            if kind in ('normalization','shape'):
                varied=copy.deepcopy(nominal)
                for nid in descriptor['affectedNodes']:
                    hist=varied['results'][nid]
                    if hist.get('kind')!='Histogram1D':raise ValueError('Template variations bind histogram identities')
                    if kind=='normalization':varied['results'][nid]=scale_histogram(hist,float(variation['factor']))
                    else:
                        replacement=variation['templates'][nid]
                        if replacement['edges']!=hist['edges'] or replacement.get('normalization','counts')!=hist.get('normalization','counts'):raise ValueError('Shape variation template binning/normalization differs')
                        root_hist=__import__('statistical').histogram(replacement,root.ROOT)
                        varied['results'][nid]=copy.deepcopy(replacement)
                # Refit changed inputs; never carry over a nominal fit as a
                # variation's scientific result.
                for node in child['plan']['nodes']:
                    if node.get('input') not in descriptor['affectedNodes']:continue
                    source=varied['results'][node['input']]
                    if node['kind']=='RooFit':varied['results'][node['id']]=__import__('statistical').fit(source,node['config'],root,cancel)
                    elif node['kind']=='Fit':varied['results'][node['id']]=root.fit_histogram(__import__('statistical').histogram(source,root.ROOT),node['config'])
                    elif node['kind']=='RooStats':
                        if source.get('yieldMode')!='luminosity' or source.get('normalization')!='counts':raise ValueError('Varied inference input must remain an expected event yield')
                        varied['results'][node['id']]=__import__('statistical').counting({**node['config'],'signal':sum(source['values'])},root,cancel)
                    if node['kind'] in ('Fit','RooFit'):varied['results'][node['id']]['histogramId']=node['input']
                stage_reuse=[{'id':s['id'],'reused':True} for s in nominal.get('stages',[])]
            else:
                if kind=='weight':
                    for nid in descriptor['affectedNodes']:
                        match=next(n for n in child['plan']['nodes'] if n['id']==nid)
                        if match['kind']!='Histo1D':raise ValueError('Weight variation must bind a histogram')
                        match['config']['weight']=variation['expression']
                else:
                    for binding in variation['bindings']:
                        if binding['nodeId'] not in descriptor['affectedNodes']:raise ValueError('Variation changes a node outside its declared affected identities')
                        assign(child['plan'],binding)
                child['planVariationIdentity']=key({'nominal':payload.get('scientificHash'),'descriptor':descriptor,'variation':variation})
                progress({'stage':'Systematic '+descriptor.get('name',sid)+' / '+label})
                varied=execute(child,cancel,progress);stage_reuse=[{'id':s['id'],'reused':s.get('cacheReused',all(p.get('cacheReused',False) for p in s.get('logicalPartitions',[])))} for s in varied.get('stages',[])]
            rows.append({'label':label,'identity':key({'descriptor':descriptor,'variation':variation}),'results':varied['results'],'stageReuse':stage_reuse,'valid':all(v.get('valid',v.get('converged',True)) for v in varied['results'].values())})
        templates[sid]={'descriptor':descriptor,'variations':rows}
    nominal['systematics']={'version':1,'nominalIdentity':payload.get('scientificHash'),'templates':templates,
                            'combination':'None: per-variation templates only. No prior or correlation combination is inferred.'}
    nominal['executionPlan']=payload['plan'];nominal['provenance']['systematics']=definitions
    return nominal

def atomic_json(path,value):
    path=Path(path);pending=path.with_suffix('.partial')
    with pending.open('w') as output:
        output.write(canonical(value)+'\n');output.flush();os.fsync(output.fileno())
    pending.replace(path)
    fd=os.open(path.parent,os.O_RDONLY)
    try:os.fsync(fd)
    finally:os.close(fd)

def recover_scans(root):
    """Recover only transactions with no live owner; verify each committed Run."""
    import fcntl
    receipts=[];root=Path(root)
    if not root.is_dir():return receipts
    for folder in sorted(root.iterdir()):
        if not folder.is_dir() or not (folder/'scan.json').is_file():continue
        with (folder/'owner.lock').open('a+b') as owner:
            try:fcntl.flock(owner,fcntl.LOCK_EX|fcntl.LOCK_NB)
            except BlockingIOError:continue
            scan=json.loads((folder/'scan.json').read_text())
            if scan.get('format')!='hep-scan' or scan.get('version')!=1 or scan.get('id')!=folder.name:raise ValueError('Incompatible scan recovery receipt')
            verified=[];corrupt=[]
            for reference in scan.get('runs',[]):
                path=Path(reference['resultPath'])
                try:
                    if not path.resolve().is_relative_to(folder.resolve()) or digest(path)!=reference['sha256']:raise ValueError('Scan result checksum/location mismatch')
                    run=json.loads(path.read_text())
                    if run['id']!=reference['runId'] or run['status']!=reference['status'] or scan.get('expectedRunHashes',{}).get(run['id'],run['workflowHash'])!=run['workflowHash']:raise ValueError('Scan result identity/status mismatch')
                    verified.append(run)
                except (ValueError,KeyError,OSError) as error:corrupt.append({'runId':reference.get('runId'),'error':str(error)})
            if scan.get('state')=='running':scan.update(state='interrupted',ended=datetime.datetime.now(datetime.timezone.utc).isoformat());atomic_json(folder/'scan.json',scan)
            receipts.append({'scan':scan,'pointRuns':verified,'corruptPoints':corrupt,'complete':scan['state']=='completed' and not corrupt})
    return receipts

def run_scan(payload,execute,cancel,progress):
    import fcntl
    points=payload['points'];scan=copy.deepcopy(payload['scan'])
    if not 1<=len(points)<=64:raise ValueError('Scan requires one to 64 canonical points')
    if not isinstance(scan.get('id'),str) or not scan['id'] or any(c not in 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789-_' for c in scan['id']):raise ValueError('Unsafe scan identity')
    ids=set()
    for point in points:
        rid=point['runId']
        if not isinstance(rid,str) or not rid or any(c not in 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789-_' for c in rid) or rid in ids:raise ValueError('Unsafe/duplicate scan Run identity')
        ids.add(rid)
    folder=Path(payload['scanRoot'])/scan['id'];folder.mkdir(parents=True,exist_ok=bool(payload.get('resume',False)))
    with (folder/'owner.lock').open('a+b') as owner:
        fcntl.flock(owner,fcntl.LOCK_EX|fcntl.LOCK_NB)
        committed={}
        if payload.get('resume',False):
            previous=json.loads((folder/'scan.json').read_text())
            if previous.get('format')!='hep-scan' or previous.get('version')!=1 or previous.get('id')!=scan['id']:raise ValueError('Incompatible scan resume identity')
            for reference in previous.get('runs',[]):
                path=Path(reference['resultPath'])
                if not path.resolve().is_relative_to(folder.resolve()) or digest(path)!=reference['sha256']:raise ValueError('Cannot resume a scan with corrupt committed points')
                run=json.loads(path.read_text());point=next((p for p in points if p['runId']==run['id']),None)
                if not point or run['workflowHash']!=point['scientificHash'] or run['workflow']!=point['workflowSnapshot']:raise ValueError('Scientific point changed since interrupted scan; create a new scan')
                committed[run['id']]=run
            scan=previous;scan['resumed']=datetime.datetime.now(datetime.timezone.utc).isoformat();scan['state']='running'
        else:scan.update(format='hep-scan',version=1,state='running',runs=[],failures=[],started=datetime.datetime.now(datetime.timezone.utc).isoformat())
        def checkpoint():atomic_json(folder/'scan.json',scan)
        checkpoint();runs=[]
        try:
            for index,point in enumerate(points):
                check_cancel(cancel);progress({'stage':'Scan point '+str(index+1)+' / '+str(len(points)),'point':index,'points':len(points)})
                if point['runId'] in committed:
                    runs.append(committed[point['runId']]);progress({'stage':'Verified resumed point','point':index,'points':len(points),'committedPoint':committed[point['runId']]});continue
                run={'id':point['runId'],'status':'Running','workflow':point['workflowSnapshot'],'workflowHash':point['scientificHash'],
                     'backend':point['payload']['plan']['backend'],'started':datetime.datetime.now(datetime.timezone.utc).isoformat(),'seed':point['payload'].get('projectSeed','1')}
                if 'nodeHashes' in point:run['nodeHashes']=point['nodeHashes']
                result=None
                try:
                    execution=copy.deepcopy(point['payload']);expected=scan.get('frozenEnvironment',{}).get('id')
                    if expected:execution.update(expectedEnvironmentId=expected,environmentPolicy='strict')
                    result=execute(execution,cancel,progress)
                    check_cancel(cancel)
                    if result.get('preview') or not result.get('valid'):raise ValueError('A scan point must be a valid full scientific execution')
                    if any(r.get('kind') in ('FitResult','HypothesisResult') and not r.get('valid',r.get('converged',False)) for r in result.get('results',{}).values()):raise ValueError('Scan fit/inference failed validation; diagnostics remain recorded but the point is not valid')
                    if expected and result.get('environment',{}).get('id')!=expected:raise ValueError('Scan scientific environment mismatch; preserve completed points and start a new scan')
                    run.update(status='Completed',result=result,environment=result['environment']['id'])
                except InterruptedError:raise
                except Exception as error:
                    run.update(status='Failed',result={**(result if isinstance(result,dict) else {}),'valid':False,'partial':True,'message':str(error)});scan['failures'].append({'point':index,'runId':run['id'],'message':str(error)})
                run['ended']=datetime.datetime.now(datetime.timezone.utc).isoformat();output=folder/(run['id']+'.json');atomic_json(output,run)
                scan['runs'].append({'runId':run['id'],'point':index,'status':run['status'],'resultPath':str(output),'sha256':digest(output)});runs.append(run);checkpoint()
                message={'stage':'Scan point committed','point':index,'points':len(points),'completedPoints':len(runs)}
                compact=run
                if len(canonical(compact).encode())>512*1024:
                    compact={**run,'result':{'valid':run['status']=='Completed','externalResultReference':{'path':str(output),'sha256':digest(output)}}}
                message['committedPoint']=compact;progress(message)
            scan['state']='completed' if not scan['failures'] else 'completed-with-failures'
        except BaseException:
            scan['state']='interrupted';checkpoint();raise
        finally:
            scan['ended']=datetime.datetime.now(datetime.timezone.utc).isoformat();checkpoint()
    return {'valid':not scan['failures'],'scan':scan,'pointRuns':runs,'preview':False,'scheduling':'Sequential points sharing one central allocation; no nested scan oversubscription'}
