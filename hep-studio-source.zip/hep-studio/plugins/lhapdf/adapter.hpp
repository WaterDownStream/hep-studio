#pragma once
#include "core/json.hpp"
namespace hep::lhapdf {
Json capability();
Json dispatch(const std::string&,const Json&);
}
