#include "plugins/lhapdf/adapter.hpp"
#include <filesystem>
#include <cmath>
#include <memory>
#include <set>
#ifdef HEP_HAS_LHAPDF
#include <LHAPDF/LHAPDF.h>
#endif
namespace hep::lhapdf {
Json capability(){
#ifdef HEP_HAS_LHAPDF
    return {{"available",true},{"version",LHAPDF::version()},{"status","Available"},{"paths",LHAPDF::paths()}};
#else
    return {{"available",false},{"version",""},{"status","Needs installation"}};
#endif
}
Json dispatch(const std::string& operation,const Json& payload){
#ifdef HEP_HAS_LHAPDF
    if(operation=="pdfSets"){
        Json sets=Json::array();
        // Scan paths afresh so a newly installed set is visible without cached catalogue state.
        std::set<std::string> seen;
        for(const auto& base:LHAPDF::paths()){
            std::error_code ec;if(!std::filesystem::is_directory(base,ec))continue;
            for(const auto& entry:std::filesystem::directory_iterator(base)){
                const auto name=entry.path().filename().string();if(!entry.is_directory()||!std::filesystem::exists(entry.path()/(name+".info"))||!seen.insert(name).second)continue;
                try{
                    const auto set=LHAPDF::getPDFSet(name);std::uint64_t bytes=0;
                    for(const auto& file:std::filesystem::directory_iterator(entry.path()))if(file.is_regular_file())bytes+=file.file_size();
                    sets.push_back({{"name",name},{"description",set.description()},{"members",set.size()},{"dataVersion",set.dataversion()},{"errorType",set.errorType()},{"sizeBytes",bytes},{"path",entry.path().string()}});
                }catch(const std::exception& e){sets.push_back({{"name",name},{"status","Incompatible"},{"error",e.what()}});}
            }
        }return {{"sets",sets},{"paths",LHAPDF::paths()},{"version",LHAPDF::version()}};
    }
    if(operation=="pdfEvaluate"){
        const auto name=payload.at("set").get<std::string>();const auto member=payload.value("member",0);const auto set=LHAPDF::getPDFSet(name);
        if(member<0||static_cast<std::size_t>(member)>=set.size())throw std::invalid_argument("PDF member unavailable");
        std::unique_ptr<LHAPDF::PDF> pdf(LHAPDF::mkPDF(name,member));const double q=payload.value("Q",91.1876),lo=payload.value("xMin",0.001),hi=payload.value("xMax",0.8);const int count=payload.value("points",100),flavour=payload.value("flavour",21);
        if(!std::isfinite(q+lo+hi)||q<=0||lo<=0||hi>=1||hi<=lo||count<2||count>2000)throw std::invalid_argument("Invalid PDF x/Q range or point count");
        if(!pdf->hasFlavor(flavour))throw std::invalid_argument("PDF flavour unavailable");
        Json values=Json::array();
        for(int i=0;i<count;++i){const auto x=std::exp(std::log(lo)+(std::log(hi)-std::log(lo))*i/(count-1));if(!pdf->inRangeXQ(x,q))throw std::invalid_argument("PDF request outside fitted x/Q domain; extrapolation was not silently applied");values.push_back({x,pdf->xfxQ(flavour,x,q)});}
        return {{"kind","PDFCurve"},{"set",name},{"member",member},{"flavour",flavour},{"QGeV",q},{"points",values},{"dataVersion",set.dataversion()},{"lhapdfVersion",LHAPDF::version()}};
    }
    throw std::invalid_argument("Unknown PDF operation");
#else
    (void)operation;(void)payload;throw std::runtime_error("LHAPDF unavailable in this runtime");
#endif
}
}
