"""Explicit PDF installation into a user-owned runtime-local directory."""
import hashlib,os,re,shutil,tarfile,tempfile,urllib.request
from pathlib import Path

def data_home():
    return Path(os.environ.get('HEP_PDF_HOME',str(Path.home()/'.local'/'share'/'HEPStudio'/'pdf')))

def install(payload,cancel,progress):
    if payload.get('approved') is not True:raise ValueError('PDF installation requires explicit user action')
    name=payload['set']
    if not isinstance(name,str) or not re.fullmatch(r'[A-Za-z0-9][A-Za-z0-9_.+-]{0,100}',name):raise ValueError('Invalid PDF set name')
    limit=int(payload.get('maxDownloadMiB',100))*1024*1024
    if not 0<limit<=2*1024*1024*1024:raise ValueError('Invalid approved download limit')
    root=data_home();root.mkdir(parents=True,exist_ok=True);destination=root/name
    if destination.exists():raise ValueError('PDF set is already installed; existing scientific inputs are not overwritten')
    with tempfile.TemporaryDirectory(prefix='.install-',dir=root) as temp:
        archive=Path(temp)/'download.tar.gz';total=0;digest=hashlib.sha256()
        url='https://lhapdfsets.web.cern.ch/current/'+name+'.tar.gz'
        with urllib.request.urlopen(url,timeout=30) as response,archive.open('wb') as output:
            length=int(response.headers.get('Content-Length',0))
            if length>limit:raise ValueError('Set exceeds the explicitly approved download size')
            if shutil.disk_usage(root).free<max(length,limit)*2:raise ValueError('Insufficient free space for PDF installation')
            while block:=response.read(256*1024):
                if cancel.is_set():raise InterruptedError('PDF installation cancelled')
                total+=len(block)
                if total>limit:raise ValueError('PDF download exceeded approved size')
                output.write(block);digest.update(block);progress({'stage':'Downloading PDF set','bytes':total,'totalBytes':length})
        with tarfile.open(archive) as tar:
            members=[]
            for member in tar:
                members.append(member)
                if len(members)>10000:raise ValueError('PDF archive entry limit exceeded')
            if len(members)>10000 or sum(m.size for m in members)>4*limit:raise ValueError('Expanded PDF archive exceeds approved storage budget')
            for member in members:
                parts=Path(member.name).parts
                if not parts or parts[0]!=name or '..' in parts or Path(member.name).is_absolute() or not (member.isfile() or member.isdir()):raise ValueError('Unsafe PDF archive entry')
            if shutil.disk_usage(root).free<sum(m.size for m in members)+1024*1024:raise ValueError('Insufficient PDF extraction space')
            for member in members:
                if cancel.is_set():raise InterruptedError('PDF installation cancelled')
                # Only validated ordinary files/directories. This works on Python 3.10+.
                target=Path(temp)/member.name
                if member.isdir():target.mkdir(parents=True,exist_ok=True)
                else:
                    target.parent.mkdir(parents=True,exist_ok=True)
                    with tar.extractfile(member) as src,target.open('wb') as dst:shutil.copyfileobj(src,dst,256*1024)
        if not (Path(temp)/name/(name+'.info')).is_file():raise ValueError('PDF metadata file is missing')
        os.rename(Path(temp)/name,destination)
    return {'installed':name,'path':str(destination),'downloadBytes':total,'archiveSha256':digest.hexdigest(),'source':url}
