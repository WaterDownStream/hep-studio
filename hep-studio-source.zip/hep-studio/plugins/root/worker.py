"""Versioned inherited-pipe protocol; bounded JSON metadata, file-backed results."""
import sys,os,json,struct,threading,time,traceback
from pathlib import Path
import backend
MAX_FRAME=1024*1024
# ROOT and Cling may write to C stdout. Keep protocol on a private duplicate.
if os.name=='nt':
    import msvcrt
    msvcrt.setmode(0,os.O_BINARY);msvcrt.setmode(1,os.O_BINARY)
wire=os.dup(1);os.dup2(2,1)
lock=threading.Lock();cancel=threading.Event();stop=threading.Event();job=None

def send(kind,**fields):
    data=json.dumps(dict(protocolVersion=1,kind=kind,**fields),allow_nan=False,separators=(',',':')).encode()
    if len(data)>MAX_FRAME:raise ValueError('Control frame too large')
    with lock:
        packet=struct.pack('!I',len(data))+data
        while packet:
            size=os.write(wire,packet)
            if size<=0:raise BrokenPipeError()
            packet=packet[size:]

def execute(request):
    global job
    rid=request['id'];start=time.perf_counter()
    try:
        def progress(stage):
            if isinstance(stage,dict):send('progress',id=rid,stage=stage.get('stage','Running'),metrics=stage)
            else:send('progress',id=rid,stage=stage)
        result=backend.dispatch(request,cancel,progress)
        if cancel.is_set():raise InterruptedError('Cancelled')
        result['operationSeconds']=time.perf_counter()-start
        try:
            import resource
            usage=resource.getrusage(resource.RUSAGE_SELF);rss=usage.ru_maxrss
            result['cpuSeconds']=usage.ru_utime+usage.ru_stime
            result['peakRssBytes']=rss if sys.platform=='darwin' else rss*1024
        except ImportError:result['peakRssBytes']=None
        text=json.dumps(result,allow_nan=False,separators=(',',':'))
        if len(text.encode())>16*1024*1024:raise ValueError('Result exceeds 16 MiB limit')
        chunks=0
        if request.get('resultTransport')=='chunks':
            for offset in range(0,len(text),65536):
                send('resultChunk',id=rid,sequence=chunks,data=text[offset:offset+65536]);chunks+=1
        else:
            path=Path(request['resultPath']);temp=path.with_suffix('.partial')
            temp.write_text(text);os.replace(temp,path)
        job=None
        send('completed',id=rid,chunks=chunks)
    except Exception as e:
        job=None
        send('failed',id=rid,message=str(e),cancelled=isinstance(e,InterruptedError))

def read_exact(size):
    data=b''
    while len(data)<size:
        more=sys.stdin.buffer.read(size-len(data))
        if not more:raise EOFError()
        data+=more
    return data

def heartbeat():
    while not stop.wait(.5):
        try:send('heartbeat')
        except OSError:os._exit(0)

def main():
    global job
    try:cap=backend.initialize()
    except Exception as e:cap={'available':False,'reason':str(e),'python':sys.executable}
    send('hello',capability=cap,chunkedResults=True)
    threading.Thread(target=heartbeat,daemon=True).start()
    try:
        while True:
            size=struct.unpack('!I',read_exact(4))[0]
            if not 0<size<=MAX_FRAME:raise ValueError('Frame length')
            request=json.loads(read_exact(size))
            if request.get('protocolVersion')!=1:raise ValueError('Protocol version')
            if request.get('kind')=='shutdown':break
            if request.get('kind')=='cancel':cancel.set();continue
            if request.get('kind')!='request' or not isinstance(request.get('id'),str):raise ValueError('Unexpected request')
            if job is not None:send('failed',id=request['id'],message='Worker busy',cancelled=False);continue
            if not cap['available']:send('failed',id=request['id'],message=cap.get('reason','Scientific runtime unavailable'),cancelled=False);continue
            cancel.clear();job=threading.Thread(target=execute,args=(request,),daemon=True);job.start()
    except (EOFError,BrokenPipeError):pass
    finally:
        stop.set();cancel.set()
        # Process exit is the isolation boundary if ROOT is still in a native call.
        if job is not None:os._exit(0)
if __name__=='__main__':
    try:main()
    except Exception:traceback.print_exc(file=sys.stderr);sys.exit(2)
