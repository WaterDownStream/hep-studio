"""ROOT adapter. No ROOT symbols are imported by the desktop process.
The only generated expressions come from the whitelist AST lowerer below.
"""
from __future__ import annotations
import array, hashlib, json, math, os, re, sys, time
from pathlib import Path

ROOT = None
UNITS = {'1': ((0,0,0,0),1.),'GeV':((1,0,0,0),1.),'MeV':((1,0,0,0),.001),
         'mm':((0,1,0,0),1.),'cm':((0,1,0,0),10.),'ns':((0,0,1,0),1.),
         'rad':((0,0,0,1),1.),'pb':((0,2,0,0),1e-34),'fb^-1':((0,-2,0,0),1e37)}
UNITS.update({'eV':((1,0,0,0),1e-9),'keV':((1,0,0,0),1e-6),'TeV':((1,0,0,0),1000.),'m':((0,1,0,0),1000.),'s':((0,0,1,0),1e9)})
ZERO=(0,0,0,0)

def initialize():
    global ROOT
    if ROOT is None:
        import ROOT as module
        ROOT=module
        ROOT.gROOT.SetBatch(True)
        ROOT.EnableThreadSafety()
        ROOT.DisableImplicitMT()  # One ResourceBroker-allocated thread in Part 2.
    return {'available':True,'version':str(ROOT.gROOT.GetVersion()),'location':str(ROOT.__file__),
            'python':sys.executable,'rntuple':hasattr(ROOT,'RNTupleReader'),'backend':'hep.root/1'}

def fingerprint(path):
    path=Path(path)
    if not path.is_file(): raise ValueError('Dataset unavailable: '+str(path))
    st=path.stat();h=hashlib.sha256()
    with path.open('rb') as f:
        if st.st_size <= 2*1024*1024:
            h.update(f.read()); strategy='sha256-full'
        else:
            h.update(f.read(1024*1024));f.seek(-1024*1024,2);h.update(f.read(1024*1024));strategy='sha256-first-last-1MiB'
    after=path.stat()
    if (st.st_size,st.st_mtime_ns)!=(after.st_size,after.st_mtime_ns):raise ValueError('Dataset changed while fingerprinting')
    return {'size':st.st_size,'mtimeNs':str(st.st_mtime_ns),'sha256':h.hexdigest(),'hashStrategy':strategy}

class FileCache:
    def __init__(self): self.path=None;self.file=None;self.stamp=None
    def open(self,path):
        stamp=fingerprint(path)
        if self.path!=path or self.stamp!=stamp:
            if self.file:self.file.Close()
            self.file=ROOT.TFile.Open(path,'READ')
            if not self.file or self.file.IsZombie():raise ValueError('Cannot open ROOT file')
            self.path=path;self.stamp=stamp
        return self.file,stamp
CACHE=FileCache()

def inspect(path):
    file,stamp=CACHE.open(path);items=[]
    def walk(directory,prefix='',depth=0):
        if depth>32:raise ValueError('ROOT directory depth exceeds limit')
        seen=set()
        for key in directory.GetListOfKeys():
            if key.GetName() in seen:continue
            seen.add(key.GetName());name=prefix+key.GetName();cls=key.GetClassName()
            info={'path':name,'name':key.GetName(),'class':cls,'depth':depth,'kind':'object'}
            if 'TDirectory' in cls:
                info['kind']='directory';items.append(info);walk(directory.Get(key.GetName()),name+'/',depth+1)
            else:
                if cls=='TTree' or 'TNtuple' in cls:info['kind']='dataset';info['format']='TTree'
                elif 'RNTuple' in cls:info['kind']='dataset';info['format']='RNTuple'
                elif cls.startswith(('TH1','TH2','TProfile')):info['kind']='histogram'
                items.append(info)
            if len(items)>10000:raise ValueError('Object browser limit: 10,000 keys')
    walk(file)
    return {'objects':items,'fingerprint':stamp,'path':path}

def schema(path,name):
    file,stamp=CACHE.open(path);obj=file.Get(name)
    if not obj:raise ValueError('Object not found: '+name)
    is_tree=hasattr(obj,'InheritsFrom') and obj.InheritsFrom('TTree')
    if is_tree:entries=int(obj.GetEntries());fmt='TTree'
    elif 'RNTuple' in type(obj).__name__:
        if not hasattr(ROOT,'RNTupleReader'):raise ValueError('Installed ROOT lacks RNTupleReader')
        entries=int(ROOT.RNTupleReader.Open(name,path).GetNEntries());fmt='RNTuple'
    else:raise ValueError('Select a TTree or RNTuple')
    df=ROOT.RDataFrame(name,path);units={};meta=file.Get('hep_units')
    if meta and meta.InheritsFrom('TObjString'):
        try:units=json.loads(str(meta.GetString()))
        except (ValueError,TypeError):pass
    columns=[]
    for raw in df.GetColumnNames():
        n=str(raw);t=str(df.GetColumnType(n));u=units.get(n,'1')
        if u not in UNITS:u='1'
        collection='vector<' in t or 'RVec<' in t or '[' in t
        primitives={'bool':'Bool','Bool_t':'Bool','char':'Int8','Char_t':'Int8','unsigned char':'UInt8','UChar_t':'UInt8',
                    'short':'Int16','Short_t':'Int16','unsigned short':'UInt16','UShort_t':'UInt16','int':'Int32','Int_t':'Int32',
                    'unsigned int':'UInt32','UInt_t':'UInt32','long':'Int64','long long':'Int64','Long64_t':'Int64',
                    'unsigned long':'UInt64','unsigned long long':'UInt64','ULong64_t':'UInt64','float':'Float32','Float_t':'Float32','double':'Float64','Double_t':'Float64',
                    'std::int32_t':'Int32','std::uint32_t':'UInt32','std::int64_t':'Int64','std::uint64_t':'UInt64'}
        inner=t[t.find('<')+1:t.rfind('>')].strip() if '<' in t else t
        numeric=inner in primitives
        columns.append({'name':n,'backendType':t,'unit':u,'unitKnown':n in units,'collection':collection,
                        'coreType':'NumericCollection' if collection and numeric else primitives.get(t,'Opaque'),
                        'path':n.split('.'),'previewSupported':numeric})
    return {'object':name,'format':fmt,'entries':entries,'columns':columns,'fingerprint':stamp,'metadata':{'title':str(obj.GetTitle()) if is_tree else name,'unitsSource':'hep_units' if units else 'unknown'}}

def sanitize(value,depth=0):
    if depth>3:return '[nested]'
    if isinstance(value,(str,bool,int)):return value
    try:
        if hasattr(value,'__len__') and not isinstance(value,str):return [sanitize(value[i],depth+1) for i in range(min(len(value),16))]
        v=float(value);return v if math.isfinite(v) else None
    except (ValueError,TypeError):return str(value)[:120]

def preview(path,name,offset=0,limit=50,columns=None,cancel=None):
    s=schema(path,name);offset=max(0,int(offset));limit=max(1,min(500,int(limit)))
    available={c['name']:c for c in s['columns']}
    columns=columns or [c['name'] for c in s['columns'] if c['previewSupported']][:12]
    if len(columns)>32 or any(c not in available or not available[c]['previewSupported'] for c in columns):raise ValueError('Select at most 32 supported numeric columns')
    stop=min(offset+limit,s['entries']);rows=[]
    if offset>=stop:return {'preview':True,'offset':offset,'entries':s['entries'],'represented':0,'columns':columns,'rows':[]}
    file,_=CACHE.open(path);obj=file.Get(name)
    if s['format']=='TTree':
        obj.SetBranchStatus('*',0)
        for c in columns:obj.SetBranchStatus(c,1)
        try:
            for i in range(offset,stop):
                if cancel and cancel.is_set():raise InterruptedError('Preview cancelled')
                obj.GetEntry(i);row=[]
                for c in columns:
                    leaf=obj.GetLeaf(c)
                    if leaf:
                        count=leaf.GetLen();integer=available[c]['coreType'].startswith(('Int','UInt'))
                        if integer and count==1:row.append(sanitize(getattr(obj,c)))
                        else:row.append(sanitize(leaf.GetValue()) if count==1 else [sanitize(leaf.GetValue(k)) for k in range(min(count,16))])
                    else:row.append(sanitize(getattr(obj,c)))
                rows.append(row)
        finally:obj.SetBranchStatus('*',1)
    else:
        with ROOT.RNTupleReader.Open(name,path) as reader:
            entry=reader.CreateEntry()
            for i in range(offset,stop):
                if cancel and cancel.is_set():raise InterruptedError('Preview cancelled')
                reader.LoadEntry(i,entry)
                rows.append([sanitize(entry[c]) for c in columns])
            del entry
    return {'preview':True,'offset':offset,'entries':s['entries'],'represented':len(rows),'columns':columns,'rows':rows,'collectionValuesCappedAt':16}

def expression(e,cols,depth=0):
    if depth>32 or not isinstance(e,dict):raise ValueError('Invalid expression nesting')
    op=e['op']
    if op=='property':
        parent=e['args'][0]
        if parent.get('op')!='column':raise ValueError('Property requires a named column record')
        return expression({'op':'column','name':parent['name']+'.'+e['name']},cols,depth+1)
    if op=='column':
        if e['name'] not in cols:raise ValueError('Unknown column: '+e['name'])
        return cols[e['name']]
    if op=='literal':
        d,scale=UNITS[e.get('unit','1')];v=float(e['value'])*scale
        if not math.isfinite(v):raise ValueError('Nonfinite literal')
        return (repr(v),d,False,False)
    args=e.get('args',[])
    if not 1<=len(args)<=32:raise ValueError('Invalid argument count')
    values=[expression(x,cols,depth+1) for x in args]
    if op in ('deltaPhi','deltaR','transverseMass'):
        if len(values)!=(2 if op=='deltaPhi' else 4) or any(v[2] or v[3] for v in values):raise ValueError('Physics observable requires scalar properties')
        angle=(0,0,0,1)
        if op=='deltaPhi':
            if any(v[1]!=angle for v in values):raise ValueError('deltaPhi requires angles in radians')
            return ('std::remainder(('+values[0][0]+')-('+values[1][0]+'),2*std::acos(-1.))',angle,False,False)
        expected=(1,0,0,0) if op=='transverseMass' else ZERO
        if [v[1] for v in values]!=[expected,angle,expected,angle]:raise ValueError('Physics observable dimension mismatch')
        a,phi,b,other=[v[0] for v in values];delta=f'std::remainder(({phi})-({other}),2*std::acos(-1.))'
        if op=='deltaR':return (f'std::hypot(({a})-({b}),{delta})',ZERO,False,False)
        return (f'std::sqrt(std::max(0.,2*({a})*({b})*(1-std::cos({delta}))))',expected,False,False)
    if op=='index':
        if len(values)!=2 or not values[0][3] or args[1].get('op')!='literal':raise ValueError('Index must be a constant nonnegative integer')
        index=float(args[1]['value'])
        if values[1][1]!=ZERO or not index.is_integer() or index<0 or index>100000:raise ValueError('Invalid collection index')
        return ('double(('+values[0][0]+').at('+str(int(index))+'))',values[0][1],False,False)
    if op in ('and','or','not'):
        if any(not v[2] or v[3] for v in values):raise ValueError('Boolean operands required')
        if op=='not':
            if len(values)!=1:raise ValueError('NOT requires one condition')
            return ('(!'+values[0][0]+')',ZERO,True,False)
        if len(values)<2:raise ValueError('Group requires two conditions')
        return ('('+(' && ' if op=='and' else ' || ').join(v[0] for v in values)+')',ZERO,True,False)
    if any(v[2] or v[3] for v in values):raise ValueError('Numeric scalar required; index collections explicitly')
    code,dim,_,_=values[0]
    if op in ('sqrt','abs','neg','square','sin','cos','exp','log'):
        if len(values)!=1:raise ValueError('Unary arity')
        if op=='sqrt':
            if any(p%2 for p in dim):raise ValueError('sqrt requires even dimension exponents')
            dim=tuple(p//2 for p in dim)
        if op=='square':return (f'(({code})*({code}))',tuple(p*2 for p in dim),False,False)
        if op=='neg':return (f'(-({code}))',dim,False,False)
        if op in ('sin','cos'):
            if dim not in (ZERO,(0,0,0,1)):raise ValueError('Trigonometric dimension mismatch')
            dim=ZERO
        if op in ('exp','log') and dim!=ZERO:raise ValueError('Dimensionless argument required')
        return (f'std::{op}({code})',dim,False,False)
    if len(values)!=2:raise ValueError('Binary arity')
    other,d2,_,_=values[1]
    operations={'add':'+','sub':'-','mul':'*','div':'/','gt':'>','ge':'>=','lt':'<','le':'<=','eq':'==','ne':'!='}
    if op not in operations and op not in ('min','max'):raise ValueError('Unknown expression operator')
    if op in ('mul','div'):dim=tuple(a+(1 if op=='mul' else -1)*b for a,b in zip(dim,d2))
    elif dim!=d2:raise ValueError('Incompatible physical dimensions; assign source units explicitly')
    if op in ('min','max'):return (f'std::{op}(double({code}),double({other}))',dim,False,False)
    boolean=op in ('gt','ge','lt','le','eq','ne')
    return (f'(({code}){operations[op]}({other}))',ZERO if boolean else dim,boolean,False)

def edges(config,key='edges'):
    if key in config:
        result=[float(x) for x in config[key]]
    else:
        bins=int(config.get('bins',50));lo=float(config.get('lower',0));hi=float(config.get('upper',10))
        if not 1<=bins<=4096 or not math.isfinite(lo+hi) or lo>=hi:raise ValueError('Invalid histogram binning')
        result=[lo+(hi-lo)*i/bins for i in range(bins+1)]
    if not 2<=len(result)<=4097 or any(not math.isfinite(x) for x in result) or any(a>=b for a,b in zip(result,result[1:])):raise ValueError('Edges must be finite and strictly increasing')
    return result

def histogram_data(h,config=None):
    config=config or {};bins=int(h.GetNbinsX());es=[float(h.GetXaxis().GetBinLowEdge(i)) for i in range(1,bins+2)]
    data={'kind':'Histogram1D','edges':es,'values':[float(h.GetBinContent(i)) for i in range(1,bins+1)],
          'errors':[float(h.GetBinError(i)) for i in range(1,bins+1)],'underflow':float(h.GetBinContent(0)),
          'overflow':float(h.GetBinContent(bins+1)),'entries':float(h.GetEntries()),'mean':float(h.GetMean()),'rms':float(h.GetRMS()),
          'normalization':config.get('normalization','counts'),'flowPolicy':config.get('flow','separate'),'title':str(h.GetTitle())}
    if data['flowPolicy'] not in ('separate','fold'):raise ValueError('Unknown underflow/overflow policy')
    if data['flowPolicy']=='fold':
        for index,rootbin in ((0,0),(-1,bins+1)):
            data['values'][index]+=float(h.GetBinContent(rootbin));data['errors'][index]=math.hypot(data['errors'][index],float(h.GetBinError(rootbin)))
    norm=data['normalization'];integral=sum(data['values'])
    if norm not in ('counts','unit-area','density'):raise ValueError('Unknown normalization')
    if norm!='counts':
        if integral<=0:raise ValueError('Unit-area/density normalization requires a positive in-range integral')
        for i in range(bins):
            factor=integral*(es[i+1]-es[i] if norm=='density' else 1)
            data['values'][i]/=factor;data['errors'][i]/=factor
    return data

def fit_histogram(h,config):
    model=config.get('model','gaussian');order=int(config.get('order',1))
    if model not in ('gaussian','exponential','polynomial') or not 0<=order<=5:raise ValueError('Unsupported fit model/order')
    formula={'gaussian':'gaus','exponential':'expo','polynomial':'pol'+str(order)}[model]
    lo=float(config.get('lower',h.GetXaxis().GetXmin()));hi=float(config.get('upper',h.GetXaxis().GetXmax()))
    if not math.isfinite(lo+hi) or lo>=hi:raise ValueError('Invalid fit range')
    f=ROOT.TF1('hep_fit_'+str(time.time_ns()),formula,lo,hi)
    initial=config.get('initial',[]);bounds=config.get('bounds',[])
    if not initial and model=='gaussian':initial=[h.GetMaximum(),h.GetMean(),max(h.GetRMS(),1e-6)]
    if initial and len(initial)!=f.GetNpar():raise ValueError('Initial parameter count does not match model')
    if bounds and len(bounds)!=f.GetNpar():raise ValueError('Bounds count does not match model')
    for i,x in enumerate(initial):
        if not math.isfinite(float(x)):raise ValueError('Nonfinite initial parameter')
        f.SetParameter(i,float(x))
    for i,b in enumerate(bounds):
        if b is None:continue
        if len(b)!=2 or not math.isfinite(float(b[0])+float(b[1])) or b[0]>=b[1]:raise ValueError('Invalid parameter bounds')
        f.SetParLimits(i,float(b[0]),float(b[1]))
    h.Fit.__release_gil__=True
    options='SQ0RN'+('B' if initial or bounds else '')+('F' if model=='polynomial' and bounds else '')
    result=h.Fit(f,options);status=int(result);valid=bool(result.Get()) and status==0 and bool(result.IsValid())
    covariance=[];covstatus=-1
    if result.Get():
        covstatus=int(result.CovMatrixStatus())
        covariance=[[float(result.CovMatrix(i,j)) for j in range(f.GetNpar())] for i in range(f.GetNpar())]
    def finite(v):
        value=float(v);return value if math.isfinite(value) else None
    valid=valid and all(math.isfinite(f.GetParameter(i)) and math.isfinite(f.GetParError(i)) for i in range(f.GetNpar()))
    poor=valid and f.GetNDF()>0 and f.GetProb()<.001
    return {'kind':'FitResult','options':options,'objective':'chi-square (bin centers)','poorGoodnessOfFit':poor,'model':model,'status':status,'converged':valid,'covarianceStatus':covstatus,
            'parameters':[{'name':str(f.GetParName(i)),'value':finite(f.GetParameter(i)),'error':finite(f.GetParError(i))} for i in range(f.GetNpar())],
            'covariance':[[finite(x) for x in row] for row in covariance],'chi2':finite(f.GetChisquare()),'ndf':int(f.GetNDF()),'probability':finite(f.GetProb()),
            'range':[lo,hi],'curve':[[lo+(hi-lo)*i/200,finite(f.Eval(lo+(hi-lo)*i/200))] for i in range(201)],
            'warning':('Poor goodness of fit (p < 0.001); convergence does not imply model adequacy' if poor else '') if valid and covstatus>=2 else 'Fit failed or covariance is unreliable; inspect status before use'}

def execute(plan,datasets,cancel,progress):
    nodes=plan['nodes']
    if len(nodes)>1000 or not nodes:raise ValueError('ROOT plan node limit')
    frames={};types={};actions={};configs={};histograms={};results={};code=['import ROOT','from array import array','ROOT.DisableImplicitMT()'];sources=[]
    def check():
        if cancel.is_set():raise InterruptedError('Analysis cancelled')
    for index,node in enumerate(nodes):
        check();nid=node['id'];kind=node['kind'];c=node['config'];configs[nid]=c;var='n'+str(index)
        if nid in frames or nid in actions:raise ValueError('Duplicate plan ID')
        if kind=='Source':
            if sources:raise ValueError('One source per workflow in Part 2')
            path=datasets[c['datasetId']]['location'];actual=schema(path,c['object']);expected=c.get('fingerprint')
            if expected and expected!=actual['fingerprint']:raise ValueError('Dataset changed since selection; refresh/relink explicitly before running')
            df=ROOT.RDataFrame(c['object'],path);root_df=df;cols={};code.append(f'{var} = ROOT.RDataFrame({c["object"]!r}, {path!r})')
            byname={x['name']:x for x in actual['columns']}
            for j,col in enumerate(c['schema']['columns']):
                name=col['name']
                if col.get('coreType')=='Opaque':continue
                if name not in byname or byname[name]['backendType']!=col['backendType']:raise ValueError('Dataset schema changed')
                alias='__hep_c'+str(j);df=df.Alias(alias,name);code.append(f'{var} = {var}.Alias({alias!r}, {name!r})')
                dim,scale=UNITS[col.get('unit','1')];numeric=alias if col.get('collection',False) or col['backendType'] in ('bool','Bool_t') else f'double({alias})';expr=numeric if scale==1 else f'({numeric}*{scale!r})'
                cols[name]=(expr,dim,col['backendType'] in ('bool','Bool_t'),col.get('collection',False))
            sources.append({'datasetId':c['datasetId'],'object':c['object'],'fingerprint':actual['fingerprint'],'locationAtRun':path})
            frames[nid]=df;types[nid]=cols;node['_var']=var
        elif kind in ('Define','Filter'):
            parent=node['input'];df=frames[parent];cols=types[parent].copy();text,dim,boolean,collection=expression(c['expression'],cols)
            if kind=='Define':
                name=c['name']
                if name in cols or not re.fullmatch('[A-Za-z_][A-Za-z0-9_]*',name) or name.startswith('__hep'):raise ValueError('Observable needs a new valid identifier')
                if boolean or collection:raise ValueError('Observable must be scalar numeric')
                alias='__hep_d'+str(index);df=df.Define(alias,text);cols[name]=(alias,dim,False,False)
                code.append(f'{var} = {next(x["_var"] for x in nodes if x["id"]==parent)}.Define({alias!r}, {text!r})  # {name}')
            else:
                if not boolean or collection:raise ValueError('Filter must be scalar Boolean')
                df=df.Filter(text,nid);code.append(f'{var} = {next(x["_var"] for x in nodes if x["id"]==parent)}.Filter({text!r})')
            frames[nid]=df;types[nid]=cols;node['_var']=var
        elif kind=='Fit':continue
        else:
            parent=node['input'];df=frames[parent];cols=types[parent];parentvar=next(x['_var'] for x in nodes if x['id']==parent)
            if kind=='Count':actions[nid]=df.Count();code.append(f'{var} = {parentvar}.Count()')
            else:
                text,dim,boolean,collection=expression(c['expression'],cols)
                if boolean or collection:raise ValueError('Numeric scalar observable required')
                column='__hep_a'+str(index);df=df.Define(column,text);code.append(f'{var}_df = {parentvar}.Define({column!r}, {text!r})')
                if kind in ('Mean','Sum','Min','Max'):
                    actions[nid]=getattr(df,kind)(column);code.append(f'{var} = {var}_df.{kind}({column!r})')
                elif kind in ('Histo1D','Histo2D'):
                    es=edges(c);model=ROOT.RDF.TH1DModel(nid,'',len(es)-1,array.array('d',es));weight=None
                    if c.get('weight'):
                        wt,wd,wb,wc=expression(c['weight'],cols)
                        if wd!=ZERO or wb or wc:raise ValueError('Weight must be dimensionless scalar')
                        weight='__hep_w'+str(index);df=df.Define(weight,wt);code.append(f'{var}_df = {var}_df.Define({weight!r}, {wt!r})')
                    if kind=='Histo1D':
                        actions[nid]=df.Histo1D(model,column,weight) if weight else df.Histo1D(model,column)
                        args=f'({nid!r}, "", {len(es)-1}, array("d", {es!r})), {column!r}'+(f', {weight!r}' if weight else '')
                        code.append(f'{var} = {var}_df.Histo1D({args})')
                    else:
                        yt,_,yb,yc=expression(c['yExpression'],cols)
                        if yb or yc:raise ValueError('Numeric y observable required')
                        yes=edges(c,'yEdges')
                        if (len(es)-1)*(len(yes)-1)>65536:raise ValueError('2D histogram is limited to 65,536 cells')
                        df=df.Define('__hep_y'+str(index),yt);model2=ROOT.RDF.TH2DModel(nid,'',len(es)-1,array.array('d',es),len(yes)-1,array.array('d',yes))
                        actions[nid]=df.Histo2D(model2,column,'__hep_y'+str(index),weight) if weight else df.Histo2D(model2,column,'__hep_y'+str(index))
                        code.append(f'{var}_df = {var}_df.Define({("__hep_y"+str(index))!r}, {yt!r})')
                        args=f'({nid!r}, "", {len(es)-1}, array("d", {es!r}), {len(yes)-1}, array("d", {yes!r})), {column!r}, {("__hep_y"+str(index))!r}'+(f', {weight!r}' if weight else '')
                        code.append(f'{var} = {var}_df.Histo2D({args})')
                else:raise ValueError('Unsupported action: '+kind)
            configs[nid]={'dimension':list(dim) if kind!='Count' else [0,0,0,0]};node['_var']=var
    if not actions:raise ValueError('Connect a histogram or aggregate action')
    check();progress('Running RDataFrame — completion estimate unavailable')
    started=time.perf_counter()
    # All actions have been booked before the first trigger. Shared graph: one event loop.
    for action in actions.values():
        action.GetValue.__release_gil__=True
        action.GetValue();check()
    elapsed=time.perf_counter()-started
    code+=['# Trigger only after all actions are booked.']+[f'{n["_var"]}.GetValue()' for n in nodes if n['id'] in actions]
    for node in nodes:
        nid=node['id'];kind=node['kind'];c=node['config']
        if kind=='Histo1D':
            h=actions[nid].GetValue();histograms[nid]=h;results[nid]=histogram_data(h,c);results[nid]['dimension']=configs[nid]['dimension']
        elif kind=='Histo2D':
            h=actions[nid].GetValue();results[nid]={'kind':'Histogram2D','xEdges':[float(h.GetXaxis().GetBinLowEdge(i)) for i in range(1,h.GetNbinsX()+2)],'yEdges':[float(h.GetYaxis().GetBinLowEdge(i)) for i in range(1,h.GetNbinsY()+2)],'values':[[float(h.GetBinContent(i,j)) for j in range(1,h.GetNbinsY()+1)] for i in range(1,h.GetNbinsX()+1)],'entries':float(h.GetEntries())}
        elif kind in ('Count','Mean','Sum','Min','Max'):results[nid]={'kind':'ScalarResult','operation':kind,'value':sanitize(actions[nid].GetValue()),'dimension':configs[nid]['dimension']}
        elif kind=='Fit':
            check();progress('Fitting histogram')
            if node['input'] not in histograms:raise ValueError('Fit requires a 1D histogram')
            # Fit the represented bin contents, including explicit normalization/flow policy.
            data=results[node['input']];h=histograms[node['input']].Clone('fit_input_'+nid);h.SetDirectory(0)
            for i,(v,e) in enumerate(zip(data['values'],data['errors']),1):h.SetBinContent(i,v);h.SetBinError(i,e)
            results[nid]=fit_histogram(h,c);results[nid]['histogramId']=node['input']
            parentvar=next(n['_var'] for n in nodes if n['id']==node['input']);fitvar='fit_'+str(len(code));formula={'gaussian':'gaus','exponential':'expo','polynomial':'pol'+str(c.get('order',1))}[c.get('model','gaussian')]
            lo=c.get('lower',data['edges'][0]);hi=c.get('upper',data['edges'][-1])
            code.append(f'{fitvar} = ROOT.TF1({fitvar!r}, {formula!r}, {lo!r}, {hi!r})')
            for i,v in enumerate(c.get('initial',[])):code.append(f'{fitvar}.SetParameter({i}, {v!r})')
            for i,b in enumerate(c.get('bounds',[])):
                if b is not None:code.append(f'{fitvar}.SetParLimits({i}, {b[0]!r}, {b[1]!r})')
            code.append(f'# Fit is approximate here: recorded normalization/flow settings may change represented bins.')
            options='SQ0RN'+('B' if c.get('initial') or c.get('bounds') else '')+('F' if c.get('model')=='polynomial' and c.get('bounds') else '')
            code.append(f'{fitvar}_result = {parentvar}.GetValue().Fit({fitvar}, {options!r})')
    check()
    for source in sources:
        if fingerprint(source['locationAtRun'])!=source['fingerprint']:raise ValueError('Dataset changed during analysis; results invalidated')
    return {'results':results,'sources':sources,'root':initialize(),'eventLoops':int(root_df.GetNRuns()),'eventLoopSeconds':elapsed,
            'sourceEntries':actual['entries'],'throughputEntriesPerSecond':actual['entries']/elapsed if elapsed else None,'generatedCode':'\n'.join(code)+'\n','mockOnly':False}

def dispatch(request,cancel,progress):
    op=request['operation'];payload=request.get('payload',{})
    if op=='inspect':return inspect(payload['path'])
    if op=='schema':return schema(payload['path'],payload['object'])
    if op=='preview':return preview(payload['path'],payload['object'],payload.get('offset',0),payload.get('limit',50),payload.get('columns'),cancel)
    if op=='histogram':
        f,_=CACHE.open(payload['path']);h=f.Get(payload['object'])
        if not h or not h.InheritsFrom('TH1') or h.GetDimension()!=1:raise ValueError('Native plot currently displays 1D stored histograms')
        return histogram_data(h)
    if op=='execute':return execute(payload['plan'],payload['datasets'],cancel,progress)
    raise ValueError('Unsupported ROOT request')
