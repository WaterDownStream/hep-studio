"""Real Delphes subprocess adapter; detector response stays distinct from truth."""
from __future__ import annotations
import os,re,shutil,sys
from pathlib import Path
try:from artifacts import run_process,digest
except ImportError:
    sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'research'))
    from artifacts import run_process,digest

def capability():
    root=Path(os.environ.get('HEP_DELPHES_PATH',''))
    installed=bool(os.environ.get('HEP_DELPHES_PATH')) and root.is_dir()
    available=installed and all((root/p).is_file() for p in ('DelphesHepMC3','DelphesLHEF','libDelphes.so')) and bool(list(root.glob('*_rdict.pcm')))
    version='unknown';sources=[]
    if available:
        version=os.environ.get('HEP_DELPHES_VERSION','unknown')
        sdk=root.parent/'research-sdk.json'
        if sdk.exists():
            import json
            data=json.loads(sdk.read_text())
            version=next((s['version'] for s in data.get('sources',[]) if s.get('name')=='delphes'),version)
            sources=[s for s in data.get('sources',[]) if s.get('name')=='delphes']
    return {'available':available,'status':'Available' if available else 'Incompatible' if installed else 'Needs installation','version':version if available else '',
            'location':str(root.resolve()) if available else '', 'reason':'' if available else 'Install a verified Delphes SDK including dictionaries',
            'readers':['HepMC3','LHEF'] if available else [],'entrypointSha256':digest(root/'DelphesHepMC3') if available else '',
            'librarySha256':digest(root/'libDelphes.so') if available else '',
            'dictionarySha256':{p.name:digest(p) for p in sorted(root.glob('*_rdict.pcm'))} if available else {},'sourceProvenance':sources}

def detector_card(config):
    cap=capability()
    if not cap['available']:raise ValueError(cap['reason'])
    selected=config.get('card',{'builtin':'CMS'})
    if selected.get('builtin')=='CMS':path=Path(cap['location'])/'cards/delphes_card_CMS.tcl'
    elif selected.get('builtin')=='ideal-muon':
        path=Path(__file__).with_name('ideal-muon.tcl')
        if not path.exists():path=Path(__file__).resolve().parents[2]/'tests/research/fixtures/ideal-muon.tcl'
    elif selected.get('path'):path=Path(selected['path'])
    else:raise ValueError('Select an installed detector card or an identified custom card resource')
    if not path.is_file():raise ValueError('Detector card unavailable; relink its resource')
    if selected.get('sha256') and digest(path)!=selected['sha256']:raise ValueError('Detector card changed since its recorded identity')
    # Tcl is executable configuration. Custom cards are explicit trusted resources;
    # relative includes are preserved in a private copy of their card directory.
    # Include card-directory Tcl inputs conservatively, preserving dynamic
    # relative source dependencies in the identified private card copy.
    inputs=sorted(path.parent.rglob('*.tcl'))
    if len(inputs)>256 or sum(p.stat().st_size for p in inputs)>16*1024*1024:raise ValueError('Detector card dependency directory exceeds 256 Tcl files / 16 MiB; use a dedicated card bundle')
    if any(not p.resolve().is_relative_to(path.parent.resolve()) for p in inputs):raise ValueError('Detector card dependency escapes its identified bundle')
    dependencies={str(p.relative_to(path.parent)):digest(p) for p in inputs if p.is_file()}
    if selected.get('dependencyChecksums') is not None and selected['dependencyChecksums']!=dependencies:raise ValueError('Detector card bundle changed since its scientific identity; explicitly select the changed bundle')
    return path,{'sha256':digest(path),'name':path.name,'builtin':selected.get('builtin'),'version':cap['version'],'cardDependencies':dependencies}

def reconstruct(config,input_path,directory,cancel=None,progress=None,format='HepMC3'):
    cap=capability();source,identity=detector_card(config);directory=Path(directory)
    if shutil.disk_usage(directory).free<64*1024*1024+2*Path(input_path).stat().st_size:raise ValueError('Insufficient disk space for estimated reconstructed output')
    seed=config.get('actualSeed',config.get('seed',24680))
    if type(seed)!=int or not 1<=seed<=2147483647:raise ValueError('Detector seed must be a fixed positive 31-bit integer')
    # Only identified Tcl dependencies are staged, never an arbitrary parent
    # directory containing datasets/projects. Non-Tcl resources require an
    # explicit future bundle contract rather than unrecorded implicit copies.
    cards=directory/'cards';cards.mkdir()
    for name,expected in identity['cardDependencies'].items():
        original=source.parent/name;target=cards/name;target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(original,target)
        if digest(target)!=expected:raise ValueError('Detector card dependency changed while being staged')
    effective=cards/source.name
    text=effective.read_text()
    # Explicit final binding wins and is retained in provenance. Response changes
    # remain structured variations; arbitrary Tcl edits require a new card identity.
    text+='\n# HEP Studio explicit detector stream seed\nset RandomSeed '+str(seed)+'\n'
    effective.write_text(text)
    env=os.environ.copy();root=Path(cap['location'])
    env['ROOT_INCLUDE_PATH']=os.pathsep.join([str(root),str(root/'external'),env.get('ROOT_INCLUDE_PATH','')])
    env['LD_LIBRARY_PATH']=os.pathsep.join([str(root),env.get('LD_LIBRARY_PATH','')])
    reader='DelphesHepMC3' if format=='HepMC3' else 'DelphesLHEF' if format=='LHEF' else None
    if reader is None:raise ValueError('Unsupported detector input format')
    output=directory/'reconstructed.root'
    run_process([str(root/reader),str(effective),str(output),str(input_path)],root,directory/'detector.log',cancel,progress,env=env)
    if not output.is_file() or not output.stat().st_size:raise ValueError('Delphes produced no reconstructed dataset')
    import ROOT
    file=ROOT.TFile.Open(str(output));tree=file.Get('Delphes') if file and not file.IsZombie() else None
    if not tree:raise ValueError('Delphes output is invalid or incomplete')
    entries=int(tree.GetEntries());branches=[str(b.GetName()) for b in tree.GetListOfBranches()];file.Close()
    return {'eventCount':entries,'format':'ROOT-TTree','object':'Delphes','collections':branches,'detectorCard':identity,
            'effectiveCardSha256':digest(effective),'actualSeed':seed,'version':cap['version'],
            'semanticType':'ReconstructedEventDataset','truthIsDistinct':True}
