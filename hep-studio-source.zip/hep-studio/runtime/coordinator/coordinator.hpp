#pragma once
#include "runtime/ipc/channel.hpp"
#include "runtime/resource_broker/broker.hpp"
#include "core/run_model/run.hpp"
#include <QLocalServer>
#include <QLocalSocket>
#include <QProcess>
#include <QTimer>
#include <QElapsedTimer>
namespace hep {
class Coordinator final : public QObject {
    Q_OBJECT
public:
    explicit Coordinator(QObject* parent=nullptr);
    ~Coordinator() override;
    void launch(const QString& workerPath);
    bool submit(const Workflow&,const std::string& seed="0",int steps=100,int intervalMs=30);
    void cancel();
    void shutdown();
    QString transport()const{return pipeTransport_?"pipes":"socket";}
    void killWorker(); // Explicit diagnostic, not a workflow parameter.
    QString workerState() const { return workerState_; }
    QString jobState() const { return jobState_; }
    QString error() const { return error_; }
    int done() const { return done_; }
    int total() const { return total_; }
    bool busy() const { return active_.has_value(); }
    const std::optional<Run>& activeRun() const { return active_; }
    const std::optional<Run>& lastRun() const { return last_; }
    ResourceBroker& broker() {return broker_;}
    const ResourceBroker& broker() const { return broker_; }
    const Json& logs() const { return logs_; }
signals:
    void changed();
    void finalized();
private:
    void receive(const ipc::Message&);
    void finish(std::string status,Json result);
    void fail(const QString& reason);
    void log(std::string severity,std::string subsystem,std::string message);
    QLocalServer server_;
    QProcess process_;
    QPointer<QLocalSocket> socket_;
    QPointer<ipc::Channel> channel_;
    QTimer startup_,watchdog_,cancelDeadline_,killDeadline_;
    QElapsedTimer lastHeartbeat_;
    QString workerState_{"Stopped"},jobState_{"Idle"},error_;
    std::string token_;
    ResourceBroker broker_;
    std::optional<ResourceLease> lease_;
    std::optional<Run> active_,last_;
    Json logs_=Json::array();
    bool pipeTransport_{false};
    bool authenticated_{false},stopping_{false},cancelRequested_{false};
    int done_{0},total_{0};
};
}
