#include "runtime/coordinator/coordinator.hpp"
#include "runtime/project_store.hpp"
#include "core/compiler/compiler.hpp"
#include "core/editing/editing.hpp"
#include <QProcessEnvironment>
#include <QDir>
#include <algorithm>
namespace hep {
Coordinator::Coordinator(QObject* parent) : QObject(parent) {
    startup_.setSingleShot(true); cancelDeadline_.setSingleShot(true); killDeadline_.setSingleShot(true);
    connect(&startup_,&QTimer::timeout,this,[this]{fail("Worker handshake timed out");});
    connect(&watchdog_,&QTimer::timeout,this,[this]{ if(authenticated_ && lastHeartbeat_.elapsed()>5000) fail("Worker heartbeat timed out"); });
    connect(&cancelDeadline_,&QTimer::timeout,this,[this]{
        if(!active_) return;
        log("Warning","coordinator","Cancellation acknowledgement timed out; terminating worker.");
        process_.terminate(); killDeadline_.start(500);
    });
    connect(&killDeadline_,&QTimer::timeout,this,[this]{if(process_.state()!=QProcess::NotRunning) process_.kill();});
    connect(&server_,&QLocalServer::newConnection,this,[this]{
        auto* incoming=server_.nextPendingConnection();
        if(!incoming) return;
        if(socket_) { incoming->abort(); incoming->deleteLater(); return; }
        socket_=incoming; incoming->setReadBufferSize(static_cast<qint64>(ipc::maxFrame+4));
        channel_=new ipc::Channel(incoming,incoming);
        connect(channel_,&ipc::Channel::received,this,&Coordinator::receive);
        connect(channel_,&ipc::Channel::protocolError,this,&Coordinator::fail);
        connect(incoming,&QLocalSocket::disconnected,this,[this]{
            if(!stopping_ && process_.state()!=QProcess::NotRunning) fail("Worker control connection was lost");
        });
    });
    connect(&process_,&QProcess::errorOccurred,this,[this](QProcess::ProcessError e){
        if(e==QProcess::FailedToStart) { fail("Cannot launch worker: "+process_.errorString()); workerState_="Unavailable"; emit changed(); }
    });
    connect(&process_,&QProcess::readyReadStandardError,this,[this]{
        const auto bytes=process_.readAllStandardError();
        if(!bytes.isEmpty()) log("Warning","worker-stderr",QString::fromUtf8(bytes.left(16384)).toStdString());
    });
    connect(&process_,&QProcess::readyReadStandardOutput,this,[this]{ if(!pipeTransport_)(void)process_.readAllStandardOutput(); });
    connect(&process_,qOverload<int,QProcess::ExitStatus>(&QProcess::finished),this,[this](int code,QProcess::ExitStatus){
        startup_.stop(); watchdog_.stop(); cancelDeadline_.stop(); killDeadline_.stop(); authenticated_=false;
        workerState_=stopping_?"Stopped":"Crashed";
        if(active_) finish(cancelRequested_?"Cancelled":"Interrupted",{{"mockOnly",true},{"valid",false},{"partial",true},{"exitCode",code},{"lastCompletedStep",done_}});
        if(!stopping_) log("Error","worker","Worker exited. Coordinator survived; restart worker to retry.");
        emit changed();
    });
}
Coordinator::~Coordinator() {
    stopping_=true; startup_.stop();watchdog_.stop();cancelDeadline_.stop();killDeadline_.stop();
    if(process_.state()!=QProcess::NotRunning) { process_.terminate(); if(!process_.waitForFinished(500)){process_.kill();process_.waitForFinished(500);} }
    if(socket_) { disconnect(socket_,nullptr,this,nullptr); socket_->abort(); }
    server_.close();
}
void Coordinator::launch(const QString& path) {
    if(process_.state()!=QProcess::NotRunning || active_) return;
    if(socket_) { disconnect(socket_,nullptr,this,nullptr); socket_->abort(); socket_->deleteLater(); socket_=nullptr; channel_=nullptr; }
    if(channel_){channel_->deleteLater();channel_=nullptr;}
    server_.close(); authenticated_=false; stopping_=false; error_.clear();
    token_=newId().value;
    const auto endpoint="hep-studio-"+QString::fromStdString(newId().value);
    server_.setSocketOptions(QLocalServer::UserAccessOption);
    const auto preference=qEnvironmentVariable("HEP_TRANSPORT");
    pipeTransport_=preference=="pipes" || !server_.listen(endpoint);
    if(pipeTransport_ && preference=="socket"){fail("Required native socket transport is unavailable: "+server_.errorString());return;}
    if(pipeTransport_) {
        log("Info","coordinator","Local sockets unavailable; using inherited anonymous pipes.");
        channel_=new ipc::Channel(&process_,this);
        connect(channel_,&ipc::Channel::received,this,&Coordinator::receive);
        connect(channel_,&ipc::Channel::protocolError,this,&Coordinator::fail);
    }
    auto environment=QProcessEnvironment::systemEnvironment();
    environment.insert("HEP_WORKER_TOKEN",QString::fromStdString(token_));
    for(const auto* name : {"OMP_NUM_THREADS","OPENBLAS_NUM_THREADS","MKL_NUM_THREADS","NUMEXPR_NUM_THREADS"}) environment.insert(name,"1");
    process_.setProcessEnvironment(environment);
    process_.setProgram(path); process_.setArguments(pipeTransport_?QStringList{"--stdio"}:QStringList{"--endpoint",server_.fullServerName()});
    workerState_="Initializing"; process_.start(); startup_.start(5000); emit changed();
}
bool Coordinator::submit(const Workflow& workflow,const std::string& seed,int steps,int intervalMs) {
    if(!authenticated_ || !channel_ || active_) { error_="Worker must be healthy and idle."; emit changed(); return false; }
    try {
        const auto plan=MockLowerer{}.lower(workflow);
        const auto encoded=ipc::encode(ipc::StartJob{"probe",plan.snapshot,steps,intervalMs,1,seed});
        (void)ipc::decode(encoded);
        if(encoded.dump().size()>ipc::maxFrame) throw std::invalid_argument("Workflow exceeds Phase 0 control frame limit");
        lease_=broker_.acquire({1,64*1024*1024});
        if(!lease_) throw std::runtime_error("Insufficient resource budget");
        active_=Run{newId(),"Running",plan.snapshot,workflowHash(scientificJson(workflow)).toStdString()};
        active_->seed=seed; active_->started=ipc::utcNow(); active_->resources=hardwareJson(broker_.hardware());
        active_->resources.update({{"allocatedThreads",lease_->allocation.threads},{"reservedMemoryBytes",lease_->allocation.memoryBytes},{"hepStudioVersion","0.1.0"},{"protocolVersion",ipc::protocolVersion},{"qtVersion",qVersion()}});
        active_->extensions["executionPlan"]={{"backend",plan.backend},{"nodes",Json::array()}};
        for(const auto& id : plan.orderedNodes) active_->extensions["executionPlan"]["nodes"].push_back(id.value);
        done_=0;total_=steps;cancelRequested_=false;error_.clear();jobState_="Running";workerState_="Busy";
        if(!channel_->send(ipc::StartJob{active_->id.value,plan.snapshot,steps,intervalMs,1,seed})) {
            finish("Failed",{{"mockOnly",true},{"valid",false},{"error","Could not send job"}}); return false;
        }
        log("Info","coordinator","Submitted validated mock execution plan. No physics is performed.");
        emit changed(); return true;
    } catch(const std::exception& e) {
        if(lease_&&!active_) {broker_.release(lease_->id);lease_.reset();}
        error_=QString::fromUtf8(e.what());emit changed();return false;
    }
}
void Coordinator::cancel() {
    if(!active_ || cancelRequested_) return;
    cancelRequested_=true;
    if(channel_) channel_->send(ipc::CancelJob{active_->id.value});
    log("Info","coordinator","Cancellation requested."); cancelDeadline_.start(1000); emit changed();
}
void Coordinator::shutdown(){
    stopping_=true;startup_.stop();watchdog_.stop();
    if(active_)finish("Interrupted",{{"valid",false},{"partial",true},{"reason","Coordinator shutdown"}});
    if(pipeTransport_)process_.closeWriteChannel();else if(socket_)socket_->disconnectFromServer();
    killDeadline_.start(1000);
}
void Coordinator::killWorker() { if(process_.state()!=QProcess::NotRunning) process_.kill(); }
void Coordinator::receive(const ipc::Message& message) {
    if(!authenticated_) {
        const auto* hello=std::get_if<ipc::Hello>(&message);
        if(!hello || hello->token!=token_ || hello->version!="0.1.0" || std::find(hello->capabilities.begin(),hello->capabilities.end(),"hep.mock/1")==hello->capabilities.end()) {fail("Worker authentication or capabilities mismatch");return;}
        authenticated_=true; startup_.stop();lastHeartbeat_.start();watchdog_.start(1000);workerState_="Healthy";
        log("Info","coordinator","Worker handshake complete: hep.mock/1."); emit changed();return;
    }
    if(std::holds_alternative<ipc::Heartbeat>(message)) {lastHeartbeat_.restart();return;}
    if(const auto* m=std::get_if<ipc::Log>(&message)) {
        logs_.push_back(ipc::encode(*m));if(logs_.size()>1000)logs_.erase(logs_.begin());
        if(active_ && m->jobId==active_->id.value && active_->logs.size()<1000) active_->logs.push_back(ipc::encode(*m));
        emit changed();return;
    }
    if(const auto* m=std::get_if<ipc::Progress>(&message)) {
        if(active_&&m->jobId==active_->id.value) {
            if(m->total!=total_ || m->done<done_) {fail("Worker reported inconsistent progress");return;}
            done_=m->done; emit changed();
        } return;
    }
    if(const auto* m=std::get_if<ipc::JobCompleted>(&message)) {
        if(active_&&m->jobId==active_->id.value) finish("Completed",m->result);
        return;
    }
    if(const auto* m=std::get_if<ipc::JobFailed>(&message)) {
        if(active_&&m->jobId==active_->id.value) {
            error_=QString::fromStdString(m->message);
            finish(m->cancelled?"Cancelled":"Failed",{{"mockOnly",true},{"valid",false},{"partial",true},{"code",m->code},{"message",m->message},{"lastCompletedStep",done_}});
        } return;
    }
    fail("Unexpected worker message for coordinator");
}
void Coordinator::finish(std::string status,Json result) {
    if(!active_)return;
    cancelDeadline_.stop();killDeadline_.stop();
    active_->status=status;active_->ended=ipc::utcNow();active_->result=std::move(result);
    last_=std::move(active_);active_.reset();
    if(lease_) {broker_.release(lease_->id);lease_.reset();}
    jobState_=QString::fromStdString(status);
    if(authenticated_)workerState_="Healthy";
    emit finalized();emit changed();
}
void Coordinator::log(std::string severity,std::string subsystem,std::string message) {
    const auto row=ipc::encode(ipc::Log{ipc::utcNow(),std::move(severity),std::move(subsystem),active_?active_->id.value:"","",std::move(message)});
    logs_.push_back(row);if(logs_.size()>1000)logs_.erase(logs_.begin());
    if(active_&&active_->logs.size()<1000)active_->logs.push_back(row);
    emit changed();
}
void Coordinator::fail(const QString& reason) {
    if(stopping_)return;
    error_=reason;authenticated_=false;startup_.stop();watchdog_.stop();workerState_="Crashed";
    log("Error","coordinator",reason.toStdString());
    if(active_)finish("Interrupted",{{"mockOnly",true},{"valid",false},{"partial",true},{"error",reason.toStdString()},{"lastCompletedStep",done_}});
    if(process_.state()!=QProcess::NotRunning)process_.kill();
    emit changed();
}
}
