#!/usr/bin/env python3
"""Explicit offline runtime bundle installation. User data is outside this tree."""
import argparse,hashlib,json,os,re,shutil,tarfile,tempfile,uuid
from pathlib import Path
FORMAT='HEPStudioRuntime-bundle-v1'
def digest(path):
    h=hashlib.sha256()
    with path.open('rb') as stream:
        while block:=stream.read(1024*1024):h.update(block)
    return h.hexdigest()
def create(root,environment):
    files={}
    for path in sorted(root.rglob('*')):
        if path.is_file() and path.name!='runtime-manifest.json':
            if not path.resolve().is_relative_to(root.resolve()):raise ValueError('Runtime file escapes bundle')
            files[path.relative_to(root).as_posix()]={'sha256':digest(path),'sizeBytes':path.stat().st_size}
    version='hep-runtime-'+hashlib.sha256(json.dumps(files,sort_keys=True).encode()).hexdigest()[:24]
    manifest={'format':FORMAT,'runtimeVersion':version,'protocolVersion':1,'environment':environment,'files':files}
    (root/'runtime-manifest.json').write_text(json.dumps(manifest,sort_keys=True,indent=2)+'\n');return manifest

def verify(root):
    manifest=json.loads((root/'runtime-manifest.json').read_text())
    if manifest.get('format')!=FORMAT or manifest.get('protocolVersion')!=1:raise ValueError('Incompatible runtime manifest/protocol')
    if not re.fullmatch(r'hep-runtime-[a-f0-9]{24}',manifest['runtimeVersion']):raise ValueError('Invalid runtime version')
    for name,identity in manifest['files'].items():
        relative=Path(name);path=root/relative
        if relative.is_absolute() or '..' in relative.parts or not path.resolve().is_relative_to(root.resolve()):raise ValueError('Unsafe runtime path')
        if not path.is_file() or path.stat().st_size!=identity['sizeBytes'] or digest(path)!=identity['sha256']:raise ValueError('Runtime file missing/corrupt: '+name)
    expected='hep-runtime-'+hashlib.sha256(json.dumps(manifest['files'],sort_keys=True).encode()).hexdigest()[:24]
    if expected!=manifest['runtimeVersion']:raise ValueError('Runtime version identity mismatch')
    return manifest

def install(root,bundle):
    releases=root/'releases';releases.mkdir(parents=True,exist_ok=True)
    current=root/'current'
    if current.exists() and not current.is_symlink():raise ValueError('Refusing to overwrite an unversioned runtime')
    previous=os.readlink(current) if current.is_symlink() else None
    with tempfile.TemporaryDirectory(prefix='.install-',dir=releases) as directory:
        stage=Path(directory);total=0;seen=set()
        with tarfile.open(bundle) as archive:
            for member in archive:
                path=Path(member.name)
                if path.is_absolute() or '..' in path.parts or member.name in seen:raise ValueError('Unsafe/duplicate runtime archive entry')
                seen.add(member.name)
                if member.isdir():continue
                if not member.isfile():raise ValueError('Runtime bundles require regular files; links are not accepted')
                total+=member.size
                if total>8*1024**3 or member.size<0:raise ValueError('Runtime bundle exceeds 8 GiB limit')
                if shutil.disk_usage(releases).free<member.size+64*1024**2:raise ValueError('Insufficient runtime installation space')
                destination=stage/path;destination.parent.mkdir(parents=True,exist_ok=True)
                with archive.extractfile(member) as source,destination.open('wb') as output:shutil.copyfileobj(source,output,1024*1024)
                destination.chmod(member.mode&0o755)
        manifest=verify(stage)
        actual={p.relative_to(stage).as_posix() for p in stage.rglob('*') if p.is_file()}
        if actual!=set(manifest['files'])|{'runtime-manifest.json'}:raise ValueError('Unlisted files in runtime bundle')
        release=releases/(manifest['runtimeVersion']+'-'+uuid.uuid4().hex[:8]);os.rename(stage,release)
        temporary=root/('.current-'+uuid.uuid4().hex)
        temporary.symlink_to(release.relative_to(root),target_is_directory=True)
        try:os.replace(temporary,current)
        finally:temporary.unlink(missing_ok=True)
    return {'runtimeVersion':manifest['runtimeVersion'],'previousRelease':previous,'activeRelease':os.readlink(current),'userDataModified':False}

def main():
    p=argparse.ArgumentParser();p.add_argument('--root',type=Path,default=Path('/opt/hep'));p.add_argument('--install',type=Path);p.add_argument('--create',type=Path);a=p.parse_args()
    if a.install:result=install(a.root,a.install)
    elif a.create:result=create(a.root,json.loads(a.create.read_text()))
    else:result=verify((a.root/'current').resolve() if (a.root/'current').exists() else a.root)
    print(json.dumps(result))
if __name__=='__main__':main()
