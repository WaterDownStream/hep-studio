#!/usr/bin/env python3
"""Image-build-only transition to immutable releases; never applied to user data."""
import json,shutil,sys
from pathlib import Path
import admin
root=Path(sys.argv[1]).resolve()
if (root/'releases').exists():raise RuntimeError('Runtime already has versioned layout')
environment=json.loads((root/'environment-build.json').read_text())['environment']
manifest=admin.create(root,environment)
entries=list(root.iterdir());release=root/'releases'/manifest['runtimeVersion'];release.mkdir(parents=True)
for entry in entries:
    if entry.name=='admin.py':shutil.copy2(entry,release/entry.name)
    else:entry.rename(release/entry.name)
(root/'current').symlink_to(release.relative_to(root),target_is_directory=True)
for entry in entries:
    if entry.name!='admin.py':entry.symlink_to(Path('current')/entry.name,target_is_directory=(release/entry.name).is_dir())
admin.verify(release)
