#pragma once
#include "core/vpir/model.hpp"
#include <QObject>
#include <QProcess>
#include <QTimer>
namespace hep {
class ManagedRuntime final:public QObject {
    Q_OBJECT
public:
    explicit ManagedRuntime(QObject* parent=nullptr);
    ~ManagedRuntime()override;
    void detect();
    void requestWslSetup();
    void importImage(const QString& archive,const QString& installationFolder);
    void installBundle(const QString& archive);
    const Json& status()const{return status_;}
    bool ready()const{return status_.value("state","")=="Healthy";}
    QString executable()const;
    QStringList workerArguments()const;
    QStringList researchWorkerArguments()const;
    static Json parseDistributionList(const QString&);
    static Json resourceLocation(const QString& path,const std::string& runtime);
signals:
    void changed();
private:
    void launch(QStringList arguments,const std::string& phase,int timeout);
    void completed(int,QProcess::ExitStatus);
    QProcess process_;QTimer timeout_;QByteArray output_,errors_;std::string phase_;
    Json status_={{"state","Unknown"},{"name","HEPStudioRuntime"},{"verifiedPlatform",false}};
};
}
