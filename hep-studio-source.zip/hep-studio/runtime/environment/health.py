#!/usr/bin/env python3
"""Managed runtime contract. Scientific diagnostics never contaminate JSON stdout."""
import json,os,sys
import admin
from pathlib import Path

def main():
    output=os.dup(sys.stdout.fileno());os.dup2(sys.stderr.fileno(),sys.stdout.fileno())
    try:
        sys.path.insert(0,str(Path(__file__).parent/'worker'))
        import backend
        capability=backend.initialize()
        root=Path(__file__).resolve().parent
        manifest={} if '--build-manifest' in sys.argv else admin.verify(root)
        result={'runtimeVersion':manifest.get('runtimeVersion'),'manifestVerified':bool(manifest),'protocolVersion':1,'healthy':capability.get('available',False),
                'environment':capability.get('environment',{}),'capability':capability,
                'runtimeFormatVersion':1}
        if (root/'research_worker/backend.py').is_file():
            # Distinct module identities prevent reusing collider globals for a
            # research capability check in the same health subprocess.
            import importlib.util
            sys.path.insert(0,str(root/'research_worker'))
            spec=importlib.util.spec_from_file_location('hep_runtime_research',root/'research_worker/backend.py');research=importlib.util.module_from_spec(spec);spec.loader.exec_module(research)
            result['researchCapability']=research.initialize();result['researchAvailable']=result['researchCapability'].get('available',False)
        else:result['researchAvailable']=False
    except Exception as error:result={'protocolVersion':1,'healthy':False,'reason':str(error)}
    with os.fdopen(output,'w') as stream:stream.write(json.dumps(result,allow_nan=False)+'\n')
    return 0 if result['healthy'] else 1

if __name__=='__main__':sys.exit(main())
