#include "runtime/environment/managed_runtime.hpp"
#include <QStandardPaths>
#include <QRegularExpression>
#include <QFileInfo>
#include <QFile>
#include <QDir>
#include <QStringConverter>
#ifdef Q_OS_WIN
#ifndef NOMINMAX
#define NOMINMAX
#endif
#include <windows.h>
#include <shellapi.h>
#endif
namespace hep {
Json ManagedRuntime::resourceLocation(const QString& path,const std::string& runtime){
    auto physical=QDir::fromNativeSeparators(path);std::string kind="local";
#ifdef Q_OS_WIN
    if(runtime.starts_with("wsl:")){
        const auto drive=QRegularExpression("^([A-Za-z]):/(.*)$").match(physical);
        if(drive.hasMatch()){physical="/mnt/"+drive.captured(1).toLower()+"/"+drive.captured(2);kind="mounted-windows";}
        else {const QString prefix="//wsl.localhost/HEPStudioRuntime/",legacy="//wsl$/HEPStudioRuntime/";
            if(physical.startsWith(prefix,Qt::CaseInsensitive))physical="/"+physical.mid(prefix.size());
            else if(physical.startsWith(legacy,Qt::CaseInsensitive))physical="/"+physical.mid(legacy.size());
            else throw std::invalid_argument("This path is not accessible in the managed runtime. Choose a local drive or the HEPStudioRuntime filesystem.");}
    }
#endif
    return {{"runtimeId",runtime},{"kind",kind},{"path",physical.toStdString()}};
}

ManagedRuntime::ManagedRuntime(QObject* parent):QObject(parent){
    timeout_.setSingleShot(true);
    connect(&timeout_,&QTimer::timeout,this,[this]{status_["state"]="Unavailable";status_["message"]="Managed runtime operation timed out";process_.kill();emit changed();});
    connect(&process_,&QProcess::readyReadStandardOutput,this,[this]{output_+=process_.readAllStandardOutput();if(output_.size()>1024*1024)process_.kill();});
    connect(&process_,&QProcess::readyReadStandardError,this,[this]{errors_+=process_.readAllStandardError();if(errors_.size()>65536)errors_=errors_.right(65536);});
    connect(&process_,qOverload<int,QProcess::ExitStatus>(&QProcess::finished),this,&ManagedRuntime::completed);
    connect(&process_,&QProcess::errorOccurred,this,[this](QProcess::ProcessError e){if(e==QProcess::FailedToStart){timeout_.stop();status_["state"]="Needs installation";status_["message"]=process_.errorString().toStdString();emit changed();}});
}
ManagedRuntime::~ManagedRuntime(){disconnect(&process_,nullptr,this,nullptr);if(process_.state()!=QProcess::NotRunning){process_.kill();process_.waitForFinished(500);}}
QString ManagedRuntime::executable()const{
    const auto override=qEnvironmentVariable("HEP_WSL_EXECUTABLE");return override.isEmpty()?QStandardPaths::findExecutable("wsl.exe"):override;
}
void ManagedRuntime::requestWslSetup(){
#ifdef Q_OS_WIN
    const auto program=executable();
    if(program.isEmpty()){status_["state"]="Needs installation";status_["message"]="Windows could not locate WSL. Install the Windows Subsystem for Linux feature through Windows Settings.";emit changed();return;}
    // Invoked only by the explicit setup button. Windows owns elevation consent.
    const auto result=ShellExecuteW(nullptr,L"runas",program.toStdWString().c_str(),L"--install --no-distribution",nullptr,SW_SHOWNORMAL);
    if(reinterpret_cast<INT_PTR>(result)<=32)status_["message"]="Windows did not start WSL setup, or administrator approval was declined.";
    else status_["message"]="Windows setup opened. Complete its administrator prompt and restart Windows if requested, then Verify Runtime.";
#else
    status_["message"]="WSL setup is only available on Windows.";
#endif
    emit changed();
}
QStringList ManagedRuntime::workerArguments()const{return {"--distribution","HEPStudioRuntime","--exec","/usr/bin/env","HEP_RUNTIME_ID=wsl:HEPStudioRuntime","/opt/hep/bin/python","/opt/hep/worker/worker.py"};}
QStringList ManagedRuntime::researchWorkerArguments()const{return {"--distribution","HEPStudioRuntime","--exec","/usr/bin/env","HEP_RUNTIME_ID=wsl:HEPStudioRuntime","/opt/hep/bin/python","/opt/hep/research_worker/worker.py"};}
Json ManagedRuntime::parseDistributionList(const QString& listing){
    QRegularExpression pattern("^\\s*\\*?\\s*HEPStudioRuntime\\s+\\S+\\s+(\\d+)\\s*$",QRegularExpression::MultilineOption);const auto match=pattern.match(listing);
    if(!match.hasMatch())return {{"state","Needs installation"},{"message","Collider Runtime Required: install the HEP Studio Linux runtime"},{"present",false}};
    const int version=match.captured(1).toInt();return {{"state",version==2?"Checking health":"Incompatible"},{"present",true},{"wslGeneration",version},{"message",version==2?"":"HEP Studio requires WSL2; this distribution uses WSL1"}};
}
void ManagedRuntime::launch(QStringList arguments,const std::string& phase,int timeout){
    if(process_.state()!=QProcess::NotRunning)return;
    output_.clear();errors_.clear();phase_=phase;process_.setProgram(executable());process_.setArguments(arguments);process_.start();timeout_.start(timeout);emit changed();
}
void ManagedRuntime::detect(){
    if(process_.state()!=QProcess::NotRunning)return;
#ifndef Q_OS_WIN
    if(qEnvironmentVariableIsEmpty("HEP_WSL_EXECUTABLE")){status_["state"]="Not applicable";status_["message"]="Linux/macOS use native scientific runtimes";emit changed();return;}
#endif
    if(executable().isEmpty()){status_["state"]="Needs installation";status_["message"]="WSL2 is not installed. Enable WSL; Windows may require administrator approval and a reboot.";emit changed();return;}
    status_["state"]="Detecting";launch({"--list","--verbose"},"list",15000);
}
void ManagedRuntime::completed(int code,QProcess::ExitStatus exitStatus){
    timeout_.stop();output_+=process_.readAllStandardOutput();errors_+=process_.readAllStandardError();
    QString output;
    if(output_.startsWith("\xff\xfe")||(output_.size()>1&&output_[1]=='\0')){QStringDecoder decoder(QStringDecoder::Utf16LE);output=decoder(output_);}else output=QString::fromUtf8(output_);
    if(code!=0||exitStatus!=QProcess::NormalExit){status_["state"]="Unavailable";status_["message"]=QString::fromUtf8(errors_).toStdString();status_["details"]=output.toStdString();emit changed();return;}
    if(phase_=="list"){
        const auto previousVersion=status_.value("runtimeVersion",std::string{});status_=parseDistributionList(output);status_["runtimeVersion"]=previousVersion;status_["name"]="HEPStudioRuntime";status_["verifiedPlatform"]=false;emit changed();
        if(status_.value("wslGeneration",0)==2)QTimer::singleShot(0,this,[this]{launch({"--distribution","HEPStudioRuntime","--exec","/usr/bin/env","HEP_RUNTIME_ID=wsl:HEPStudioRuntime","/opt/hep/bin/python","/opt/hep/health.py"},"health",120000);});
    }else if(phase_=="health"){
        try{auto health=Json::parse(output.toStdString());if(health.at("protocolVersion")!=1||!health.value("healthy",false))throw std::runtime_error("Runtime health check failed");if(!health.value("manifestVerified",false))throw std::runtime_error("Runtime manifest is unverified; repair using a versioned bundle");const auto previous=status_.value("runtimeVersion",std::string{});status_["versionChanged"]=!previous.empty()&&previous!=health.value("runtimeVersion",std::string{});status_["runtimeVersion"]=health.at("runtimeVersion");status_["state"]="Healthy";status_["health"]=health;status_["message"]="Managed WSL2 runtime ready";}
        catch(const std::exception& e){status_["state"]="Incompatible";status_["message"]=e.what();}
        emit changed();
    }else if(phase_=="bundle"){
        try{status_["repair"]=Json::parse(output.toStdString());}catch(...){status_["state"]="Unavailable";status_["message"]="Invalid runtime repair response";emit changed();return;}
        QTimer::singleShot(0,this,&ManagedRuntime::detect);
    }else if(phase_=="import"){status_["message"]="Runtime imported; verifying health";QTimer::singleShot(0,this,&ManagedRuntime::detect);}
}
void ManagedRuntime::installBundle(const QString& archive){
    if(process_.state()!=QProcess::NotRunning)return;
    if(!status_.value("present",false)||!QFileInfo(archive).isFile()){status_["message"]="Install the runtime image first, then choose a valid repair/update bundle.";emit changed();return;}
    // WSL accepts drive paths through /mnt/<drive>; reject UNC/network locations.
    QString path=QDir::fromNativeSeparators(QFileInfo(archive).absoluteFilePath());
    if(path.size()<3||path[1]!=':'||path[2]!='/'||!path[0].isLetter()){status_["message"]="Select a runtime bundle on a local Windows drive.";emit changed();return;}
    path="/mnt/"+path.left(1).toLower()+path.mid(2);
    status_["state"]="Repairing";status_["message"]="Verifying and activating the selected runtime bundle. User projects and samples are preserved.";
    launch({"--distribution","HEPStudioRuntime","--user","root","--exec","/usr/bin/python3","/opt/hep/admin.py","--install",path},"bundle",300000);
}
void ManagedRuntime::importImage(const QString& archive,const QString& installationFolder){
    if(process_.state()!=QProcess::NotRunning)return;
    if(status_.value("present",false)){status_["message"]="Runtime already exists. Import never overwrites an existing distribution.";emit changed();return;}
    if(!QFileInfo::exists(archive)||!QDir().mkpath(installationFolder)){status_["message"]="Runtime archive or installation folder unavailable";emit changed();return;}
    status_["state"]="Installing";status_["message"]="Importing the selected runtime image into WSL2";
    launch({"--import","HEPStudioRuntime",installationFolder,archive,"--version","2"},"import",300000);
}
}
