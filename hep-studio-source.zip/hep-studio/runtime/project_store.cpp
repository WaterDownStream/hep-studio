#include "runtime/project_store.hpp"
#include <QSaveFile>
#include <QFile>
#include <QLockFile>
#include <QCryptographicHash>
#include <stdexcept>
namespace hep {
void saveProject(const Project& project,const QString& path) {
    QLockFile lock(path+".lock");
    if(!lock.tryLock(0)) throw std::runtime_error("Project is being written by another process");
    const auto text=serialize(project);
    if(text.size()>16*1024*1024) throw std::runtime_error("Project exceeds the Phase 0 16 MiB limit; archive run history before saving");
    QSaveFile file(path); file.setDirectWriteFallback(false);
    if(!file.open(QIODevice::WriteOnly)) throw std::runtime_error(file.errorString().toStdString());
    if(file.write(text.data(),static_cast<qint64>(text.size()))!=static_cast<qint64>(text.size()) || !file.commit())
        throw std::runtime_error(file.errorString().toStdString());
}
Project loadProject(const QString& path) {
    QFile file(path);
    if(!file.open(QIODevice::ReadOnly)) throw std::runtime_error(file.errorString().toStdString());
    if(file.size()>16*1024*1024) throw std::runtime_error("Project exceeds the Phase 0 16 MiB limit");
    const auto bytes=file.readAll();
    return parseProject(std::string_view(bytes.constData(),static_cast<std::size_t>(bytes.size())));
}
QString workflowHash(const Json& snapshot) {
    const auto text=snapshot.dump();
    return QString::fromLatin1(QCryptographicHash::hash(QByteArray(text.data(),static_cast<qsizetype>(text.size())),QCryptographicHash::Sha256).toHex());
}
}
