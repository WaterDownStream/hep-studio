#pragma once
#include "core/json.hpp"
namespace hep {
// Internal value boundary keeps VPIR's C++23 contracts out of library adapters
// built with the C++ standard of their scientific SDK (ROOT here).
Json validatedColliderPlan(const Json& workflow);
double colliderUnitScale(const std::string& symbol);
}
