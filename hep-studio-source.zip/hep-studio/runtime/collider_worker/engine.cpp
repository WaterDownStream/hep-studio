#include "runtime/collider_worker/lowering.hpp"
#include "plugins/pythia/adapter.hpp"
#include "plugins/fastjet/adapter.hpp"
#include "plugins/hepmc/adapter.hpp"
#include "plugins/lhapdf/adapter.hpp"
#include <Pythia8Plugins/HepMC3.h>
#include <HepMC3/ReaderAscii.h>
#include <HepMC3/WriterAscii.h>
#include <HepMC3/Version.h>
#include <HepMC3/GenParticle.h>
#include <TH1D.h>
#include <TROOT.h>
#include <algorithm>
#include <chrono>
#include <cstring>
#include <cstdlib>
#include <filesystem>
#include <functional>
#include <fstream>
#include <limits>
#include <numeric>
#include <optional>
#include <set>
#define HEP_STRINGIFY_IMPL(x) #x
#define HEP_STRINGIFY(x) HEP_STRINGIFY_IMPL(x)
using hep::Json;
namespace hep {Json showerLhe(const Json&,void(*)(const char*),int(*)());}
namespace {
using Clock=std::chrono::steady_clock;
using Row=std::vector<double>;
using Expr=std::function<double(const Row&)>;
using Progress=void(*)(const char*);
using Cancel=int(*)();
Expr expression(const Json& e,const std::map<std::string,std::size_t>& columns,int depth=0){
    if(depth>32)throw std::invalid_argument("Expression nesting limit");const auto op=e.at("op").get<std::string>();
    if(op=="literal"){const double value=e.at("value").get<double>()*hep::colliderUnitScale(e.value("unit","1"));return [value](const Row&){return value;};}
    if(op=="column"){const auto i=columns.at(e.at("name").get<std::string>());return [i](const Row& row){return row.at(i);};}
    std::vector<Expr> args;for(const auto& a:e.at("args"))args.push_back(expression(a,columns,depth+1));
    if(op=="and"||op=="or")return [args,op](const Row& row){for(const auto& a:args){const auto x=a(row);if(op=="and"&&!x)return 0.;if(op=="or"&&x)return 1.;}return op=="and"?1.:0.;};
    if(op=="deltaPhi"&&args.size()==2)return [args](const Row& r){return std::remainder(args[0](r)-args[1](r),2*std::acos(-1.));};
    if((op=="deltaR"||op=="transverseMass")&&args.size()==4)return [args,op](const Row& r){const auto phi=std::remainder(args[1](r)-args[3](r),2*std::acos(-1.));return op=="deltaR"?std::hypot(args[0](r)-args[2](r),phi):std::sqrt(std::max(0.,2*args[0](r)*args[2](r)*(1-std::cos(phi))));};
    if(args.size()==1){const auto a=args[0];
        if(op=="abs")return [a](const Row& r){return std::abs(a(r));};if(op=="neg")return [a](const Row& r){return -a(r);};
        if(op=="sqrt")return [a](const Row& r){return std::sqrt(a(r));};if(op=="square")return [a](const Row& r){auto x=a(r);return x*x;};
        if(op=="not")return [a](const Row& r){return a(r)?0.:1.;};if(op=="sin")return [a](const Row& r){return std::sin(a(r));};
        if(op=="cos")return [a](const Row& r){return std::cos(a(r));};if(op=="exp")return [a](const Row& r){return std::exp(a(r));};if(op=="log")return [a](const Row& r){return std::log(a(r));};
    }
    if(args.size()==2){const auto a=args[0],b=args[1];
        if(op=="add")return [a,b](const Row& r){return a(r)+b(r);};if(op=="sub")return [a,b](const Row& r){return a(r)-b(r);};
        if(op=="mul")return [a,b](const Row& r){return a(r)*b(r);};if(op=="div")return [a,b](const Row& r){return a(r)/b(r);};
        if(op=="min")return [a,b](const Row& r){return std::min(a(r),b(r));};if(op=="max")return [a,b](const Row& r){return std::max(a(r),b(r));};
        if(op=="gt")return [a,b](const Row& r){return a(r)>b(r)?1.:0.;};if(op=="ge")return [a,b](const Row& r){return a(r)>=b(r)?1.:0.;};
        if(op=="lt")return [a,b](const Row& r){return a(r)<b(r)?1.:0.;};if(op=="le")return [a,b](const Row& r){return a(r)<=b(r)?1.:0.;};
        if(op=="eq")return [a,b](const Row& r){return a(r)==b(r)?1.:0.;};if(op=="ne")return [a,b](const Row& r){return a(r)!=b(r)?1.:0.;};
    }throw std::invalid_argument("Unsupported collider expression: "+op);
}
struct Step {
    std::string id,kind;Json config,dimension;
    std::size_t input{},property{},take{1};bool descending{true};
    Expr expr,weight;std::unique_ptr<TH1D> histogram;
    std::optional<fastjet::JetDefinition> jetDefinition;
    std::vector<fastjet::PseudoJet> jets;std::vector<Row> rows;
    std::unique_ptr<fastjet::ClusterSequence> sequence;
    std::uint64_t count{};double sum{},minimum{std::numeric_limits<double>::infinity()},maximum{-std::numeric_limits<double>::infinity()};
};
Json histogram(const TH1D& h,const Json& dim){
    double stats[4]{};h.GetStats(stats);
    Json edges=Json::array(),values=Json::array(),errors=Json::array();
    for(int i=1;i<=h.GetNbinsX();++i){edges.push_back(h.GetXaxis()->GetBinLowEdge(i));values.push_back(h.GetBinContent(i));errors.push_back(h.GetBinError(i));}
    edges.push_back(h.GetXaxis()->GetXmax());
    return {{"kind","Histogram1D"},{"edges",edges},{"values",values},{"errors",errors},{"entries",h.GetEntries()},{"underflow",h.GetBinContent(0)},{"overflow",h.GetBinContent(h.GetNbinsX()+1)},
        {"underflowError",h.GetBinError(0)},{"overflowError",h.GetBinError(h.GetNbinsX()+1)},{"statistics",Json::array({stats[0],stats[1],stats[2],stats[3]})},{"mean",h.GetMean()},{"rms",h.GetRMS()},{"normalization","counts"},{"flowPolicy","separate"},{"dimension",dim}};
}
Row jetRow(const fastjet::PseudoJet& j,double weight,std::size_t columns){Row r(columns,0);r[0]=j.pt();r[1]=j.eta();r[2]=j.phi_std();r[3]=j.m();r[4]=j.e();r[5]=j.pt();r[6]=weight;return r;}
Json capabilities(){
    return {{"available",true},{"backend","hep.collider/1"},{"cppStandard",__cplusplus},{"pythiaData",HEP_PYTHIA_DATA},{"compiler",
#ifdef _MSC_VER
    "MSVC " HEP_STRINGIFY(_MSC_VER)
#else
    __VERSION__
#endif
    },{"libraries",{
        {"PYTHIA",{{"available",true},{"status","Available"},{"version",std::to_string(PYTHIA_VERSION)},{"parallel_generation",false},{"externalLHAPDF",hep::pythia::externalPdfAvailable()}}},
        {"FastJet",{{"available",true},{"status","Available"},{"version",fastjet::fastjet_version_string()}}},
        {"HepMC3",{{"available",true},{"status","Available"},{"version",HepMC3::version()}}},
        {"ROOT",{{"available",true},{"status","Available"},{"version",gROOT->GetVersion()}}},
        {"LHAPDF",hep::lhapdf::capability()}
    }}};
}
Json exportSample(const Json& payload,Progress progress,Cancel cancelled){
    const auto destination=std::filesystem::path(payload.at("destination").get<std::string>());
    const auto paths=payload.at("shards").get<std::vector<std::string>>();
    if(paths.empty()||paths.size()>4096)throw std::invalid_argument("Invalid shard list");
    if(std::filesystem::exists(destination))throw std::runtime_error("Export destination already exists");
    std::uintmax_t bytes=64*1024*1024;
    for(const auto& path:paths)bytes+=std::filesystem::file_size(path);
    if(std::filesystem::space(destination.parent_path()).available<bytes)throw std::runtime_error("Insufficient disk space for single-file export");
    const auto pending=destination.string()+".partial-"+std::to_string(Clock::now().time_since_epoch().count());
    struct Cleanup {std::string path;~Cleanup(){std::error_code ec;std::filesystem::remove(path,ec);}} cleanup{pending};
    HepMC3::WriterAscii writer(pending);std::uint64_t count=0;
    for(const auto& path:paths){
        std::ifstream input(path,std::ios::binary);if(!input)throw std::runtime_error("Sample shard unavailable");
        input.seekg(0,std::ios::end);auto size=input.tellg();input.seekg(std::max<std::streamoff>(0,static_cast<std::streamoff>(size)-4096));
        const std::string tail((std::istreambuf_iterator<char>(input)),{});
        if(tail.find("HepMC::Asciiv3-END_EVENT_LISTING")==std::string::npos)throw std::runtime_error("Incomplete HepMC shard");
        input.clear();input.seekg(0);HepMC3::ReaderAscii reader(input);
        while(true){
            if(cancelled&&cancelled())throw std::runtime_error("Cancelled");
            HepMC3::GenEvent event;reader.read_event(event);
            if(input.bad()||(reader.failed()&&!input.eof()))throw std::runtime_error("Malformed HepMC shard during export");
            if(reader.failed())break;
            writer.write_event(event);if(writer.failed())throw std::runtime_error("HepMC export write failed");++count;
            if(progress&&count%100==0){const auto status=Json{{"stage","Exporting HepMC shards"},{"accepted",count}}.dump();progress(status.c_str());}
        }
    }
    writer.close();if(writer.failed())throw std::runtime_error("HepMC export finalization failed");
    if(count==0||(payload.contains("eventCount")&&count!=payload.at("eventCount").get<std::uint64_t>()))throw std::runtime_error("Incomplete sample export; event count mismatch");
    if(cancelled&&cancelled())throw std::runtime_error("Cancelled");
    // Same-filesystem hard link publishes atomically without overwriting existing data.
    std::filesystem::create_hard_link(pending,destination);
    return {{"path",destination.string()},{"eventCount",count},{"format","HepMC3-Asciiv3"},{"complete",true}};
}
Json run(const Json& request,Progress progress,Cancel cancelled){
    const auto operation=request.at("operation").get<std::string>();const auto payload=request.value("payload",Json::object());
    if(operation=="showerLhe")return hep::showerLhe(payload,progress,cancelled);
    if(operation=="pdfSets"||operation=="pdfEvaluate")return hep::lhapdf::dispatch(operation,payload);
    if(operation=="exportSample")return exportSample(payload,progress,cancelled);
    if(operation=="clusterFixture")return hep::fastjet_adapter::fixture(payload);
    const auto data=payload.value("pythiaData",std::string(HEP_PYTHIA_DATA));
    if(operation=="settings"){
        auto p=hep::pythia::create(data);if(payload.contains("config"))hep::pythia::configure(*p,payload["config"],1);
        auto m=hep::pythia::metadata(*p,payload.value("search",""),payload.value("changedOnly",false));m["processes"]=hep::pythia::processes();return m;
    }
    if(operation!="execute"&&operation!="eventPreview")throw std::invalid_argument("Unknown collider operation");
    auto plan=hep::validatedColliderPlan(payload.at("workflow"));
    if(plan.at("nodes").size()>1000)throw std::invalid_argument("Collider node limit");
    std::map<std::string,std::size_t> columns={{"pt",0},{"eta",1},{"phi",2},{"mass",3},{"energy",4},{"value",5},{"weight",6}},ids;
    for(const auto& n:plan["nodes"])if(n["kind"]=="Define")columns.emplace(n["config"]["name"].get<std::string>(),columns.size());
    std::vector<Step> steps;std::unique_ptr<Pythia8::Pythia> generator;std::ifstream inputStream;std::unique_ptr<HepMC3::ReaderAscii> reader;
    std::vector<std::string> inputPaths;std::size_t inputIndex=0;std::optional<std::uint64_t> manifestCount;
    auto openInput=[&](const std::string& path){
        reader.reset();inputStream.close();inputStream.clear();inputStream.open(path,std::ios::binary);
        if(!inputStream)throw std::runtime_error("Sample shard unavailable");
        inputStream.seekg(0,std::ios::end);const auto bytes=inputStream.tellg();inputStream.seekg(std::max<std::streamoff>(0,static_cast<std::streamoff>(bytes)-4096));
        const std::string tail((std::istreambuf_iterator<char>(inputStream)),{});
        if(tail.find("HepMC::Asciiv3-END_EVENT_LISTING")==std::string::npos)throw std::runtime_error("Incomplete HepMC3 sample: missing end marker");
        inputStream.clear();inputStream.seekg(0);reader=std::make_unique<HepMC3::ReaderAscii>(inputStream);
    };
    std::vector<std::unique_ptr<HepMC3::WriterAscii>> writers;Json samples=Json::array(),generatorInfo=Json::object();
    const auto preview=operation=="eventPreview";std::uint64_t target=preview?static_cast<std::uint64_t>(std::clamp(payload.value("previewEvents",10),1,20)):0;
    std::uint64_t estimatedMaterialization=0,progressTarget=target;
    std::vector<std::filesystem::path> pendingFiles,finalFiles;
    struct Cleanup {std::vector<std::filesystem::path>& files;~Cleanup(){for(const auto& f:files){std::error_code ec;std::filesystem::remove(f,ec);}}} cleanup{pendingFiles};
    for(const auto& n:plan["nodes"]){
        Step s;s.id=n["id"];s.kind=n["kind"];s.config=n["config"];s.dimension=n.value("dimension",Json::array({1,0,0,0}));
        if(n.contains("input"))s.input=ids.at(n["input"].get<std::string>());const auto& c=s.config;
        if(s.kind=="Pythia"){
            if(!preview)target=c.value("events",std::uint64_t(1000));
            if(target<1||target>1000000000ULL)throw std::invalid_argument("Event target must be in [1, 1000000000]");
            progressTarget=target;estimatedMaterialization=target*1024*1024;
            generator=hep::pythia::create(data);generatorInfo=hep::pythia::configure(*generator,c,payload.at("actualSeed").get<int>());
            if(progress)progress("{\"stage\":\"Initializing PYTHIA\"}");
            if(!generator->init())throw std::runtime_error("PYTHIA initialization failed; check beam/process configuration and raw logs");
        }else if(s.kind=="HepMCSource"){
            const auto rid=c.at("resourceId").get<std::string>();const auto& resource=payload.at("resources").at(rid);
            const auto path=resource.at("path").get<std::string>();if(!std::filesystem::is_regular_file(path))throw std::runtime_error("Sample unavailable; relink its physical location");
            inputPaths=resource.value("shards",std::vector<std::string>{path});
            if(inputPaths.empty())throw std::runtime_error("Empty sample manifest");
            if(resource.contains("manifestEventCount"))manifestCount=resource.at("manifestEventCount").get<std::uint64_t>();
            openInput(inputPaths.front());
            if(!preview)target=1000000000; // Read the stream; metadata is not a truncation limit.
            if(!preview)progressTarget=resource.value("eventCount",std::uint64_t(0));
            estimatedMaterialization=std::filesystem::file_size(path)*2;
        }else if(s.kind=="StoreHepMC"){
            if(preview)throw std::invalid_argument("Preview does not materialize samples; use a Full Run");
            const auto rid=c.at("resourceId").get<std::string>();const auto path=std::filesystem::path(payload.at("resources").at(rid).at("path").get<std::string>());
            if(std::filesystem::exists(path))throw std::runtime_error("Sample output already exists; choose a new resource location");
            const auto parent=path.parent_path();if(!std::filesystem::is_directory(parent))throw std::runtime_error("Sample destination folder is unavailable");
            const auto space=std::filesystem::space(parent);const auto estimate=64*1024*1024+estimatedMaterialization;
            if(space.available<estimate)throw std::runtime_error("Insufficient disk space for HepMC estimate (1 MiB/generated event or twice input size, plus 64 MiB reserve)");
            const auto pending=path.string()+".partial-"+payload.value("jobId",std::string("job"));
            if(std::filesystem::exists(pending))throw std::runtime_error("Partial output already exists");
            pendingFiles.emplace_back(pending);finalFiles.push_back(path);writers.push_back(std::make_unique<HepMC3::WriterAscii>(pending));
            samples.push_back({{"resourceId",rid},{"format","HepMC3"},{"path",path.string()},{"estimatedBytes",estimate}});
        }else if(s.kind=="ClusterJets"){
            s.jetDefinition=hep::fastjet_adapter::definition(c);const auto min=c.value("minimumPtGeV",0.);if(min<0||!std::isfinite(min))throw std::invalid_argument("Invalid minimum jet pT");
        }else if(s.kind=="CollectionFilter"||s.kind=="Filter"||s.kind=="Define"||s.kind=="Histo1D"||s.kind=="Mean"||s.kind=="Sum"||s.kind=="Min"||s.kind=="Max"){
            s.expr=expression(c.at("expression"),columns);
            if(s.kind=="Define")s.property=columns.at(c.at("name").get<std::string>());
        }else if(s.kind=="CollectionSort"||s.kind=="Property"){
            s.property=columns.at(c.at("property").get<std::string>());s.descending=c.value("descending",true);
        }else if(s.kind=="CollectionTake"){
            const auto count=c.value("count",1);if(count<1||count>100000)throw std::invalid_argument("Take count must be in [1,100000]");s.take=static_cast<std::size_t>(count);
        }else if(s.kind!="CollectionCount"&&s.kind!="Count"&&s.kind!="Fit")throw std::invalid_argument("Collider action not implemented: "+s.kind);
        if(s.kind=="Histo1D"){
            std::vector<double> edges;
            if(c.contains("edges")&&!c["edges"].empty())edges=c["edges"].get<std::vector<double>>();
            else {const int bins=c.value("bins",50);const double lo=c.value("lower",0.),hi=c.value("upper",500.);if(bins<1||bins>4096||!std::isfinite(lo+hi)||hi<=lo)throw std::invalid_argument("Invalid histogram binning");for(int i=0;i<=bins;++i)edges.push_back(lo+(hi-lo)*i/bins);}
            if(edges.size()<2||edges.size()>4097)throw std::invalid_argument("Histogram edge limit");for(std::size_t i=0;i<edges.size();++i)if(!std::isfinite(edges[i])||(i&&edges[i]<=edges[i-1]))throw std::invalid_argument("Histogram edges must increase");
            s.histogram=std::make_unique<TH1D>(s.id.c_str(),"",static_cast<int>(edges.size()-1),edges.data());s.histogram->SetDirectory(nullptr);s.histogram->Sumw2();
            s.weight=c.contains("weight")&&!c["weight"].is_null()?expression(c["weight"],columns):Expr([](const Row& r){return r[6];});
        }
        ids.emplace(s.id,steps.size());steps.push_back(std::move(s));
    }
    if(!generator&&!reader)throw std::invalid_argument("Missing event source");
    const auto start=Clock::now();auto last=start;std::uint64_t accepted=0,attempts=0,failed=0;double sumWeights=0,sumWeightsSquared=0;Json events=Json::array();
    HepMC3::Pythia8ToHepMC3 converter;const unsigned inspectLimit=preview?static_cast<unsigned>(target):static_cast<unsigned>(std::clamp(payload.value("inspectEvents",1),0,1));
    while(accepted<target){
        if(cancelled&&cancelled())throw std::runtime_error("Cancelled");++attempts;
        HepMC3::GenEvent event(HepMC3::Units::GEV,HepMC3::Units::MM);
        if(generator){
            if(!generator->next()){++failed;if(failed>100&&failed*10>attempts)throw std::runtime_error("PYTHIA repeatedly failed to generate events; inspect raw logs");continue;}
            if(!writers.empty()||events.size()<inspectLimit)if(!converter.fill_next_event(*generator,&event,static_cast<int>(accepted+payload.value("eventOffset",std::uint64_t(0)))))throw std::runtime_error("PYTHIA to HepMC3 conversion failed");
        }else {
            reader->read_event(event);
            if(inputStream.bad()||(reader->failed()&&!inputStream.eof()))throw std::runtime_error("Malformed HepMC3 event; partial analysis discarded");
            if(reader->failed()){if(++inputIndex<inputPaths.size()){openInput(inputPaths[inputIndex]);continue;}if(accepted==0)throw std::runtime_error("Malformed or empty HepMC3 sample");break;}
            event.set_units(HepMC3::Units::GEV,HepMC3::Units::MM);
        }
        const double weight=generator?generator->info.weight():event.weights().empty()?1.:event.weights().front();sumWeights+=weight;sumWeightsSquared+=weight*weight;
        if(!std::isfinite(weight))throw std::runtime_error("Nonfinite event weight");
        for(auto& writer:writers){writer->write_event(event);if(writer->failed())throw std::runtime_error("HepMC write failed; check available disk space");}
        Json inspected;if(events.size()<inspectLimit)inspected=hep::hepmc::inspect(event);
        for(std::size_t si=0;si<steps.size();++si){
            auto& s=steps[si];s.rows.clear();s.jets.clear();s.sequence.reset();
            if(s.kind=="Pythia"||s.kind=="HepMCSource"||s.kind=="StoreHepMC"||s.kind=="Fit")continue;
            if(s.kind=="ClusterJets"){
                std::vector<fastjet::PseudoJet> inputs;const bool invisible=s.config.value("includeInvisible",false);
                auto add=[&](double px,double py,double pz,double en,int pdg,int index){
                    const auto absid=std::abs(pdg);if(!invisible&&(absid==12||absid==14||absid==16||absid==18))return;
                    inputs.emplace_back(px,py,pz,en);inputs.back().set_user_index(index);
                };
                if(generator){for(int i=1;i<generator->event.size();++i){const auto& p=generator->event[i];if(p.isFinal())add(p.px(),p.py(),p.pz(),p.e(),p.id(),i);}}
                else for(const auto& p:event.particles())if(p->status()==1){const auto& m=p->momentum();add(m.px(),m.py(),m.pz(),m.e(),p->pid(),p->id());}
                s.sequence=std::make_unique<fastjet::ClusterSequence>(inputs,*s.jetDefinition);s.jets=fastjet::sorted_by_pt(s.sequence->inclusive_jets(s.config.value("minimumPtGeV",0.)));
                if(!inspected.is_null()){
                    Json jets=Json::array(),points=Json::array();for(const auto& jet:s.jets)jets.push_back(hep::fastjet_adapter::jetData(jet));
                    for(const auto& p:inputs)if(points.size()<10000)points.push_back({{"index",p.user_index()},{"pt",p.pt()},{"eta",p.eta()},{"phi",p.phi_std()}});
                    inspected["jetCollections"][s.id]={{"jets",jets},{"particles",points},{"configuration",s.config},{"indexSpace",generator?"pythia":"hepmc"}};
                }continue;
            }
            auto& input=steps.at(s.input);
            if(s.kind=="CollectionFilter"||s.kind=="CollectionSort"||s.kind=="CollectionTake"){
                s.jets=input.jets;
                if(s.kind=="CollectionFilter")s.jets.erase(std::remove_if(s.jets.begin(),s.jets.end(),[&](const auto& jet){return !s.expr(jetRow(jet,weight,columns.size()));}),s.jets.end());
                if(s.kind=="CollectionSort")std::stable_sort(s.jets.begin(),s.jets.end(),[&](const auto& a,const auto& b){const auto av=jetRow(a,weight,columns.size())[s.property],bv=jetRow(b,weight,columns.size())[s.property];return s.descending?av>bv:av<bv;});
                if(s.kind=="CollectionTake"&&s.jets.size()>s.take)s.jets.resize(s.take);continue;
            }
            if(s.kind=="Property"){for(const auto& j:input.jets){auto r=jetRow(j,weight,columns.size());r[5]=r[s.property];s.rows.push_back(std::move(r));}continue;}
            if(s.kind=="CollectionCount"){Row r(columns.size(),0);r[5]=static_cast<double>(input.jets.size());r[6]=weight;s.rows.push_back(std::move(r));continue;}
            if(s.kind=="Define"||s.kind=="Filter"){
                for(const auto& r:input.rows){const auto value=s.expr(r);if(!std::isfinite(value))throw std::runtime_error("Nonfinite expression result in "+s.id);if(s.kind=="Filter"&&!value)continue;auto row=r;if(s.kind=="Define")row[s.property]=value;s.rows.push_back(std::move(row));}continue;
            }
            for(const auto& r:input.rows){++s.count;if(s.kind=="Count")continue;const double value=s.expr(r);if(!std::isfinite(value))throw std::runtime_error("Nonfinite observable");
                if(s.histogram){const auto w=s.weight(r);if(!std::isfinite(w))throw std::runtime_error("Nonfinite histogram weight");s.histogram->Fill(value,w);}else{s.sum+=value;s.minimum=std::min(s.minimum,value);s.maximum=std::max(s.maximum,value);}}
        }
        ++accepted;if(!inspected.is_null())events.push_back(inspected);
        const auto now=Clock::now();if(progress&&(now-last>std::chrono::milliseconds(200)||accepted==target)){
            const auto elapsed=std::chrono::duration<double>(now-start).count();const auto msg=Json{{"stage","Generating / clustering"},{"accepted",accepted},{"generated",accepted},{"attempts",attempts},{"failed",failed},{"target",progressTarget},{"elapsedSeconds",elapsed},{"eventsPerSecond",accepted/elapsed}}.dump();progress(msg.c_str());last=now;
        }
    }
    if(manifestCount&&!preview&&accepted!=*manifestCount)throw std::runtime_error("Sample manifest event count disagrees with HepMC shards");
    Json results=Json::object();
    for(const auto& s:steps){if(s.histogram)results[s.id]=histogram(*s.histogram,s.dimension);
        else if(s.kind=="Count"||s.kind=="Mean"||s.kind=="Sum"||s.kind=="Min"||s.kind=="Max"){
            Json value=s.kind=="Count"?Json(s.count):s.kind=="Sum"?Json(s.sum):!s.count?Json():s.kind=="Mean"?Json(s.sum/static_cast<double>(s.count)):s.kind=="Min"?Json(s.minimum):Json(s.maximum);
            results[s.id]={{"kind","ScalarResult"},{"operation",s.kind},{"value",value},{"count",s.count},{"sum",s.sum}};
        }}
    for(std::size_t i=0;i<writers.size();++i){
        writers[i]->close();if(writers[i]->failed())throw std::runtime_error("Failed to finalize HepMC sample");
        // Linking in the same directory is atomic and never replaces a racing
        // writer's file. Filesystems without hard links must use runtime storage.
        std::error_code error;std::filesystem::create_hard_link(pendingFiles[i],finalFiles[i],error);
        if(error)throw std::runtime_error("Cannot commit sample without overwriting: "+error.message()+". Choose runtime-local storage.");
        std::filesystem::remove(pendingFiles[i]);samples[i]["eventCount"]=accepted;samples[i]["sizeBytes"]=std::filesystem::file_size(finalFiles[i]);
    }
    const auto seconds=std::chrono::duration<double>(Clock::now()-start).count();
    return {{"valid",true},{"preview",preview},{"results",results},{"events",events},{"samples",samples},{"generator",generatorInfo},{"executionPlan",plan},
        {"metrics",{{"generated",accepted},{"accepted",accepted},{"attempts",attempts},{"failed",failed},{"sumWeights",sumWeights},{"sumWeightsSquared",sumWeightsSquared},{"eventLoopSeconds",seconds},{"eventsPerSecond",accepted/seconds},{"threads",1},{"bulkEventsThroughIPC",0}}}};
}
char* resultString(const Json& j){const auto s=j.dump(-1,' ',false,Json::error_handler_t::replace);auto* p=static_cast<char*>(std::malloc(s.size()+1));if(p)std::memcpy(p,s.c_str(),s.size()+1);return p;}
}
#if defined(_WIN32)
#define HEP_EXPORT __declspec(dllexport)
#else
#define HEP_EXPORT __attribute__((visibility("default")))
#endif
extern "C" {
HEP_EXPORT char* hep_collider_capabilities(){try{return resultString(capabilities());}catch(const std::exception& e){return resultString({{"available",false},{"error",e.what()}});}}
HEP_EXPORT char* hep_collider_execute(const char* text,Progress progress,Cancel cancel){try{return resultString(run(Json::parse(text),progress,cancel));}catch(const std::exception& e){return resultString({{"error",e.what()}});}catch(...){return resultString({{"error","Unknown native collider failure"}});}}
HEP_EXPORT void hep_collider_free(void* p){std::free(p);}
}
