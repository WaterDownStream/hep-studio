#include "runtime/collider_worker/lowering.hpp"
#include "core/collider/collider.hpp"
#include "core/project/project.hpp"
#include "core/units/units.hpp"
namespace hep {
Json validatedColliderPlan(const Json& workflow){return lowerCollider(workflowFromJson(workflow));}
double colliderUnitScale(const std::string& symbol){return unit(symbol).scale;}
}
