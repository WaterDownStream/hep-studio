#include "plugins/pythia/adapter.hpp"
#include "plugins/hepmc/adapter.hpp"
#include <Pythia8Plugins/HepMC3.h>
#include <HepMC3/WriterAscii.h>
#include <chrono>
#include <filesystem>
#include <cmath>
#include <algorithm>
#include <limits>
namespace hep {
// One stable logical LHE block per isolated generator instance. Physical worker
// scheduling lives above this boundary; failed records are never silently retried
// from another random stream or presented as a complete requested sample.
Json showerLhe(const Json& payload,void(*progress)(const char*),int(*cancelled)()){
    const auto input=payload.at("input").get<std::string>();
    const auto output=std::filesystem::path(payload.at("output").get<std::string>());
    const auto expected=payload.at("eventCount").get<std::uint64_t>();
    if(!expected||expected>1000000000ULL)throw std::invalid_argument("Invalid logical LHE event count");
    if(!std::filesystem::is_regular_file(input))throw std::runtime_error("LHE sample unavailable");
    if(std::filesystem::exists(output))throw std::runtime_error("Shower output already exists");
    if(std::filesystem::space(output.parent_path()).available<64*1024*1024ULL+expected*1024*1024ULL)
        throw std::runtime_error("Insufficient disk space for shower output estimate");
    const auto pending=output.string()+".partial";
    if(std::filesystem::exists(pending))throw std::runtime_error("Incomplete shower output already exists");
    struct Cleanup {std::string path;~Cleanup(){std::error_code ec;std::filesystem::remove(path,ec);}} cleanup{pending};
    auto p=pythia::create(payload.value("pythiaData",std::string(HEP_PYTHIA_DATA)));
    auto metadata=pythia::configureLhe(*p,payload.value("config",Json::object()),payload.at("actualSeed").get<int>(),input);
    if(cancelled&&cancelled())throw std::runtime_error("Cancelled");
    if(!p->init())throw std::runtime_error("PYTHIA LHE initialization failed; inspect retained diagnostics");
    HepMC3::WriterAscii writer(pending);HepMC3::Pythia8ToHepMC3 converter;
    std::uint64_t accepted=0;double sum=0,sum2=0;Json events=Json::array();
    const auto start=std::chrono::steady_clock::now();
    const auto offset=payload.value("eventOffset",std::uint64_t(0));
    while(accepted<expected){
        if(cancelled&&cancelled())throw std::runtime_error("Cancelled");
        if(!p->next())throw std::runtime_error(p->info.atEndOfFile()?"LHE stream ended before requested event count":"PYTHIA failed to shower an LHE event; incomplete block discarded");
        const double weight=p->info.weight();if(!std::isfinite(weight))throw std::runtime_error("Nonfinite LHE shower weight");
        HepMC3::GenEvent event(HepMC3::Units::GEV,HepMC3::Units::MM);
        if(offset+accepted>static_cast<std::uint64_t>(std::numeric_limits<int>::max()))throw std::runtime_error("HepMC event-number range exceeded");
        if(!converter.fill_next_event(*p,&event,static_cast<int>(offset+accepted)))throw std::runtime_error("LHE shower HepMC conversion failed");
        writer.write_event(event);if(writer.failed())throw std::runtime_error("HepMC shower write failed");
        if(events.size()<static_cast<std::size_t>(std::clamp(payload.value("inspectEvents",1),0,10)))events.push_back(hepmc::inspect(event));
        sum+=weight;sum2+=weight*weight;++accepted;
        if(progress&&(accepted%100==0||accepted==expected)){
            const auto seconds=std::chrono::duration<double>(std::chrono::steady_clock::now()-start).count();
            const auto message=Json{{"stage","Showering LHE"},{"accepted",accepted},{"target",expected},{"eventsPerSecond",accepted/seconds}}.dump();progress(message.c_str());
        }
    }
    writer.close();if(writer.failed())throw std::runtime_error("HepMC shower finalization failed");
    if(cancelled&&cancelled())throw std::runtime_error("Cancelled");
    std::filesystem::create_hard_link(pending,output);
    return {{"valid",true},{"path",output.string()},{"eventCount",accepted},{"generator",metadata},{"events",events},
        {"metrics",{{"accepted",accepted},{"failed",0},{"sumWeights",sum},{"sumWeightsSquared",sum2},{"bulkEventsThroughIPC",0},{"threads",1}}}};
}
}
