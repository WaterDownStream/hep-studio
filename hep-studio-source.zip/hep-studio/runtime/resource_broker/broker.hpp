#pragma once
#include "core/vpir/model.hpp"
#include <cstdint>
#include <optional>
#include <QString>
#include <QTimer>
namespace hep {
struct Hardware {
    unsigned logicalCpus{1}; std::optional<std::uint64_t> physicalMemoryBytes;
    std::string platform, architecture;
    // Empty optional means not detected, not zero devices.
    std::optional<Json> gpus,numa,coreTopology,storage;
};
struct ResourceRequest { unsigned threads{1}; std::uint64_t memoryBytes{64*1024*1024}; };
struct ResourceLease { Id id; ResourceRequest allocation; };
class ResourceBroker {
public:
    explicit ResourceBroker(QString registryPath={});
    ~ResourceBroker();
    ResourceBroker(const ResourceBroker&)=delete;
    ResourceBroker& operator=(const ResourceBroker&)=delete;
    const Hardware& hardware() const { return hardware_; }
    std::optional<ResourceLease> acquire(ResourceRequest);
    void release(const Id&);
    bool reallocate(const Id&,ResourceRequest);
    Json usage()const;
private:
    void flushReleases(int timeout=50);
    QString registryPath_;
    Hardware hardware_;
    std::vector<ResourceLease> leases_;
    std::vector<Id> pendingReleases_;
    QTimer releaseRetry_;
};
Json hardwareJson(const Hardware&);
}
