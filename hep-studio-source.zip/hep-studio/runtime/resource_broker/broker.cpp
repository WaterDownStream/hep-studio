#include "runtime/resource_broker/broker.hpp"
#include <QSysInfo>
#include <QString>
#include <QStandardPaths>
#include <QCoreApplication>
#include <QDir>
#include <QFileInfo>
#include <QFile>
#include <QSaveFile>
#include <QLockFile>
#include <thread>
#include <algorithm>
#if defined(_WIN32)
#ifndef NOMINMAX
#define NOMINMAX
#endif
#include <windows.h>
#elif defined(__APPLE__)
#include <sys/sysctl.h>
#else
#include <unistd.h>
#endif
#ifndef _WIN32
#include <signal.h>
#include <cerrno>
#endif
namespace hep {
namespace {
bool alive(qint64 pid){
#ifdef _WIN32
    const auto handle=OpenProcess(PROCESS_QUERY_LIMITED_INFORMATION,FALSE,static_cast<DWORD>(pid));if(!handle)return GetLastError()==ERROR_ACCESS_DENIED;
    DWORD status=0;const bool result=GetExitCodeProcess(handle,&status)&&status==STILL_ACTIVE;CloseHandle(handle);return result;
#else
    return pid>0&&(kill(static_cast<pid_t>(pid),0)==0||errno==EPERM);
#endif
}
Json readLeases(const QString& path){
    QFile file(path);if(!file.exists())return Json::array();
    if(!file.open(QIODevice::ReadOnly)||file.size()>1024*1024)throw std::runtime_error("Resource registry unavailable");
    const auto data=file.readAll();auto rows=Json::parse(data.constData(),data.constData()+data.size());
    if(!rows.is_array())throw std::runtime_error("Invalid resource registry");
    std::erase_if(rows.get_ref<Json::array_t&>(),[](const Json& row){return !alive(row.at("pid").get<qint64>());});return rows;
}
bool writeLeases(const QString& path,const Json& rows){QSaveFile file(path);const auto data=QByteArray::fromStdString(rows.dump());return file.open(QIODevice::WriteOnly)&&file.write(data)==data.size()&&file.commit();}
bool fits(const Hardware& hardware,const Json& rows,ResourceRequest request,const std::string& exclude=""){
    std::uint64_t threads=0,memory=0;for(const auto& row:rows)if(row.at("id")!=exclude){threads+=row.at("threads").get<unsigned>();memory+=row.at("memoryBytes").get<std::uint64_t>();}
    const auto limit=std::max(1u,hardware.logicalCpus-1);
    if(request.threads==0||threads>=limit||request.threads>limit-threads)return false;
    return !hardware.physicalMemoryBytes||(memory<=*hardware.physicalMemoryBytes/2&&request.memoryBytes<=*hardware.physicalMemoryBytes/2-memory);
}
}
ResourceBroker::ResourceBroker(QString registryPath):registryPath_(std::move(registryPath)) {
    releaseRetry_.setSingleShot(true);releaseRetry_.setInterval(100);
    QObject::connect(&releaseRetry_,&QTimer::timeout,&releaseRetry_,[this]{flushReleases();});
    if(registryPath_.isEmpty())registryPath_=QStandardPaths::writableLocation(QStandardPaths::GenericDataLocation)+"/HEPStudio/resource-broker-v1.json";
    QDir().mkpath(QFileInfo(registryPath_).absolutePath());
    hardware_.logicalCpus=std::max(1u,std::thread::hardware_concurrency());
#if defined(__linux__)
    // Respect a cgroup v2 CPU ceiling before reserving the UI core.
    QFile quota("/sys/fs/cgroup/cpu.max");
    if(quota.open(QIODevice::ReadOnly)){
        const auto fields=quota.readAll().simplified().split(' ');
        if(fields.size()==2&&fields[0]!="max"){
            bool okQuota=false,okPeriod=false;const auto q=fields[0].toULongLong(&okQuota),period=fields[1].toULongLong(&okPeriod);
            if(okQuota&&okPeriod&&period>0)hardware_.logicalCpus=std::min(hardware_.logicalCpus,static_cast<unsigned>(std::max(1ULL,q/period)));
        }
    }
    QFile memoryLimit("/sys/fs/cgroup/memory.max");
#endif
    hardware_.platform=QSysInfo::prettyProductName().toStdString();
    hardware_.architecture=QSysInfo::currentCpuArchitecture().toStdString();
#if defined(_WIN32)
    MEMORYSTATUSEX status{}; status.dwLength=sizeof(status);
    if (GlobalMemoryStatusEx(&status)) hardware_.physicalMemoryBytes=status.ullTotalPhys;
#elif defined(__APPLE__)
    std::uint64_t memory=0; std::size_t size=sizeof(memory);
    if(sysctlbyname("hw.memsize",&memory,&size,nullptr,0)==0) hardware_.physicalMemoryBytes=memory;
#else
    const long pages=sysconf(_SC_PHYS_PAGES),pageSize=sysconf(_SC_PAGE_SIZE);
    if(pages>0 && pageSize>0) hardware_.physicalMemoryBytes=static_cast<std::uint64_t>(pages)*static_cast<std::uint64_t>(pageSize);
#endif
#if defined(__linux__)
    if(memoryLimit.open(QIODevice::ReadOnly)){bool ok=false;const auto limit=memoryLimit.readAll().trimmed().toULongLong(&ok);if(ok&&limit>0)hardware_.physicalMemoryBytes=std::min<std::uint64_t>(hardware_.physicalMemoryBytes.value_or(limit),limit);}
#endif
}
ResourceBroker::~ResourceBroker(){releaseRetry_.stop();for(const auto& lease:leases_)pendingReleases_.push_back(lease.id);flushReleases(500);releaseRetry_.stop();}
std::optional<ResourceLease> ResourceBroker::acquire(ResourceRequest request) {
    QLockFile lock(registryPath_+".lock");lock.setStaleLockTime(0);if(!lock.tryLock(50))return std::nullopt;
    try{
        auto rows=readLeases(registryPath_);if(!fits(hardware_,rows,request))return std::nullopt;
        ResourceLease lease{newId(),request};rows.push_back({{"id",lease.id.value},{"pid",QCoreApplication::applicationPid()},{"threads",request.threads},{"memoryBytes",request.memoryBytes}});
        if(!writeLeases(registryPath_,rows))return std::nullopt;
        leases_.push_back(lease);return lease;
    }catch(const std::exception&){return std::nullopt;}
}
void ResourceBroker::release(const Id& id) {
    if(std::none_of(leases_.begin(),leases_.end(),[&](const auto& l){return l.id==id;}))return;
    if(std::find(pendingReleases_.begin(),pendingReleases_.end(),id)==pendingReleases_.end())pendingReleases_.push_back(id);
    flushReleases();
}
void ResourceBroker::flushReleases(int timeout){
    if(pendingReleases_.empty())return;
    QLockFile lock(registryPath_+".lock");lock.setStaleLockTime(0);
    if(lock.tryLock(timeout))try{
        auto rows=readLeases(registryPath_);
        auto pending=[&](const Id& id){return std::find(pendingReleases_.begin(),pendingReleases_.end(),id)!=pendingReleases_.end();};
        std::erase_if(rows.get_ref<Json::array_t&>(),[&](const Json& row){return pending(Id(row.at("id").get<std::string>()));});
        if(writeLeases(registryPath_,rows)){std::erase_if(leases_,[&](const auto& l){return pending(l.id);});pendingReleases_.clear();}
    }catch(const std::exception&){}
    if(!pendingReleases_.empty())releaseRetry_.start();
}
bool ResourceBroker::reallocate(const Id& id,ResourceRequest request){
    auto lease=std::find_if(leases_.begin(),leases_.end(),[&](const auto& l){return l.id==id;});if(lease==leases_.end())return false;
    QLockFile lock(registryPath_+".lock");lock.setStaleLockTime(0);if(!lock.tryLock(50))return false;
    try{auto rows=readLeases(registryPath_);if(!fits(hardware_,rows,request,id.value))return false;for(auto& row:rows)if(row.at("id")==id.value){row["threads"]=request.threads;row["memoryBytes"]=request.memoryBytes;}if(!writeLeases(registryPath_,rows))return false;lease->allocation=request;return true;}catch(const std::exception&){return false;}
}
Json ResourceBroker::usage()const{
    QLockFile lock(registryPath_+".lock");lock.setStaleLockTime(0);if(!lock.tryLock(20))return {{"available",false}};
    try{return {{"available",true},{"leases",readLeases(registryPath_)},{"scope","HEP Studio instances for this host user; WSL jobs budgeted by Windows host"},{"uiReservedThreads",hardware_.logicalCpus>1?1:0}};}catch(const std::exception&){return {{"available",false}};}
}
Json hardwareJson(const Hardware& h) {
    return {{"logicalCpus",h.logicalCpus},{"physicalMemoryBytes",h.physicalMemoryBytes?Json(*h.physicalMemoryBytes):Json(nullptr)},
      {"platform",h.platform},{"architecture",h.architecture},{"gpus",nullptr},{"numa",nullptr},{"coreTopology",nullptr},{"storage",nullptr}};
}
}
