#pragma once
#include "core/vpir/model.hpp"
#include <QObject>
#include <QProcess>
#include <QProcessEnvironment>
#include <QTemporaryDir>
#include <QTimer>
#include <QElapsedTimer>
namespace hep {
class RootService final:public QObject {
    Q_OBJECT
public:
    explicit RootService(QObject* parent=nullptr);
    ~RootService()override;
    void start();void restart();void shutdown();void cancel();void crash();
    bool request(const std::string& operation,const Json& payload);
    bool busy()const{return !requestId_.empty();}
    QString state()const{return state_;}
    QString stage()const{return stage_;}
    const Json& capability()const{return capability_;}
    const Json& result()const{return result_;}
    QString error()const{return error_;}
    QString diagnostics()const{return diagnostics_;}
    std::string operation()const{return operation_;}
    void configure(QString python,QString script,std::string backend={}){python_=std::move(python);script_=std::move(script);expectedBackend_=std::move(backend);}
    void configureCommand(QString program,QStringList arguments,std::string expectedBackend){program_=std::move(program);arguments_=std::move(arguments);expectedBackend_=std::move(expectedBackend);}
    void configureEnvironment(QProcessEnvironment overrides){environmentOverrides_=std::move(overrides);}
    const Json& metrics()const{return metrics_;}
    Json transportMetrics()const{return {{"controlSentBytes",controlSentBytes_},{"controlReceivedBytes",controlReceivedBytes_},{"diagnosticReceivedBytes",diagnosticReceivedBytes_},{"resultBytes",resultBytes_}};}
signals:
    void changed();void finished(bool success,bool cancelled);
private:
    bool send(Json);
    void read();void fail(const QString&,bool cancelled=false);
    void frame(const Json&);
    QProcess process_;QTemporaryDir temporary_;QTimer startup_,watchdog_,cancelTimer_,partialTimer_;
    QElapsedTimer heartbeat_;QByteArray buffer_;
    QString python_,script_,state_{"Stopped"},stage_,error_,diagnostics_,resultPath_;
    QString program_;QStringList arguments_;std::string expectedBackend_;
    QProcessEnvironment environmentOverrides_;
    QByteArray resultBuffer_;unsigned resultSequence_{0};bool chunked_{false};
    std::uint64_t controlSentBytes_{},controlReceivedBytes_{},diagnosticReceivedBytes_{},resultBytes_{};
    Json metrics_=Json::object();
    Json capability_=Json::object(),result_=Json::object();
    std::string requestId_,operation_;
    bool shutting_{false},cancelling_{false},restartRequested_{false};
};
}
