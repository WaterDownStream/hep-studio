#include "runtime/root/service.hpp"
#include "core/analysis/analysis.hpp"
#include <QCoreApplication>
#include <QStandardPaths>
#include <QProcessEnvironment>
#include <QFile>
#include <QtEndian>
namespace hep {
RootService::RootService(QObject* parent):QObject(parent){
    for(auto* timer:{&startup_,&cancelTimer_,&partialTimer_})timer->setSingleShot(true);
    connect(&startup_,&QTimer::timeout,this,[this]{fail("Scientific capability detection timed out (30 s)");process_.kill();});
    connect(&partialTimer_,&QTimer::timeout,this,[this]{fail("Incomplete Scientific control frame timed out");process_.kill();});
    connect(&watchdog_,&QTimer::timeout,this,[this]{if(heartbeat_.elapsed()>30000){fail("Scientific worker heartbeat timed out");process_.kill();}});
    connect(&cancelTimer_,&QTimer::timeout,this,[this]{if(busy())process_.kill();});
    connect(&process_,&QProcess::readyReadStandardOutput,this,&RootService::read);
    connect(&process_,&QProcess::readyReadStandardError,this,[this]{const auto bytes=process_.readAllStandardError();if(busy())diagnosticReceivedBytes_+=static_cast<std::uint64_t>(bytes.size());diagnostics_+=QString::fromUtf8(bytes);if(diagnostics_.size()>65536)diagnostics_=diagnostics_.right(65536);emit changed();});
    connect(&process_,&QProcess::errorOccurred,this,[this](QProcess::ProcessError e){if(e==QProcess::FailedToStart){startup_.stop();capability_={{"available",false},{"reason",process_.errorString().toStdString()}};state_="Unavailable";fail(process_.errorString());}});
    connect(&process_,qOverload<int,QProcess::ExitStatus>(&QProcess::finished),this,[this](int,QProcess::ExitStatus){
        read();startup_.stop();watchdog_.stop();partialTimer_.stop();cancelTimer_.stop();state_=shutting_?"Stopped":"Crashed";
        if(busy())fail(cancelling_?"Scientific operation cancelled":"Scientific worker terminated; results are invalid",cancelling_);
        emit changed();
        if(restartRequested_){restartRequested_=false;QTimer::singleShot(0,this,&RootService::start);}
    });
}
RootService::~RootService(){
    disconnect(&process_,nullptr,this,nullptr);shutting_=true;
    if(process_.state()!=QProcess::NotRunning){send({{"kind","shutdown"}});process_.closeWriteChannel();if(!process_.waitForFinished(300)){process_.kill();process_.waitForFinished(700);}}
}
void RootService::start(){
    if(process_.state()!=QProcess::NotRunning)return;
    shutting_=false;cancelling_=false;buffer_.clear();error_.clear();diagnostics_.clear();capability_=Json::object();
    auto python=python_.isEmpty()?qEnvironmentVariable("HEP_ROOT_PYTHON"):python_;
    if(python.isEmpty())python=QStandardPaths::findExecutable("python3");
    if(python.isEmpty())python=QStandardPaths::findExecutable("python");
    auto script=script_.isEmpty()?QCoreApplication::applicationDirPath()+"/root_worker/worker.py":script_;
    if(program_.isEmpty()&&(python.isEmpty()||!QFile::exists(script))){capability_={{"available",false},{"reason","Python runtime or Scientific worker script is unavailable"}};state_="Unavailable";emit changed();return;}
    auto environment=QProcessEnvironment::systemEnvironment();environment.insert("PYTHONUNBUFFERED","1");
    for(const auto& name:environmentOverrides_.keys())environment.insert(name,environmentOverrides_.value(name));
    for(const auto* key:{"OMP_NUM_THREADS","OPENBLAS_NUM_THREADS","MKL_NUM_THREADS"})environment.insert(key,"1");
    process_.setProcessEnvironment(environment);process_.setProgram(program_.isEmpty()?python:program_);process_.setArguments(program_.isEmpty()?QStringList{script}:arguments_);
    state_="Initializing";process_.start();startup_.start(30000);emit changed();
}
void RootService::restart(){if(process_.state()==QProcess::NotRunning)start();else{restartRequested_=true;shutdown();}}
void RootService::shutdown(){
    shutting_=true;state_=process_.state()==QProcess::NotRunning?"Stopped":"Stopping";
    send({{"kind","shutdown"}});process_.closeWriteChannel();emit changed();
    QTimer::singleShot(1000,this,[this]{if(shutting_&&process_.state()!=QProcess::NotRunning)process_.kill();});
}
void RootService::cancel(){if(!busy())return;cancelling_=true;send({{"kind","cancel"},{"id",requestId_}});cancelTimer_.start(1000);stage_="Cancelling";emit changed();}
void RootService::crash(){process_.kill();}
bool RootService::send(Json j){
    j["protocolVersion"]=1;auto bytes=j.dump();if(bytes.size()>1024*1024||process_.state()!=QProcess::Running)return false;
    QByteArray packet(4,'\0');qToBigEndian(static_cast<quint32>(bytes.size()),packet.data());packet.append(bytes.data(),static_cast<qsizetype>(bytes.size()));
    const auto written=process_.write(packet);if(busy()&&written>0)controlSentBytes_+=static_cast<std::uint64_t>(written);
    return written==packet.size();
}
bool RootService::request(const std::string& operation,const Json& payload){
    if(shutting_||state_!="Healthy"||busy()||!capability_.value("available",false)){error_="Scientific worker is unavailable or busy";emit changed();return false;}
    requestId_=newId().value;operation_=operation;result_=Json::object();error_.clear();cancelling_=false;
    resultBuffer_.clear();resultSequence_=0;metrics_=Json::object();controlSentBytes_=controlReceivedBytes_=diagnosticReceivedBytes_=resultBytes_=0;
    resultPath_=temporary_.path()+"/"+QString::fromStdString(requestId_)+".json";state_="Busy";stage_=QString::fromStdString(operation);
    if(!send({{"kind","request"},{"id",requestId_},{"operation",operation},{"payload",payload},{"resultPath",resultPath_.toStdString()},{"resultTransport",chunked_?"chunks":"file"}})){fail("Cannot send scientific request");return false;}
    emit changed();return true;
}
void RootService::read(){
    try{
        while(process_.bytesAvailable()>0){
            const auto room=1024*1024+4-buffer_.size();if(room<=0)throw std::runtime_error("Scientific control buffer limit");
            const auto bytes=process_.read(room);if(busy())controlReceivedBytes_+=static_cast<std::uint64_t>(bytes.size());buffer_+=bytes;
            while(buffer_.size()>=4){auto size=qFromBigEndian<quint32>(buffer_.constData());if(size==0||size>1024*1024)throw std::runtime_error("Scientific frame limit");if(buffer_.size()<static_cast<qsizetype>(size)+4)break;
                auto data=buffer_.mid(4,size);buffer_.remove(0,static_cast<qsizetype>(size)+4);
                auto guard=[](int depth,Json::parse_event_t,Json&){if(depth>64)throw std::runtime_error("Scientific protocol nesting limit");return true;};
                frame(Json::parse(data.constData(),data.constData()+data.size(),guard));
            }
        }
        if(buffer_.isEmpty())partialTimer_.stop();else if(!partialTimer_.isActive())partialTimer_.start(3000);
    }catch(const std::exception& e){fail(QString::fromUtf8(e.what()));process_.kill();}
}
void RootService::frame(const Json& message){
    if(message.at("protocolVersion")!=1)throw std::runtime_error("Scientific protocol mismatch");
    auto kind=message.at("kind").get<std::string>();
    if(kind=="hello"){
        if(state_!="Initializing")throw std::runtime_error("Unexpected Scientific handshake");
        capability_=message.at("capability");state_=capability_.value("available",false)?"Healthy":"Unavailable";
        if(!expectedBackend_.empty()&&capability_.value("backend","")!=expectedBackend_)throw std::runtime_error("Scientific backend handshake mismatch");
        chunked_=message.value("chunkedResults",false);
        startup_.stop();heartbeat_.start();watchdog_.start(1000);emit changed();return;
    }
    if(kind=="heartbeat"){heartbeat_.restart();return;}
    if(!busy()||message.at("id").get<std::string>()!=requestId_)throw std::runtime_error("Scientific request correlation mismatch");
    if(kind=="progress"){stage_=QString::fromStdString(message.at("stage"));metrics_=message.value("metrics",Json::object());emit changed();return;}
    if(kind=="resultChunk"){
        if(!chunked_||message.at("sequence").get<unsigned>()!=resultSequence_++)throw std::runtime_error("Out-of-order scientific result chunks");
        resultBuffer_+=QByteArray::fromStdString(message.at("data").get<std::string>());
        if(resultBuffer_.size()>16*1024*1024)throw std::runtime_error("Scientific result limit");
        return;
    }
    if(kind=="failed"){fail(QString::fromStdString(message.at("message")),message.value("cancelled",false));return;}
    if(kind!="completed")throw std::runtime_error("Unknown Scientific response");
    QByteArray bytes;
    if(chunked_){if(message.at("chunks").get<unsigned>()!=resultSequence_)throw std::runtime_error("Incomplete scientific result");bytes=std::move(resultBuffer_);}
    else {QFile file(resultPath_);if(!file.open(QIODevice::ReadOnly)||file.size()>16*1024*1024)throw std::runtime_error("Scientific result missing or too large");bytes=file.readAll();file.close();file.remove();}
    auto guard=[](int depth,Json::parse_event_t,Json&){if(depth>64)throw std::runtime_error("Scientific result nesting limit");return true;};
    resultBytes_=static_cast<std::uint64_t>(bytes.size());
    result_=Json::parse(bytes.constData(),bytes.constData()+bytes.size(),guard);
    if(!result_.is_object())throw std::runtime_error("Scientific result must be a typed object");
    if(operation_=="inspect"){
        if(!result_.at("objects").is_array())throw std::runtime_error("Invalid Scientific object list");
        for(const auto& object:result_.at("objects")){(void)object.at("path").get<std::string>();(void)object.at("name").get<std::string>();(void)object.at("kind").get<std::string>();}
    }else if(operation_=="schema"){(void)datasetSchema(result_);if(!result_.at("fingerprint").is_object())throw std::runtime_error("Missing dataset identity");}
    else if(operation_=="preview"){if(!result_.at("rows").is_array()||!result_.at("columns").is_array()||result_.at("rows").size()>500)throw std::runtime_error("Invalid bounded preview");}
    else if(operation_=="execute"){
        if(!result_.at("results").is_object())throw std::runtime_error("Invalid Scientific result collection");
        for(const auto& result:result_.at("results")){(void)result.at("kind").get<std::string>();}
    }else if(operation_=="histogram"){if(result_.at("kind")!="Histogram1D"||!result_.at("edges").is_array()||!result_.at("values").is_array())throw std::runtime_error("Invalid histogram result");}
    requestId_.clear();state_=shutting_?"Stopping":"Healthy";cancelTimer_.stop();emit changed();emit finished(true,false);
}
void RootService::fail(const QString& message,bool cancelled){
    error_=message;cancelTimer_.stop();const bool had=busy();requestId_.clear();
    if(state_=="Busy")state_="Healthy";
    emit changed();if(had)emit finished(false,cancelled);
}
}
