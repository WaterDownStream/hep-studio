#include "runtime/ipc/channel.hpp"
#include "runtime/ipc/stdio_device.hpp"
#include <memory>
#include "core/compiler/compiler.hpp"
#include "core/project/project.hpp"
#include <QCoreApplication>
#include <QLocalSocket>
#include <QTimer>
#include <optional>
int main(int argc,char** argv) {
    QCoreApplication app(argc,argv);
    const auto args=app.arguments();
    const bool pipes=args.size()==2 && args[1]=="--stdio";
    if(!pipes && (args.size()!=3 || args[1]!="--endpoint")) return 2;
    const auto token=qEnvironmentVariable("HEP_WORKER_TOKEN").toStdString();
    if(token.empty())return 3;
    QLocalSocket socket;socket.setReadBufferSize(static_cast<qint64>(hep::ipc::maxFrame+4));
    std::unique_ptr<hep::ipc::StdioDevice> stdio;
    if(pipes)stdio=std::make_unique<hep::ipc::StdioDevice>();
    hep::ipc::Channel channel(pipes?static_cast<QIODevice*>(stdio.get()):static_cast<QIODevice*>(&socket));
    std::optional<hep::ipc::StartJob> job;
    std::optional<hep::ExecutionPlan> plan;
    QTimer timer,heartbeat,startup;int done=0;
    startup.setSingleShot(true);
    QObject::connect(&startup,&QTimer::timeout,&app,[&]{app.exit(4);});startup.start(5000);
    auto send=[&](const hep::ipc::Message& message){if(!channel.send(message))app.exit(5);};
    auto handshake=[&]{startup.stop();send(hep::ipc::Hello{token,{"hep.mock/1"},"0.1.0"});heartbeat.start(500);};
    QObject::connect(&socket,&QLocalSocket::connected,&app,handshake);
    if(pipes)QObject::connect(stdio.get(),&hep::ipc::StdioDevice::inputClosed,&app,&QCoreApplication::quit);
    QObject::connect(&socket,&QLocalSocket::disconnected,&app,[&]{app.quit();});
    QObject::connect(&socket,&QLocalSocket::errorOccurred,&app,[&](auto){app.exit(6);});
    QObject::connect(&heartbeat,&QTimer::timeout,&app,[&]{send(hep::ipc::Heartbeat{hep::ipc::utcNow()});});
    QObject::connect(&channel,&hep::ipc::Channel::protocolError,&app,[&](const QString&){app.exit(7);});
    QObject::connect(&channel,&hep::ipc::Channel::received,&app,[&](const hep::ipc::Message& message){
        if(const auto* m=std::get_if<hep::ipc::StartJob>(&message)) {
            if(job) {send(hep::ipc::JobFailed{m->jobId,"busy","Worker is busy",false});return;}
            try {
                if(m->threads!=1)throw std::invalid_argument("Phase 0 mock worker requires one allocated thread");
                plan=hep::MockLowerer{}.lower(hep::workflowFromJson(m->workflow));
                job=*m;done=0;
                send(hep::ipc::Log{hep::ipc::utcNow(),"Info","mock-worker",m->jobId,"","Executing mock plan; steps are lifecycle ticks, not simulated events."});
                send(hep::ipc::Progress{m->jobId,0,m->steps,"mock-plan"});timer.start(m->intervalMs);
            } catch(const std::exception& e) {send(hep::ipc::JobFailed{m->jobId,"validation",e.what(),false});}
        } else if(const auto* cancel=std::get_if<hep::ipc::CancelJob>(&message)) {
            if(job && cancel->jobId==job->jobId) {
                timer.stop();send(hep::ipc::JobFailed{job->jobId,"cancelled","Mock job cancelled; no scientific output was produced.",true});job.reset();plan.reset();
            }
        } else {app.exit(8);}
    });
    QObject::connect(&timer,&QTimer::timeout,&app,[&]{
        if(!job)return;
        ++done;send(hep::ipc::Progress{job->jobId,done,job->steps,"mock-plan"});
        if(done==job->steps) {
            timer.stop();hep::Json nodes=hep::Json::array();
            for(const auto& id : plan->orderedNodes) nodes.push_back(id.value);
            send(hep::ipc::JobCompleted{job->jobId,{{"mockOnly",true},{"valid",true},{"partial",false},{"completedSteps",done},{"validatedNodeIds",nodes},{"scientificOutputs",hep::Json::array()}}});
            job.reset();plan.reset();
        }
    });
    if(pipes)QTimer::singleShot(0,&app,handshake);else socket.connectToServer(args[2]);
    return app.exec();
}
