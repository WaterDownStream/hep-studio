#pragma once
#include "core/vpir/model.hpp"
#include <variant>
namespace hep::ipc {
inline constexpr int protocolVersion=1;
inline constexpr std::size_t maxFrame=1024*1024;
struct Hello { std::string token; std::vector<std::string> capabilities; std::string version; };
struct StartJob { std::string jobId; Json workflow; int steps; int intervalMs; unsigned threads; std::string seed; };
struct CancelJob { std::string jobId; };
struct Progress { std::string jobId; int done; int total; std::string stage; };
struct Log { std::string timestamp,severity,subsystem,jobId,nodeId,message; };
struct JobCompleted { std::string jobId; Json result; };
struct JobFailed { std::string jobId,code,message; bool cancelled; };
struct Heartbeat { std::string timestamp; };
using Message=std::variant<Hello,StartJob,CancelJob,Progress,Log,JobCompleted,JobFailed,Heartbeat>;
Json encode(const Message&);
Message decode(const Json&);
std::string utcNow();
}
