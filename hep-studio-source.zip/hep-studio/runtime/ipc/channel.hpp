#pragma once
#include "runtime/ipc/protocol.hpp"
#include <QObject>
#include <QIODevice>
#include <QPointer>
#include <QTimer>
namespace hep::ipc {
// Framing depends on QIODevice, not on local sockets: future transports reuse the codec.
class Channel final : public QObject {
    Q_OBJECT
public:
    explicit Channel(QIODevice* device,QObject* parent=nullptr);
    bool send(const Message&);
signals:
    void received(const hep::ipc::Message& message);
    void protocolError(const QString& reason);
private:
    void read();
    QPointer<QIODevice> device_;
    QByteArray buffer_;
    bool failed_{false};
    QTimer partialDeadline_;
};
}
