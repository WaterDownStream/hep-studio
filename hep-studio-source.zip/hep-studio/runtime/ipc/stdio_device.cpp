#include "runtime/ipc/stdio_device.hpp"
#include "runtime/ipc/protocol.hpp"
#include <algorithm>
#include <cstring>
#ifdef _WIN32
#ifndef NOMINMAX
#define NOMINMAX
#endif
#include <windows.h>
#else
#include <poll.h>
#include <unistd.h>
#include <cerrno>
#endif
namespace hep::ipc {
StdioDevice::StdioDevice(QObject* parent):QIODevice(parent){
    open(QIODevice::ReadWrite|QIODevice::Unbuffered);
    connect(&poll_,&QTimer::timeout,this,&StdioDevice::pollInput);poll_.start(5);
}
qint64 StdioDevice::readData(char* out,qint64 maximum){
    const auto count=std::min(maximum,static_cast<qint64>(buffer_.size()));
    std::memcpy(out,buffer_.constData(),static_cast<std::size_t>(count));buffer_.remove(0,count);return count;
}
qint64 StdioDevice::writeData(const char* data,qint64 length){
    qint64 done=0;
    while(done<length){
#ifdef _WIN32
        DWORD count=0;
        if(!WriteFile(GetStdHandle(STD_OUTPUT_HANDLE),data+done,static_cast<DWORD>(length-done),&count,nullptr))return -1;
#else
        const auto count=::write(STDOUT_FILENO,data+done,static_cast<std::size_t>(length-done));
        if(count<0){if(errno==EINTR)continue;return -1;}
#endif
        if(count==0)return -1;
        done+=static_cast<qint64>(count);
    }return done;
}
void StdioDevice::pollInput(){
    if(buffer_.size()>static_cast<qsizetype>(maxFrame)){poll_.stop();emit inputClosed();return;}
    char chunk[8192];qint64 count=0;
#ifdef _WIN32
    DWORD available=0,received=0;
    const auto handle=GetStdHandle(STD_INPUT_HANDLE);
    if(!PeekNamedPipe(handle,nullptr,0,nullptr,&available,nullptr)){poll_.stop();emit inputClosed();return;}
    if(available==0)return;
    if(!ReadFile(handle,chunk,std::min(available,static_cast<DWORD>(sizeof(chunk))),&received,nullptr)){poll_.stop();emit inputClosed();return;}
    count=received;
#else
    pollfd descriptor{STDIN_FILENO,POLLIN,0};
    const auto ready=::poll(&descriptor,1,0);
    if(ready<0){if(errno==EINTR)return;poll_.stop();emit inputClosed();return;}
    if(ready==0)return;
    count=::read(STDIN_FILENO,chunk,sizeof(chunk));
    if(count<0&&errno==EINTR)return;
#endif
    if(count<=0){poll_.stop();emit inputClosed();return;}
    buffer_.append(chunk,static_cast<qsizetype>(count));emit readyRead();
}
}
