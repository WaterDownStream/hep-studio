#include "runtime/ipc/protocol.hpp"
#include <QDateTime>
#include <stdexcept>
#include <charconv>
#include <cstdint>
namespace hep::ipc {
std::string utcNow() { return QDateTime::currentDateTimeUtc().toString(Qt::ISODateWithMs).toStdString(); }
Json encode(const Message& message) {
    Json j={{"protocolVersion",protocolVersion}};
    std::visit([&](const auto& m) {
        using T=std::decay_t<decltype(m)>;
        if constexpr(std::is_same_v<T,Hello>) j.update({{"kind","Hello"},{"token",m.token},{"capabilities",m.capabilities},{"version",m.version}});
        else if constexpr(std::is_same_v<T,StartJob>) j.update({{"kind","StartJob"},{"jobId",m.jobId},{"workflow",m.workflow},{"steps",m.steps},{"intervalMs",m.intervalMs},{"threads",m.threads},{"seed",m.seed}});
        else if constexpr(std::is_same_v<T,CancelJob>) j.update({{"kind","CancelJob"},{"jobId",m.jobId}});
        else if constexpr(std::is_same_v<T,Progress>) j.update({{"kind","Progress"},{"jobId",m.jobId},{"done",m.done},{"total",m.total},{"stage",m.stage}});
        else if constexpr(std::is_same_v<T,Log>) j.update({{"kind","Log"},{"timestamp",m.timestamp},{"severity",m.severity},{"subsystem",m.subsystem},{"jobId",m.jobId},{"nodeId",m.nodeId},{"message",m.message}});
        else if constexpr(std::is_same_v<T,JobCompleted>) j.update({{"kind","JobCompleted"},{"jobId",m.jobId},{"result",m.result}});
        else if constexpr(std::is_same_v<T,JobFailed>) j.update({{"kind","JobFailed"},{"jobId",m.jobId},{"code",m.code},{"message",m.message},{"cancelled",m.cancelled}});
        else if constexpr(std::is_same_v<T,Heartbeat>) j.update({{"kind","Heartbeat"},{"timestamp",m.timestamp}});
    },message); return j;
}
Message decode(const Json& j) {
    if (!j.is_object() || j.at("protocolVersion")!=protocolVersion) throw std::invalid_argument("Unsupported worker protocol version");
    auto string=[&](const char* field) { auto value=j.at(field).get<std::string>(); if (value.size()>16384) throw std::invalid_argument("Message string too long"); return value; };
    auto integer=[&](const char* field,int min,int max) { const auto& v=j.at(field); if (!v.is_number_integer()) throw std::invalid_argument("Expected integer"); auto x=v.get<long long>(); if(x<min||x>max) throw std::invalid_argument("Message number outside range"); return static_cast<int>(x); };
    auto job=[&] { return Id(string("jobId")).value; };
    const auto kind=string("kind");
    if (kind=="Hello") {
        auto caps=j.at("capabilities").get<std::vector<std::string>>();
        if (caps.size()>64) throw std::invalid_argument("Too many capabilities");
        return Hello{string("token"),caps,string("version")};
    }
    if (kind=="StartJob") {
        auto seed=string("seed");std::uint64_t parsed=0;
        auto [end,error]=std::from_chars(seed.data(),seed.data()+seed.size(),parsed);
        if(error!=std::errc{} || end!=seed.data()+seed.size())throw std::invalid_argument("Seed must be an unsigned 64-bit decimal integer");
        return StartJob{job(),j.at("workflow"),integer("steps",1,100000),integer("intervalMs",1,1000),static_cast<unsigned>(integer("threads",1,4096)),seed};
    }
    if (kind=="CancelJob") return CancelJob{job()};
    if (kind=="Progress") {
        auto done=integer("done",0,100000),total=integer("total",1,100000);
        if(done>total) throw std::invalid_argument("Progress exceeds total");
        return Progress{job(),done,total,string("stage")};
    }
    if (kind=="Log") {
        auto severity=string("severity");
        if(severity!="Info"&&severity!="Warning"&&severity!="Error") throw std::invalid_argument("Invalid log severity");
        return Log{string("timestamp"),severity,string("subsystem"),string("jobId"),string("nodeId"),string("message")};
    }
    if (kind=="JobCompleted") { if (!j.at("result").is_object()) throw std::invalid_argument("Expected result object"); return JobCompleted{job(),j.at("result")}; }
    if (kind=="JobFailed") return JobFailed{job(),string("code"),string("message"),j.at("cancelled").get<bool>()};
    if (kind=="Heartbeat") return Heartbeat{string("timestamp")};
    throw std::invalid_argument("Unknown worker message");
}
}
