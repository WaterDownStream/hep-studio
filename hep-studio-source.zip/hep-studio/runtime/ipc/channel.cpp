#include "runtime/ipc/channel.hpp"
#include <QtEndian>
#include <stdexcept>
namespace hep::ipc {
Channel::Channel(QIODevice* device,QObject* parent) : QObject(parent),device_(device) {
    partialDeadline_.setSingleShot(true);partialDeadline_.setInterval(2000);
    connect(&partialDeadline_,&QTimer::timeout,this,[this]{failed_=true;emit protocolError("Incomplete control frame timed out");});
    connect(device,&QIODevice::readyRead,this,&Channel::read);
    QMetaObject::invokeMethod(this,[this]{read();},Qt::QueuedConnection);
}
bool Channel::send(const Message& m) {
    if (failed_ || !device_ || !device_->isWritable()) return false;
    const auto bytes=encode(m).dump();
    if (bytes.size()>maxFrame) return false;
    QByteArray frame(4, '\0'); qToBigEndian(static_cast<quint32>(bytes.size()),frame.data());
    frame.append(bytes.data(),static_cast<qsizetype>(bytes.size()));
    if (device_->bytesToWrite()>static_cast<qint64>(maxFrame*2)) return false;
    return device_->write(frame)==frame.size();
}
void Channel::read() {
    if (failed_ || !device_) return;
    try {
        while (device_->bytesAvailable()>0) {
            const auto room=static_cast<qint64>(maxFrame+4)-buffer_.size();
            if (room<=0) throw std::invalid_argument("IPC receive buffer limit exceeded");
            buffer_.append(device_->read(room));
            while (buffer_.size()>=4) {
                auto size=qFromBigEndian<quint32>(buffer_.constData());
                if (size==0 || size>maxFrame) throw std::invalid_argument("Invalid IPC frame length");
                if (buffer_.size()<static_cast<qsizetype>(size)+4) break;
                auto payload=buffer_.mid(4,size); buffer_.remove(0,static_cast<qsizetype>(size)+4);
                auto guard=[](int depth,Json::parse_event_t,Json&) { if(depth>64) throw std::invalid_argument("IPC nesting limit exceeded"); return true; };
                const auto message=decode(Json::parse(payload.constData(),payload.constData()+payload.size(),guard));
                emit received(message);
                if (failed_ || !device_) return;
            }
        }
        if(buffer_.isEmpty())partialDeadline_.stop();else if(!partialDeadline_.isActive())partialDeadline_.start();
    } catch (const std::exception& e) { failed_=true; buffer_.clear(); emit protocolError(QString::fromUtf8(e.what())); }
}
}
