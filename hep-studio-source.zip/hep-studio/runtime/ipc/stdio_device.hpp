#pragma once
#include <QIODevice>
#include <QTimer>
namespace hep::ipc {
// Child-side anonymous pipes. A nonblocking readiness check avoids input threads.
class StdioDevice final : public QIODevice {
    Q_OBJECT
public:
    explicit StdioDevice(QObject* parent=nullptr);
    bool isSequential() const override{return true;}
    qint64 bytesAvailable() const override{return buffer_.size()+QIODevice::bytesAvailable();}
signals:
    void inputClosed();
protected:
    qint64 readData(char*,qint64) override;
    qint64 writeData(const char*,qint64) override;
private:
    void pollInput();
    QByteArray buffer_;
    QTimer poll_;
};
}
