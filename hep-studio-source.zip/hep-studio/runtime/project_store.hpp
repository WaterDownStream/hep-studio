#pragma once
#include "core/project/project.hpp"
#include <QString>
namespace hep {
void saveProject(const Project&,const QString& path);
Project loadProject(const QString& path);
QString workflowHash(const Json& snapshot);
}
