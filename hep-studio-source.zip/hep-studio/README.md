# HEP Studio — Research Pipeline (Part 4, frozen release candidate)

Part 4 is complete under the 2026-10-04 scope freeze. Release candidate:
`part4-rc1`. See [closure evidence](docs/developer/part4-closure.md) and
[STATUS.md](STATUS.md). General UFO, NLO and matching/merging are deferred;
Windows/WSL and macOS host acceptance remain UNVERIFIED. Part 5 is not started.

A C++23 / Qt 6 visual scientific workbench with a real, optional ROOT backend.
ROOT runs in an isolated Python worker. The UI and core build without ROOT.
The original Phase 0 mock graphs remain available for architecture testing.
Part 3 adds an optional native collider worker and a no-code leading-jet workflow.
Part 4 adds real MadGraph/LHE shower/Delphes reconstruction, explicit systematic
templates, RooFit/RooStats/HistFactory and immutable parameter scans.
See STATUS.md for honest platform and completion status.

External host acceptance instructions:
[Windows 11 / WSL2](docs/WINDOWS_WSL_ACCEPTANCE.md) and
[macOS](docs/MACOS_ACCEPTANCE.md). Both platforms remain unverified pending actual
host runs; the source archive includes the harness and Linux evidence.

## What you can do

- Inspect ROOT directories, trees, ntuples and stored histograms; preview bounded samples.
- Build dimension-checked observables and nested filters without typing conventional code.
- Execute lazy RDataFrame graphs: Define, Filter, Count, Mean, Sum, Min/Max, Histo1D.
- Fit Gaussian, exponential and low-order polynomial models; inspect uncertainties and covariance.
- Plot, zoom, pan, compare compatible Runs, and export PNG/PDF independently of ROOT canvases.
- Manage workflows and undo graph edits; save/reopen complete provenance and results.
- Recover from worker failure and relink moved datasets without changing historical Runs.

- Generate real PYTHIA events; cluster with FastJet; select leading jets and histogram their pT.
- Inspect bounded events/ancestry/constituents; store and reuse real HepMC3 samples.
- Discover/evaluate LHAPDF sets, compare environments, and export reference C++.
- Generate a typed MadGraph → shower → detector → reconstructed dimuon analysis.
- Inspect/relink identified detector cards, fit reconstructed distributions and
  perform explicit template inference with recorded statistical assumptions.
- Run unit-aware scans with stage reuse, recover committed points, and inspect
  native diagnostic/scan plots. Three executed research examples are included.

## Build

Requirements: CMake >= 3.24, a compiler accepting C++23 (GCC 13, Clang 16,
AppleClang 15, MSVC 2022 or newer), Qt >= 6.4 with Core, Network, Gui, Qml,
Quick, QuickControls2 and Test. nlohmann/json 3.12.0 headers and their license
are included, so the build does not fetch C++ dependencies.

```sh
cmake -S . -B build -DCMAKE_BUILD_TYPE=Debug
cmake --build build --config Debug --parallel 3
ctest --test-dir build -C Debug --output-on-failure
```

Run `build/bin/hep-studio` (`hep-studio.exe` on Windows). Keep `hep-worker`
beside it and keep the generated `root_worker/` directory beside both. A Qt SDK install may require `-DCMAKE_PREFIX_PATH=/path/to/Qt/6.x/<kit>`.
Use a Visual Studio developer shell on Windows. This is a developer build,
not a self-contained installer.

For the Qt-free core:

```sh
cmake -S . -B build-core -DHEP_BUILD_DESKTOP=OFF -DHEP_BUILD_RUNTIME=OFF
cmake --build build-core --parallel 3
ctest --test-dir build-core --output-on-failure
```

Build switches: `HEP_BUILD_DESKTOP`, `HEP_BUILD_RUNTIME`, `HEP_BUILD_TESTS`,
`HEP_WARNINGS_AS_ERRORS`. Desktop depends on runtime. The CMake presets offer
Ninja-based `dev` and `core-only` configurations.

### Ubuntu 24.04 dependencies

```sh
sudo apt install build-essential cmake ninja-build qt6-base-dev qt6-declarative-dev \
  qml6-module-qtqml qml6-module-qtqml-models qml6-module-qtqml-workerscript \
  qml6-module-qtquick qml6-module-qtquick-window qml6-module-qtquick-controls \
  qml6-module-qtquick-layouts qml6-module-qtquick-dialogs qml6-module-qtquick-templates
```

### Headless smoke test

```sh
QT_QPA_PLATFORM=offscreen QT_QUICK_BACKEND=software build/bin/hep-studio --smoke-test
```

`--screenshot /absolute/path/shell.png` captures the actual Qt window for QA;
it is not an illustration. The smoke test loads QML, launches the real mock
worker, completes and cancels jobs, kills/restarts the worker, saves/reopens a project
and checks all four run records.

## ROOT runtime (optional)

Use a Python interpreter with PyROOT from a ROOT installation. Launching the app
reports the detected ROOT version and runtime path. Set `HEP_ROOT_PYTHON` to an
absolute Python executable if automatic `python3`/`python` discovery is unsuitable.
The child inherits `PYTHONPATH` and the ROOT environment from the launching shell.
The adapter was tested with ROOT 6.40.00. Older ROOT versions may lack RNTuple APIs;
TTree remains the baseline. Missing ROOT produces an explicit unavailable state.

For reproducible **development tests**, Linux CI installs `ROOT==0.1a12` from PyPI.
This wheel identifies itself as alpha and is not a production distribution.
No ROOT binary or Python environment is bundled in this repository archive.

```sh
python tests/root/fixtures.py sample.root 10000
```

Follow the [ROOT Studio walkthrough](docs/user/root-studio.md). The fixture has
known px/py values and explicit GeV metadata, so the pT preset can be checked.
Run `python tests/root/benchmark.py sample.root` for repeatable local timings.

## Structure

| Module | Responsibility |
| --- | --- |
| `core/types`, `core/units` | Stable identities, primitives, dimensions, quantities |
| `core/vpir`, `core/graph`, `core/validation` | Typed graph and structural checks |
| `core/compiler`, `core/analysis`, `core/editing` | Lowering, structured AST, schema, hashes and commands |
| `core/project`, `core/run_model` | Canonical JSON and historical snapshots |
| `runtime/ipc` | Typed protocol variants and bounded transport framing |
| `runtime/coordinator`, `runtime/worker` | Process lifecycle and jobs |
| `runtime/root`, `plugins/root` | Async service, isolated ROOT worker, RDataFrame adapter |
| `core/research`, `plugins/research`, `plugins/madgraph`, `plugins/delphes` | Typed research stages, systematic/scan contracts, isolated subprocesses, RooFit/RooStats/templates |
| `render/plots` | ROOT-independent QPainter histogram rendering |
| `runtime/resource_broker` | Hardware inventory and resource leases |
| `apps/desktop` | Qt Quick shell and core/runtime bridge |
| `sdk/schemas` | Project and protocol JSON schemas |
| `tests` | Core, process integration and desktop smoke tests |

See [STATUS.md](STATUS.md) for exact verification and remaining work,
[architecture overview](docs/architecture/overview.md),
[user walkthrough](docs/user/root-studio.md), and
[architecture decisions](docs/adr/README.md).

The source archive is a developer handoff, not a platform installer. See STATUS.md for tested platforms and limits.

## Optional collider SDK

Configure `HEP_SCIENCE_PREFIX` for PYTHIA/HepMC3/LHAPDF headers and libraries.
FastJet and ROOT can share that prefix or use explicit `HEP_FASTJET_INCLUDE`,
`HEP_FASTJET_LIBRARY`, `HEP_ROOT_INCLUDE`, `HEP_ROOT_CORE`, `HEP_ROOT_HIST` paths.
Set `HEP_PYTHIA_DATA` if xmldoc lives outside `<prefix>/share/Pythia8/xmldoc`.
CMake detects the ROOT C++ standard; `HEP_COLLIDER_CXX_STANDARD` overrides it.
`HEP_BUILD_COLLIDER_ENGINE=OFF` explicitly omits native scientific dependencies.
Missing libraries leave core/GUI buildable and capability visibly unavailable.

Keep `collider_worker/` beside the desktop executable. `HEP_COLLIDER_PYTHON`
selects its interpreter; `HEP_COLLIDER_ENGINE` can select an alternate native
engine for development. There is no automatic science dependency download.
`scripts/build_collider_sdk.py` is an explicit maintainer source-build recipe;
`packaging/wsl/` contains an unverified image recipe, not an end-user installer.

Follow [Collider Studio](docs/user/collider-studio.md). Architecture and limitations
are in [collider-runtime](docs/architecture/collider-runtime.md) and
[Windows/WSL](docs/platform/windows-wsl.md). Reproducible benchmarks are in
`tests/collider/benchmark.py`; actual measurements are committed under
`docs/developer/collider-benchmark.json`.

## Optional research SDK

The pinned development recipe records source commits/checksums and compiler
metadata. It needs an existing ROOT installation and Fortran compiler:

```sh
python3 scripts/build_research_sdk.py --prefix /path/to/research-sdk \
  --cache /path/to/source-archives --root-prefix /path/to/ROOT \
  --fortran /path/to/gfortran --jobs 2
```

Inspect the recipe and verification evidence before executing it. `--offline`
uses already verified cached archives. Choose the resulting `research-sdk.json`
through **Research → Runtime → Select SDK**. Keep `research_worker/` and
`collider_worker/` beside the desktop. The archive contains source/evidence and
rebuild recipes, not compiled scientific dependencies or a production SDK.

Follow [Research Studio](docs/user/research-studio.md) and
[executed examples](examples/README.md). Adapter boundaries and supported subsets
are in [research architecture](docs/architecture/research-pipeline.md),
[MadGraph](docs/backends/madgraph.md), [Delphes](docs/backends/delphes.md) and
[statistics](docs/backends/statistics.md). Linux numerical/offscreen evidence
does not imply Windows/WSL or macOS host validation. No Part 5 work has started.
