# Third-party dependencies

- Vendored `third_party/nlohmann/`: JSON for Modern C++, version 3.12.0,
  copyright 2013–2025 Niels Lohmann, MIT. See `nlohmann-LICENSE` and individual
  header notices. Headers were sourced from the nlohmann_json 3.12.0 package.
- Qt 6: external build/runtime dependency, not included in this source archive.
  Refer to the installed Qt distribution's module-specific license terms and
  notices when preparing binary redistribution.
- CMake and test toolchains are external build tools and are not bundled.

No scientific backend libraries are linked. Phase 0 does not settle licensing
for future HEP plugins or public binary distribution. The project's own public
release license remains a maintainer decision; no rights in third-party code
are changed by this source package.
