import importlib.util,json,subprocess,sys,tempfile,unittest
from pathlib import Path
from unittest.mock import patch
from types import SimpleNamespace

REPO=Path(__file__).resolve().parents[2]
def module(name,path):
    spec=importlib.util.spec_from_file_location(name,REPO/path);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m
locality=module('locality','scripts/wsl/locality_probe.py')
native=module('native','scripts/acceptance/native_receipt.py')
def response_writer(directory,text):
    def run(arguments,timeout=240):
        if Path(arguments[0]).name=='hep-host-acceptance':(Path(directory)/'worker-acceptance.json').write_text(text)
        return {'exitCode':0}
    return run

class HarnessContracts(unittest.TestCase):
    def test_wrong_host_is_unverified(self):
        with tempfile.TemporaryDirectory() as tmp,patch.object(native.platform,'system',return_value='Linux'):
            args=['native','--bin-directory',tmp,'--repository',str(REPO),'--output-directory',tmp,'--required-platform','Darwin']
            with patch.object(sys,'argv',args):self.assertEqual(native.main(),1)
            receipt=json.loads((Path(tmp)/'macos-acceptance.json').read_text())
            self.assertEqual(receipt['status'],'UNVERIFIED');self.assertEqual(receipt['automatedStatus'],'FAIL')
            self.assertEqual(receipt['tests'],[]);self.assertIn('Wrong host',receipt['error'])
    def test_command_failure_and_timeout_are_visible(self):
        self.assertIsNone(native.command(['/no/such/program'])['exitCode'])
        result=native.command([sys.executable,'-c','import time; time.sleep(5)'],timeout=.02)
        self.assertIsNone(result['exitCode']);self.assertIn('error',result)
    def test_preview_configuration_does_not_mutate_fixture(self):
        original=json.loads((REPO/'examples/collider-workflow.json').read_text());before=json.dumps(original,sort_keys=True)
        changed,source=locality.source_workflow(original,25)
        self.assertEqual(json.dumps(original,sort_keys=True),before)
        self.assertEqual(source['config']['events'],25);self.assertEqual(source['config']['workers'],1)
        self.assertEqual(source['config']['streamPolicy'],'logical-blocks-v2');self.assertIsNot(changed,original)
    def test_transfer_checksum_and_wrong_wsl_host(self):
        with tempfile.TemporaryDirectory() as tmp:
            path=Path(tmp)/'fixture';path.write_bytes(b'physics')
            import hashlib
            self.assertEqual(locality.checksum(path),hashlib.sha256(b'physics').hexdigest())
            class Args:
                events=25;transfer_mib=1;native_root=Path(tmp);mounted_root=Path(tmp)/'other';require_wsl=True
            Args.mounted_root.mkdir()
            with patch.object(locality.platform,'release',return_value='6.0-linux'):
                with self.assertRaisesRegex(ValueError,'actual WSL kernel'):locality.run(Args)
    def test_automated_pass_does_not_certify_platform(self):
        with tempfile.TemporaryDirectory() as tmp,patch.object(native.platform,'system',return_value='Linux'):
            args=['native','--bin-directory',tmp,'--repository',str(REPO),'--output-directory',tmp,'--required-platform','Linux']
            with patch.object(sys,'argv',args),patch.object(native,'command',side_effect=response_writer(tmp,json.dumps({'status':'UNVERIFIED','automatedStatus':'PASS'}))),patch.object(native.subprocess,'run',return_value=SimpleNamespace(returncode=0,stdout='',stderr='')):
                self.assertEqual(native.main(),0)
            receipt=json.loads((Path(tmp)/'linux-acceptance.json').read_text())
            self.assertEqual(receipt['automatedStatus'],'PASS');self.assertEqual(receipt['status'],'UNVERIFIED')
            self.assertEqual(receipt['interactiveUiAcceptance'],'UNVERIFIED')
    def test_missing_receipt_is_failure(self):
        with tempfile.TemporaryDirectory() as tmp,patch.object(native.platform,'system',return_value='Linux'):
            (Path(tmp)/'worker-acceptance.json').write_text(json.dumps({'automatedStatus':'PASS'}))
            args=['native','--bin-directory',tmp,'--repository',str(REPO),'--output-directory',tmp,'--required-platform','Linux']
            with patch.object(sys,'argv',args),patch.object(native,'command',return_value={'exitCode':0}),patch.object(native.subprocess,'run',return_value=SimpleNamespace(returncode=0,stdout='',stderr='')):
                self.assertEqual(native.main(),1)
            self.assertIn('Missing worker',json.loads((Path(tmp)/'linux-acceptance.json').read_text())['tests'][0]['error'])
    def test_corrupt_receipt_is_recorded_as_failure(self):
        with tempfile.TemporaryDirectory() as tmp,patch.object(native.platform,'system',return_value='Linux'):
            args=['native','--bin-directory',tmp,'--repository',str(REPO),'--output-directory',tmp,'--required-platform','Linux']
            with patch.object(sys,'argv',args),patch.object(native,'command',side_effect=response_writer(tmp,'{incomplete')),patch.object(native.subprocess,'run',return_value=SimpleNamespace(returncode=0,stdout='',stderr='')):
                self.assertEqual(native.main(),1)
            receipt=json.loads((Path(tmp)/'linux-acceptance.json').read_text());self.assertEqual(receipt['status'],'UNVERIFIED')
            self.assertIn('Invalid worker',receipt['tests'][0]['error'])

if __name__=='__main__':unittest.main()
