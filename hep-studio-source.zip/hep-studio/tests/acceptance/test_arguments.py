"""Verify literal native argv without a shell or installed scientific SDK."""
import json,subprocess,sys
cases=['C:\\HEP space\\trailing\\','quote"inside','literal$()','','unicode-π']
result=subprocess.run([sys.argv[1],'--echo-arguments',*cases],capture_output=True,text=True,encoding='utf-8',timeout=10)
if result.returncode or json.loads(result.stdout)!=cases:
    raise AssertionError('Native argument transport changed literal values: '+result.stderr)
print('PASS literal native argv, including quotes, trailing slash, empty and Unicode')
