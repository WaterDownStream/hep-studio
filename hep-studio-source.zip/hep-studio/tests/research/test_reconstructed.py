"""Deterministic reconstructed-object mapping, not a detector-response simulation.

Known Delphes class records exercise ROOT/RDataFrame and the adapter numerically.
Detector-response validation is independently recorded by validate_reference.py.
"""
import importlib.util,json,math,os,subprocess,sys,tempfile,threading
from pathlib import Path
REPO=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(REPO/'plugins/research'))
import reconstruction,transparency
spec=importlib.util.spec_from_file_location('root_adapter',REPO/'plugins/root/backend.py');root=importlib.util.module_from_spec(spec);spec.loader.exec_module(root)
def main():
    try:root.initialize()
    except ImportError:print('SKIP ROOT is not installed');return 77
    sdk=Path(os.environ.get('HEP_DELPHES_PATH',''))
    if not os.environ.get('HEP_DELPHES_PATH') or not (sdk/'libDelphes.so').exists():print('SKIP Delphes SDK is not installed');return 77
    R=root.ROOT;R.gInterpreter.AddIncludePath(str(sdk));R.gInterpreter.AddIncludePath(str(sdk/'external'))
    if R.gSystem.Load(str(sdk/'libDelphes.so'))<0:raise RuntimeError('Installed Delphes dictionaries are incompatible')
    assert R.gInterpreter.Declare(r'''
#include "classes/DelphesClasses.h"
#include <TFile.h>
#include <TTree.h>
#include <TClonesArray.h>
void hep_reco_fixture(const char* path){
 TFile file(path,"RECREATE");TTree tree("Delphes","Deterministic adapter fixture");
 auto* events=new TClonesArray("HepMCEvent");auto* photons=new TClonesArray("Photon");auto* tracks=new TClonesArray("Track");auto* jets=new TClonesArray("Jet");auto* muons=new TClonesArray("Muon");auto* electrons=new TClonesArray("Electron");
 tree.Branch("Event",&events,32000,99);tree.Branch("Photon",&photons,32000,99);tree.Branch("Track",&tracks,32000,99);tree.Branch("Jet",&jets,32000,99);
 tree.Branch("Muon",&muons,32000,99);tree.Branch("Electron",&electrons,32000,99);
 for(int i=0;i<2;++i){events->Clear("C");photons->Clear("C");tracks->Clear("C");jets->Clear("C");muons->Clear("C");electrons->Clear("C");
  auto* e=static_cast<HepMCEvent*>(events->ConstructedAt(0));e->Weight=i?3:2;
  auto* p=static_cast<Photon*>(photons->ConstructedAt(0));p->PT=i?15:10;p->Eta=.2;p->Phi=.3;p->IsolationVar=i?.02:.05;
  auto* t=static_cast<Track*>(tracks->ConstructedAt(0));t->PT=i?11:5;t->Eta=-.1;t->Phi=.4;t->Mass=.139;t->Charge=1;
  if(!i){p=static_cast<Photon*>(photons->ConstructedAt(1));p->PT=20;p->Eta=-.2;p->Phi=-.3;p->IsolationVar=.2;t=static_cast<Track*>(tracks->ConstructedAt(1));t->PT=7;t->Eta=.1;t->Phi=-.4;t->Mass=.494;t->Charge=-1;}
  auto* j=static_cast<Jet*>(jets->ConstructedAt(0));j->PT=i?40:30;j->Eta=.1;j->Phi=2.;j->Mass=5.;j->Charge=0;j->BTag=i?0:1;
  if(!i){j=static_cast<Jet*>(jets->ConstructedAt(1));j->PT=35;j->Eta=.2;j->Phi=.31;j->Mass=3.;j->Charge=0;j->BTag=0;}
  auto* m=static_cast<Muon*>(muons->ConstructedAt(0));m->PT=i?30:10;m->Eta=0;m->Phi=i?1:0;m->Charge=-1;m->IsolationVar=.02;
  if(!i){m=static_cast<Muon*>(muons->ConstructedAt(1));m->PT=20;m->Eta=0;m->Phi=std::acos(-1.);m->Charge=1;m->IsolationVar=.03;}
  auto* l=static_cast<Electron*>(electrons->ConstructedAt(0));l->PT=i?25:15;l->Eta=0;l->Phi=i?-1:.5;l->Charge=i?-1:1;l->IsolationVar=.04;
  tree.Fill();
 }tree.Write();file.Close();delete events;delete photons;delete tracks;delete jets;delete muons;delete electrons;
}
''')
    column=lambda n:{'op':'column','name':n}
    def plan(kind,property='pt',selection=None):
        nodes=[{'id':'source','kind':'RecoSource','config':{}},{'id':'objects','kind':kind,'config':{},'input':'source'}]
        parent='objects'
        if selection:nodes.append({'id':'selection','kind':'CollectionFilter','config':{'expression':selection},'input':parent});parent='selection'
        nodes.extend([{'id':'property','kind':'Property','config':{'property':property},'input':parent},{'id':'hist','kind':'Histo1D','config':{'expression':column('value'),'bins':5,'lower':0.,'upper':50.,'normalization':'counts'},'input':'property'}]);return {'nodes':nodes}
    cancel=threading.Event();receipt={}
    with tempfile.TemporaryDirectory(prefix='hep-reco-properties-') as folder:
        path=Path(folder)/'objects.root';R.hep_reco_fixture(str(path))
        photon=plan('Photons');result=reconstruction.analyze(photon,[path],{},root,cancel,lambda _:None)
        h=result['results']['hist'];assert h['entries']==3 and h['values']==[0.,5.,2.,0.,0.] and math.isclose(sum(e*e for e in h['errors']),17.,rel_tol=1e-12)
        isolation={'op':'lt','args':[column('isolation'),{'op':'literal','value':.1,'unit':'1'}]}
        selected=reconstruction.analyze(plan('Photons',selection=isolation),[path],{},root,cancel,lambda _:None)['results']['hist'];assert selected['entries']==2 and sum(selected['values'])==5.
        track=reconstruction.analyze(plan('Tracks'),[path],{},root,cancel,lambda _:None)['results']['hist'];assert track['entries']==3 and track['values']==[4.,3.,0.,0.,0.]
        btag={'op':'gt','args':[column('btag'),{'op':'literal','value':0,'unit':'1'}]}
        jetplan=plan('Jets',selection=btag);jet=reconstruction.analyze(jetplan,[path],{},root,cancel,lambda _:None)['results']['hist'];assert jet['entries']==1 and sum(jet['values'])==2.
        overlap={'nodes':[{'id':'source','kind':'RecoSource','config':{}},{'id':'jets','kind':'Jets','input':'source','config':{}},{'id':'photons','kind':'Photons','input':'source','config':{}},
                         {'id':'clean','kind':'OverlapRemoval','input':'jets','reference':'photons','config':{'radius':.1,'boundary':'strict-less-than'}},
                         {'id':'property','kind':'Property','input':'clean','config':{'property':'pt'}},plan('Jets')['nodes'][-1]]}
        cleaned_result=reconstruction.analyze(overlap,[path],{},root,cancel,lambda _:None);cleaned=cleaned_result['results']['hist']
        assert cleaned['entries']==2 and cleaned['values']==[0.,0.,0.,2.,3.] and math.isclose(sum(e*e for e in cleaned['errors']),13.,rel_tol=1e-12)
        assert cleaned_result['metrics']['rdfEventLoops']==1 and cleaned_result['metrics']['bulkEventsThroughIPC']==0
        branching=json.loads(json.dumps(overlap));branching['nodes'][3:3]=[
            {'id':'reference-count','kind':'CollectionCount','input':'photons','config':{}},
            {'id':'reference-events','kind':'Filter','input':'reference-count','config':{'expression':{'op':'gt','args':[column('value'),{'op':'literal','value':1.,'unit':'1'}]}}},
            {'id':'selected-events','kind':'Count','input':'reference-events','config':{}}]
        branched=reconstruction.analyze(branching,[path],{},root,cancel,lambda _:None)
        assert branched['results']['hist']['values']==cleaned['values'] and branched['results']['selected-events']['value']==1 and branched['metrics']['rdfEventLoops']==1
        changed=json.loads(json.dumps(overlap));changed['nodes'].insert(3,{'id':'reference-cut','kind':'CollectionFilter','input':'photons','config':{'expression':{'op':'gt','args':[column('pt'),{'op':'literal','value':12.,'unit':'GeV'}]}}});changed['nodes'][4]['reference']='reference-cut'
        varied=reconstruction.analyze(changed,[path],{},root,cancel,lambda _:None)['results']['hist'];assert varied['entries']==3 and varied['values']==[0.,0.,0.,4.,3.]
        zero=json.loads(json.dumps(overlap));zero['nodes'][3]['config']['radius']=0.;assert reconstruction.analyze(zero,[path],{},root,cancel,lambda _:None)['results']['hist']['entries']==3
        R.gInterpreter.Declare(r'''bool hep_overlap_boundaries(){
          hep_reco::Objects a{{10.,0.,0.,0.,0.,0}},b{{10.,.125,0.,0.,0.,0}};
          if(hep_reco::remove_overlaps(a,b,.125).size()!=1||!hep_reco::remove_overlaps(a,b,.126).empty())return false;
          a[0].phi=3.13;b[0].eta=0.;b[0].phi=-3.13;
          return hep_reco::remove_overlaps(a,b,.03).empty()&&hep_reco::remove_overlaps(a,{},.4).size()==1&&hep_reco::remove_overlaps({},b,.4).empty();}''')
        assert R.hep_overlap_boundaries()
        combine={'nodes':[{'id':'source','kind':'RecoSource','config':{}},{'id':'muons','kind':'Muons','input':'source','config':{}},{'id':'electrons','kind':'Electrons','input':'source','config':{}},
                         {'id':'combined','kind':'CollectionCombine','input':'muons','reference':'electrons','config':{'order':'primary-then-reference','duplicates':'source-object-once'}},
                         {'id':'property','kind':'Property','input':'combined','config':{'property':'pt'}},plan('Jets')['nodes'][-1]]}
        combined=reconstruction.analyze(combine,[path],{},root,cancel,lambda _:None)['results']['hist'];assert combined['entries']==5 and combined['values']==[0.,4.,5.,3.,0.] and math.isclose(sum(e*e for e in combined['errors']),30.,rel_tol=1e-12)
        duplicate=json.loads(json.dumps(combine));duplicate['nodes'][2]={'id':'selected-muons','kind':'CollectionFilter','input':'muons','config':{'expression':{'op':'gt','args':[column('pt'),{'op':'literal','value':12.,'unit':'GeV'}]}}};duplicate['nodes'][3]['reference']='selected-muons'
        deduplicated=reconstruction.analyze(duplicate,[path],{},root,cancel,lambda _:None)['results']['hist'];assert deduplicated['entries']==3 and deduplicated['values']==[0.,2.,2.,3.,0.] and math.isclose(sum(e*e for e in deduplicated['errors']),17.,rel_tol=1e-12)
        pairs=json.loads(json.dumps(combine));pairs['nodes'].insert(4,{'id':'pairs','kind':'Pairs','input':'combined','config':{'oppositeSign':True,'sameFlavour':True}});pairs['nodes'][5].update(input='pairs',config={'property':'mass'});pairs['nodes'][6]['config'].update(bins=10,upper=100.)
        same_flavour=reconstruction.analyze(pairs,[path],{},root,cancel,lambda _:None)['results']['hist'];assert same_flavour['entries']==1 and same_flavour['values']==[0.,0.,2.,0.,0.,0.,0.,0.,0.,0.]
        mixed=json.loads(json.dumps(pairs));mixed['nodes'][4]['config']['sameFlavour']=False
        mixed_pairs=reconstruction.analyze(mixed,[path],{},root,cancel,lambda _:None)['results']['hist'];assert mixed_pairs['entries']==2 and mixed_pairs['values']==[2.,0.,2.,0.,0.,0.,0.,0.,0.,0.]
        invalid=json.loads(json.dumps(combine));invalid['nodes'][2]['kind']='Jets'
        try:reconstruction.analyze(invalid,[path],{},root,cancel,lambda _:None);raise AssertionError('Incompatible object union was accepted')
        except ValueError as error:assert 'incompatible' in str(error)
        for workflow,expected in ((plan('Photons',selection=isolation),selected),(jetplan,jet),(overlap,cleaned),(changed,varied),(combine,combined),(duplicate,deduplicated),(pairs,same_flavour),(mixed,mixed_pairs)):
            reference=Path(folder)/'reference.py';reference.write_text(transparency.analysis(workflow,[path],{},root,{'fixture':'known-records'}));subprocess.run([sys.executable,str(reference)],cwd=folder,check=True,timeout=30)
            exported=json.loads((Path(folder)/'reference-results.json').read_text())['hist'];assert exported['values']==expected['values'] and exported['errors']==expected['errors']
        # Unsupported structural properties must not turn into fabricated zeros.
        try:reconstruction.analyze(plan('Tracks',selection=isolation),[path],{},root,cancel,lambda _:None);raise AssertionError('Track isolation silently fabricated')
        except ValueError as error:assert 'Unknown column' in str(error)
        assert result['metrics']['rdfEventLoops']==1 and result['metrics']['bulkEventsThroughIPC']==0
        receipt={'status':'VERIFIED','fixture':'Manually specified Delphes class records; not simulated response','ROOT':str(R.gROOT.GetVersion()),'photons':h,'isolatedPhotons':selected,'tracks':track,'taggedJets':jet,'overlapCleanedJets':cleaned,'overlapReferenceVariation':varied,'independentEventFiltersShareOneLoop':True,'combinedLeptons':combined,'deduplicatedMuons':deduplicated,'sameFlavourPairs':same_flavour,'mixedFlavourPairs':mixed_pairs,'strictBoundaryAndWrappedPhi':True,'standaloneMatches':True,'rdfEventLoops':1,'bulkEventsThroughIPC':0}
    (REPO/'docs/developer/part4-reconstructed-validation.json').write_text(json.dumps(receipt,indent=2)+'\n')
    print('PASS real reconstructed photon/track mapping, isolation/btag weights and standalone export');return 0
if __name__=='__main__':
    if '--child' in sys.argv:raise SystemExit(main())
    child=subprocess.run([sys.executable,'-u',str(Path(__file__).resolve()),'--child'],capture_output=True,text=True,timeout=80)
    print(child.stdout,end='');print(child.stderr,end='',file=sys.stderr)
    if child.returncode==77:raise SystemExit(77)
    if child.returncode or 'PASS real reconstructed' not in child.stdout:raise SystemExit('Reconstructed numerical assertions did not complete')
