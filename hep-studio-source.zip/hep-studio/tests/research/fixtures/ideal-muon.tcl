# HEP Studio deterministic ideal-response validation card, not a realistic detector.
# Uses genuine Delphes propagation/efficiency/smearing/writer modules.
set RandomSeed 24680
set ExecutionPath {ParticlePropagator MuonEfficiency MuonMomentumSmearing TreeWriter}
module ParticlePropagator ParticlePropagator {
  set InputArray Delphes/stableParticles
  set OutputArray stableParticles
  set ChargedHadronOutputArray chargedHadrons
  set ElectronOutputArray electrons
  set MuonOutputArray muons
  set Radius 10.0
  set HalfLength 1000.0
  set Bz 0.0
}
module Efficiency MuonEfficiency {
  set InputArray ParticlePropagator/muons
  set OutputArray muons
  set EfficiencyFormula {1.0}
}
module MomentumSmearing MuonMomentumSmearing {
  set InputArray MuonEfficiency/muons
  set OutputArray muons
  set ResolutionFormula {0.0}
}
module TreeWriter TreeWriter {
  add Branch Delphes/allParticles Particle GenParticle
  add Branch MuonMomentumSmearing/muons Muon Muon
}
