"""Real HistFactory with independent Poisson reference and explicit nuisances."""
import copy,importlib.util,json,math,subprocess,sys,tempfile,threading
from pathlib import Path
REPO=Path(__file__).resolve().parents[2];sys.path.insert(0,str(REPO/'plugins/research'))
import templates
spec=importlib.util.spec_from_file_location('root_adapter',REPO/'plugins/root/backend.py');root=importlib.util.module_from_spec(spec);spec.loader.exec_module(root)

def reject(call):
    try:call()
    except (ValueError,KeyError):return
    raise AssertionError('Invalid statistical contract accepted')

def main():
    try:root.initialize()
    except ImportError:print('SKIP ROOT absent');return 77
    if not hasattr(root.ROOT.RooStats,'HistFactory'):print('SKIP HistFactory absent');return 77
    config={'samples':[{'id':r,'role':r,'reference':{'runId':'run-'+r,'nodeId':'hist','inputIdentity':'identified-'+r}} for r in ('signal','background')],'flowPolicy':'exclude-unfolded-flows'}
    inputs={}
    for r,v in [('signal',10.),('background',20.)]:
        h={'kind':'Histogram1D','edges':[0.,1.],'values':[v],'errors':[math.sqrt(v)],'normalization':'counts','yieldMode':'luminosity','dimension':[0,0,0,0]}
        inputs['run-'+r+'/hist']={'runStatus':'Completed','runValid':True,'inputIdentity':'identified-'+r,'histogram':h}
    model={'datasetRole':'background-asimov','muMax':5.,'mcStat':'none','interpolation':'histfactory-default','nuisances':[]}
    inference={'method':'asymptotic-profile-likelihood','testStatistic':'one-sided-qmu','useCLs':True,'confidenceLevel':.95,'points':60}
    hs=templates.template_set(config,inputs);nominal=templates.infer(templates.likelihood(hs,model,root),inference,root,threading.Event())
    assert hs['version']==1 and 'channels' not in hs and hs['identity']==templates.key(hs['samples'])
    assert nominal['valid'],nominal
    # Known-background Asimov: CLs=2*(1-Phi(sqrt(q_mu,A))).
    lo=0.;hi=5.;z=1.959963984540054
    for _ in range(100):
        m=(lo+hi)/2.;q=2*(m*10-20*math.log1p(m*10/20))
        if q<z*z:lo=m
        else:hi=m
    analytic=(lo+hi)/2.;assert abs(nominal['upperLimit']-analytic)<.03
    nuisance={'kind':'normalization','samples':['signal','background'],'correlationGroup':'shared_scale','constraint':'gaussian-standard-normal','variationMeaning':'minus-plus-one-sigma','down':.9,'up':1.1}
    varied=templates.infer(templates.likelihood(hs,{**model,'nuisances':[nuisance]},root),inference,root)
    assert varied['valid'] and varied['upperLimit']>nominal['upperLimit'],varied
    assert varied['model']['nuisanceParameters']==['alpha_shared_scale'],varied['model']
    shape_inputs=copy.deepcopy(inputs);hist=shape_inputs['run-signal/hist']['histogram']
    shape_inputs['run-signal/hist']['systematics']={'templates':{'response':{'variations':[{'label':label,'results':{'hist':{**hist,'values':[value],'errors':[math.sqrt(value)]}}} for label,value in [('down',9.),('up',11.)]]}}}
    shape={'kind':'shape','samples':['signal'],'correlationGroup':'response','constraint':'gaussian-standard-normal','variationMeaning':'minus-plus-one-sigma','systematicId':'response','downLabel':'down','upLabel':'up'}
    shape_result=templates.infer(templates.likelihood(templates.template_set(config,shape_inputs),{**model,'nuisances':[shape]},root),inference,root)
    assert shape_result['valid'] and shape_result['upperLimit']>nominal['upperLimit']
    assert shape_result['model']['nuisanceParameters']==['alpha_response']
    gamma=templates.infer(templates.likelihood(hs,{**model,'mcStat':'poisson-gamma','mcStatAssumption':'independent-effective-counts'},root),inference,root)
    assert gamma['valid'] and gamma['upperLimit']>nominal['upperLimit'],gamma
    # Two distinct bins audit the binned likelihood, rather than only a
    # one-bin normalization implemented through the shape endpoint API.
    binned=copy.deepcopy(inputs)
    for r,values in [('signal',[10.,5.]),('background',[20.,30.])]:
        binned['run-'+r+'/hist']['histogram'].update(edges=[0.,1.,2.],values=values,errors=[math.sqrt(v) for v in values])
    binned_result=templates.infer(templates.likelihood(templates.template_set(config,binned),model,root),inference,root)
    lo=0.;hi=5.
    for _ in range(100):
        m=(lo+hi)/2.;q=sum(2*(m*s-b*math.log1p(m*s/b)) for s,b in zip([10.,5.],[20.,30.]))
        if q<z*z:lo=m
        else:hi=m
    binned_analytic=(lo+hi)/2.;assert binned_result['valid'] and abs(binned_result['upperLimit']-binned_analytic)<.03
    h=binned['run-signal/hist']['histogram']
    binned['run-signal/hist']['systematics']={'templates':{'response':{'variations':[{'label':label,'results':{'hist':{**h,'values':values,'errors':[math.sqrt(v) for v in values]}}} for label,values in [('down',[9.,6.]),('up',[11.,4.])]]}}}
    binned_shape=templates.infer(templates.likelihood(templates.template_set(config,binned),{**model,'nuisances':[shape]},root),inference,root)
    assert binned_shape['valid'] and abs(binned_shape['upperLimit']-binned_result['upperLimit'])>1e-5
    # Independent categories may have different observables/bin edges. Their
    # Poisson log-likelihoods add; there is one shared signal-strength POI.
    combined=copy.deepcopy(config);combined['samples']=[];combined['channelIndependence']='disjoint-event-categories';combined_inputs={}
    for channel,sv,bv,edges,dimension in [('electron',[10.],[20.],[0.,1.],[0,0,0,0]),('muon',[5.,8.],[30.,15.],[60.,80.,120.],[1,0,0,0])]:
        for role,values in [('signal',sv),('background',bv)]:
            identity=channel+'_'+role;ref={'runId':'run-'+identity,'nodeId':'hist','inputIdentity':'identified-'+identity}
            combined['samples'].append({'id':identity,'channel':channel,'role':role,'reference':ref})
            combined_inputs[ref['runId']+'/hist']={'runStatus':'Completed','runValid':True,'inputIdentity':ref['inputIdentity'],
                'histogram':{'kind':'Histogram1D','edges':edges,'dimension':dimension,'values':values,'errors':[math.sqrt(v) for v in values],'normalization':'counts','yieldMode':'luminosity'}}
    combined_hs=templates.template_set(combined,combined_inputs)
    combined_result=templates.infer(templates.likelihood(combined_hs,model,root),inference,root)
    lo=0.;hi=5.
    for _ in range(100):
        m=(lo+hi)/2.;q=sum(2*(m*s-b*math.log1p(m*s/b)) for s,b in zip([10.,5.,8.],[20.,30.,15.]))
        if q<z*z:lo=m
        else:hi=m
    combined_analytic=(lo+hi)/2.
    assert combined_result['valid'] and abs(combined_result['upperLimit']-combined_analytic)<.03
    assert [c['id'] for c in combined_result['model']['channels']]==['electron','muon']
    shared={**nuisance,'samples':[s['id'] for s in combined['samples']]}
    shared_result=templates.infer(templates.likelihood(combined_hs,{**model,'nuisances':[shared]},root),inference,root)
    assert shared_result['valid'] and shared_result['model']['nuisanceParameters']==['alpha_shared_scale']
    independent=[{**nuisance,'samples':[s['id'] for s in combined['samples'] if s['channel']==c],'correlationGroup':c+'_scale'} for c in ('electron','muon')]
    independent_result=templates.infer(templates.likelihood(combined_hs,{**model,'nuisances':independent},root),inference,root)
    assert independent_result['valid'] and set(independent_result['model']['nuisanceParameters'])=={'alpha_electron_scale','alpha_muon_scale'}
    assert abs(shared_result['upperLimit']-independent_result['upperLimit'])>1e-4
    reject(lambda:templates.template_set({k:v for k,v in combined.items() if k!='channelIndependence'},combined_inputs))
    reject(lambda:templates.likelihood(combined_hs,{**model,'datasetRole':'observed-counts'},root))
    reject(lambda:templates.template_set({**combined,'samples':combined['samples']+[{**combined['samples'][0],'id':'duplicate','channel':'other'}]},combined_inputs))
    observed=copy.deepcopy(combined);observed_inputs=copy.deepcopy(combined_inputs)
    for channel,values in [('electron',[20.]),('muon',[30.,15.])]:
        source=next(s for s in combined['samples'] if s['channel']==channel and s['role']=='background');identity=channel+'_data'
        ref={'runId':'run-'+identity,'nodeId':'hist','inputIdentity':'identified-'+identity}
        observed['samples'].append({'id':identity,'channel':channel,'role':'observed','reference':ref})
        observed_inputs[ref['runId']+'/hist']={**copy.deepcopy(combined_inputs[source['reference']['runId']+'/hist']),'inputIdentity':ref['inputIdentity']}
    observed_result=templates.infer(templates.likelihood(templates.template_set(observed,observed_inputs),{**model,'datasetRole':'observed-counts'},root),inference,root)
    assert observed_result['valid'] and abs(observed_result['upperLimit']-combined_result['upperLimit'])<1e-8
    reject(lambda:templates.likelihood(hs,{**model,'mcStat':'poisson-gamma'},root))
    reject(lambda:templates.likelihood(hs,{**model,'nuisances':[{**nuisance,'constraint':'auto'}]},root))
    reject(lambda:templates.likelihood(hs,{**model,'nuisances':[{**nuisance,'samples':['unknown']}]},root))
    reject(lambda:templates.likelihood(hs,{**model,'nuisances':[nuisance,nuisance]},root))
    for field,value in [('edges',[0.,2.]),('values',[-1.])]:
        bad=copy.deepcopy(inputs);bad['run-signal/hist']['histogram'][field]=value;reject(lambda:templates.template_set(config,bad))
    bad=copy.deepcopy(inputs);bad['run-signal/hist']['runStatus']='Interrupted';reject(lambda:templates.template_set(config,bad))
    bad=copy.deepcopy(inputs);bad['run-signal/hist']['histogram']['yieldMode']='raw-weights';reject(lambda:templates.template_set(config,bad))
    reject(lambda:templates.template_set({**config,'samples':[config['samples'][0],{**config['samples'][0],'id':'second','role':'background'}]},inputs))
    plan={'version':1,'backend':'hep.research/1','nodes':[{'id':'templates','kind':'TemplateSet','config':config},{'id':'model','kind':'BinnedLikelihood','input':'templates','config':model},{'id':'limit','kind':'Inference','input':'model','config':inference}]}
    with tempfile.TemporaryDirectory() as folder:
        path=Path(folder)/'reference.py';path.write_text(templates.equivalent_code(plan,inputs))
        exported=subprocess.run([sys.executable,str(path)],cwd=folder,capture_output=True,text=True,timeout=35)
        assert exported.returncode==0,exported.stderr
        result=json.loads((Path(folder)/'reference-inference.json').read_text())['limit']
        assert result['valid'] and abs(result['upperLimit']-nominal['upperLimit'])<1e-8
        plan['nodes'][0]['config']=combined;plan['nodes'][1]['config']={**model,'nuisances':[shared]}
        path.write_text(templates.equivalent_code(plan,combined_inputs));exported=subprocess.run([sys.executable,str(path)],cwd=folder,capture_output=True,text=True,timeout=35)
        assert exported.returncode==0,exported.stderr
        result=json.loads((Path(folder)/'reference-inference.json').read_text())['limit']
        assert result['valid'] and abs(result['upperLimit']-shared_result['upperLimit'])<1e-8
    receipt={'status':'VERIFIED','platform':sys.platform,'ROOT':str(root.ROOT.gROOT.GetVersion()),'oneBinPoissonReference':{'signal':10.,'background':20.,'analyticCLs95Limit':analytic,'numericalTolerance':.03},'twoBinPoissonReference':{'analyticCLs95Limit':binned_analytic,'result':binned_result,'shapeResult':binned_shape,'numericalTolerance':.03},'nominal':nominal,'correlatedNormalization':varied,'explicitShape':shape_result,'mcStat':gamma,'standaloneExport':'Executed; numerical limit agrees within 1e-8','limitations':['Sparse-data asymptotic coverage unverified','Gamma constraints assume independent effective MC counts','Single analysis channel','No negative expected bins'],'sources':['https://root.cern.ch/doc/v640/classRooStats_1_1HistFactory_1_1Sample.html','https://root.cern.ch/doc/v640/classRooStats_1_1HistFactory_1_1HistoToWorkspaceFactoryFast.html']}
    receipt['multichannelPoissonReference']={'analyticCLs95Limit':combined_analytic,'numericalTolerance':.03,'result':combined_result,'observedResult':observed_result,'sharedNuisance':shared_result,'independentNuisances':independent_result,'export':'Executed; shared-nuisance limit agrees within 1e-8'}
    receipt['limitations'].remove('Single analysis channel');receipt['limitations'].append('Channel disjointness must be explicitly asserted; arrays cannot establish it')
    (REPO/'docs/developer/part4-template-validation.json').write_text(json.dumps(receipt,indent=2,allow_nan=False)+'\n')
    print('PASS real HistFactory templates, Poisson reference, correlated/shape/gamma nuisances, export and failure contracts');return 0

if __name__=='__main__':
    if '--child' in sys.argv:raise SystemExit(main())
    child=subprocess.run([sys.executable,'-u',str(Path(__file__).resolve()),'--child'],capture_output=True,text=True,timeout=80)
    print(child.stdout,end='');print(child.stderr,end='',file=sys.stderr)
    if child.returncode==77:raise SystemExit(77)
    if child.returncode or 'PASS real HistFactory' not in child.stdout:raise SystemExit('Template scientific test did not complete its assertions')
