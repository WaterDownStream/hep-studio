"""Dependency-free contracts for real subprocess lifelines and artifact recovery."""
import json,os,signal,subprocess,sys,tempfile,threading,time,unittest
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT/'plugins/research'))
from artifacts import ArtifactCache,run_process
import lhe,campaigns
import importlib.util
def adapter(name,path):
    spec=importlib.util.spec_from_file_location(name,path);result=importlib.util.module_from_spec(spec);spec.loader.exec_module(result);return result
MG=adapter("contract_madgraph",ROOT/"plugins/madgraph/backend.py")
DELPHES=adapter("contract_delphes",ROOT/"plugins/delphes/backend.py")

class ResearchContracts(unittest.TestCase):
    def test_identified_model_selection_and_dependent_parameters(self):
        configuration={'process':{'incoming':[-11,11],'outgoing':[-13,13]}}
        self.assertEqual(MG.selected_model(configuration),'sm')
        self.assertEqual(MG.selected_model(dict(configuration,model='sm-full')),'sm-full')
        for model in ('external-model','sm\nquit',None,{},'sm-full; touch unexpected'):
            with self.assertRaises(ValueError):MG.process_text(dict(configuration,model=model))
        card='Block mass\n 6 173 # MT\n## Dependent parameters, given by model restrictions.\n 13 0 # mu- : 0.0\n 24 80.419 # w+ : expression\nBlock sminputs\n 1 1.32507D+02 # aEWM1\nDECAY 6 1.49 # WT\n## Dependent parameters, given by model restrictions.\nDECAY 13 0 # mu- : 0.0\n'
        rows={p['binding']:p for p in MG.parameter_metadata(card)}
        self.assertEqual(rows['sminputs:1']['value'],132.507);self.assertTrue(rows['decay:6']['editable'])
        self.assertFalse(rows['mass:13']['editable']);self.assertFalse(rows['decay:13']['editable'])
        for key in ('mass:13','mass:24','decay:13'):
            with self.assertRaisesRegex(ValueError,'fixed or derived'):MG.parameter_card(card,{key:20.})
        self.assertIn('1.7200000000000000e+02',MG.parameter_card(card,{'mass:6':172.}))
        with self.assertRaisesRegex(ValueError,'Duplicate'):MG.parameter_card('Block mass\n 6 173\n 6 175\n',{'mass:6':172.})
    def test_compiler_selection_precedes_export_and_rejects_fallback(self):
        from unittest.mock import patch
        with tempfile.TemporaryDirectory(prefix='compiler contract ') as folder:
            folder=Path(folder);compiler=folder/'selected compiler';compiler.write_text('#!/bin/sh\nprintf "%s\\n" selected-compiler\n');compiler.chmod(0o700)
            cap={'available':True,'location':str(folder),'version':'contract','compilerVersion':'selected','compilerEntrypointSha256':MG.digest(compiler)}
            configuration={'process':{'incoming':[-11,11],'outgoing':[-13,13]},'events':1}
            def unexpected_export(command,cwd,log,*args,**kwargs):
                environment=kwargs['env'];self.assertEqual(environment['FC'],'gfortran');self.assertNotIn('MAKEFLAGS',environment)
                alias=Path(environment['PATH'].split(os.pathsep)[0])/'gfortran'
                self.assertEqual(subprocess.check_output([str(alias),'--version'],text=True).strip(),'selected-compiler')
                commands=(folder/'commands.mg5').read_text();self.assertLess(commands.index('set fortran_compiler gfortran --no_save'),commands.index('output process'))
                self.assertIn('set auto_update 0 --no_save',commands);self.assertEqual(environment['MADGRAPH_DATA'],str(folder))
                source=folder/'process/Source';source.mkdir(parents=True);(source/'make_opts').write_text('DEFAULT_F_COMPILER=another-compiler\n')
            with patch.object(MG,'capability',return_value=cap),patch.object(MG,'run_process',side_effect=unexpected_export),patch.dict(os.environ,{'HEP_FORTRAN_COMPILER':str(compiler),'MAKEFLAGS':'FC=another-compiler'}):
                with self.assertRaisesRegex(RuntimeError,'did not honor'):MG.generate(configuration,folder)
    def test_parameter_cards_and_unavailable_or_broken_compiler(self):
        from unittest.mock import patch
        text='BLOCK MASS\n 6 1.730000e+02 # top\nDECAY 6 1.491500e+00 # width\n 1.0 2 24 5 # branching fraction\n'
        changed=MG.parameter_card(text,{'mass:6':172.5,'decay:6':1.4})
        self.assertIn('6 1.7250000000000000e+02',changed);self.assertIn('DECAY 6 1.3999999999999999e+00',changed);self.assertIn('1.0 2 24 5',changed)
        for values in ({'unknown:9':1.},{'decay:6':-1.},{'mass:6':float('nan')},{'mass:6':True}):
            with self.assertRaises(ValueError):MG.parameter_card(text,values)
        with tempfile.TemporaryDirectory() as folder:
            folder=Path(folder);(folder/'bin').mkdir();(folder/'bin/mg5_aMC').write_text('# known test entrypoint\n');(folder/'VERSION').write_text('version = contract-test\n');compiler=folder/'compiler';compiler.write_text('#!/bin/sh\nexit 1\n');compiler.chmod(0o700)
            with patch.dict(os.environ,{'HEP_MADGRAPH_PATH':str(folder),'HEP_FORTRAN_COMPILER':str(compiler)}):
                capability=MG.capability();self.assertFalse(capability['available']);self.assertEqual(capability['status'],'Incompatible')
            with patch.dict(os.environ,{'HEP_MADGRAPH_PATH':str(folder),'HEP_FORTRAN_COMPILER':str(folder/'missing')}):self.assertEqual(MG.capability()['status'],'Needs installation')
            model=folder/'models/sm';model.mkdir(parents=True);(model/'parameters.py').write_text('# identified model source\n')
            with patch.dict(os.environ,{'HEP_MADGRAPH_PATH':str(folder),'HEP_FORTRAN_COMPILER':str(compiler)}):
                identity=MG.capability()['scientificSourceSha256'];(model/'py3_model.pkl').write_bytes(b'generated import cache')
                self.assertEqual(MG.capability()['scientificSourceSha256'],identity)
                (model/'parameters.py').write_text('# changed model source\n');self.assertNotEqual(MG.capability()['scientificSourceSha256'],identity)
    def test_card_bundle_change_and_partial_sdk(self):
        from unittest.mock import patch
        with tempfile.TemporaryDirectory() as folder:
            folder=Path(folder);card=folder/'detector.tcl';card.write_text('set Efficiency 0.9\n');extra=folder/'dependency.tcl';extra.write_text('set Resolution 1\n');(folder/'events.bin').write_bytes(b'not a card dependency')
            with patch.object(DELPHES,'capability',return_value={'available':True,'version':'contract-test'}):
                _,identity=DELPHES.detector_card({'card':{'path':str(card)}});self.assertEqual(set(identity['cardDependencies']),{'detector.tcl','dependency.tcl'})
                selected={'path':str(card),'sha256':identity['sha256'],'dependencyChecksums':identity['cardDependencies']};DELPHES.detector_card({'card':selected})
                extra.write_text('set Resolution 2\n')
                with self.assertRaisesRegex(ValueError,'bundle changed'):DELPHES.detector_card({'card':selected})
            with patch.dict(os.environ,{'HEP_DELPHES_PATH':str(folder)}):self.assertEqual(DELPHES.capability()['status'],'Incompatible')
    def test_recorded_card_inspection_is_bounded_and_verified(self):
        if os.name!='posix':self.skipTest('Scientific cache runs in native Unix or managed Linux')
        with tempfile.TemporaryDirectory() as folder:
            cache=ArtifactCache(folder)
            def build(path):
                (path/'card.tcl').write_text('set RandomSeed 17\n');(path/'events.root').write_bytes(b'bulk scientific data');return {'events':1}
            path,manifest,_=cache.stage({'config':'known'},build)
            rows=cache.text_artifacts(manifest['key'],['card.tcl']);self.assertEqual(rows[0]['text'],'set RandomSeed 17\n')
            # Inspecting cards never reads the bulk scientific artifact.
            (path/'events.root').write_bytes(b'changed bulk data')
            self.assertEqual(cache.text_artifacts(manifest['key'],['card.tcl']),rows)
            with self.assertRaises(ValueError):cache.text_artifacts(manifest['key'],['events.root'])
            with self.assertRaises(ValueError):cache.text_artifacts('../escape',['card.tcl'])
            (path/'card.tcl').write_text('set RandomSeed 18\n')
            with self.assertRaises(ValueError):cache.text_artifacts(manifest['key'],['card.tcl'])
    def test_subprocess_exit_cancel_and_parent_death(self):
        if os.name!='posix':self.skipTest('Executed by the managed Unix scientific runtime')
        with tempfile.TemporaryDirectory() as folder:
            folder=Path(folder)
            run_process([sys.executable,'-c','print("normal backend exit")'],folder,folder/'normal.log',timeout=5)
            self.assertIn('normal backend exit',(folder/'normal.log').read_text())
            cancel=threading.Event();timer=threading.Timer(.15,cancel.set);timer.start()
            with self.assertRaises(InterruptedError):run_process([sys.executable,'-c','import time;time.sleep(20)'],folder,folder/'cancel.log',cancel,timeout=5)
            timer.join()
            pidfile=folder/'child.pid';parent_code='import sys;sys.path.insert(0,'+repr(str(ROOT/'plugins/research'))+');from artifacts import run_process;run_process([sys.executable,"-c",'+repr('import os,time;open('+repr(str(pidfile))+',"w").write(str(os.getpid()));time.sleep(30)')+'],'+repr(str(folder))+','+repr(str(folder/'death.log'))+',timeout=40)'
            parent=subprocess.Popen([sys.executable,'-c',parent_code])
            try:
                deadline=time.monotonic()+5
                while not pidfile.exists() and time.monotonic()<deadline:time.sleep(.03)
                self.assertTrue(pidfile.exists());child=int(pidfile.read_text());parent.kill();parent.wait(timeout=3)
                deadline=time.monotonic()+3
                def alive():
                    try:
                        if sys.platform=='linux':return Path('/proc/'+str(child)+'/stat').read_text().split()[2]!='Z'
                        os.kill(child,0);return True
                    except (ProcessLookupError,FileNotFoundError):return False
                while alive() and time.monotonic()<deadline:time.sleep(.03)
                self.assertFalse(alive(),'Scientific child survived worker death')
            finally:
                if parent.poll() is None:parent.kill();parent.wait(timeout=3)
    def test_transaction_corruption_cancellation_and_restart(self):
        if os.name!='posix':self.skipTest('Scientific cache runs in native Unix or managed Linux')
        with tempfile.TemporaryDirectory() as folder:
            cache=ArtifactCache(folder);identity={'physics':'fixed'}
            def build(path):(path/'events').write_bytes(b'complete');return {'eventCount':1}
            path,manifest,reused=cache.stage(identity,build);self.assertFalse(reused)
            path2,_,reused=ArtifactCache(folder).stage(identity,lambda p:self.fail('regenerated completed artifact'));self.assertTrue(reused);self.assertEqual(path,path2)
            (path/'events').write_bytes(b'corrupt')
            with self.assertRaises(ValueError):cache.stage(identity,build)
            cancel=threading.Event()
            def interrupted(path):(path/'events').write_bytes(b'incomplete');cancel.set();return {'eventCount':1}
            with self.assertRaises(InterruptedError):cache.stage({'physics':'new'},interrupted,cancel)
            self.assertFalse(any(Path(folder).glob('.pending-*')))
            def diskfull(path):raise OSError(28,'No space left on device')
            with self.assertRaisesRegex(OSError,'No space left'):cache.stage({'physics':'diskfull'},diskfull)
            self.assertFalse(any(Path(folder).glob('.pending-*')))
            def linked(path):(path/'external').symlink_to(Path(folder)/'unowned')
            with self.assertRaisesRegex(ValueError,'symbolic link'):cache.stage({'physics':'linked'},linked)
    def test_scan_environment_and_failed_points_remain_explicit(self):
        if os.name!='posix':self.skipTest('Managed Unix runtime required')
        with tempfile.TemporaryDirectory() as folder:
            payload={'scanRoot':folder,'scan':{'id':'environment-check','frozenEnvironment':{'id':'expected'}},'points':[{'runId':'point-'+str(i),'workflowSnapshot':{},'scientificHash':'hash-'+str(i),'payload':{'plan':{'backend':'hep.research/1'}}} for i in range(3)]}
            calls=[]
            def execution(point,cancel,progress):
                calls.append(point);self.assertEqual(point['expectedEnvironmentId'],'expected');self.assertEqual(point['environmentPolicy'],'strict')
                return {'valid':True,'environment':{'id':'different' if len(calls)==2 else 'expected'},'results':{'fit':{'kind':'FitResult','valid':False,'status':4}} if len(calls)==3 else {}}
            result=campaigns.run_scan(payload,execution,None,lambda _:None);self.assertFalse(result['valid']);self.assertEqual(result['scan']['state'],'completed-with-failures');self.assertEqual([r['status'] for r in result['pointRuns']],['Completed','Failed','Failed'])
            self.assertEqual(result['pointRuns'][2]['result']['results']['fit']['status'],4)
            receipt=campaigns.recover_scans(folder)[0];self.assertFalse(receipt['complete']);self.assertEqual(receipt['pointRuns'],result['pointRuns']);self.assertEqual(receipt['corruptPoints'],[])
    def test_scan_publication_cancel_and_corruption(self):
        if os.name!='posix':self.skipTest('Managed Unix runtime required')
        with tempfile.TemporaryDirectory() as folder:
            cancel=threading.Event();messages=[]
            points=[{'runId':'point-'+str(i),'workflowSnapshot':{},'scientificHash':'hash-'+str(i),'payload':{'plan':{'backend':'hep.research/1'}}} for i in range(3)]
            payload={'scanRoot':folder,'scan':{'id':'scan-1'},'points':points}
            def execution(payload,cancel,progress):return {'valid':True,'preview':False,'environment':{'id':'frozen-test-environment'},'results':{}}
            def progress(message):
                messages.append(message)
                if 'committedPoint' in message:cancel.set()
            with self.assertRaises(InterruptedError):campaigns.run_scan(payload,execution,cancel,progress)
            receipt=campaigns.recover_scans(folder)[0]
            self.assertEqual(receipt['scan']['state'],'interrupted');self.assertFalse(receipt['complete']);self.assertEqual(len(receipt['pointRuns']),1)
            self.assertEqual(receipt['pointRuns'][0],messages[-1]['committedPoint'])
            cancel.clear();executed=[]
            def remaining(payload,cancel,progress):executed.append(payload);return execution(payload,cancel,progress)
            resumed=campaigns.run_scan({**payload,'resume':True},remaining,cancel,lambda _:None)
            self.assertTrue(resumed['valid']);self.assertEqual(len(executed),2);self.assertEqual(len(resumed['pointRuns']),3)
            point=Path(receipt['scan']['runs'][0]['resultPath']);point.write_text('{}')
            recovered=campaigns.recover_scans(folder)[0];self.assertEqual(len(recovered['pointRuns']),2);self.assertEqual(len(recovered['corruptPoints']),1)
            with self.assertRaises(ValueError):campaigns.run_scan({**payload,'scan':{'id':'../unsafe'}},execution,cancel,progress)
    def test_scan_worker_kill_recovery(self):
        if os.name!='posix':self.skipTest('Managed Unix runtime required')
        with tempfile.TemporaryDirectory() as folder:
            folder=Path(folder);marker=folder/'committed'
            code="""import sys,time,json;sys.path.insert(0,PATH)
import campaigns
payload={'scanRoot':FOLDER,'scan':{'id':'killed'},'points':[{'runId':'r'+str(i),'workflowSnapshot':{},'scientificHash':'h'+str(i),'payload':{'plan':{'backend':'hep.root/1'}}} for i in range(2)]}
def execute(p,c,g):
 if __import__('pathlib').Path(MARKER).exists():time.sleep(30)
 return {'valid':True,'environment':{'id':'fixed'}}
def progress(m):
 if 'committedPoint' in m:__import__('pathlib').Path(MARKER).touch()
campaigns.run_scan(payload,execute,None,progress)
""".replace('PATH',repr(str(ROOT/'plugins/research'))).replace('FOLDER',repr(str(folder))).replace('MARKER',repr(str(marker)))
            worker=subprocess.Popen([sys.executable,'-c',code])
            try:
                deadline=time.monotonic()+5
                while not marker.exists() and time.monotonic()<deadline:time.sleep(.02)
                self.assertTrue(marker.exists());self.assertEqual(campaigns.recover_scans(folder),[],'Live owner must not be recovered')
                worker.kill();worker.wait(timeout=3)
                recovered=campaigns.recover_scans(folder)[0];self.assertEqual(recovered['scan']['state'],'interrupted');self.assertEqual(len(recovered['pointRuns']),1)
            finally:
                if worker.poll() is None:worker.kill();worker.wait(timeout=3)
    def test_incomplete_lhe_cannot_be_materialized(self):
        with tempfile.TemporaryDirectory() as folder:
            path=Path(folder)/'bad.lhe';path.write_text('<LesHouchesEvents>\n<event>\n2 1 1 1 1 1\n')
            with self.assertRaises(ValueError):lhe.blocks(path,folder,25)

if __name__=='__main__':unittest.main()
