"""Real RooFit and RooStats, numerical expectations independent of the adapters."""
import importlib.util,json,math,sys,threading
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT/'plugins/research'))
import statistical
spec=importlib.util.spec_from_file_location('root_adapter',ROOT/'plugins/root/backend.py');root=importlib.util.module_from_spec(spec);spec.loader.exec_module(root)

def main():
    try:root.initialize()
    except ImportError:print('SKIP ROOT is not installed');return 77
    if not hasattr(root.ROOT,'RooStats'):print('SKIP RooStats is not installed');return 77
    edges=[-5+i*.1 for i in range(101)];mean=.4;sigma=1.2;events=50000
    cdf=lambda x:.5*(1+math.erf((x-mean)/(sigma*math.sqrt(2))))
    values=[events*(cdf(b)-cdf(a)) for a,b in zip(edges,edges[1:])]
    hist={'kind':'Histogram1D','edges':edges,'values':values,'errors':[math.sqrt(v) for v in values],'normalization':'counts'}
    config={'model':{'kind':'Gaussian','mean':{'value':0,'lower':-3,'upper':3},'sigma':{'value':1,'lower':.1,'upper':3}},'errorModel':'sumw2'}
    result=statistical.fit(hist,config,root,threading.Event());assert result['valid'],result
    parameters={p['name']:p for p in result['parameters']}
    assert abs(parameters['mean']['value']-mean)<.002
    assert abs(parameters['sigma']['value']-sigma)<.002
    assert result['covarianceStatus']==3 and all(result['covariance'][i][i]>0 for i in range(2))
    model={'signal':10.,'background':20.,'observed':20.,'datasetRole':'asimov','method':'asymptotic-profile-likelihood','testStatistic':'one-sided-qmu','useCLs':True,'confidenceLevel':.95,'muMax':4.,'points':60}
    limit=statistical.counting(model,root);assert limit['valid'],limit
    # For the background Asimov count, CLs=2*(1-Phi(sqrt(q_mu,A))).
    # Thus q_mu,A=z_.975^2. Solve the exact known-b Poisson log likelihood.
    z=1.959963984540054;lo=0.;hi=4.
    for _ in range(100):
        m=(lo+hi)/2;q=2*(m*10-20*math.log1p(m*10/20))
        if q<z*z:lo=m
        else:hi=m
    expected=(lo+hi)/2
    assert abs(limit['upperLimit']-expected)<.03,(limit['upperLimit'],expected)
    assert abs(limit['expectedMedianLimit']-expected)<.03
    discovery=statistical.counting({**model,'observed':30.,'datasetRole':'observed-counts','muMax':6.,'calculateDiscovery':True,'calculateInterval':True},root)
    analytic_z=math.sqrt(2*(30*math.log(30/20)-30+20))
    assert abs(discovery['discovery']['significanceSigma']-analytic_z)<.005,(discovery['discovery'],analytic_z)
    assert discovery['profileInterval']['valid'] and discovery['profileInterval']['lower']<1<discovery['profileInterval']['upper']
    constrained=statistical.counting({**model,'backgroundConstraint':{'kind':'Gaussian','sigma':2.}},root)
    assert constrained['valid'] and constrained['upperLimit']>limit['upperLimit'],constrained
    # A real exponential model: exact-bin expected contents on [0,10].
    exp_edges=[i*.1 for i in range(101)];slope=-.35
    exp_values=[events*(math.exp(slope*a)-math.exp(slope*b))/(1-math.exp(slope*10)) for a,b in zip(exp_edges,exp_edges[1:])]
    exp_hist={**hist,'edges':exp_edges,'values':exp_values,'errors':[math.sqrt(v) for v in exp_values]}
    exp_fit=statistical.fit(exp_hist,{'model':{'kind':'Exponential','slope':{'value':-.2,'lower':-1,'upper':-.01}},'errorModel':'sumw2'},root)
    assert exp_fit['valid'] and abs(exp_fit['parameters'][0]['value']-slope)<.002,exp_fit
    def par(value,lower,upper,**kwargs):return {'value':value,'lower':lower,'upper':upper,**kwargs}
    def fitted(edges,values,model):return statistical.fit({'kind':'Histogram1D','edges':edges,'values':values,'errors':[math.sqrt(v) for v in values],'normalization':'counts'},{'model':model,'errorModel':'sumw2'},root)
    # Breit-Wigner: use its analytic Cauchy bin integrals, not sampled midpoints.
    bw_edges=[-10+i*.2 for i in range(101)];bw_cdf=lambda x:math.atan((x-.7)/1.1)/math.pi+.5
    bw_values=[events*(bw_cdf(b)-bw_cdf(a))/(bw_cdf(10)-bw_cdf(-10)) for a,b in zip(bw_edges,bw_edges[1:])]
    bw_fit=fitted(bw_edges,bw_values,{'kind':'BreitWigner','mean':par(0,-3,3),'width':par(1,.1,5)})
    truth={p['name']:p['value'] for p in bw_fit['parameters']};assert bw_fit['valid'] and abs(truth['mean']-.7)<.003 and abs(truth['width']-2.2)<.003,bw_fit
    # Positive first-order polynomial on [0,10], exact analytic integrals.
    coefficient=.04;norm=10+coefficient*50
    polynomial_values=[events*((b-a)+coefficient*(b*b-a*a)/2)/norm for a,b in zip(exp_edges,exp_edges[1:])]
    poly_fit=fitted(exp_edges,polynomial_values,{'kind':'Polynomial','coefficients':[par(.01,0,.09)]})
    assert poly_fit['valid'] and abs(poly_fit['parameters'][0]['value']-coefficient)<.0005,poly_fit
    # Fixed component shapes with one fitted fraction: tests real RooHistPdf
    # interpolation and Sum, including template ownership lifetimes.
    gauss_template={**hist,'values':values,'errors':[math.sqrt(v) for v in values]}
    uniform=[events/100]*100;uniform_template={**hist,'values':uniform,'errors':[math.sqrt(v) for v in uniform]}
    fraction=.65;mixed=[fraction*a+(1-fraction)*b for a,b in zip(values,uniform)]
    mixture=fitted(edges,mixed,{'kind':'Sum','components':[{'kind':'Histogram','template':gauss_template},{'kind':'Histogram','template':uniform_template}],'fractions':[par(.5,.01,.99)]})
    assert mixture['valid'] and abs(mixture['parameters'][0]['value']-fraction)<.002,mixture
    # Product of a fixed unit Gaussian and exp(a*x) is a Gaussian shifted by a.
    shift=.3;product_cdf=lambda x:.5*(1+math.erf((x-shift)/math.sqrt(2)))
    product_values=[events*(product_cdf(b)-product_cdf(a))/(product_cdf(5)-product_cdf(-5)) for a,b in zip(edges,edges[1:])]
    product=fitted(edges,product_values,{'kind':'Product','components':[{'kind':'Gaussian','mean':par(0,-1,1,constant=True),'sigma':par(1,.5,2,constant=True)},{'kind':'Exponential','slope':par(.1,-1,1)}]})
    assert product['valid'] and abs(product['parameters'][0]['value']-shift)<.002,product
    for fixed in ({'kind':'Histogram','template':hist},{'kind':'Gaussian','mean':par(mean,-3,3,constant=True),'sigma':par(sigma,.1,3,constant=True)}):
        try:fitted(edges,values,fixed);raise AssertionError('Fixed model falsely reported an optimizer fit')
        except ValueError as error:assert 'no floating parameters' in str(error)
    narrowed=statistical.fit(hist,{**config,'range':[-2.,2.]},root);assert narrowed['valid']
    assert all(p is None for i,p in enumerate(narrowed['pulls']) if edges[i]<-2 or edges[i+1]>2),'Pulls outside the fitted range are misleading'
    failed=statistical.fit(hist,{**config,'maximumCalls':1},root);assert not failed['valid'] and not failed['converged'] and failed['warnings'] and failed['status']!=0,failed
    bad={**hist,'values':[-1]+values[1:]}
    try:statistical.fit(bad,config,root);raise AssertionError('Negative statistical template accepted')
    except ValueError:pass
    try:statistical.counting({**model,'observed':20.5,'datasetRole':'observed-counts'},root);raise AssertionError('Weighted noninteger observation silently treated as Poisson count')
    except ValueError:pass
    receipt={'status':'VERIFIED','platform':sys.platform,'ROOT':str(root.ROOT.gROOT.GetVersion()),'gaussianTruth':{'mean':mean,'sigma':sigma},'fit':result,
             'exponentialTruth':slope,'exponentialFit':exp_fit,'breitWignerTruth':{'mean':.7,'width':2.2},'breitWignerFit':bw_fit,'polynomialTruth':coefficient,'polynomialFit':poly_fit,'templateMixtureTruth':fraction,'templateMixtureFit':mixture,'productTruth':shift,'productFit':product,'fixedPdfFitRejected':True,'fitRangePullMaskVerified':True,'discovery':discovery['discovery'],'discoveryAnalyticZ':analytic_z,'profileInterval':discovery['profileInterval'],'gaussianBackgroundConstraintLimit':constrained['upperLimit'],'knownBackgroundPoissonCLs':{'analyticExpectedLimit':expected,'rootObservedLimit':limit['upperLimit'],'rootExpectedMedianLimit':limit['expectedMedianLimit'],'tolerance':.03,'configuration':model},
             'failedNativeOptimizer':failed,'sources':['https://root.cern.ch/doc/v640/rf614__binned__fit__problems_8C.html','https://root.cern.ch/doc/v640/classRooStats_1_1AsymptoticCalculator.html'],
             'limitations':['Asymptotic coverage is not established for sparse data','ROOT SDK is alpha','Gaussian validation uses exact-bin Asimov content','No production detector validation']}
    (ROOT/'docs/developer/part4-statistics-validation.json').write_text(json.dumps(receipt,indent=2)+'\n')
    print('PASS real RooFit exact-bin Gaussian recovery and RooStats CLs versus analytic Poisson reference');return 0

if __name__=='__main__':
    # A native library may terminate without raising a Python exception. The
    # parent harness requires the completion marker as well as a zero exit code.
    if '--child' in sys.argv:raise SystemExit(main())
    import subprocess
    child=subprocess.run([sys.executable,'-u',str(Path(__file__).resolve()),'--child'],capture_output=True,text=True,timeout=80)
    print(child.stdout,end='');print(child.stderr,end='',file=sys.stderr)
    if child.returncode==77:raise SystemExit(77)
    if child.returncode or 'PASS real RooFit' not in child.stdout:raise SystemExit('Scientific test did not complete its assertions')
