"""Execute small, identified example workflows using real research backends.

Invoke under hep-benchmark-budget 2; no example scientific results are fabricated.
The template study uses disjoint hard processes and distinct generator/shower/
detector seeds. It is a software demonstration, not an experimental analysis.
"""
import argparse,datetime,json,subprocess,sys,threading
from pathlib import Path
REPO=Path(__file__).resolve().parents[2]
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def main():
    p=argparse.ArgumentParser();p.add_argument('--build',default='build');p.add_argument('--directory',type=Path,required=True);a=p.parse_args();folder=a.directory.resolve();folder.mkdir(parents=True,exist_ok=True)
    build=REPO/a.build;writer=(build/'bin/hep-research-examples').resolve()
    def write(mode):subprocess.run([str(writer),mode,str(folder)],check=True,timeout=30)
    for name in ('template-inference.json','dilepton-result.json','scan-result.json'):(folder/name).unlink(missing_ok=True)
    write('prepare');sys.path.insert(0,str((build/'bin/research_worker').resolve()));import backend
    cap=backend.initialize()
    for lib in ('ROOT','MadGraph','PYTHIA','HepMC3','Delphes','HistFactory'):
        if not cap['libraries'].get(lib,{}).get('available'):raise RuntimeError(lib+' unavailable; cannot validate scientific examples')
    backend.CAPABILITY['cacheRoot']=str(folder/'cache');cancel=threading.Event()
    resources=json.loads(subprocess.check_output([str((build/'bin/hep-benchmark-budget').resolve())],text=True,timeout=10));resources['allocatedThreads']=2
    records={};seeds=[]
    for specification in json.loads((folder/'template-specifications.json').read_text()):
        role=specification['role'];started=now();result=backend.execute({**specification,'projectSeed':'42','allocatedThreads':2},cancel,lambda _:None)
        hist=next(h for h in result['results'].values() if h.get('kind')=='Histogram1D')
        assert result['valid'] and result['metrics']['inputEvents']==1000 and result['metrics']['bulkEventsThroughIPC']==0 and hist['entries']>0
        assert hist['yieldMode']=='luminosity' and sum(hist['values'])>0
        actual=[]
        for stage in result['stages']:
            if stage['kind']=='Shower':actual.extend(p['seed'] for p in stage['logicalPartitions'])
            if stage['kind']=='Delphes':actual.extend(p['metadata']['actualSeed'] for p in stage['logicalPartitions'])
        seeds.append(set(actual));records[role]={'started':started,'ended':now(),'result':result,'resources':resources}
    assert not seeds[0]&seeds[1],'Example samples share a generator/detector logical seed'
    records_path=folder/'template-results.json';records_path.write_text(json.dumps(records,allow_nan=False)+'\n');write('finalize')
    model=json.loads((folder/'template-model-specification.json').read_text());records['inferenceStarted']=now()
    inference=backend.execute({**model,'projectSeed':'42','allocatedThreads':2},cancel,lambda _:None);records['inferenceEnded']=now()
    hypothesis=next(v for v in inference['results'].values() if v.get('kind')=='HypothesisResult');assert hypothesis['valid'],hypothesis
    records_path.write_text(json.dumps(records,allow_nan=False)+'\n');(folder/'template-inference.json').write_text(json.dumps(inference,allow_nan=False)+'\n');write('finalize')
    dilepton=json.loads((folder/'dilepton-specification.json').read_text());started=now();response=backend.execute({**dilepton,'projectSeed':'42','allocatedThreads':2},cancel,lambda _:None)
    (folder/'dilepton-result.json').write_text(json.dumps({'started':started,'ended':now(),'resources':resources,'result':response},allow_nan=False)+'\n')
    fit=next(v for v in response['results'].values() if v.get('kind')=='FitResult');assert fit['valid'] and fit['covarianceStatus']==3,fit
    parameters={p['name']:p['value'] for p in fit['parameters']};assert abs(parameters['mean']-100)<1 and .1<parameters['sigma']<3
    import campaigns
    specification=json.loads((folder/'scan-specification.json').read_text());specification['scanRoot']=str(folder/'scans');specification['scan']['id']='example-cut-scan-'+datetime.datetime.now().strftime('%Y%m%d%H%M%S')
    scanned=campaigns.run_scan(specification,backend.execute,cancel,lambda _:None)
    assert scanned['valid'] and len(scanned['pointRuns'])==3
    integrals=[]
    for point in scanned['pointRuns']:
        assert point['status']=='Completed' and point['result']['metrics']['bulkEventsThroughIPC']==0
        assert all(stage.get('cacheReused',all(p.get('cacheReused',False) for p in stage.get('logicalPartitions',[]))) for stage in point['result']['stages']),'Cut scan regenerated invariant upstream stages'
        integrals.append(sum(next(h for h in point['result']['results'].values() if h.get('kind')=='Histogram1D')['values']))
    assert all(a>=b for a,b in zip(integrals,integrals[1:])) and integrals[0]>integrals[-1]
    (folder/'scan-result.json').write_text(json.dumps(scanned,allow_nan=False)+'\n');write('finalize')
    receipt={'status':'VERIFIED','environment':cap['environment'],'eventCountPerSample':1000,'sampleProcesses':{r:v['result']['stages'][0]['metadata']['process'] for r,v in records.items() if r in ('signal','background')},
             'histograms':{r:next(h for h in v['result']['results'].values() if h.get('kind')=='Histogram1D') for r,v in records.items() if r in ('signal','background')},'hypothesis':hypothesis,'dileptonFit':fit,
             'scan':{'axes':scanned['scan']['axes'],'state':scanned['scan']['state'],'pointRuns':[p['id'] for p in scanned['pointRuns']],'yields':integrals,'upstreamStagesReused':True},
             'seedIndependence':'Distinct configured and actual shower/detector streams audited across samples','limitations':['Software/reference study; not experimental physics inference','1000-event samples have finite MC uncertainty','Asymptotic sparse-bin/boundary coverage unverified','ROOT alpha SDK','Native Windows/macOS execution unverified']}
    (REPO/'docs/developer/part4-examples-validation.json').write_text(json.dumps(receipt,indent=2,allow_nan=False)+'\n')
    for name in ('research-dilepton.hep.json','research-scan.hep.json','research-template-study.hep.json'):
        (REPO/'examples'/name).write_bytes((folder/name).read_bytes())
    print('PASS real signal/background HistFactory, reconstructed RooFit and three-point cached scan examples')
if __name__=='__main__':main()
