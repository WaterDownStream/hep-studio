"""Optional real SM-parameter scan and deliberate Fortran compilation failure.

Run under hep-benchmark-budget 2 with the verified research SDK configured.
This is a numerical reference, separate from ordinary dependency-free CI.
"""
import argparse,datetime,json,math,os,shlex,subprocess,sys,threading
from pathlib import Path
REPO=Path(__file__).resolve().parents[2]
def main():
    p=argparse.ArgumentParser();p.add_argument('--build',default='build');p.add_argument('--directory',type=Path,required=True);a=p.parse_args();folder=a.directory.resolve();folder.mkdir(parents=True,exist_ok=True);build=(REPO/a.build).resolve()
    subprocess.run([str(build/'bin/hep-research-examples'),'model-reference',str(folder)],check=True,timeout=30)
    sys.path.insert(0,str(build/'bin/research_worker'));import backend,campaigns
    cap=backend.initialize()
    for lib in ('MadGraph','ROOT','PYTHIA','HepMC3','Delphes'):
        if not cap['libraries'].get(lib,{}).get('available'):raise RuntimeError(lib+' unavailable; cannot validate model scan')
    cancel=threading.Event();spec=json.loads((folder/'model-reference-specification.json').read_text());spec['scanRoot']=str(folder/'scans');spec['scan']['id']='model-reference-'+datetime.datetime.now().strftime('%Y%m%d%H%M%S');spec['scan']['frozenEnvironment']=cap['environment'];backend.CAPABILITY['cacheRoot']=str(folder/'cache'/spec['scan']['id'])
    result=campaigns.run_scan(spec,backend.execute,cancel,lambda _:None);assert result['valid'] and len(result['pointRuns'])==3
    rows=[]
    for index,run in enumerate(result['pointRuns']):
        value=spec['points'][index]['payload']['plan']['nodes'][0]['config']['parameters']['sminputs:1'];generated=run['result']['stages'][0];metadata=generated['metadata'];observed=metadata['crossSectionPb'];error=metadata['integrationErrorPb']
        expected=4*math.pi/(3*100**2*value**2)*3.893793721e8
        tolerance=max(5*error,.002*expected);assert abs(observed-expected)<tolerance,(observed,expected,tolerance)
        histogram=next(v for v in run['result']['results'].values() if v.get('kind')=='Histogram1D');assert histogram['entries']==20 and math.isclose(sum(histogram['values']),observed,rel_tol=3e-6)
        assert not generated['cacheReused'] and run['result']['metrics']['bulkEventsThroughIPC']==0
        assert metadata['compiler']['entrypointSha256']==cap['libraries']['MadGraph']['compilerEntrypointSha256']
        rows.append({'inverseAlpha':value,'crossSectionPb':observed,'analyticMasslessQEDPb':expected,'tolerancePb':tolerance,'integrationErrorPb':error,'histogramIntegralPb':sum(histogram['values']),'runId':run['id'],'workflowScientificHash':run['workflowHash'],'compiler':metadata['compiler']})
    assert rows[0]['crossSectionPb']>rows[1]['crossSectionPb']>rows[2]['crossSectionPb']
    recovered=campaigns.recover_scans(folder/'scans');receipt=next(r for r in recovered if r['scan']['id']==spec['scan']['id']);assert receipt['complete'] and receipt['pointRuns']==result['pointRuns']
    # A real generated process invokes a deliberately failing compiler wrapper.
    # Its version probe remains genuine; every compile invocation fails. The
    # error must retain diagnostics and never publish a complete LHE artifact.
    original=os.environ['HEP_FORTRAN_COMPILER'];compiler=folder/'failing-gfortran';compiler.write_text('#!/bin/sh\ncase "$1" in --version|-dumpversion|-dumpfullversion) exec '+shlex.quote(original)+' "$@";; esac\nprintf "%s\\n" "Intentional HEP Studio compiler failure" >&2\nexit 23\n');compiler.chmod(0o700)
    from artifacts import ArtifactCache
    cache=ArtifactCache(folder/'verified-compiler-failure-cache');configuration=spec['points'][0]['payload']['plan']['nodes'][0]['config']
    sdk=Path(cap['libraries']['MadGraph']['location']);sdk_files=[sdk/'input/mg5_configuration.txt',sdk/'Template/LO/Source/make_opts'];sdk_before=[backend.MG.digest(p) for p in sdk_files]
    try:
        os.environ['HEP_FORTRAN_COMPILER']=str(compiler)
        try:cache.stage({'reference':'deliberate-compilation-failure','compiler':str(compiler),'adapterSha256':backend.MG.digest(backend.MG.__file__)},lambda path:backend.MG.generate(configuration,path,cancel));raise AssertionError('Deliberate compiler failure reported success')
        except (RuntimeError,FileNotFoundError):pass
    finally:os.environ['HEP_FORTRAN_COMPILER']=original
    assert sdk_before==[backend.MG.digest(p) for p in sdk_files],'Compiler selection changed shared SDK configuration'
    assert not list(cache.root.glob('*/manifest.json'))
    logs=list((cache.root/'failures').rglob('*.log'));assert logs and any('Intentional HEP Studio compiler failure' in p.read_text(errors='replace') for p in logs),'Compilation failure diagnostics were not retained'
    output={'status':'VERIFIED','environment':cap['environment'],'parameter':'SM SLHA sminputs:1 (inverse electromagnetic coupling)','rows':rows,'reference':'4*pi*alpha^2/(3*s), massless photon-only LO, GeV^-2 to pb conversion','toleranceReason':'Five integration standard errors or 0.2%, whichever is larger; lepton masses negligible','seedPolicy':'Fixed seeds/common logical streams across parameter points; not independent statistical samples','scanRecoveryMatches':True,'realCompilationFailureUnpublished':True,'rawCompilationLogsRetained':True,'sharedSDKConfigurationUnchanged':True,'limitations':['LO SM only','Not NLO/UFO validation','ROOT alpha SDK','External Windows/macOS hosts unverified']}
    (REPO/'docs/developer/part4-model-scan-validation.json').write_text(json.dumps(output,indent=2,allow_nan=False)+'\n');print('PASS real SM parameter scan versus analytic QED and unpublished deliberate compiler failure',flush=True)
if __name__=='__main__':
    if '--child' in sys.argv:sys.argv.remove('--child');main()
    else:
        child=subprocess.run([sys.executable,'-u',str(Path(__file__).resolve()),*sys.argv[1:],'--child'],capture_output=True,text=True,timeout=600)
        print(child.stdout,end='');print(child.stderr,end='',file=sys.stderr)
        if child.returncode or 'PASS real SM parameter scan' not in child.stdout:raise SystemExit('Model scan/reference assertions did not complete')
