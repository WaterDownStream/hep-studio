"""Real identified SM variants and finite-mass QED reference; never mock MG."""
import copy,importlib.util,json,math,os,subprocess,sys,tempfile,threading
from pathlib import Path
REPO=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(REPO/'plugins/research'))
spec=importlib.util.spec_from_file_location('model_adapter',REPO/'plugins/madgraph/backend.py')
mg=importlib.util.module_from_spec(spec);spec.loader.exec_module(mg)
from artifacts import ArtifactCache,digest

def validate_events(path,mass,count):
    events=0;lines=iter(path.read_text().splitlines())
    for line in lines:
        if line.strip()!='<event>':continue
        header=next(lines).split();particles=[next(lines).split() for _ in range(int(header[0]))]
        final=[p for p in particles if int(p[1])==1]
        assert sorted(int(p[0]) for p in final)==[-13,13]
        for p in final:
            assert math.isclose(float(p[10]),mass,abs_tol=2e-6)
            px,py,pz,energy=map(float,p[6:10])
            assert math.isclose(energy*energy-px*px-py*py-pz*pz,mass*mass,abs_tol=2e-5)
        incoming=[p for p in particles if int(p[1])==-1]
        for index in range(6,10):assert abs(sum(float(p[index]) for p in incoming)-sum(float(p[index]) for p in final))<2e-6
        events+=1
    assert events==count

def main():
    cap=mg.capability()
    if not cap.get('available'):
        print('SKIP: identified MadGraph/compiler is unavailable');return 77
    configuration={'model':'sm','accuracy':'LO','process':{'incoming':[-11,11],'outgoing':[-13,13],'exclude':[23,25],'orders':{'QED':2,'QCD':0}},
        'beam':{'ids':[-11,11],'energiesGeV':[50.,50.]},'events':20,'seed':24680,'runCard':{'ptl':0.,'etal':-1.,'drll':0.},'parameters':{}}
    sdk=Path(cap['location']);shared=[sdk/'input/mg5_configuration.txt',sdk/'Template/LO/Source/make_opts'];before=[digest(p) for p in shared]
    rows=[];cancel=threading.Event()
    with tempfile.TemporaryDirectory(prefix='hep-model-reference-') as folder:
        cache=ArtifactCache(folder)
        for model,mass,inverse_alpha in [('sm',0.,132.507),('sm-full',20.,132.507),('sm-full',20.,120.)]:
            config=copy.deepcopy(configuration);config['model']=model
            if mass:config['parameters']['mass:13']=mass
            if inverse_alpha!=132.507:config['parameters']['sminputs:1']=inverse_alpha
            path,manifest,reused=cache.stage({'config':config,'environment':cap['scientificSourceSha256']},lambda d:mg.generate(config,d,cancel))
            metadata=manifest['metadata'];assert not reused and metadata['model']['id']==model
            validate_events(path/'events.lhe',mass,20)
            expected=4*math.pi/(3*100**2*inverse_alpha**2)*3.893793721e8*math.sqrt(1-4*mass**2/100**2)*(1+2*mass**2/100**2)
            observed=metadata['crossSectionPb'];tolerance=max(5*metadata['integrationErrorPb'],.002*expected)
            assert abs(observed-expected)<tolerance,(observed,expected,tolerance)
            params={p['binding']:p for p in metadata['model']['effectiveParameters']}
            assert math.isclose(params['mass:13']['value'],mass,abs_tol=1e-12)
            assert params['mass:13']['editable']==bool(mass) and not params['mass:24']['editable']
            assert params['mass:13']['changedFromDefault']==bool(mass)
            card={p['binding']:p for p in mg.parameter_metadata((path/'param_card.dat').read_text())}
            assert all(card[p['binding']]['value']==p['value'] for p in params.values())
            assert ('import model '+model+'\n') in (path/'commands.mg5').read_text()
            _,_,reused=cache.stage({'config':config,'environment':cap['scientificSourceSha256']},lambda _:(_ for _ in ()).throw(AssertionError('regenerated cached model')))
            assert reused
            rows.append({'model':model,'muonMassGeV':mass,'inverseAlpha':inverse_alpha,'crossSectionPb':observed,'analyticFiniteMassQEDPb':expected,
                'integrationErrorPb':metadata['integrationErrorPb'],'tolerancePb':tolerance,'eventCount':metadata['eventCount'],
                'effectiveCardSha256':digest(path/'param_card.dat'),'lheSha256':metadata['sha256'],'modelDependentWMassGeV':params['mass:24']['value']})
        rejected=copy.deepcopy(configuration);rejected['parameters']['mass:13']=20.
        key={'rejectedRestrictedParameter':rejected}
        try:cache.stage(key,lambda d:mg.generate(rejected,d,cancel));raise AssertionError('Restricted mass was accepted')
        except ValueError as error:assert 'fixed or derived' in str(error)
        assert len(list(cache.root.glob('*/manifest.json')))==3
        assert cap['scientificSourceSha256']==mg.capability()['scientificSourceSha256'],'Generated import cache changed scientific source identity'
        assert before==[digest(p) for p in shared],'Model selection modified the shared SDK'
    assert rows[2]['crossSectionPb']>rows[1]['crossSectionPb']
    assert rows[2]['modelDependentWMassGeV']!=rows[1]['modelDependentWMassGeV'],'Effective derived card entry was not refreshed'
    receipt={'status':'VERIFIED','platform':sys.platform,'madgraphVersion':cap['version'],'sourceProvenance':cap['sourceProvenance'],
        'scientificSourceSha256':cap['scientificSourceSha256'],'compilerVersion':cap['compilerVersion'],'compilerEntrypointSha256':cap['compilerEntrypointSha256'],
        'reference':'Photon-only unpolarized LO QED, 4*pi*alpha^2/(3*s) * beta*(1+2*m_mu^2/s)',
        'toleranceReason':'Five integration standard errors or 0.2%; incoming electron mass is negligible at 100 GeV',
        'rows':rows,'restrictedOverrideUnpublished':True,'effectiveCardsMatchProvenance':True,'importCacheExcludedFromSourceIdentity':True,
        'sharedSDKUnchanged':True,'limitations':['Identified bundled SM LO variants only','Common integration seeds; not independent samples','Not NLO/UFO or cross-platform validation']}
    (REPO/'docs/developer/part4-model-selection-validation.json').write_text(json.dumps(receipt,indent=2,allow_nan=False)+'\n')
    print('PASS real MadGraph identified models, massive QED and rejected restricted parameter',flush=True);return 0

if __name__=='__main__':
    if '--child' in sys.argv:raise SystemExit(main())
    child=subprocess.run([sys.executable,'-u',str(Path(__file__).resolve()),'--child'],capture_output=True,text=True,timeout=115)
    print(child.stdout,end='');print(child.stderr,end='',file=sys.stderr)
    if child.returncode==77:raise SystemExit(77)
    if child.returncode or 'PASS real MadGraph identified models' not in child.stdout:raise SystemExit('MadGraph model reference assertions did not complete')
