"""Reproducible research-stage latency/cache benchmark with process-tree monitoring.

Small reference process; no comparison across hardware or production extrapolation.
Use --build build-release to measure the Release native shower engine.
"""
import argparse,copy,datetime,json,os,platform,subprocess,sys,time
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2]

def child(a):
    sys.path.insert(0,str((ROOT/a.build/'bin/research_worker').resolve()))
    import backend
    startup=time.monotonic();cap=backend.initialize();initialization=time.monotonic()-startup
    if not all(cap['libraries'].get(n,{}).get('available') for n in ('ROOT','MadGraph','PYTHIA','HepMC3','Delphes')):raise RuntimeError('Research benchmark requires the real scientific SDK')
    directory=a.directory.resolve();directory.mkdir(parents=True,exist_ok=True);backend.CAPABILITY['cacheRoot']=str(directory/'cache')
    nodes=[('generator','MadGraph',{'model':'sm','accuracy':'LO','process':{'incoming':[-11,11],'outgoing':[-13,13],'exclude':[23]},'beam':{'ids':[-11,11],'energiesGeV':[50.,50.]},'events':a.events,'seed':24680,'runCard':{'ptl':0.,'etal':-1.,'drll':0.},'parameters':{}}),
           ('shower','Shower',{'seedStrategy':'fixed','seed':'731','streamPolicy':'lhe-logical-blocks-v1','partitionEvents':250,'workers':a.workers,'isr':False,'fsr':True,'mpi':False,'hadronisation':False}),
           ('detector','Delphes',{'card':{'builtin':'CMS'},'seed':24680}),('muons','Muons',{}),
           ('pairs','Pairs',{'oppositeSign':True,'sameFlavour':True,'collectionType':'RecoMuonCollection'}),('mass','Property',{'property':'mass','collectionType':'RecoPairCollection'}),
           ('hist','Histo1D',{'expression':{'op':'column','name':'value'},'bins':40,'lower':80.,'upper':120.,'normalization':'counts','flow':'separate','yieldMode':'cross-section-pb'})]
    plan={'version':1,'backend':'hep.research/1','requiredThreads':a.workers,'requiredLibraries':['ROOT','MadGraph','PYTHIA','HepMC3','Delphes'],
          'nodes':[{'id':nid,'kind':kind,'config':c,**({'input':nodes[i-1][0]} if i else {})} for i,(nid,kind,c) in enumerate(nodes)]}
    payload={'plan':plan,'allocatedThreads':a.workers,'projectSeed':'42','scientificHash':'benchmark-reference'}
    timings=[]
    for repeat in range(2):
        started=time.monotonic();result=backend.execute(payload,None,lambda _:None);elapsed=time.monotonic()-started
        timings.append({'case':'cold' if repeat==0 else 'verified-cache','wallSeconds':elapsed,'inputEventsPerSecond':a.events/elapsed,'stages':result['stages'],'metrics':result['metrics'],'histogramEntries':result['results']['hist']['entries']})
    # Keep each sequential campaign under the outer broker lease. These are
    # bounded reference latencies, not event-generation throughput claims.
    extra=[]
    def measure(label,operation):
        started=time.monotonic();answer=operation();elapsed=time.monotonic()-started
        if not answer.get('valid',answer.get('converged',False)):raise RuntimeError(label+' returned an invalid result')
        extra.append({'case':label,'wallSeconds':elapsed});return answer
    histogram=result['results']['hist'];root=backend.ROOT_ADAPTER
    fitted=measure('RooFit Gaussian',lambda:backend.statistical.fit(histogram,{'model':{'kind':'Gaussian','mean':{'value':100.,'lower':90.,'upper':105.},'sigma':{'value':1.,'lower':.01,'upper':10.}},'errorModel':'sumw2'},root))
    inference=measure('RooStats one-bin CLs',lambda:backend.statistical.counting({'signal':10.,'background':20.,'observed':20.,'datasetRole':'asimov','method':'asymptotic-profile-likelihood','testStatistic':'one-sided-qmu','useCLs':True,'confidenceLevel':.95,'muMax':4.,'points':40},root))
    varied=copy.deepcopy(payload);varied['plan']['systematics']=[{'id':'scale','name':'Scale benchmark','kind':'normalization','nominal':1.,'affectedNodes':['hist'],'correlation':{'group':'scale'},'interpretation':'Sensitivity envelope, no prior','variations':[{'label':'down','factor':.9},{'label':'up','factor':1.1}]}]
    measure('two normalization variations with reused event stages',lambda:backend.dispatch({'operation':'execute','payload':varied},None,lambda _:None))
    points=[]
    for i,bins in enumerate((40,50,60)):
        point=copy.deepcopy(payload);point['plan']['nodes'][-1]['config']['bins']=bins;point['scientificHash']=backend.key({'benchmarkPlan':point['plan'],'seed':point['projectSeed']})
        points.append({'runId':'benchmark-point-'+str(i),'workflowSnapshot':{'benchmarkScientificPlan':point['plan']},'scientificHash':point['scientificHash'],'payload':point})
    scanned=measure('three-point analysis scan with reused event stages',lambda:backend.dispatch({'operation':'scan','payload':{'scan':{'id':'benchmark-'+datetime.datetime.now().strftime('%Y%m%d%H%M%S'),'frozenEnvironment':cap['environment']},'points':points}},None,lambda _:None))
    cpu=platform.processor()
    if Path('/proc/cpuinfo').exists():cpu=next(s.split(':',1)[1].strip() for s in Path('/proc/cpuinfo').read_text().splitlines() if s.startswith('model name'))
    cache=directory/'cache';output={'timestamp':datetime.datetime.now(datetime.timezone.utc).isoformat(),'platform':platform.platform(),'cpu':cpu,'hostLogicalCpus':os.cpu_count(),'workerCount':a.workers,'eventCount':a.events,
             'buildType':next((s.split('=',1)[1] for s in (ROOT/a.build/'CMakeCache.txt').read_text().splitlines() if s.startswith('CMAKE_BUILD_TYPE:')),''),
             'environment':cap['environment'],'seedConfiguration':{'integration':24680,'showerMaster':731,'partitionEvents':250,'detectorMaster':24680},
             'capabilityStartupSeconds':initialization,'measurements':timings,'campaignMeasurements':extra,'fitStatus':fitted['status'],'inferenceValid':inference['valid'],'scanCompletedPoints':len(scanned['pointRuns']),
             'resourceBrokerHardware':json.loads(subprocess.check_output([str((ROOT/a.build/'bin/hep-benchmark-budget').resolve())],text=True,timeout=10)),
             'allocatedThreads':a.workers,'artifactBytes':sum(p.stat().st_size for p in cache.rglob('*') if p.is_file()),
             'limitations':['Reference-sized workload; startup and JIT remain significant','MadGraph integration serial and detector partitions currently serial','Cache validation reads full artifact checksums','Process-tree RSS double counts shared pages']}
    a.output.write_text(json.dumps(output,indent=2)+'\n')

def main():
    p=argparse.ArgumentParser();p.add_argument('--build',default='build-release');p.add_argument('--events',type=int,default=1000);p.add_argument('--workers',type=int,default=2);p.add_argument('--directory',type=Path,required=True);p.add_argument('--output',type=Path,required=True);p.add_argument('--child',action='store_true');a=p.parse_args()
    if a.child:return child(a)
    import psutil
    sys.path.insert(0,str(ROOT/'tests/collider'));from process_monitor import host_pid
    a.output.parent.mkdir(parents=True,exist_ok=True)
    with a.output.with_suffix('.log').open('w') as log:
        process=subprocess.Popen([sys.executable,'-u',str(Path(__file__).resolve()),*sys.argv[1:],'--child'],stdout=log,stderr=subprocess.STDOUT)
        began=time.monotonic();cpu={};peak_rss=peak_pss=0
        while process.poll() is None:
            rss=pss=0;pid=host_pid(process.pid)
            try:tree=[psutil.Process(pid)] if pid is not None else [];tree+=tree[0].children(recursive=True) if tree else []
            except psutil.Error:tree=[]
            for child_process in tree:
                try:
                    t=child_process.cpu_times();cpu[(child_process.pid,child_process.create_time())]=t.user+t.system;memory=child_process.memory_full_info();rss+=memory.rss;pss+=getattr(memory,'pss',0)
                except psutil.Error:pass
            peak_rss=max(peak_rss,rss);peak_pss=max(peak_pss,pss)
            if time.monotonic()-began>600:process.kill();process.wait(timeout=5);raise TimeoutError('Research benchmark timed out')
            time.sleep(.05)
        if process.returncode or not a.output.exists():raise RuntimeError('Benchmark did not complete; inspect retained log')
    report=json.loads(a.output.read_text());elapsed=time.monotonic()-began
    report['processTree']={'peakRssBytes':peak_rss,'peakPssBytes':peak_pss,'sampledCpuSeconds':sum(cpu.values()),'cpuUtilizationPercent':100*sum(cpu.values())/elapsed,'wallSecondsIncludingStartup':elapsed,'samplingSeconds':.05}
    a.output.write_text(json.dumps(report,indent=2)+'\n');print('PASS real research benchmark:',a.output)

if __name__=='__main__':main()
