"""Real worker-local LHE → PYTHIA → Delphes → RDF scientific regression."""
import copy,gzip,json,math,os,sys,tempfile,threading,subprocess
from pathlib import Path

ROOT=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT/'plugins/research'))
import backend

def plan():
    expressions=lambda name:{'op':'column','name':name}
    nodes=[('lhe','LHESource',{'resourceId':'fixture'}),
           ('shower','Shower',{'seedStrategy':'fixed','seed':'731','streamPolicy':'lhe-logical-blocks-v1','partitionEvents':25,'workers':2,'isr':False,'fsr':False,'mpi':False,'hadronisation':False}),
           ('detector','Delphes',{'card':{'builtin':'ideal-muon'},'seed':24680}),
           ('muons','Muons',{}),('selection','CollectionFilter',{'expression':{'op':'gt','args':[expressions('pt'),{'op':'literal','value':0.,'unit':'GeV'}]},'collectionType':'RecoMuonCollection'}),
           ('pairs','Pairs',{'oppositeSign':True,'sameFlavour':True,'collectionType':'RecoMuonCollection'}),
           ('mass','Property',{'property':'mass','collectionType':'RecoPairCollection'}),
           ('hist','Histo1D',{'expression':expressions('value'),'bins':20,'lower':90.,'upper':110.,'normalization':'counts','flow':'separate','yieldMode':'raw-weights'})]
    return {'version':1,'backend':'hep.research/1','requiredThreads':2,'requiredLibraries':['ROOT','PYTHIA','HepMC3','Delphes'],
            'nodes':[{'id':nid,'kind':kind,'config':c,**({'input':nodes[i-1][0]} if i else {})} for i,(nid,kind,c) in enumerate(nodes)]}

def main():
    cap=backend.initialize()
    if not all(cap['libraries'].get(n,{}).get('available') for n in ('ROOT','PYTHIA','HepMC3','Delphes')):
        print('SKIP: real research scientific SDK is unavailable');return 77
    cancel=threading.Event()
    with tempfile.TemporaryDirectory(prefix='hep-research-integration-') as folder:
        backend.CAPABILITY['cacheRoot']=str(Path(folder)/'cache')
        source=Path(folder)/'fixture.lhe'
        with gzip.open(ROOT/'tests/research/fixtures/madgraph-qed-100.lhe.gz','rb') as inp:source.write_bytes(inp.read())
        payload={'plan':plan(),'resources':{'fixture':{'path':str(source),'logicalUri':'hep://fixture/qed100'}},'allocatedThreads':2,'projectSeed':'42','scientificHash':'reference-scientific-hash'}
        first=backend.execute(payload,cancel,lambda m:print(m,flush=True))
        histogram=first['results']['hist']
        assert first['valid'] and not first['preview'] and first['metrics']['inputEvents']==100
        assert first['metrics']['rdfEventLoops']==1 and first['metrics']['bulkEventsThroughIPC']==0
        assert histogram['entries']==100 and abs(histogram['mean']-100)<.003
        assert math.isclose(sum(histogram['values']),926.99,rel_tol=2e-6)
        assert math.isclose(sum(e*e for e in histogram['errors']),100*9.2699**2,rel_tol=3e-6)
        assert histogram['underflow']==histogram['overflow']==0
        reference=Path(folder)/'equivalent-analysis.py';reference.write_text(first['generatedCode'])
        subprocess.run([sys.executable,str(reference)],cwd=folder,check=True,timeout=45)
        exported=json.loads((Path(folder)/'reference-results.json').read_text())['hist']
        assert exported['values']==histogram['values'] and exported['errors']==histogram['errors'],'Equivalent PyROOT differs from canonical worker histogram'
        assert 'actualSeed' in first['generatedCode'] and 'ideal-muon' in first['generatedCode']
        # Explicit normalization variation: bin errors scale with weights;
        # sum of squared weights scales quadratically. Reuse all event stages.
        systematic=copy.deepcopy(payload);systematic['plan']['systematics']=[{'id':'lumi','name':'Normalization audit','kind':'normalization','nominal':1.,'affectedNodes':['hist'],
            'correlation':{'group':'lumi'},'interpretation':'Sensitivity envelope; no prior','variations':[{'label':'up','factor':1.1},{'label':'down','factor':.9}]}]
        templates=backend.dispatch({'operation':'execute','payload':systematic},cancel,lambda _:None)
        for row,factor in zip(templates['systematics']['templates']['lumi']['variations'],[1.1,.9]):
            varied=row['results']['hist'];assert varied['values']==[v*factor for v in histogram['values']]
            assert varied['errors']==[e*factor for e in histogram['errors']]
            assert math.isclose(varied['sumWeightsSquared'],histogram['sumWeightsSquared']*factor*factor,rel_tol=1e-14)
        # Scan the object cut. Every scientific point owns a durable Run and
        # reuses generator/shower/detector inputs independently of the cut.
        points=[]
        for index,cut in enumerate([0.,30.,40.]):
            child=copy.deepcopy(payload);child['plan']['nodes'][4]['config']['expression']['args'][1]['value']=cut;child['scientificHash']='cut-'+str(cut)
            points.append({'runId':'scan-point-'+str(index),'workflowSnapshot':{'cut':cut},'scientificHash':child['scientificHash'],'payload':child})
        campaign=backend.dispatch({'operation':'scan','payload':{'scan':{'id':'cut-scan'},'points':points}},cancel,lambda _:None)
        assert campaign['valid'] and len(campaign['pointRuns'])==3
        integrals=[sum(r['result']['results']['hist']['values']) for r in campaign['pointRuns']]
        assert integrals[0]>integrals[1]>integrals[2]
        assert all(all(p['cacheReused'] for s in r['result']['stages'] if s['kind'] in ('Shower','Delphes') for p in s['logicalPartitions']) for r in campaign['pointRuns'])

        serial=copy.deepcopy(payload);serial['plan']['requiredThreads']=1;serial['plan']['nodes'][1]['config']['workers']=1
        reused=backend.execute(serial,cancel,lambda _:None)
        assert all(p['cacheReused'] for s in reused['stages'] if s['kind'] in ('Shower','Delphes') for p in s['logicalPartitions'])
        backend.CAPABILITY['cacheRoot']=str(Path(folder)/'fresh-serial-cache')
        second=backend.execute(serial,cancel,lambda _:None)
        assert first['results']==second['results'],'fresh serial/parallel execution changed reconstructed physics'
        # Explicit cross-section normalization: divide nominal pb weights by
        # input sample count, including events that fail downstream selections.
        scaled=copy.deepcopy(serial);scaled['plan']['nodes'][-1]['config']['yieldMode']='cross-section-pb'
        third=backend.execute(scaled,cancel,lambda _:None)
        assert math.isclose(sum(third['results']['hist']['values']),9.2699,rel_tol=2e-6)
        assert third['provenance']['environment']['id']==cap['environment']['id']
        # Enable genuine stochastic final-state showering, then compare fresh
        # executions. Stable LHE block seeds govern physics; CPUs only schedule.
        radiative=copy.deepcopy(payload);radiative['plan']['nodes'][1]['config']['fsr']=True
        backend.CAPABILITY['cacheRoot']=str(Path(folder)/'radiative-parallel')
        rad_parallel=backend.execute(radiative,cancel,lambda _:None)
        radiative['allocatedThreads']=1;radiative['plan']['requiredThreads']=1;radiative['plan']['nodes'][1]['config']['workers']=1
        backend.CAPABILITY['cacheRoot']=str(Path(folder)/'radiative-serial')
        rad_serial=backend.execute(radiative,cancel,lambda _:None)
        assert rad_parallel['results']==rad_serial['results'] and rad_parallel['events']==rad_serial['events'],'Actual stochastic shower depends on physical worker count'
        assert rad_parallel['results']['hist']['mean']<99.99,'FSR audit did not produce an observable radiative effect'
        # Real reconstructed response plus all three supported statistical
        # actions. Standalone code executes them, retaining invalid-fit status
        # rather than merely printing configuration declarations.
        statistics=copy.deepcopy(serial);statistics['plan']['nodes'][2]['config']['card']={'builtin':'CMS'}
        statistics['plan']['nodes'][-1]['config'].update(bins=40,yieldMode='luminosity',luminosityFb=10./(9.2699*1000))
        statistics['plan']['nodes'].extend([
            {'id':'native_fit','kind':'Fit','input':'hist','config':{'model':'gaussian','lower':90.,'upper':110.}},
            {'id':'roofit','kind':'RooFit','input':'hist','config':{'model':{'kind':'Gaussian','mean':{'value':100.,'lower':95.,'upper':105.},'sigma':{'value':1.,'lower':.1,'upper':3.}},'errorModel':'sumw2'}},
            {'id':'limit','kind':'RooStats','input':'hist','config':{'signalSource':'histogram-integral','background':20.,'observed':20.,'datasetRole':'asimov','method':'asymptotic-profile-likelihood','testStatistic':'one-sided-qmu','useCLs':True,'confidenceLevel':.95,'muMax':5.,'points':40}}])
        statistical_run=backend.execute(statistics,cancel,lambda _:None)
        reference.write_text(statistical_run['generatedCode']);subprocess.run([sys.executable,str(reference)],cwd=folder,check=True,timeout=45)
        exported_stats=json.loads((Path(folder)/'reference-results.json').read_text())
        assert exported_stats['hist']==statistical_run['results']['hist'],'Export changed statistical histogram input identity'
        assert exported_stats['roofit']['valid'] and statistical_run['results']['roofit']['valid']
        for kind in ('native_fit','roofit'):
            actual=statistical_run['results'][kind];external=exported_stats[kind]
            assert actual['status']==external['status'] and actual['covarianceStatus']==external['covarianceStatus']
            for a,b in zip(actual['parameters'],external['parameters']):
                assert a['name']==b['name'] and math.isclose(a['value'],b['value'],rel_tol=1e-6,abs_tol=1e-6) and math.isclose(a['error'],b['error'],rel_tol=1e-6,abs_tol=1e-6)
        assert exported_stats['roofit']['inputIdentity']==statistical_run['results']['roofit']['inputIdentity']
        assert exported_stats['limit']['valid'] and abs(exported_stats['limit']['upperLimit']-statistical_run['results']['limit']['upperLimit'])<1e-8
        corrupt=statistical_run['generatedCode'].replace(statistical_run['artifactReferences'][0]['sha256'],'0'*64)
        reference.write_text(corrupt);rejected=subprocess.run([sys.executable,str(reference)],cwd=folder,capture_output=True,text=True,timeout=15)
        assert rejected.returncode!=0 and 'checksum differs' in rejected.stderr
        # Fail closed before scientific execution on a mismatched environment.
        try:backend.execute({**payload,'expectedEnvironmentId':'unavailable-frozen-environment'},cancel,lambda _:None);raise AssertionError('Environment mismatch accepted')
        except ValueError as error:assert 'environment mismatch' in str(error)
        from unittest.mock import patch
        with patch.object(backend.DELPHES.shutil,'disk_usage',return_value=type('Disk',(),{'free':0})()):
            try:backend.DELPHES.reconstruct({'card':{'builtin':'ideal-muon'}},source,Path(folder),cancel);raise AssertionError('Out-of-space reconstruction was accepted')
            except ValueError as error:assert 'disk space' in str(error)
        # An identified detector bundle is independent of its physical folder.
        # Use a real reference card; changing a dependency is detected before
        # reconstruction rather than silently reusing an old detector response.
        import shutil
        cards=Path(folder)/'cards-one';moved=Path(folder)/'cards-two';cards.mkdir();moved.mkdir()
        for directory in (cards,moved):
            shutil.copyfile(ROOT/'tests/research/fixtures/ideal-muon.tcl',directory/'detector.tcl');(directory/'dependency.tcl').write_text('set ExampleResponse 1\n')
        _,identity=backend.DELPHES.detector_card({'card':{'path':str(cards/'detector.tcl')}})
        custom=copy.deepcopy(payload);custom['plan']['nodes'][2]['config']['card']={'resourceVersion':1,'resourceId':'identified-detector','sha256':identity['sha256'],'dependencyChecksums':identity['cardDependencies'],'name':'detector.tcl'}
        custom['resources']['identified-detector']={'path':str(cards/'detector.tcl'),'sha256':identity['sha256'],'logicalUri':'hep://fixture/detector'}
        backend.CAPABILITY['cacheRoot']=str(Path(folder)/'card-relink')
        identified=backend.execute(custom,cancel,lambda _:None);custom['resources']['identified-detector']['path']=str(moved/'detector.tcl');relocated=backend.execute(custom,cancel,lambda _:None)
        assert identified['results']==relocated['results'] and all(p['cacheReused'] for s in relocated['stages'] if s['kind']=='Delphes' for p in s['logicalPartitions'])
        assert 'path' not in relocated['stages'][-1]['configuration']['card']
        (moved/'dependency.tcl').write_text('set ExampleResponse 2\n')
        try:backend.execute(custom,cancel,lambda _:None);raise AssertionError('Changed card dependency was silently reused')
        except ValueError as error:assert 'bundle changed' in str(error)
        (ROOT/'docs/developer/part4-pipeline-validation.json').write_text(json.dumps({'status':'VERIFIED','platform':sys.platform,
            'environment':cap['environment'],'inputEvents':100,'histogramEntries':histogram['entries'],'weightedIntegral':sum(histogram['values']),
            'sumSquaredWeights':sum(e*e for e in histogram['errors']),'crossSectionIntegralPb':sum(third['results']['hist']['values']),
            'stochasticFSRWorkerInvariant':True,'radiativeMassMean':rad_parallel['results']['hist']['mean'],'standalonePyROOTMatches':True,'standaloneStatisticalActions':{k:statistical_run['results'][k] for k in ('native_fit','roofit','limit')},'statisticalExportParameterTolerance':1e-6,'statisticalExportLimitTolerance':1e-8,'exportRejectsChangedInput':True,'systematicWeightAudit':True,'cutScanIntegrals':integrals,'identifiedDetectorRelinkReusesResponse':True,'changedCardDependencyRejected':True,'rdfEventLoops':1,'physicalWorkerBudgets':[1,2],'logicalPartitions':4,'bulkEventsThroughIPC':0},indent=2)+'\n')
    print('PASS real LHE shower, reconstructed pairs, weighted RDF, cache, provenance and worker-independent physics')
    return 0

if __name__=='__main__':raise SystemExit(main())
