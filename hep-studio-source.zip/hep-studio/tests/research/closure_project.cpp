#include "core/research/campaign.hpp"
#include "core/editing/editing.hpp"
#include "core/graph/graph.hpp"
#include "runtime/project_store.hpp"
#include <QCoreApplication>
#include <filesystem>
#include <fstream>
#include <iostream>
using namespace hep;
static Json read(const std::filesystem::path& path){Json value;std::ifstream stream(path);stream>>value;return value;}
static void write(const std::filesystem::path& path,const Json& value){std::ofstream stream(path);stream<<value.dump(2)<<'\n';if(!stream)throw std::runtime_error("Closure artifact write failed");}
static std::string hash(const Json& value){return workflowHash(value).toStdString();}
static Run completed(const Project& p,const Workflow& w,const std::string& id,const Json& record){
    const auto& result=record.at("result");
    if(!result.value("valid",false)||result.value("preview",false)||result.value("partial",false))throw std::runtime_error("Incomplete closure Run");
    Run run{Id(id),"Completed",workflowJson(w),hash(scientificJson(w,p.seed))};
    run.backend="hep.research/1";run.environment=result.at("environment").at("id");run.seed=p.seed;run.started=record.at("started");run.ended=record.at("ended");run.result=result;run.resources=record.at("resources");
    run.extensions["frozenEnvironment"]=result.at("environment");run.extensions["workflowRevision"]=hash(workflowJson(w));
    Json hashes=Json::object();for(const auto& node:w.nodes)hashes[node.id.value]=hash(dependencyJson(w,node.id,p.seed));run.extensions["nodeHashes"]=hashes;return run;
}
int main(int argc,char** argv){QCoreApplication app(argc,argv);try{
    if(argc!=4)throw std::invalid_argument("Usage: closure-project prepare|attach|finalize SOURCE_PROJECT DIRECTORY");
    const std::string mode=argv[1];const std::filesystem::path folder=argv[3];std::filesystem::create_directories(folder);
    const auto file=QString::fromStdString((folder/"workflow.hep.json").string());
    auto p=loadProject(mode=="prepare"?QString::fromLocal8Bit(argv[2]):file);
    if(mode=="prepare"){
        p.id=Id("part4-closure");p.name="Part 4 frozen-scope closure: generated systematic templates";p.runs.clear();
        Json sources=Json::array();
        for(std::size_t i=0;i<2;++i){auto& w=p.workflows.at(i);const auto hid=w.nodes.back().id.value;
            const Json descriptor={{"id","closure_luminosity"},{"kind","normalization"},{"name","Explicit two-percent luminosity endpoints"},{"nominal",1.},{"affectedNodes",Json::array({hid})},{"correlation",{{"group","closure_luminosity"}}},{"interpretation","Explicit Gaussian auxiliary constraint; endpoints are minus/plus one sigma, not a prior inferred from labels."},{"variations",Json::array({{{"label","down"},{"factor",.98}},{{"label","up"},{"factor",1.02}}})}};
            w.extensions["systematics"]=Json::array({descriptor});
            sources.push_back({{"role",i==0?"signal":"background"},{"plan",lowerResearch(w)},{"scientificHash",hash(scientificJson(w,p.seed))},{"workflowRevision",hash(workflowJson(w))},{"projectSeed",p.seed},{"allocatedThreads",2}});
        }
        auto& model=p.workflows.back();model.nodes.at(1).extensions["config"]["muMax"]=2.;model.nodes.at(1).extensions["config"]["nuisances"]=Json::array({{{"kind","shape"},{"samples",Json::array({"signal","background"})},{"correlationGroup","closure_luminosity"},{"constraint","gaussian-standard-normal"},{"variationMeaning","minus-plus-one-sigma"},{"systematicId","closure_luminosity"},{"downLabel","down"},{"upLabel","up"}}});
        saveProject(p,file);write(folder/"source-payloads.json",sources);
    }else if(mode=="attach"){
        const auto records=read(folder/"source-results.json");Json refs=Json::array(),inputs=Json::object();p.runs.clear();
        for(std::size_t i=0;i<2;++i){const std::string role=i==0?"signal":"background";const auto& w=p.workflows.at(i);auto run=completed(p,w,"closure-"+role,records.at(role));const auto hid=w.nodes.back().id.value;const auto& h=run.result.at("results").at(hid);
            const Json reference={{"runId",run.id.value},{"nodeId",hid},{"inputIdentity",hash(h)}};
            refs.push_back({{"id",role},{"role",role},{"reference",reference}});
            inputs[run.id.value+"/"+hid]={{"runStatus",run.status},{"runValid",true},{"inputIdentity",hash(h)},{"histogram",h},{"systematics",run.result.at("systematics")},{"sourceRun",{{"id",run.id.value},{"backend",run.backend},{"workflowScientificHash",run.workflowHash},{"environmentId",run.environment},{"seed",run.seed},{"started",run.started},{"ended",run.ended}}}};
            p.runs.push_back(std::move(run));
        }
        auto& model=p.workflows.back();model.nodes.front().extensions["config"]["samples"]=refs;p.extensions["preferredResearchEnvironment"]=p.runs.front().extensions.at("frozenEnvironment");
        saveProject(p,file);write(folder/"model-payload.json",{{"plan",lowerResearch(model)},{"templateInputs",inputs},{"scientificHash",hash(scientificJson(model,p.seed))},{"workflowRevision",hash(workflowJson(model))},{"projectSeed",p.seed},{"allocatedThreads",2}});
    }else if(mode=="finalize"){
        auto& model=p.workflows.back();p.runs.push_back(completed(p,model,"closure-inference",read(folder/"model-result.json")));saveProject(p,file);
        const auto before=projectJson(p);auto reopened=loadProject(file);if(projectJson(reopened)!=before)throw std::runtime_error("Native save/reload changed project state");
        const auto second=QString::fromStdString((folder/"reopened.hep.json").string());saveProject(reopened,second);if(projectJson(loadProject(second))!=before)throw std::runtime_error("Second native save/reload differs");
        for(const auto& run:reopened.runs)if(run.workflowHash!=hash(scientificJson(workflowFromJson(run.workflowSnapshot),reopened.seed)))throw std::runtime_error("Scientific identity changed across save/reload");
        write(folder/"persistence.json",{{"verified",true},{"workflows",p.workflows.size()},{"runs",p.runs.size()},{"completeProjectEquality",true},{"immutableRunEquality",true},{"scientificHashesVerified",true}});
        const Json axes={{"axes",Json::array({{{"nodeId",model.nodes.at(1).id.value},{"pointer","/muMax"},{"unit","1"},{"values",Json::array({2.,1.})}},{{"nodeId",model.nodes.at(2).id.value},{"pointer","/confidenceLevel"},{"unit","1"},{"values",Json::array({.90,.95})}}})}};
        auto payload=read(folder/"model-payload.json");Json points=Json::array();const auto varied=scanWorkflows(model,axes);
        for(std::size_t i=0;i<varied.size();++i){const auto& w=varied[i];const auto scientific=hash(scientificJson(w,p.seed));auto execution=payload;execution["plan"]=lowerResearch(w);execution["scientificHash"]=scientific;execution["workflowRevision"]=hash(workflowJson(w));
            Json hashes=Json::object();for(const auto& node:w.nodes)hashes[node.id.value]=hash(dependencyJson(w,node.id,p.seed));
            points.push_back({{"runId","closure-grid-"+std::to_string(i)},{"workflowSnapshot",workflowJson(w)},{"scientificHash",scientific},{"nodeHashes",hashes},{"payload",execution}});
        }
        write(folder/"scan-payload.json",{{"scan",{{"id","part4-closure-grid"},{"axes",axes.at("axes")},{"workflowId",model.id.value},{"workflowHash",hash(scientificJson(model,p.seed))},{"frozenEnvironment",p.runs.back().extensions.at("frozenEnvironment")}}},{"points",points},{"scanRoot",(folder/"scans").string()}});
    }else throw std::invalid_argument("Unknown closure verification mode");
    std::cout<<"PASS closure project "<<mode<<'\n';return 0;
}catch(const std::exception& error){std::cerr<<error.what()<<'\n';return 1;}}
