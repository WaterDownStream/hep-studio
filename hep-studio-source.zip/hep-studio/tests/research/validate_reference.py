"""Numerical audit of real MadGraph QED and Delphes ideal/CMS reference output."""
import argparse,hashlib,json,math,re,statistics,xml.etree.ElementTree as ET
from pathlib import Path

def identity(path):
    path=Path(path)
    return {'sizeBytes':path.stat().st_size,'sha256':hashlib.sha256(path.read_bytes()).hexdigest()}

def validate(lhe,ideal,cms,library):
    import ROOT
    assert ROOT.gSystem.Load(str(library))>=0,'Delphes dictionary unavailable'
    # Upstream tagged Git checkouts can embed coloured development banners in
    # the header. Strip terminal control escapes only for metadata parsing; the
    # original input bytes/checksum are retained and passed unchanged to Delphes.
    text=re.sub(r'\x1b\[[0-9;]*m','',Path(lhe).read_text())
    document=ET.fromstring(text);init=document.find('init').text.strip().splitlines()
    header=init[0].split();process=init[1].split();cross,error=float(process[0]),float(process[1])
    assert [int(x) for x in header[:2]]==[-11,11]
    assert [float(x) for x in header[2:4]]==[50.,50.]
    slha=document.find('./header/slha').text
    alpha=None;block=''
    for line in slha.splitlines():
        fields=line.split('#')[0].split()
        if not fields:continue
        if fields[0].lower()=='block':block=fields[1].lower()
        elif block=='sminputs' and fields[0]=='1':alpha=1/float(fields[1])
    assert alpha is not None
    # Massless LO photon exchange, complete angular phase space, GeV^-2 → pb.
    expected=4*math.pi*alpha**2/(3*100**2)*389379365.6
    tolerance=max(5*error,.002*expected)
    assert abs(cross-expected)<=tolerance,(cross,expected,error)
    events=[]
    for event in document.findall('event'):
        lines=event.text.strip().splitlines();particles=[]
        for line in lines[1:1+int(lines[0].split()[0])]:
            f=line.split()
            if int(f[1])==1:particles.append({'pdg':int(f[0]),'px':float(f[6]),'py':float(f[7]),'pz':float(f[8]),'energy':float(f[9])})
        assert sorted(p['pdg'] for p in particles)==[-13,13]
        for key in ('px','py','pz'):assert abs(sum(p[key] for p in particles))<1e-7
        assert abs(sum(p['energy'] for p in particles)-100)<1e-7
        events.append(particles)
    assert len(events)==100
    f=ROOT.TFile.Open(str(ideal));assert f and not f.IsZombie();tree=f.Get('Delphes');assert tree.GetEntries()==100
    max_pt_error=0.;max_mass_error=0.;muons=0
    for i,particles in enumerate(events):
        tree.GetEntry(i);assert tree.Muon.GetEntries()==2
        objects=[tree.Muon.At(j) for j in range(2)];assert sum(int(p.Charge) for p in objects)==0
        original=sorted(math.hypot(p['px'],p['py']) for p in particles)
        reconstructed=sorted(float(p.PT) for p in objects)
        for a,b in zip(original,reconstructed):
            error_pt=abs(a-b)/max(1.,abs(a));max_pt_error=max(max_pt_error,error_pt);assert error_pt<3e-6
        mass=float((objects[0].P4()+objects[1].P4()).M());max_mass_error=max(max_mass_error,abs(mass-100));assert abs(mass-100)<.003
        muons+=2
    f.Close()
    f=ROOT.TFile.Open(str(cms));assert f and not f.IsZombie();tree=f.Get('Delphes');assert tree.GetEntries()==100
    for name in ('Muon','Electron','Jet','MissingET','Track'):assert tree.GetBranch(name),name
    counts=[];masses=[]
    for i in range(100):
        tree.GetEntry(i);count=tree.Muon.GetEntries();counts.append(count)
        if count==2:
            objects=[tree.Muon.At(j) for j in range(2)];assert sum(int(p.Charge) for p in objects)==0
            masses.append(float((objects[0].P4()+objects[1].P4()).M()))
    assert 100<=sum(counts)<=200 and len(masses)>=30
    assert abs(statistics.mean(masses)-100)<5
    f.Close()
    return {'format':'hep-studio-research-reference','version':1,'status':'VERIFIED','platform':'Linux',
            'madgraph':{'process':'e+ e- > mu+ mu- / z','energyGeV':100,'seed':24680,'events':100,
                        'crossSectionPb':cross,'integrationErrorPb':error,'qedExpectedPb':expected,'tolerancePb':tolerance,
                        'reference':'4 pi alpha^2/(3 s), massless LO photon exchange; full lepton phase space',
                        'toleranceReason':'Five reported integration standard errors or 0.2 percent, whichever is larger; not a cross-version bitwise test'},
            'delphesIdeal':{'events':100,'muons':muons,'maxRelativePtError':max_pt_error,'maxMassErrorGeV':max_mass_error,
                            'massToleranceGeV':.003,'toleranceReason':'Float32 stored kinematics and Delphes reconstructed muon rest mass versus massless SM input'},
            'delphesCMS':{'events':100,'muons':sum(counts),'dimuonEvents':len(masses),'massMeanGeV':statistics.mean(masses),
                          'massRmsGeV':statistics.pstdev(masses),'reference':'Seeded upstream CMS card; acceptance and mass-response sanity bounds, not an experimental detector validation'},
            'inputs':{'lhe':identity(lhe),'idealRoot':identity(ideal),'cmsRoot':identity(cms),'delphesLibrary':identity(library)}}

if __name__=='__main__':
    p=argparse.ArgumentParser()
    for name in ('lhe','ideal','cms','library','output'):p.add_argument('--'+name,type=Path,required=True)
    a=p.parse_args();result=validate(a.lhe,a.ideal,a.cms,a.library);a.output.write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
