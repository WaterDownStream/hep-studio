"""Frozen Part 4 acceptance; exercises existing adapters, not new capabilities.

Run with the established scientific SDK and a central two-thread broker lease.
The companion closure_project.cpp uses native core lowering and project storage.
"""
import argparse,copy,datetime,json,math,subprocess,sys,threading
from pathlib import Path
REPO=Path(__file__).resolve().parents[2]
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def write(path,value):path.write_text(json.dumps(value,indent=2,allow_nan=False)+'\n')
def main():
    p=argparse.ArgumentParser();p.add_argument('--project-helper',type=Path,required=True);p.add_argument('--build',default='build');p.add_argument('--directory',type=Path,required=True);p.add_argument('--output',type=Path,required=True);a=p.parse_args()
    folder=a.directory.resolve();folder.mkdir(parents=True,exist_ok=True);build=REPO/a.build
    def native(mode):subprocess.run([str(a.project_helper.resolve()),mode,str(REPO/'examples/research-template-study.hep.json'),str(folder)],check=True,timeout=30)
    sys.path.insert(0,str((build/'bin/research_worker').resolve()));import backend,campaigns
    capability=backend.initialize()
    for name in ('MadGraph','PYTHIA','HepMC3','Delphes','ROOT','RooFit','RooStats','HistFactory'):
        if not capability['libraries'].get(name,{}).get('available'):raise RuntimeError(name+' is required for closure')
    backend.CAPABILITY['cacheRoot']=str(folder/'cache');cancel=threading.Event()
    resources=json.loads(subprocess.check_output([str(build/'bin/hep-benchmark-budget')],text=True));resources['allocatedThreads']=2
    native('prepare');records={};stream_seeds=[]
    for source in json.loads((folder/'source-payloads.json').read_text()):
        start=now();result=backend.dispatch({'operation':'execute','payload':source},cancel,lambda _:None)
        hist_id=source['plan']['nodes'][-1]['id'];hist=result['results'][hist_id]
        assert result['valid'] and not result.get('preview') and result['metrics']['inputEvents']==1000
        assert result['metrics']['bulkEventsThroughIPC']==0 and hist['entries']>0 and sum(hist['values'])>0
        assert hist['yieldMode']=='luminosity' and {s['kind'] for s in result['stages']}=={'MadGraph','Shower','Delphes'}
        endpoints=result['systematics']['templates']['closure_luminosity']['variations']
        for endpoint,factor in zip(endpoints,(.98,1.02)):
            varied=endpoint['results'][hist_id]
            assert endpoint['valid'] and varied['edges']==hist['edges']
            for key in ('values','errors'):
                assert all(math.isclose(v,n*factor,rel_tol=1e-12,abs_tol=1e-12) for v,n in zip(varied[key],hist[key]))
            assert math.isclose(varied['sumWeightsSquared'],hist['sumWeightsSquared']*factor**2,rel_tol=1e-12)
        seeds=[]
        for stage in result['stages']:
            if stage['kind']=='Shower':seeds.extend(part['seed'] for part in stage['logicalPartitions'])
            elif stage['kind']=='Delphes':seeds.extend(part['metadata']['actualSeed'] for part in stage['logicalPartitions'])
        stream_seeds.append(set(seeds));records[source['role']]={'started':start,'ended':now(),'resources':resources,'result':result}
        print('PASS real generated '+source['role']+' sample and systematic endpoints',flush=True)
    assert not stream_seeds[0]&stream_seeds[1]
    write(folder/'source-results.json',records);native('attach')
    payload=json.loads((folder/'model-payload.json').read_text());start=now();inference=backend.execute(payload,cancel,lambda _:None)
    hypothesis=next(r for r in inference['results'].values() if r.get('kind')=='HypothesisResult')
    model=next(r for r in inference['results'].values() if r.get('kind')=='LikelihoodModel')
    assert inference['valid'] and hypothesis['valid'] and 'alpha_closure_luminosity' in model['nuisanceParameters']
    assert inference['metrics']['bulkEventsThroughIPC']==0
    write(folder/'model-result.json',{'started':start,'ended':now(),'resources':resources,'result':inference});native('finalize')
    export=folder/'independent-export';export.mkdir(exist_ok=True);script=export/'reference.py';script.write_text(inference['generatedCode'])
    with (export/'execution.log').open('w') as log:subprocess.run([sys.executable,str(script)],cwd=export,stdout=log,stderr=subprocess.STDOUT,check=True,timeout=90)
    independent=json.loads((export/'reference-inference.json').read_text());reference=next(r for r in independent.values() if r.get('kind')=='HypothesisResult')
    assert reference['valid'] and reference['model']['inputIdentity']==hypothesis['model']['inputIdentity']
    differences={key:abs(reference[key]-hypothesis[key]) for key in ('upperLimit','expectedMedianLimit')}
    assert all(value<1e-8 for value in differences.values())
    assert len(reference['scan'])==len(hypothesis['scan'])
    assert all(abs(a['mu']-b['mu'])<1e-12 and abs(a['CLs']-b['CLs'])<1e-8 for a,b in zip(reference['scan'],hypothesis['scan']))
    assert all(0<=p['CLs']<=1+1e-6 for p in hypothesis['scan'])
    wide=copy.deepcopy(payload)
    next(n for n in wide['plan']['nodes'] if n['kind']=='BinnedLikelihood')['config']['muMax']=100.
    failed_limit=next(r for r in backend.execute(wide,cancel,lambda _:None)['results'].values() if r.get('kind')=='HypothesisResult')
    assert not failed_limit['valid'] and any(p['CLs']<0 for p in failed_limit['scan'])
    assert any('invalid CLs' in warning for warning in failed_limit['warnings'])
    print('PASS independent HistFactory/RooFit/RooStats export and native project round-trip',flush=True)
    scan=json.loads((folder/'scan-payload.json').read_text());scan_cancel=threading.Event()
    def progress(message):
        if message.get('completedPoints')==3 and 'committedPoint' in message:scan_cancel.set()
    try:campaigns.run_scan(scan,backend.execute,scan_cancel,progress)
    except InterruptedError:pass
    else:raise AssertionError('Controlled partial scan should have been interrupted')
    recovered=campaigns.recover_scans(folder/'scans');assert len(recovered)==1
    receipt=recovered[0];runs=receipt['pointRuns'];statuses=[r['status'] for r in runs]+['Missing']
    assert statuses==['Completed','Completed','Failed','Missing'] and not receipt['complete'] and not receipt['corruptPoints']
    assert receipt['scan']['state']=='interrupted' and not (folder/'scans'/scan['scan']['id']/'closure-grid-3.json').exists()
    failed=runs[2];assert failed['result']['valid'] is False and 'mu=1' in failed['result']['message']
    assert all(r['environment']==capability['environment']['id'] for r in runs[:2])
    report={'status':'VERIFIED','timestamp':now(),'environment':capability['environment'],'scientificWorkflow':'MadGraph -> PYTHIA -> Delphes -> reconstructed selection -> identified systematic templates -> HistFactory/RooFit/RooStats -> CLs',
        'eventCountPerSample':1000,'sampleSeedsDisjoint':True,'systematic':{'kind':'normalization','factors':[.98,1.02],'materialization':'identified histogram endpoints bound explicitly to one correlated HistoSys Gaussian auxiliary constraint','binErrorSumw2Audit':True},
        'hypothesis':hypothesis,'persistence':json.loads((folder/'persistence.json').read_text()),'independentExport':{'valid':True,'guiRequired':False,'maximumLimitDifference':max(differences.values()),'allCLsCurvePointsMatch':True,'inputIdentityMatches':True},
        'twoDimensionalScan':{'axes':scan['scan']['axes'],'pointStatuses':statuses,'state':receipt['scan']['state'],'pointRunIds':[point['runId'] for point in scan['points']],'failure':failed['result']['message'],'missingReason':'Deliberate cancellation after the third transaction; fourth point was never published','checksumsVerified':True,'environmentFrozen':True,'failedOutputNotValid':True},
        'invalidNumericalCLsRejected':True,'bulkEventsThroughIPC':0,'limitations':['Software acceptance, not experimental detector or statistical coverage validation','Windows/WSL and macOS execution UNVERIFIED','General UFO, NLO and matching/merging explicitly deferred']}
    write(a.output,report);write(folder/'scan-recovery.json',receipt)
    print('PASS two-dimensional scan: two successful, one real rejected point, one unexecuted/missing point',flush=True)
if __name__=='__main__':main()
