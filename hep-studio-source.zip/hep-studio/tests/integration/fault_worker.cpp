// Deliberately adversarial transport fixture; never a scientific backend.
#include "runtime/ipc/protocol.hpp"
#include <QCoreApplication>
#include <QFile>
#include <QTimer>
#include <QtEndian>
int main(int argc,char** argv){
    QCoreApplication app(argc,argv);QFile out;out.open(stdout,QIODevice::WriteOnly);const auto mode=qEnvironmentVariable("HEP_FAULT_MODE");QByteArray bytes;
    if(mode=="badhello")bytes=QByteArray::fromStdString(hep::ipc::encode(hep::ipc::Hello{"wrong-token",{"hep.mock/1"},"0.1.0"}).dump());
    if(mode=="incomplete")bytes="{";
    if(!bytes.isEmpty()){QByteArray header(4,'\0');qToBigEndian(static_cast<quint32>(mode=="incomplete"?30:bytes.size()),header.data());out.write(header);out.write(bytes);out.flush();}
    QTimer::singleShot(10000,&app,&QCoreApplication::quit);return app.exec();
}
