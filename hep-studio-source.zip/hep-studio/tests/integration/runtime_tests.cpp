#include "runtime/coordinator/coordinator.hpp"
#include "runtime/project_store.hpp"
#include "runtime/environment/managed_runtime.hpp"
#include <QLockFile>
#include <QTest>
#include <QTemporaryDir>
#include <QFile>
#include <QBuffer>
#include <QtEndian>
#include <QSignalSpy>
#include <cstring>
class FeedDevice:public QIODevice{
    QByteArray data_;
public:
    FeedDevice(){open(QIODevice::ReadWrite);}
    void feed(QByteArray b){data_+=b;emit readyRead();}
    qint64 bytesAvailable()const override{return data_.size()+QIODevice::bytesAvailable();}
    qint64 readData(char* p,qint64 n)override{auto size=std::min(n,static_cast<qint64>(data_.size()));std::memcpy(p,data_.constData(),static_cast<std::size_t>(size));data_.remove(0,size);return size;}
    qint64 writeData(const char*,qint64 n)override{return n;}
};
class RuntimeTests : public QObject {
    Q_OBJECT
    QTemporaryDir data_;
    static QString worker(){return QCoreApplication::applicationDirPath()+"/hep-worker"
#ifdef Q_OS_WIN
    ".exe"
#endif
    ;}
private slots:
    void initTestCase(){
#ifdef Q_OS_LINUX
        QVERIFY(data_.isValid());qputenv("XDG_DATA_HOME",data_.path().toUtf8());
#endif
    }
    void managedRuntimeContracts(){
        using hep::ManagedRuntime;
        QVERIFY(ManagedRuntime::parseDistributionList("  NAME STATE VERSION\n* HEPStudioRuntime Stopped 2\n").at("wslGeneration")==2);
        QVERIFY(ManagedRuntime::parseDistributionList("HEPStudioRuntime Arrêté 1\n").at("state")=="Incompatible");
        QVERIFY(ManagedRuntime::parseDistributionList("OtherRuntime Running 2\n").at("present")==false);
        ManagedRuntime runtime;const auto args=runtime.workerArguments();QVERIFY(args.contains("HEP_RUNTIME_ID=wsl:HEPStudioRuntime"));QVERIFY(args.contains("--exec"));QVERIFY(!args.contains("--shell-type"));
#ifndef Q_OS_WIN
        QTemporaryDir tmp;QFile program(tmp.path()+"/fake-wsl");QVERIFY(program.open(QIODevice::WriteOnly));
        program.write("#!/bin/sh\nif [ \"$1\" = \"--list\" ]; then printf 'HEPStudioRuntime Stopped 2\\n'; else printf '{\"protocolVersion\":1,\"healthy\":true,\"fixtureOnly\":true,\"manifestVerified\":true,\"runtimeVersion\":\"fixture-v1\"}\\n'; fi\n");program.close();
        QVERIFY(program.setPermissions(QFile::ReadOwner|QFile::WriteOwner|QFile::ExeOwner));qputenv("HEP_WSL_EXECUTABLE",program.fileName().toUtf8());
        runtime.detect();QTRY_VERIFY_WITH_TIMEOUT(runtime.ready(),3000);QVERIFY(runtime.status().at("health").at("fixtureOnly")==true);qunsetenv("HEP_WSL_EXECUTABLE");
        runtime.detect();QVERIFY(runtime.status().at("state")=="Not applicable");
#endif
    }
    void releaseBudgetAfterTemporaryContention(){
        QTemporaryDir tmp;const auto path=tmp.path()+"/registry.json";hep::ResourceBroker broker(path);auto lease=broker.acquire({1,1024});QVERIFY(lease);
        QLockFile competing(path+".lock");QVERIFY(competing.tryLock());broker.release(lease->id);competing.unlock();
        QTRY_VERIFY(broker.usage().value("leases",hep::Json::array()).empty());
    }
    void sharedResourceBudget(){
        QTemporaryDir tmp;const auto registry=tmp.path()+"/budget.json";hep::ResourceBroker first(registry),second(registry);
        const auto total=std::max(1u,first.hardware().logicalCpus-1);auto lease=first.acquire({total,1024});QVERIFY(lease);QVERIFY(!second.acquire({1,1024}));
        if(total>1){QVERIFY(first.reallocate(lease->id,{1,1024}));auto other=second.acquire({total-1,1024});QVERIFY(other);second.release(other->id);}
        first.release(lease->id);QVERIFY(second.acquire({total,1024}));
    }
    void fragmentedFrames(){
        FeedDevice device;hep::ipc::Channel channel(&device);int received=0;connect(&channel,&hep::ipc::Channel::received,this,[&](const hep::ipc::Message&){++received;});QSignalSpy errors(&channel,&hep::ipc::Channel::protocolError);
        auto payload=QByteArray::fromStdString(hep::ipc::encode(hep::ipc::Heartbeat{"now"}).dump());QByteArray packet(4,'\0');qToBigEndian(static_cast<quint32>(payload.size()),packet.data());packet+=payload;
        device.feed(packet.left(2));QCOMPARE(received,0);device.feed(packet.mid(2,5));QCOMPARE(received,0);device.feed(packet.mid(7)+packet);QCOMPARE(received,2);QCOMPARE(errors.count(),0);
    }
    void rejectWorkerHandshakeAndTimeout(){
        qputenv("HEP_TRANSPORT","pipes");
        for(const auto* mode:{"badhello","incomplete","silent"}){qputenv("HEP_FAULT_MODE",mode);hep::Coordinator c;auto executable=worker();executable.replace("hep-worker","hep-fault-worker");c.launch(executable);QTRY_COMPARE_WITH_TIMEOUT(c.workerState(),QString("Crashed"),6500);QVERIFY(!c.error().isEmpty());QVERIFY(!c.busy());}
        qunsetenv("HEP_FAULT_MODE");qunsetenv("HEP_TRANSPORT");
    }
    void forcedPipesAndShutdown(){
        qputenv("HEP_TRANSPORT","pipes");hep::Coordinator c;c.launch(worker());QTRY_COMPARE_WITH_TIMEOUT(c.workerState(),QString("Healthy"),6000);QCOMPARE(c.transport(),QString("pipes"));
        QVERIFY(c.submit(hep::mockWorkflow(),"0",1000,10));QTRY_VERIFY(c.done()>0);c.shutdown();QTRY_COMPARE_WITH_TIMEOUT(c.workerState(),QString("Stopped"),3000);QCOMPARE(c.jobState(),QString("Interrupted"));
        c.launch(worker());QTRY_COMPARE_WITH_TIMEOUT(c.workerState(),QString("Healthy"),6000);c.shutdown();QTRY_COMPARE_WITH_TIMEOUT(c.workerState(),QString("Stopped"),3000);qunsetenv("HEP_TRANSPORT");
    }
    void nativeSocketTransport(){
        QLocalServer probe;if(!probe.listen("hep-probe-"+QString::fromStdString(hep::newId().value)))QSKIP("Native local sockets prohibited by this environment");probe.close();
        qputenv("HEP_TRANSPORT","socket");hep::Coordinator c;c.launch(worker());QTRY_COMPARE_WITH_TIMEOUT(c.workerState(),QString("Healthy"),6000);QCOMPARE(c.transport(),QString("socket"));QVERIFY(c.submit(hep::mockWorkflow(),"0",3,10));QTRY_COMPARE(c.jobState(),QString("Completed"));c.shutdown();QTRY_COMPARE(c.workerState(),QString("Stopped"));qunsetenv("HEP_TRANSPORT");
    }
    void malformedAndIncompleteFrames(){
        for(const auto size:{quint32(0),static_cast<quint32>(hep::ipc::maxFrame+1)}){QByteArray data(4,'\0');qToBigEndian(size,data.data());QBuffer buffer(&data);buffer.open(QIODevice::ReadOnly);hep::ipc::Channel channel(&buffer);QSignalSpy errors(&channel,&hep::ipc::Channel::protocolError);QTRY_COMPARE(errors.count(),1);}
        QByteArray data(4,'\0');qToBigEndian(quint32(30),data.data());data.append("{");QBuffer buffer(&data);buffer.open(QIODevice::ReadOnly);hep::ipc::Channel channel(&buffer);QSignalSpy errors(&channel,&hep::ipc::Channel::protocolError);QTRY_COMPARE_WITH_TIMEOUT(errors.count(),1,3000);
        QByteArray broken(4,'\0');qToBigEndian(quint32(3),broken.data());broken.append("bad");QBuffer b(&broken);b.open(QIODevice::ReadOnly);hep::ipc::Channel bad(&b);QSignalSpy failed(&bad,&hep::ipc::Channel::protocolError);QTRY_COMPARE(failed.count(),1);
    }
    void coordinatorDestructionWhileBusy(){QElapsedTimer timer;timer.start();{hep::Coordinator c;c.launch(worker());QTRY_COMPARE(c.workerState(),QString("Healthy"));QVERIFY(c.submit(hep::mockWorkflow(),"0",1000,10));QTRY_VERIFY(c.done()>0);}QVERIFY(timer.elapsed()<6000);}

    void protocolRoundTrip(){
        using namespace hep::ipc;
        const std::vector<Message> messages={Hello{"secret",{"hep.mock/1"},"0.1.0"},StartJob{"job",hep::workflowJson(hep::mockWorkflow()),2,5,1,"0"},CancelJob{"job"},Progress{"job",1,2,"mock"},Log{utcNow(),"Info","worker","job","","test"},JobCompleted{"job",hep::Json::object()},JobFailed{"job","test","failed",false},Heartbeat{utcNow()}};
        for(const auto& m:messages)QVERIFY(encode(decode(encode(m)))==encode(m));
        auto bad=encode(Progress{"job",1,2,"mock"});bad["done"]=3;QVERIFY_EXCEPTION_THROWN(decode(bad),std::invalid_argument);
        bad=encode(Heartbeat{utcNow()});bad["protocolVersion"]=2;QVERIFY_EXCEPTION_THROWN(decode(bad),std::invalid_argument);
    }
    void brokerBudget(){
        hep::ResourceBroker broker;QVERIFY(broker.hardware().logicalCpus>=1);
        const auto n=std::max(1u,broker.hardware().logicalCpus-1);
        auto lease=broker.acquire({n,1024});QVERIFY(lease);QVERIFY(!broker.acquire({1,1024}));
        broker.release(lease->id);QVERIFY(broker.acquire({1,1024}));QVERIFY(!broker.acquire({0,1024}));
    }
    void handshakeAndCompletion(){
        hep::Coordinator c;c.launch(worker());QTRY_COMPARE_WITH_TIMEOUT(c.workerState(),QString("Healthy"),5000);
        QVERIFY(c.submit(hep::mockWorkflow(),"42",5,10));QVERIFY(!c.submit(hep::mockWorkflow()));
        QTRY_COMPARE_WITH_TIMEOUT(c.jobState(),QString("Completed"),5000);
        QVERIFY(c.lastRun());QVERIFY(c.lastRun()->result.at("mockOnly")==true);QVERIFY(c.lastRun()->result.at("scientificOutputs").empty());
        QCOMPARE(c.done(),5);QCOMPARE(c.total(),5);QVERIFY(c.lastRun()->workflowHash.size()==64);QVERIFY(c.lastRun()->seed=="42");
        const auto previous=hep::projectJson({hep::newId(),"snapshot",{hep::mockWorkflow()},{*c.lastRun()}}).at("runs")[0];
        QVERIFY(c.submit(hep::mockWorkflow(true),"43",2,10));QTRY_COMPARE(c.jobState(),QString("Completed"));
        QVERIFY(previous.at("seed")=="42");QVERIFY(c.lastRun()->seed=="43");
    }
    void cancelAndReuseWorker(){
        hep::Coordinator c;c.launch(worker());QTRY_COMPARE(c.workerState(),QString("Healthy"));
        QVERIFY(c.submit(hep::mockWorkflow(),"0",1000,10));QTRY_VERIFY(c.done()>0);c.cancel();
        QTRY_COMPARE(c.jobState(),QString("Cancelled"));QVERIFY(!c.busy());QCOMPARE(c.workerState(),QString("Healthy"));
        QVERIFY(c.lastRun()->result.at("valid")==false);QVERIFY(c.submit(hep::mockWorkflow(),"0",2,10));QTRY_COMPARE(c.jobState(),QString("Completed"));
    }
    void crashIsolationAndRestart(){
        hep::Coordinator c;c.launch(worker());QTRY_COMPARE(c.workerState(),QString("Healthy"));
        QVERIFY(c.submit(hep::mockWorkflow(),"0",1000,10));QTRY_VERIFY(c.done()>0);c.killWorker();
        QTRY_COMPARE(c.workerState(),QString("Crashed"));QCOMPARE(c.jobState(),QString("Interrupted"));QVERIFY(c.lastRun()->result.at("valid")==false);
        c.launch(worker());QTRY_COMPARE(c.workerState(),QString("Healthy"));
        QVERIFY(c.submit(hep::mockWorkflow(),"0",2,10));QTRY_COMPARE(c.jobState(),QString("Completed"));
    }
    void failedLaunch(){hep::Coordinator c;c.launch("/this-path-does-not-exist/hep-worker");QTRY_COMPARE(c.workerState(),QString("Unavailable"));QVERIFY(!c.error().isEmpty());}
    void projectSaveReloadAndFailureSafety(){
        QTemporaryDir tmp;QVERIFY(tmp.isValid());const auto path=tmp.path()+"/analysis.hep.json";
        hep::Project p{hep::newId(),"Test study",{hep::mockWorkflow()}, {}};hep::saveProject(p,path);
        QVERIFY(hep::serialize(p)==hep::serialize(hep::loadProject(path)));
        QFile original(path);QVERIFY(original.open(QIODevice::ReadOnly));const auto bytes=original.readAll();original.close();
        QFile lock(path+".lock");QVERIFY(lock.open(QIODevice::WriteOnly));lock.write("1\nunrelated\nother-host\n");lock.close();
        // Invalid serialization fails before any replacement, regardless of lock ownership.
        p.extensions=hep::Json::array();QVERIFY_EXCEPTION_THROWN(hep::saveProject(p,path),std::exception);
        QVERIFY(original.open(QIODevice::ReadOnly));QCOMPARE(original.readAll(),bytes);
    }
    void invalidGraphNeverSubmitted(){
        hep::Coordinator c;c.launch(worker());QTRY_COMPARE(c.workerState(),QString("Healthy"));
        auto w=hep::mockWorkflow();w.connections.clear();QVERIFY(!c.submit(w));QVERIFY(!c.busy());QVERIFY(!c.lastRun());
    }
};
QTEST_GUILESS_MAIN(RuntimeTests)
#include "runtime_tests.moc"
