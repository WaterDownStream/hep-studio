#include "apps/desktop/bridge.hpp"
#include "core/research/research.hpp"
#include "core/analysis/analysis.hpp"
#include "render/plots/histogram_item.hpp"
#include "render/plots/scan_grid_item.hpp"
#include "runtime/project_store.hpp"
#include <QTest>
#include <QThread>
#include <QTemporaryDir>
#include <QStandardPaths>
#include <QFile>
#include <QDir>
#include <QJsonDocument>
#include <QSignalSpy>
#include <QQmlApplicationEngine>
#include <QQmlContext>
#include <QQuickWindow>
#include <QQuickStyle>
#include <QImage>
using namespace hep;
static QVariantMap map(const Json& j){return QJsonDocument::fromJson(QByteArray::fromStdString(j.dump())).toVariant().toMap();}
static Json expression(const char* op,std::initializer_list<Json> args){return {{"op",op},{"args",Json(args)}};}
class StudioTests:public QObject {
    Q_OBJECT
    QTemporaryDir tmp_;
    QString fixture_;
    static QString python(){auto p=qEnvironmentVariable("HEP_ROOT_PYTHON");return p.isEmpty()?QStandardPaths::findExecutable("python3"):p;}
private slots:
    void initTestCase(){QQuickStyle::setStyle("Fusion");qmlRegisterType<HistogramItem>("HEPStudio",1,0,"HistogramPlot");qmlRegisterType<ScanGridItem>("HEPStudio",1,0,"ScanGridPlot");QStandardPaths::setTestModeEnabled(true);
#ifdef Q_OS_LINUX
        qputenv("XDG_DATA_HOME",tmp_.path().toUtf8());QStandardPaths::setTestModeEnabled(false);
#endif
        fixture_=tmp_.path()+"/known.root";}
    void malformedRootWorker(){
        if(python().isEmpty())QSKIP("Python unavailable");
        QFile file(tmp_.path()+"/bad.py");QVERIFY(file.open(QIODevice::WriteOnly));file.write("import sys,time\nsys.stdout.buffer.write(b'\\x00\\x00\\x00\\x03bad');sys.stdout.buffer.flush();time.sleep(10)\n");file.close();
        RootService service;service.configure(python(),file.fileName());service.start();QTRY_COMPARE_WITH_TIMEOUT(service.state(),QString("Crashed"),5000);QVERIFY(!service.error().isEmpty());QVERIFY(!service.busy());
    }
    void rootWorkerLaunchFailure(){RootService service;service.configure("/nonexistent/python",QString::fromUtf8(HEP_SOURCE_DIR)+"/plugins/root/worker.py");service.start();QTRY_COMPARE_WITH_TIMEOUT(service.state(),QString("Unavailable"),3000);QVERIFY(!service.capability().value("available",false));}
    void restartRejectsClosingPipeRequests(){
        if(python().isEmpty())QSKIP("Python unavailable");
        QFile file(tmp_.path()+"/lifecycle.py");QVERIFY(file.open(QIODevice::WriteOnly));
        file.write(R"PY(import json,struct,sys,time
def send(message):
    payload=json.dumps(dict(protocolVersion=1,**message)).encode()
    sys.stdout.buffer.write(struct.pack('>I',len(payload))+payload);sys.stdout.buffer.flush()
send(dict(kind='hello',capability=dict(available=True,backend='protocol-fixture'),chunkedResults=True))
while True:
    header=sys.stdin.buffer.read(4)
    if len(header)!=4:break
    message=json.loads(sys.stdin.buffer.read(struct.unpack('>I',header)[0]))
    if message['kind']=='shutdown':time.sleep(.05);break
    if message['kind']=='request':
        send(dict(kind='resultChunk',id=message['id'],sequence=0,data='{"fixture":true}'))
        send(dict(kind='completed',id=message['id'],chunks=1))
)PY");file.close();
        RootService service;service.configure(python(),file.fileName(),"protocol-fixture");service.start();
        QTRY_COMPARE_WITH_TIMEOUT(service.state(),QString("Healthy"),5000);
        service.restart();QCOMPARE(service.state(),QString("Stopping"));QVERIFY(!service.request("settings",Json::object()));
        QTRY_COMPARE_WITH_TIMEOUT(service.state(),QString("Healthy"),5000);
        QVERIFY(service.request("settings",Json::object()));QTRY_VERIFY_WITH_TIMEOUT(!service.busy(),5000);QVERIFY(service.result().at("fixture")==true);
        service.shutdown();QVERIFY(!service.request("settings",Json::object()));QTRY_COMPARE_WITH_TIMEOUT(service.state(),QString("Stopped"),5000);
    }
    void workflowManagement(){
        Bridge bridge;const auto first=bridge.activeWorkflowId();bridge.createWorkflow("Second");QCOMPARE(bridge.workflows().size(),2);const auto second=bridge.activeWorkflowId();QVERIFY(second!=first);
        bridge.renameWorkflow("Renamed");bridge.duplicateWorkflow();QCOMPARE(bridge.workflows().size(),3);bridge.deleteWorkflow();bridge.switchToWorkflow(second);QCOMPARE(activeWorkflow(bridge.project()).name,std::string("Renamed"));
        const auto file=QUrl::fromLocalFile(tmp_.path()+"/multi.hep.json");QVERIFY(bridge.save(file));QVERIFY(bridge.open(file));QCOMPARE(bridge.activeWorkflowId(),second);bridge.switchToWorkflow(first);QCOMPARE(bridge.nodes().size(),3);
    }
    void scanGridPresentation(){
        // Plot-only fixture: these values do not assert a scientific backend.
        const auto grid=map(Json{{"title","Discrete scan rendering fixture"},{"xValues",Json::array({1.,2.})},{"yValues",Json::array({3.,4.})},{"xLabel","First parameter"},{"yLabel","Second parameter"},{"valueLabel","Recorded value"},
            {"grid",Json::array({{{"x",1.},{"y",3.},{"value",nullptr},{"status","Failed"},{"runId","failed-point"}},{{"x",2.},{"y",3.},{"value",5.},{"status","Completed"},{"runId","lower-value"}},{{"x",1.},{"y",4.},{"value",nullptr},{"status","Missing"},{"runId",""}},{{"x",2.},{"y",4.},{"value",10.},{"status","Completed"},{"runId","upper-value"}}})}});
        ScanGridItem plot;plot.setWidth(800);plot.setHeight(500);plot.setPlotData(grid);
        QCOMPARE(plot.pointAt(110,412)["status"].toString(),QString("Failed"));QVERIFY(plot.pointAt(110,412)["value"].isNull());QCOMPARE(plot.pointAt(643,75)["value"].toDouble(),10.);QVERIFY(plot.pointAt(0,0).isEmpty());
        const auto png=tmp_.path()+"/discrete-grid.png",pdf=tmp_.path()+"/discrete-grid.pdf";QVERIFY(plot.exportFigure(QUrl::fromLocalFile(png)));QVERIFY(plot.exportFigure(QUrl::fromLocalFile(pdf)));QCOMPARE(QImage(png).size(),QSize(1600,1000));QVERIFY(QFileInfo(pdf).size()>1000);QVERIFY(!plot.exportFigure(QUrl("https://invalid/export.png")));
        plot.zoom(1.4);plot.pan(.1,-.1);plot.resetView();QCOMPARE(plot.pointAt(643,75)["value"].toDouble(),10.);
        const auto artifacts=qEnvironmentVariable("HEP_TEST_ARTIFACT_DIR");if(!artifacts.isEmpty()){QDir().mkpath(artifacts);QVERIFY(plot.exportFigure(QUrl::fromLocalFile(artifacts+"/scan-grid.png")));}
    }
    void inspectorScientificIdentity(){
        Bridge bridge;bridge.newColliderWorkflow(false);
        const auto before=scientificJson(activeWorkflow(bridge.project()),bridge.project().seed).dump();
        const auto configBefore=activeWorkflow(bridge.project()).nodes.front().extensions.at("config");
        auto config=bridge.selectedConfig();config["workers"]=2;bridge.updateAnalysisNode(config);
        QCOMPARE(scientificJson(activeWorkflow(bridge.project()),bridge.project().seed).dump(),before);
        auto configAfter=activeWorkflow(bridge.project()).nodes.front().extensions.at("config");
        configAfter.erase("workers");auto unchanged=configBefore;unchanged.erase("workers");QCOMPARE(configAfter.dump(),unchanged.dump());
        bridge.undo();QCOMPARE(activeWorkflow(bridge.project()).nodes.front().extensions.at("config").dump(),configBefore.dump());
        bridge.redo();QCOMPARE(scientificJson(activeWorkflow(bridge.project()),bridge.project().seed).dump(),before);
    }
    void madgraphModelEditing(){
        Bridge bridge;bridge.newResearchWorkflow();const auto source=bridge.selectedId();QCOMPARE(bridge.selectedKind(),QString("MadGraph"));
        const auto nominal=scientificJson(activeWorkflow(bridge.project()));
        QQmlApplicationEngine engine;engine.rootContext()->setContextProperty("studio",&bridge);engine.load(QUrl("qrc:/apps/desktop/Main.qml"));QVERIFY(!engine.rootObjects().isEmpty());
        auto* selector=engine.rootObjects().front()->findChild<QObject*>("madgraphModelSelector");QVERIFY(selector);
        selector->setProperty("currentIndex",1);QVERIFY(QMetaObject::invokeMethod(selector,"activated",Q_ARG(int,1)));
        QCOMPARE(bridge.selectedConfig()["model"].toString(),QString("sm-full"));const auto changed=scientificJson(activeWorkflow(bridge.project()));QVERIFY(changed!=nominal);lowerResearch(activeWorkflow(bridge.project()));
        bridge.undo();QVERIFY(scientificJson(activeWorkflow(bridge.project()))==nominal);bridge.redo();QVERIFY(scientificJson(activeWorkflow(bridge.project()))==changed);
        const auto file=QUrl::fromLocalFile(tmp_.path()+"/model.hep.json");QVERIFY(bridge.save(file));QVERIFY(bridge.open(file));bridge.select(source);QCOMPARE(bridge.selectedConfig()["model"].toString(),QString("sm-full"));
        QVERIFY(scientificJson(activeWorkflow(bridge.project()))==changed);
    }
    void structuredQmlBuilder(){
        Bridge bridge;bridge.createWorkflow("Visual builder test");auto source=rootNode("Source",newId());
        Json schema={{"entries",5},{"columns",Json::array()}};
        for(const auto* name:{"px","py"})schema["columns"].push_back({{"name",name},{"backendType","double"},{"unit","GeV"},{"unitKnown",true}});
        source.extensions["config"]={{"datasetId","fixture"},{"object","Events"},{"schema",schema}};
        activeWorkflow(bridge.project()).nodes.push_back(source);
        QQmlApplicationEngine engine;engine.rootContext()->setContextProperty("studio",&bridge);engine.load(QUrl("qrc:/apps/desktop/Main.qml"));QVERIFY(!engine.rootObjects().isEmpty());
        auto* builder=engine.rootObjects().front()->findChild<QObject*>("analysisBuilder");auto* formula=engine.rootObjects().front()->findChild<QObject*>("formulaEditor");QVERIFY(builder);QVERIFY(formula);
        QVERIFY(QMetaObject::invokeMethod(builder,"begin",Q_ARG(QVariant,QVariant("Define")),Q_ARG(QVariant,QVariant(false))));
        const auto pt=expression("sqrt",{expression("add",{expression("square",{columnExpression("px")}),expression("square",{columnExpression("py")})})});
        QVERIFY(formula->setProperty("expression",map(pt)));QVERIFY(bridge.expressionSummary(map(pt)).contains("momentum"));
        QTest::qWait(30);QVERIFY(QMetaObject::invokeMethod(builder,"accept"));QCOMPARE(activeWorkflow(bridge.project()).nodes.size(),std::size_t(2));
        QVERIFY(activeWorkflow(bridge.project()).nodes.back().extensions["config"]["expression"]==pt);
        QVERIFY(QMetaObject::invokeMethod(builder,"begin",Q_ARG(QVariant,QVariant("Filter")),Q_ARG(QVariant,QVariant(false))));
        const auto cut=expression("and",{expression("gt",{columnExpression("pT"),literalExpression(1,"GeV")}),expression("not",{expression("lt",{columnExpression("px"),literalExpression(0,"GeV")})})});
        QVERIFY(formula->setProperty("expression",map(cut)));QVERIFY(QMetaObject::invokeMethod(builder,"accept"));QCOMPARE(activeWorkflow(bridge.project()).nodes.size(),std::size_t(3));QVERIFY(activeWorkflow(bridge.project()).nodes.back().extensions["config"]["expression"]==cut);
    }
    void templateLikelihoodWorkflow(){
        Bridge bridge;QTRY_VERIFY_WITH_TIMEOUT(bridge.researchService().state()!="Initializing",35000);
        if(!bridge.researchService().capability().value("libraries",Json::object()).value("RooStats",Json::object()).value("available",false))QSKIP("RooStats unavailable");
        for(const auto& [role,yield]:std::vector<std::pair<std::string,double>>{{"signal",10.},{"background",20.}}){
            Run input{Id("template-"+role),"Completed",workflowJson(activeWorkflow(bridge.project())),"numerical-reference"};input.backend="numerical-reference";
            const auto h=Json{{"kind","Histogram1D"},{"edges",Json::array({0.,1.})},{"values",Json::array({yield})},{"errors",Json::array({std::sqrt(yield)})},{"normalization","counts"},{"yieldMode","luminosity"}};
            // Original ROOT Runs did not carry a top-level valid field. They
            // remain reusable when complete and without an invalid/partial flag.
            input.result={{"results",{{"hist",h}}}};bridge.project().runs.push_back(std::move(input));
        }
        QCOMPARE(bridge.histogramReferences().size(),2);const auto immutable=projectJson(bridge.project())["runs"];
        bridge.newTemplateWorkflow();QQmlApplicationEngine engine;engine.rootContext()->setContextProperty("studio",&bridge);engine.load(QUrl("qrc:/apps/desktop/Main.qml"));QVERIFY(!engine.rootObjects().isEmpty());
        const auto& w=activeWorkflow(bridge.project());const auto source=QString::fromStdString(w.nodes[0].id.value),model=QString::fromStdString(w.nodes[1].id.value),inference=QString::fromStdString(w.nodes[2].id.value);
        Json samples=Json::array();const auto refs=bridge.histogramReferences();
        for(int i=0;i<refs.size();++i){const auto ref=Json::parse(QJsonDocument::fromVariant(refs[i].toMap()["reference"]).toJson().toStdString());samples.push_back({{"id",i==0?"signal":"background"},{"role",i==0?"signal":"background"},{"reference",ref}});}
        auto config=bridge.selectedConfig();config["samples"]=QJsonDocument::fromJson(QByteArray::fromStdString(samples.dump())).toVariant();bridge.updateAnalysisNode(config);
        bridge.run();QTRY_COMPARE_WITH_TIMEOUT(bridge.project().runs.size(),std::size_t(3),20000);QVERIFY2(bridge.project().runs.back().status=="Completed",bridge.notice().toUtf8());
        const auto limit=bridge.project().runs.back().result.at("results").at(inference.toStdString());QVERIFY(limit.at("valid")==true);QVERIFY(std::abs(limit.at("upperLimit").get<double>()-1.009)<.03);
        QVERIFY(bridge.generatedCode().contains("reference-inference.json"));QVERIFY(bridge.provenance().contains("inputRuns"));QVERIFY(bridge.fitDiagnostics().contains("INFERENCE RESULT"));
        QCOMPARE(bridge.statisticalResult()["kind"].toString(),QString("HypothesisResult"));QVERIFY(bridge.statisticalResult()["scan"].toList().size()>=10);
        const auto file=QUrl::fromLocalFile(tmp_.path()+"/templates.hep.json");QVERIFY(bridge.save(file));QVERIFY(bridge.open(file));QCOMPARE(bridge.project().runs.size(),std::size_t(3));
        bridge.select(model);config=bridge.selectedConfig();const auto nuisance=Json::array({{{"kind","normalization"},{"samples",Json::array({"signal","background"})},{"correlationGroup","scale"},{"constraint","gaussian-standard-normal"},{"variationMeaning","minus-plus-one-sigma"},{"down",.9},{"up",1.1}}});
        config["nuisances"]=QJsonDocument::fromJson(QByteArray::fromStdString(nuisance.dump())).toVariant();bridge.updateAnalysisNode(config);
        bool sourceStale=true,inferenceStale=false;for(const auto& row:bridge.nodes()){const auto item=row.toMap();if(item["id"]==source)sourceStale=item["stale"].toBool();if(item["id"]==inference)inferenceStale=item["stale"].toBool();}QVERIFY(!sourceStale);QVERIFY(inferenceStale);
        bridge.undo();QCOMPARE(bridge.selectedConfig()["nuisances"].toList().size(),0);bridge.redo();bridge.run();QTRY_COMPARE_WITH_TIMEOUT(bridge.project().runs.size(),std::size_t(4),20000);QVERIFY2(bridge.project().runs.back().status=="Completed",bridge.notice().toUtf8());
        QVERIFY(bridge.project().runs.back().result["results"][inference.toStdString()]["upperLimit"].get<double>()>limit["upperLimit"].get<double>());
        for(std::size_t i=0;i<2;++i)QVERIFY(projectJson(bridge.project())["runs"][i]==immutable[i]);
        bridge.chooseRuns(0,1);QVERIFY(bridge.comparison().contains("nuisances"));
        bridge.exportCode(QUrl::fromLocalFile(tmp_.path()+"/template-reference.py"));QVERIFY(QFileInfo::exists(tmp_.path()+"/template-reference.py"));
        QVERIFY(bridge.save(file));QVERIFY(bridge.open(file));QCOMPARE(bridge.project().runs.size(),std::size_t(4));
        bridge.select(source);config=bridge.selectedConfig();auto unavailable=samples;unavailable[0]["reference"]["runId"]="missing-run";config["samples"]=QJsonDocument::fromJson(QByteArray::fromStdString(unavailable.dump())).toVariant();bridge.updateAnalysisNode(config);bridge.run();QVERIFY(!bridge.busy());QCOMPARE(bridge.project().runs.size(),std::size_t(4));QVERIFY(bridge.notice().contains("unavailable"));
    }
    void savedResearchExamples(){
        Bridge bridge;
        for(const auto* name:{"research-dilepton","research-template-study","research-scan"}){
            const auto file=QUrl::fromLocalFile(QString::fromUtf8(HEP_SOURCE_DIR)+"/examples/"+name+".hep.json");
            QVERIFY2(bridge.open(file),bridge.notice().toUtf8());QVERIFY(!bridge.project().runs.empty());
            for(const auto& run:bridge.project().runs){QCOMPARE(run.status,std::string("Completed"));QVERIFY(run.result.value("valid",false));QVERIFY(!run.resources.empty());QVERIFY(run.extensions.contains("frozenEnvironment"));QCOMPARE(run.workflowHash,workflowHash(scientificJson(workflowFromJson(run.workflowSnapshot),bridge.project().seed)).toStdString());}
            const auto history=projectJson(bridge.project())["runs"];
            if(std::string(name)=="research-dilepton"){bridge.select("example-dilepton-fit");QVERIFY(bridge.statisticalResult()["valid"].toBool());QCOMPARE(bridge.statisticalResult()["parameters"].toList().size(),2);QVERIFY(!bridge.plotSeries().isEmpty());}
            if(std::string(name)=="research-template-study"){QCOMPARE(bridge.histogramReferences().size(),2);bridge.select("example-model-2");QVERIFY(bridge.statisticalResult()["valid"].toBool());QCOMPARE(bridge.project().workflows.size(),std::size_t(3));QCOMPARE(bridge.activeWorkflowId(),QString("example-statistical-model"));}
            if(std::string(name)=="research-scan"){QCOMPARE(bridge.scans().size(),1);QCOMPARE(bridge.recommendedScan()["axes"].toList().size(),1);const auto curve=bridge.parameterScanPlot(bridge.scans()[0].toMap()["id"].toString(),"histogram-integral");QVERIFY2(!curve.contains("error"),curve.value("error").toString().toUtf8());QCOMPARE(curve["curve"].toList().size(),3);QCOMPARE(curve["excludedPoints"].toUInt(),0U);}
            const auto copy=QUrl::fromLocalFile(tmp_.path()+"/saved-example.hep.json");QVERIFY(bridge.save(copy));QVERIFY(bridge.open(copy));QVERIFY(projectJson(bridge.project())["runs"]==history);
        }
    }
    void multichannelAndTwoAxisScan(){
        Bridge bridge;QTRY_VERIFY_WITH_TIMEOUT(bridge.researchService().state()!="Initializing",35000);
        if(!bridge.researchService().capability().value("libraries",Json::object()).value("RooStats",Json::object()).value("available",false))QSKIP("RooStats unavailable");
        Json samples=Json::array();
        for(const auto& channel:std::vector<std::string>{"electron","muon"})for(const auto& role:std::vector<std::string>{"signal","background"}){
            const auto id=channel+"_"+role;const double yield=role=="signal"?(channel=="electron"?10.:5.):(channel=="electron"?20.:30.);
            const Json h={{"kind","Histogram1D"},{"edges",Json::array({0.,1.})},{"values",Json::array({yield})},{"errors",Json::array({std::sqrt(yield)})},{"normalization","counts"},{"yieldMode","luminosity"}};
            Run input{Id(id),"Completed",workflowJson(activeWorkflow(bridge.project())),"controlled-poisson-reference"};input.backend="controlled-poisson-reference";input.result={{"results",{{"hist",h}}}};bridge.project().runs.push_back(std::move(input));
            samples.push_back({{"id",id},{"channel",channel},{"role",role},{"reference",{{"runId",id},{"nodeId","hist"},{"inputIdentity",workflowHash(h).toStdString()}}}});
        }
        const auto inputs=projectJson(bridge.project())["runs"];bridge.newTemplateWorkflow();
        QQmlApplicationEngine engine;engine.rootContext()->setContextProperty("studio",&bridge);engine.load(QUrl("qrc:/apps/desktop/Main.qml"));QVERIFY(!engine.rootObjects().empty());
        const auto& w=activeWorkflow(bridge.project());const auto source=w.nodes[0].id.value,model=w.nodes[1].id.value,inference=w.nodes[2].id.value;
        auto config=bridge.selectedConfig();config["samples"]=QJsonDocument::fromJson(QByteArray::fromStdString(samples.dump())).toVariant();bridge.updateAnalysisNode(config);
        auto* consent=engine.rootObjects()[0]->findChild<QObject*>("channelIndependence");QVERIFY(consent);QVERIFY(consent->setProperty("checked",true));QVERIFY(QMetaObject::invokeMethod(consent,"clicked"));
        QCOMPARE(bridge.selectedConfig()["channelIndependence"].toString(),QString("disjoint-event-categories"));
        bridge.undo();QVERIFY(!bridge.selectedConfig().contains("channelIndependence"));bridge.redo();
        bridge.run();QTRY_COMPARE_WITH_TIMEOUT(bridge.project().runs.size(),std::size_t(5),20000);QVERIFY2(bridge.project().runs.back().status=="Completed",bridge.notice().toUtf8());
        QVERIFY(bridge.project().runs.back().result["results"][inference]["valid"]==true);QCOMPARE(bridge.project().runs.back().result["results"][inference]["model"]["channels"].size(),std::size_t(2));
        QVERIFY(bridge.generatedCode().contains("disjoint-event-categories"));const auto initialRun=projectJson(bridge.project())["runs"][4];
        const Json scan={{"axes",Json::array({{{"nodeId",model},{"pointer","/muMax"},{"unit","1"},{"spacing","linear"},{"lower",4.},{"upper",5.},{"count",2}},{{"nodeId",inference},{"pointer","/confidenceLevel"},{"unit","1"},{"spacing","linear"},{"lower",.90},{"upper",.95},{"count",2}}})}};
        bridge.runParameterScan(map(scan));QTRY_VERIFY_WITH_TIMEOUT(!bridge.busy(),30000);QCOMPARE(bridge.scans().size(),1);QVERIFY2(bridge.scans()[0].toMap()["state"]=="completed",bridge.notice().toUtf8());QCOMPARE(bridge.project().runs.size(),std::size_t(9));
        const auto scanId=bridge.scans()[0].toMap()["id"].toString();auto grid=bridge.parameterScanPlot(scanId,"upper-limit");QVERIFY2(!grid.contains("error"),grid.value("error").toString().toUtf8());QCOMPARE(grid["dimensions"].toInt(),2);QCOMPARE(grid["grid"].toList().size(),4);QCOMPARE(grid["excludedPoints"].toUInt(),0U);
        double low=0,high=0;for(const auto& cell:grid["grid"].toList()){const auto c=cell.toMap();QCOMPARE(c["status"].toString(),QString("Completed"));QVERIFY(c["value"].toDouble()>0);if(c["x"].toDouble()==5.){if(c["y"].toDouble()==.90)low=c["value"].toDouble();else high=c["value"].toDouble();}}QVERIFY(high>low);
        const auto unchanged=projectJson(bridge.project());ScanGridItem plot;plot.setWidth(800);plot.setHeight(500);plot.setPlotData(grid);QVERIFY(plot.exportFigure(QUrl::fromLocalFile(tmp_.path()+"/scan-grid.png")));QVERIFY(plot.exportFigure(QUrl::fromLocalFile(tmp_.path()+"/scan-grid.pdf")));QVERIFY(QFileInfo(tmp_.path()+"/scan-grid.png").size()>10000);plot.zoom(1.2);plot.pan(.1,-.1);plot.resetView();QVERIFY(projectJson(bridge.project())==unchanged);
        QVERIFY(engine.rootObjects()[0]->findChild<QObject*>("scanTwoAxes"));QVERIFY(engine.rootObjects()[0]->findChild<QObject*>("scanGridPlot"));
        const auto file=QUrl::fromLocalFile(tmp_.path()+"/two-axis.hep.json");QVERIFY(bridge.save(file));QVERIFY(bridge.open(file));QCOMPARE(bridge.project().runs.size(),std::size_t(9));QCOMPARE(bridge.parameterScanPlot(scanId,"upper-limit"),grid);
        // Faulted historical fixtures must display holes, never interpolated
        // or silently substituted values. This mutation is test setup only.
        bridge.project().runs.back().status="Failed";bridge.project().runs.pop_back();bridge.project().runs.back().status="Failed";
        grid=bridge.parameterScanPlot(scanId,"upper-limit");QVERIFY(!grid.contains("error"));QCOMPARE(grid["grid"].toList().size(),4);QCOMPARE(grid["excludedPoints"].toUInt(),2U);
        unsigned missing=0,failed=0;for(const auto& cell:grid["grid"].toList()){const auto c=cell.toMap();if(c["status"]=="Missing"){++missing;QVERIFY(c["value"].isNull());}if(c["status"]=="Failed"){++failed;QVERIFY(c["value"].isNull());}}QCOMPARE(missing,1U);QCOMPARE(failed,1U);
        for(std::size_t i=0;i<4;++i){QVERIFY(projectJson(bridge.project())["runs"][i]==inputs[i]);}
        QVERIFY(projectJson(bridge.project())["runs"][4]==initialRun);
        QVERIFY(bridge.open(file));bridge.select(QString::fromStdString(source));config=bridge.selectedConfig();config["channelIndependence"]="";bridge.updateAnalysisNode(config);bridge.run();QTRY_VERIFY_WITH_TIMEOUT(!bridge.busy(),20000);QCOMPARE(bridge.project().runs.back().status,std::string("Failed"));QVERIFY(bridge.notice().contains("disjoint"));QVERIFY(bridge.project().runs.back().result["valid"]==false);
    }
    void reconstructedOverlapEditing(){
        Bridge bridge;bridge.newResearchWorkflow();QString detector,muons;
        for(const auto& node:activeWorkflow(bridge.project()).nodes){if(node.typeId=="hep.research.Delphes")detector=QString::fromStdString(node.id.value);if(node.typeId=="hep.research.Muons")muons=QString::fromStdString(node.id.value);}
        bridge.select(detector);bridge.addResearchNode("Jets");const auto original=scientificJson(activeWorkflow(bridge.project()));
        bridge.addOverlapRemoval(muons);QCOMPARE(bridge.selectedKind(),QString("OverlapRemoval"));const auto config=bridge.selectedConfig();QCOMPARE(config["collectionType"].toString(),QString("RecoJetCollection"));QCOMPARE(config["referenceType"].toString(),QString("RecoMuonCollection"));
        const auto created=scientificJson(activeWorkflow(bridge.project()));QVERIFY(created!=original);lowerResearch(activeWorkflow(bridge.project()));
        bridge.undo();QVERIFY(scientificJson(activeWorkflow(bridge.project()))==original);bridge.redo();QVERIFY(scientificJson(activeWorkflow(bridge.project()))==created);
        QVERIFY(bridge.researchCollections().size()>=2);const auto file=QUrl::fromLocalFile(tmp_.path()+"/overlap.hep.json");QVERIFY(bridge.save(file));QVERIFY(bridge.open(file));QVERIFY(scientificJson(activeWorkflow(bridge.project()))==created);
    }
    void reconstructedCombinationEditing(){
        Bridge bridge;bridge.newResearchWorkflow();QString detector,muons;for(const auto& node:activeWorkflow(bridge.project()).nodes){if(node.typeId=="hep.research.Delphes")detector=QString::fromStdString(node.id.value);if(node.typeId=="hep.research.Muons")muons=QString::fromStdString(node.id.value);}
        bridge.select(detector);bridge.addResearchNode("Electrons");const auto electrons=bridge.selectedId();bridge.select(muons);const auto initial=scientificJson(activeWorkflow(bridge.project()));
        bridge.addCollectionCombine(electrons);QCOMPARE(bridge.selectedKind(),QString("CollectionCombine"));const auto combined=scientificJson(activeWorkflow(bridge.project()));lowerResearch(activeWorkflow(bridge.project()));
        bridge.undo();QVERIFY(scientificJson(activeWorkflow(bridge.project()))==initial);bridge.redo();QVERIFY(scientificJson(activeWorkflow(bridge.project()))==combined);
        bridge.addResearchNode("Pairs");QCOMPARE(bridge.selectedConfig()["collectionType"].toString(),QString("RecoLeptonCollection"));lowerResearch(activeWorkflow(bridge.project()));
        const auto state=scientificJson(activeWorkflow(bridge.project()));const auto file=QUrl::fromLocalFile(tmp_.path()+"/combination.hep.json");QVERIFY(bridge.save(file));QVERIFY(bridge.open(file));QVERIFY(scientificJson(activeWorkflow(bridge.project()))==state);
    }
    void detectorCardRelinking(){
        Bridge bridge;bridge.newResearchWorkflow();QString detector;for(const auto& node:activeWorkflow(bridge.project()).nodes)if(node.typeId=="hep.research.Delphes")detector=QString::fromStdString(node.id.value);bridge.select(detector);
        const auto first=tmp_.path()+"/card-first",second=tmp_.path()+"/card-second";QVERIFY(QDir().mkpath(first));QVERIFY(QDir().mkpath(second));
        for(const auto& directory:{first,second}){QFile card(directory+"/detector.tcl");QVERIFY(card.open(QIODevice::WriteOnly));card.write("set RandomSeed 10\n");card.close();QFile dependency(directory+"/included.tcl");QVERIFY(dependency.open(QIODevice::WriteOnly));dependency.write("set Efficiency 0.9\n");}
        bridge.selectDetectorCard(QUrl::fromLocalFile(first+"/detector.tcl"));const auto science=scientificJson(activeWorkflow(bridge.project()),bridge.project().seed);const auto config=bridge.selectedConfig();QVERIFY(config["card"].toMap().contains("resourceId"));
        bridge.selectDetectorCard(QUrl::fromLocalFile(second+"/detector.tcl"));QVERIFY(scientificJson(activeWorkflow(bridge.project()),bridge.project().seed)==science);QVERIFY(bridge.selectedConfig()==config);
        const auto id=config["card"].toMap()["resourceId"].toString().toStdString();QVERIFY(bridge.project().extensions["resources"][id]["locations"][0]["path"]==(second+"/detector.tcl").toStdString());
        QFile changed(second+"/included.tcl");QVERIFY(changed.open(QIODevice::WriteOnly|QIODevice::Truncate));changed.write("set Efficiency 0.8\n");changed.close();bridge.selectDetectorCard(QUrl::fromLocalFile(second+"/detector.tcl"));QVERIFY(scientificJson(activeWorkflow(bridge.project()),bridge.project().seed)!=science);
        bridge.undo();QVERIFY(scientificJson(activeWorkflow(bridge.project()),bridge.project().seed)==science);bridge.redo();QVERIFY(scientificJson(activeWorkflow(bridge.project()),bridge.project().seed)!=science);
        const auto file=QUrl::fromLocalFile(tmp_.path()+"/card-relink.hep.json");QVERIFY(bridge.save(file));QVERIFY(bridge.open(file));QCOMPARE(bridge.project().extensions["resources"].size(),std::size_t(2));
    }
    void researchWorkflow(){
        Bridge bridge;QTRY_VERIFY_WITH_TIMEOUT(bridge.researchService().state()!="Initializing",35000);
        const auto cap=bridge.researchService().capability();
        for(const auto* name:{"MadGraph","PYTHIA","HepMC3","Delphes","ROOT"})if(!cap.value("libraries",Json::object()).value(name,Json::object()).value("available",false)){
            QVERIFY2(!qEnvironmentVariableIsSet("HEP_REQUIRE_RESEARCH"),"Required research library unavailable");QSKIP("Real research SDK is not configured");
        }
        bridge.newResearchWorkflow();QString generator,selection,histogram;
        for(auto& n:activeWorkflow(bridge.project()).nodes){
            if(n.typeId=="hep.research.MadGraph")generator=QString::fromStdString(n.id.value);
            if(n.typeId=="hep.research.Shower"){n.extensions["config"].update({{"isr",false},{"fsr",false},{"mpi",false},{"hadronisation",false},{"partitionEvents",25},{"workers",2}});}
            if(n.typeId=="hep.research.Delphes")n.extensions["config"]["card"]={{"builtin","ideal-muon"}};
            if(n.typeId=="hep.research.CollectionFilter"){selection=QString::fromStdString(n.id.value);n.extensions["config"]["expression"]["args"][1]["value"]=0.;}
            if(n.typeId=="hep.root.Histo1D")histogram=QString::fromStdString(n.id.value);
        }
        bridge.run();QTRY_COMPARE_WITH_TIMEOUT(bridge.project().runs.size(),std::size_t(1),90000);QVERIFY2(bridge.project().runs.back().status=="Completed",bridge.notice().toUtf8());
        const auto immutable=projectJson(bridge.project())["runs"][0];const auto result=bridge.project().runs.back().result;
        QCOMPARE(result.at("metrics").at("inputEvents").get<int>(),100);QCOMPARE(result.at("metrics").at("rdfEventLoops").get<int>(),1);QVERIFY(result["metrics"]["bulkEventsThroughIPC"]==0);
        bridge.inspectResearchCards();QTRY_VERIFY_WITH_TIMEOUT(!bridge.busy(),10000);QCOMPARE(bridge.researchPreview()["cards"].toList().size(),6);QCOMPARE(bridge.project().runs.size(),std::size_t(1));
        const auto evidenceFile=QUrl::fromLocalFile(tmp_.path()+"/run-evidence.json");bridge.exportResearchEvidence(evidenceFile);QFile evidence(evidenceFile.toLocalFile());QVERIFY(evidence.open(QIODevice::ReadOnly));const auto exported=Json::parse(evidence.readAll().toStdString());QCOMPARE(exported.at("recordedCards").size(),std::size_t(6));QVERIFY(exported["run"]==immutable);QVERIFY(exported["recordedCards"][1]["text"].get<std::string>().find("nevents")!=std::string::npos);
        bridge.select(histogram);QVERIFY(!bridge.plotSeries().empty());QVERIFY(bridge.provenance().contains("detectorCard"));QVERIFY(bridge.provenance().contains("actualSeed"));
        bridge.previewReconstruction(0,5);QTRY_VERIFY_WITH_TIMEOUT(!bridge.busy(),10000);QVERIFY2(bridge.researchPreview().value("preview").toBool(),bridge.notice().toUtf8());QCOMPARE(bridge.project().runs.size(),std::size_t(1));
        QVERIFY(bridge.save(QUrl::fromLocalFile(tmp_.path()+"/research.hep.json")));QVERIFY(bridge.open(QUrl::fromLocalFile(tmp_.path()+"/research.hep.json")));
        bridge.select(selection);auto config=bridge.selectedConfig();const auto ast=expression("gt",{columnExpression("pt"),literalExpression(40,"GeV")});config["expression"]=map(ast);bridge.updateAnalysisNode(config);
        bool generatorStale=true,histStale=false;for(const auto& row:bridge.nodes()){const auto m=row.toMap();if(m["id"]==generator)generatorStale=m["stale"].toBool();if(m["id"]==histogram)histStale=m["stale"].toBool();}QVERIFY(!generatorStale);QVERIFY(histStale);
        bridge.run();QTRY_COMPARE_WITH_TIMEOUT(bridge.project().runs.size(),std::size_t(2),45000);QVERIFY2(bridge.project().runs.back().status=="Completed",bridge.notice().toUtf8());
        const auto stages=bridge.project().runs.back().result.at("stages");QVERIFY(stages[0].at("cacheReused")==true);
        bridge.chooseRuns(0,1);bridge.select(histogram);QCOMPARE(bridge.plotSeries().size(),2);QVERIFY(bridge.comparison().contains("40"));QVERIFY(projectJson(bridge.project())["runs"][0]==immutable);
        QVERIFY(bridge.generatedCode().contains("ROOT.RDataFrame"));bridge.exportCode(QUrl::fromLocalFile(tmp_.path()+"/research-reference.py"));QVERIFY(QFileInfo::exists(tmp_.path()+"/research-reference.py"));
        const auto nominalHash=workflowHash(scientificJson(activeWorkflow(bridge.project()),bridge.project().seed));
        const auto scan=Json{{"axes",Json::array({{{"nodeId",selection.toStdString()},{"pointer","/expression/args/1/value"},{"unit","GeV"},{"spacing","linear"},{"lower",10.},{"upper",40.},{"count",3}}})}};
        bridge.runParameterScan(map(scan));QTRY_VERIFY_WITH_TIMEOUT(!bridge.busy(),45000);QVERIFY2(bridge.project().runs.size()==5,bridge.notice().toUtf8());
        QCOMPARE(bridge.scans().size(),1);QCOMPARE(bridge.scans()[0].toMap()["state"].toString(),QString("completed"));
        const auto scanPlot=bridge.parameterScanPlot(bridge.scans()[0].toMap()["id"].toString(),"histogram-integral");QVERIFY2(!scanPlot.contains("error"),scanPlot.value("error").toString().toUtf8());QCOMPARE(scanPlot["curve"].toList().size(),3);QCOMPARE(scanPlot["excludedPoints"].toUInt(),0U);
        const auto curve=scanPlot["curve"].toList();QCOMPARE(curve[0].toList()[0].toDouble(),10.);QCOMPARE(curve[2].toList()[0].toDouble(),40.);QVERIFY(curve[0].toList()[1].toDouble()>=curve[2].toList()[1].toDouble());
        for(std::size_t i=2;i<5;++i){QCOMPARE(bridge.project().runs[i].status,std::string("Completed"));QVERIFY(bridge.project().runs[i].extensions.contains("scanId"));QVERIFY(bridge.project().runs[i].extensions.contains("nodeHashes"));}
        QCOMPARE(workflowHash(scientificJson(activeWorkflow(bridge.project()),bridge.project().seed)),nominalHash);QVERIFY(projectJson(bridge.project())["runs"][0]==immutable);
        const auto systematic=Json::array({{{"id","normalization"},{"name","Normalization study"},{"kind","normalization"},{"nominal",1.},{"affectedNodes",Json::array({histogram.toStdString()})},{"correlation",{{"group","normalization"}}},{"interpretation","Sensitivity envelope; no prior"},{"variations",Json::array({{{"label","up"},{"factor",1.1}},{{"label","down"},{"factor",0.9}}})}}});
        bridge.setSystematics(QJsonDocument::fromJson(QByteArray::fromStdString(systematic.dump())).toVariant().toList());QCOMPARE(bridge.systematics().size(),1);
        bridge.undo();QCOMPARE(bridge.systematics().size(),0);bridge.redo();QCOMPARE(bridge.systematics().size(),1);
        QVERIFY(bridge.save(QUrl::fromLocalFile(tmp_.path()+"/research.hep.json")));QVERIFY(bridge.open(QUrl::fromLocalFile(tmp_.path()+"/research.hep.json")));QCOMPARE(bridge.project().runs.size(),std::size_t(5));QCOMPARE(bridge.systematics().size(),1);QCOMPARE(bridge.scans().size(),1);
        bridge.researchService().crash();QTRY_COMPARE_WITH_TIMEOUT(bridge.researchService().state(),QString("Crashed"),3000);bridge.restartResearch();QTRY_COMPARE_WITH_TIMEOUT(bridge.researchService().state(),QString("Healthy"),15000);
    }
    void researchCancellationAndCrash(){
        Bridge bridge;QTRY_VERIFY_WITH_TIMEOUT(bridge.researchService().state()!="Initializing",35000);
        const auto cap=bridge.researchService().capability();for(const auto* name:{"MadGraph","PYTHIA","HepMC3","Delphes","ROOT"})if(!cap.value("libraries",Json::object()).value(name,Json::object()).value("available",false)){QSKIP("Real research SDK is unavailable");}
        const auto file=QUrl::fromLocalFile(QString::fromUtf8(HEP_SOURCE_DIR)+"/examples/research-dilepton.hep.json");QVERIFY(bridge.open(file));const auto original=projectJson(bridge.project())["runs"][0];
        auto& workflow=activeWorkflow(bridge.project());workflow.nodes.front().extensions["config"]["events"]=1000;workflow.nodes.front().extensions["config"]["seed"]=29701;
        bridge.run();QTRY_VERIFY_WITH_TIMEOUT(bridge.researchService().metrics().value("elapsedSeconds",0.)>.1,30000);bridge.cancel();QTRY_VERIFY_WITH_TIMEOUT(!bridge.busy(),5000);QCOMPARE(bridge.project().runs.size(),std::size_t(2));QCOMPARE(bridge.project().runs.back().status,std::string("Cancelled"));QVERIFY(bridge.project().runs.back().result["partial"]==true);QVERIFY(bridge.project().runs.back().result["valid"]==false);QVERIFY(projectJson(bridge.project())["runs"][0]==original);
        bridge.run();QTRY_VERIFY_WITH_TIMEOUT(bridge.researchService().metrics().value("elapsedSeconds",0.)>.1,30000);bridge.researchService().crash();QTRY_VERIFY_WITH_TIMEOUT(!bridge.busy(),5000);QCOMPARE(bridge.project().runs.size(),std::size_t(3));QCOMPARE(bridge.project().runs.back().status,std::string("Interrupted"));QVERIFY(bridge.project().runs.back().result["valid"]==false);
        bridge.restartResearch();QTRY_COMPARE_WITH_TIMEOUT(bridge.researchService().state(),QString("Healthy"),35000);QVERIFY(bridge.save(QUrl::fromLocalFile(tmp_.path()+"/research-interrupted.hep.json")));QVERIFY(bridge.open(QUrl::fromLocalFile(tmp_.path()+"/research-interrupted.hep.json")));QVERIFY(projectJson(bridge.project())["runs"][0]==original);QCOMPARE(bridge.project().runs.back().status,std::string("Interrupted"));
    }
    void colliderWorkflow(){
        Bridge bridge;
#ifdef Q_OS_WIN
        QTRY_VERIFY_WITH_TIMEOUT(bridge.colliderService().state()=="Healthy"||bridge.managedRuntime().value("state").toString()=="Needs installation"||bridge.managedRuntime().value("state").toString()=="Unavailable"||bridge.managedRuntime().value("state").toString()=="Incompatible",180000);
#else
        QTRY_VERIFY_WITH_TIMEOUT(bridge.colliderService().state()!="Initializing",35000);
#endif
        if(!bridge.colliderService().capability().value("available",false)){QVERIFY2(!qEnvironmentVariableIsSet("HEP_REQUIRE_COLLIDER"),"Required collider runtime unavailable");QSKIP("Collider engine unavailable");}
        bridge.newColliderWorkflow(true);auto& workflow=activeWorkflow(bridge.project());QCOMPARE(workflow.nodes.size(),std::size_t(7));
        QString generator,cluster,hist;const int workers=QThread::idealThreadCount()>2?2:1;
        for(auto& n:workflow.nodes){if(n.typeId=="hep.collider.Pythia"){generator=QString::fromStdString(n.id.value);n.extensions["config"]["events"]=100;n.extensions["config"]["partitionEvents"]=25;n.extensions["config"]["workers"]=workers;}if(n.typeId=="hep.collider.ClusterJets")cluster=QString::fromStdString(n.id.value);if(n.typeId=="hep.root.Histo1D")hist=QString::fromStdString(n.id.value);}
        bridge.previewCollider(2);QTRY_VERIFY_WITH_TIMEOUT(!bridge.busy(),15000);QVERIFY2(!bridge.colliderEvents().isEmpty(),bridge.notice().toUtf8());QVERIFY(bridge.project().runs.empty());
        bridge.run();QTRY_COMPARE_WITH_TIMEOUT(bridge.project().runs.size(),std::size_t(1),30000);QVERIFY2(bridge.project().runs.back().status=="Completed",bridge.notice().toUtf8());
        QCOMPARE(bridge.project().runs.back().result["metrics"]["threads"].get<int>(),workers);
        const auto traffic=bridge.project().runs.back().extensions.at("transport");QVERIFY(traffic.at("controlSentBytes").get<std::uint64_t>()>0);QVERIFY(traffic.at("controlReceivedBytes").get<std::uint64_t>()<2*1024*1024);QVERIFY(traffic.at("resultBytes").get<std::uint64_t>()>0);
        const auto immutable=projectJson(bridge.project())["runs"][0];QVERIFY(bridge.provenance().contains("actualSeed"));QVERIFY(bridge.provenance().contains("frozenEnvironment"));QCOMPARE(bridge.project().runs.back().result["metrics"]["accepted"].get<int>(),100);
        bridge.select(hist);QVERIFY(!bridge.plotSeries().isEmpty());QVERIFY(bridge.save(QUrl::fromLocalFile(tmp_.path()+"/collider.hep.json")));QVERIFY(bridge.open(QUrl::fromLocalFile(tmp_.path()+"/collider.hep.json")));
        bridge.select(cluster);auto config=bridge.selectedConfig();config["R"]=0.6;bridge.updateAnalysisNode(config);
        bool generatorStale=true,histStale=false;for(const auto& row:bridge.nodes()){const auto m=row.toMap();if(m["id"]==generator)generatorStale=m["stale"].toBool();if(m["id"]==hist)histStale=m["stale"].toBool();}QVERIFY(!generatorStale);QVERIFY(histStale);
        bridge.run();QTRY_COMPARE_WITH_TIMEOUT(bridge.project().runs.size(),std::size_t(2),30000);QCOMPARE(bridge.project().runs.back().status,std::string("Completed"));bridge.chooseRuns(0,1);bridge.select(hist);QCOMPARE(bridge.plotSeries().size(),2);QVERIFY(bridge.comparison().contains("0.6"));QVERIFY(projectJson(bridge.project())["runs"][0]==immutable);
        const auto previous=bridge.project().runs.back().result.at("results");const auto previousHash=bridge.project().runs.back().workflowHash;
        bridge.select(generator);auto executionConfig=bridge.selectedConfig();executionConfig["workers"]=1;bridge.updateAnalysisNode(executionConfig);
        for(const auto& row:bridge.nodes()){QVERIFY(!row.toMap().value("stale").toBool());}
        bridge.run();
        QTRY_COMPARE_WITH_TIMEOUT(bridge.project().runs.size(),std::size_t(3),30000);QCOMPARE(bridge.project().runs.back().status,std::string("Completed"));QVERIFY(bridge.project().runs.back().result.at("results")==previous);QCOMPARE(bridge.project().runs.back().workflowHash,previousHash);
        bridge.chooseRuns(0,1);const auto diff=Json::parse(bridge.comparison().toStdString());QVERIFY(diff.at("parameters").empty());QCOMPARE(diff.at("execution").size(),std::size_t(workers>1?1:0));QVERIFY(diff.at("scientificHash").at("equal")==true);
        bridge.run();bridge.checkpoint();
        const auto interruptedFile=tmp_.path()+"/interrupted-collider.hep.json";
        QVERIFY(QFile::copy(QStandardPaths::writableLocation(QStandardPaths::AppDataLocation)+"/recovery.hep.json",interruptedFile));
        bridge.colliderService().crash();QTRY_COMPARE_WITH_TIMEOUT(bridge.project().runs.size(),std::size_t(4),5000);QCOMPARE(bridge.project().runs.back().status,std::string("Interrupted"));bridge.restartCollider();QTRY_COMPARE_WITH_TIMEOUT(bridge.colliderService().state(),QString("Healthy"),35000);
        bridge.run();bridge.cancel();QTRY_COMPARE_WITH_TIMEOUT(bridge.project().runs.size(),std::size_t(5),5000);QCOMPARE(bridge.project().runs.back().status,std::string("Cancelled"));
        Bridge reopened;QVERIFY(reopened.open(QUrl::fromLocalFile(interruptedFile)));QCOMPARE(reopened.project().runs.size(),std::size_t(4));
        const auto& interrupted=reopened.project().runs.back();QCOMPARE(interrupted.status,std::string("Interrupted"));QVERIFY(interrupted.result.at("valid")==false);QVERIFY(interrupted.result.at("partial")==true);
        QVERIFY(projectJson(reopened.project())["runs"][0]==immutable);
    }
    void colliderStoredSampleRelink(){
        Bridge bridge;
#ifdef Q_OS_WIN
        QTRY_VERIFY_WITH_TIMEOUT(bridge.colliderService().state()=="Healthy"||bridge.managedRuntime().value("state").toString()=="Needs installation"||bridge.managedRuntime().value("state").toString()=="Unavailable"||bridge.managedRuntime().value("state").toString()=="Incompatible",180000);
#else
        QTRY_VERIFY_WITH_TIMEOUT(bridge.colliderService().state()!="Initializing",35000);
#endif
        if(!bridge.colliderService().capability().value("available",false)){QVERIFY2(!qEnvironmentVariableIsSet("HEP_REQUIRE_COLLIDER"),"Required collider runtime unavailable");QSKIP("Collider engine unavailable");}
        bridge.newColliderWorkflow(true);for(auto& node:activeWorkflow(bridge.project()).nodes)if(node.typeId=="hep.collider.Pythia")node.extensions["config"]["events"]=5;
        const auto original=tmp_.path()+"/generated.hepmc";bridge.storeHepMC(QUrl::fromLocalFile(original));bridge.run();
        QTRY_COMPARE_WITH_TIMEOUT(bridge.project().runs.size(),std::size_t(1),20000);QVERIFY2(bridge.project().runs.back().status=="Completed",bridge.notice().toUtf8());
        QVERIFY(QFileInfo::exists(original));QCOMPARE(bridge.samples().size(),1);const auto sample=bridge.samples().front().toMap().value("id").toString();
        bridge.reuseSample(sample);for(const auto* kind:{"ClusterJets","Property","Histo1D"})bridge.addColliderNode(kind);
        bridge.run();QTRY_COMPARE_WITH_TIMEOUT(bridge.project().runs.size(),std::size_t(2),10000);QCOMPARE(bridge.project().runs.back().status,std::string("Completed"));
        const auto immutable=projectJson(bridge.project())["runs"];const auto scientificBeforeMove=scientificJson(activeWorkflow(bridge.project()));
        const auto moved=original+".moved";QVERIFY(QFile::rename(original,moved));bridge.run();QVERIFY(bridge.notice().contains("No healthy runtime"));QCOMPARE(bridge.project().runs.size(),std::size_t(2));
        bridge.relinkSample(sample,QUrl::fromLocalFile(moved));QTRY_VERIFY_WITH_TIMEOUT(!bridge.busy(),10000);QVERIFY2(bridge.notice().contains("completed"),bridge.notice().toUtf8());
        QVERIFY(scientificJson(activeWorkflow(bridge.project()))==scientificBeforeMove);
        bridge.run();QTRY_COMPARE_WITH_TIMEOUT(bridge.project().runs.size(),std::size_t(3),10000);QCOMPARE(bridge.project().runs.back().status,std::string("Completed"));QVERIFY(projectJson(bridge.project())["runs"][0]==immutable[0]);
        QFile changed(moved);QVERIFY(changed.open(QIODevice::Append));changed.write("modified\n");changed.close();bridge.run();QTRY_COMPARE_WITH_TIMEOUT(bridge.project().runs.size(),std::size_t(4),10000);QCOMPARE(bridge.project().runs.back().status,std::string("Failed"));QVERIFY(bridge.notice().contains("changed"));
    }
    void completeScientificWorkflow(){
        Bridge bridge;QTRY_VERIFY_WITH_TIMEOUT(bridge.rootService().state()!="Initializing",35000);
        if(!bridge.rootService().capability().value("available",false))QSKIP("PyROOT unavailable; core and GUI tests still run");
        QProcess create;create.start(python(),{QString::fromUtf8(HEP_SOURCE_DIR)+"/tests/root/fixtures.py",fixture_,"10000"});QVERIFY(create.waitForFinished(20000));QCOMPARE(create.exitCode(),0);
        bridge.inspectRoot(QUrl::fromLocalFile(fixture_));QTRY_VERIFY_WITH_TIMEOUT(!bridge.busy(),10000);QVERIFY(!bridge.rootObjects().isEmpty());
        bridge.selectRootObject("Events","dataset");QTRY_VERIFY_WITH_TIMEOUT(!bridge.busy(),15000);QCOMPARE(bridge.columns().size(),4);QCOMPARE(activeWorkflow(bridge.project()).nodes.size(),std::size_t(1));
        bridge.previewRoot(9950,12);QTRY_VERIFY_WITH_TIMEOUT(!bridge.busy(),10000);QCOMPARE(bridge.previewData().value("represented").toInt(),12);QVERIFY(bridge.project().runs.empty());
        const auto pt=expression("sqrt",{expression("add",{expression("square",{columnExpression("px")}),expression("square",{columnExpression("py")})})});
        bridge.addAnalysisNode("Define",map({{"name","pT"},{"expression",pt}}));const auto define=bridge.selectedId();
        auto cut=Json{{"expression",expression("gt",{columnExpression("pT"),literalExpression(1,"GeV")})}};
        bridge.addAnalysisNode("Filter",map(cut));const auto filter=bridge.selectedId();
        bridge.addAnalysisNode("Histo1D",map({{"expression",columnExpression("pT")},{"edges",{0,5,10,15,20}}}));const auto hist=bridge.selectedId();
        bridge.addAnalysisNode("Fit",map({{"model","polynomial"},{"order",0},{"lower",4},{"upper",20}}));
        QCOMPARE(activeWorkflow(bridge.project()).nodes.size(),std::size_t(5));QCOMPARE(activeWorkflow(bridge.project()).connections.size(),std::size_t(4));
        bridge.run();QTRY_COMPARE_WITH_TIMEOUT(bridge.project().runs.size(),std::size_t(1),30000);
        QVERIFY2(bridge.project().runs.back().status=="Completed",bridge.notice().toUtf8());
        const auto& first=bridge.project().runs.back();QVERIFY(first.result["results"][hist.toStdString()]["values"]==Json({0.,2000.,2000.,2000.}));QCOMPARE(first.result["eventLoops"].get<int>(),1);
        const auto firstJson=projectJson(bridge.project())["runs"][0];QVERIFY(bridge.generatedCode().contains(".Filter("));QVERIFY(bridge.provenance().contains("sha256"));
        bridge.select(hist);QVERIFY(!bridge.plotSeries().isEmpty());QVERIFY(bridge.fitDiagnostics().contains("covariance"));
        const auto savedHash=workflowHash(scientificJson(activeWorkflow(bridge.project())));bridge.moveNode(hist,850,420);bridge.setPlotSettings({{"title","Publication figure"},{"logY",true}});QCOMPARE(workflowHash(scientificJson(activeWorkflow(bridge.project()))),savedHash);
        HistogramItem plot;plot.setSeries(bridge.plotSeries());plot.setCurve(bridge.fitCurve());plot.setTitle("Known pT");QVERIFY(plot.exportFigure(QUrl::fromLocalFile(tmp_.path()+"/plot.png")));QVERIFY(plot.exportFigure(QUrl::fromLocalFile(tmp_.path()+"/plot.pdf")));QVERIFY(QFileInfo(tmp_.path()+"/plot.png").size()>10000);
        const auto projectFile=QUrl::fromLocalFile(tmp_.path()+"/analysis.hep.json");QVERIFY(bridge.save(projectFile));QVERIFY(bridge.open(projectFile));QCOMPARE(bridge.project().runs.size(),std::size_t(1));QCOMPARE(bridge.plotSettings().value("title").toString(),QString("Publication figure"));
        bridge.select(filter);cut["expression"]["args"][1]["value"]=10;bridge.updateAnalysisNode(map(cut));bool histStale=false,defineStale=true;
        for(const auto& row:bridge.nodes()){auto m=row.toMap();if(m["id"]==hist)histStale=m["stale"].toBool();if(m["id"]==define)defineStale=m["stale"].toBool();}QVERIFY(histStale);QVERIFY(!defineStale);
        bridge.undo();QCOMPARE(workflowHash(scientificJson(activeWorkflow(bridge.project()))),savedHash);bridge.redo();bridge.run();QTRY_COMPARE_WITH_TIMEOUT(bridge.project().runs.size(),std::size_t(2),30000);QCOMPARE(bridge.project().runs.back().status,std::string("Completed"));
        bridge.select(hist);bridge.chooseRuns(0,1);QCOMPARE(bridge.plotSeries().size(),2);QVERIFY(bridge.comparison().contains("10"));QVERIFY(projectJson(bridge.project())["runs"][0]==firstJson);
        QVERIFY(bridge.save(projectFile));QVERIFY(bridge.open(projectFile));QCOMPARE(bridge.project().runs.size(),std::size_t(2));
        // A crash during an actual request leaves an invalid terminal Run; restart remains usable.
        bridge.run();QVERIFY(bridge.busy());bridge.rootService().crash();QTRY_COMPARE_WITH_TIMEOUT(bridge.project().runs.size(),std::size_t(3),5000);QVERIFY(bridge.project().runs.back().status!="Completed");bridge.restartRoot();QTRY_COMPARE_WITH_TIMEOUT(bridge.rootService().state(),QString("Healthy"),35000);
        bridge.run();bridge.cancel();QTRY_COMPARE_WITH_TIMEOUT(bridge.project().runs.size(),std::size_t(4),5000);QCOMPARE(bridge.project().runs.back().status,std::string("Cancelled"));
        if(bridge.rootService().state()!="Healthy"){bridge.restartRoot();QTRY_COMPARE_WITH_TIMEOUT(bridge.rootService().state(),QString("Healthy"),35000);}
        QVERIFY(QFile::rename(fixture_,fixture_+".moved"));bridge.run();QTRY_COMPARE_WITH_TIMEOUT(bridge.project().runs.size(),std::size_t(5),10000);QCOMPARE(bridge.project().runs.back().status,std::string("Failed"));QVERIFY(bridge.notice().contains("unavailable"));
        bridge.inspectRoot(QUrl::fromLocalFile(fixture_+".moved"));QTRY_VERIFY_WITH_TIMEOUT(!bridge.busy(),10000);bridge.selectRootObject("Events","dataset");QTRY_VERIFY_WITH_TIMEOUT(!bridge.busy(),10000);bridge.run();QTRY_COMPARE_WITH_TIMEOUT(bridge.project().runs.size(),std::size_t(6),30000);QCOMPARE(bridge.project().runs.back().status,std::string("Completed"));
        bridge.rootService().shutdown();QTRY_COMPARE_WITH_TIMEOUT(bridge.rootService().state(),QString("Stopped"),3000);
    }
};
QTEST_MAIN(StudioTests)
#include "studio_tests.moc"
