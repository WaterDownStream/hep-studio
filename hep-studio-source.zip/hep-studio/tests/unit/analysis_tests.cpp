#include "core/analysis/analysis.hpp"
#include "core/editing/editing.hpp"
#include "core/graph/graph.hpp"
#include <iostream>
#include <stdexcept>
using namespace hep;
static void check(bool b,const char* m){if(!b)throw std::runtime_error(m);}
template<class F>static void rejects(F f){try{f();}catch(const std::exception&){return;}throw std::runtime_error("Expected rejection");}
static Json unary(const char* op,Json a){return {{"op",op},{"args",Json::array({a})}};}
static Json binary(const char* op,Json a,Json b){return {{"op",op},{"args",Json::array({a,b})}};}
int main(){try{
    auto w=mockWorkflow();History h;const auto original=scientificJson(w);const auto layout=layoutJson(w);
    auto id=w.nodes.front().id;h.execute(w,MoveEdit{id,w.nodes.front().x,w.nodes.front().y,901,321});
    check(scientificJson(w)==original,"Move altered science");check(layoutJson(w)!=layout,"Move did not alter layout");check(h.undo(w)&&layoutJson(w)==layout,"Move undo");check(h.redo(w),"Move redo");
    auto extra=mockNode("Histogram",newId());h.execute(w,NodeEdit{std::nullopt,extra,{}});check(findNode(w,extra.id),"Node create");check(h.undo(w)&&!findNode(w,extra.id),"Node undo");check(h.redo(w),"Node redo");
    const Connection edge{w.nodes.front().id,Id("out"),extra.id,Id("in")};h.execute(w,EdgeEdit{edge,true});check(h.undo(w),"Connect undo");check(h.redo(w),"Connect redo");
    const auto edges=w.connections.size();h.execute(w,NodeEdit{extra,std::nullopt,{edge}});check(!findNode(w,extra.id),"Delete");check(h.undo(w)&&w.connections.size()==edges,"Delete undo restores connections");
    h.execute(w,EdgeEdit{edge,false});check(w.connections.size()==edges-1,"Disconnect");check(h.undo(w)&&w.connections.size()==edges,"Disconnect undo");
    auto& n=w.nodes.front();n.parameters.push_back({"threshold",scalar(energy),1,1,"GeV","constant","user","Test cut",std::nullopt,std::nullopt});auto before=n.parameters.back();auto after=before;after.value=2;
    const auto old=scientificJson(w);h.execute(w,ParameterEdit{id,n.parameters.size()-1,before,after});check(scientificJson(w)!=old,"Parameter hash");check(h.undo(w)&&scientificJson(w)==old,"Parameter undo");
    Project p{newId(),"Study",{w},{}};const auto copied=duplicateWorkflow(p,w.id);check(p.workflows.size()==2&&activeWorkflow(p).id==copied,"Duplicate/switch");check(p.workflows[0].nodes[0].id!=p.workflows[1].nodes[0].id,"Node identity remap");
    auto restored=parseProject(serialize(p));check(activeWorkflow(restored).id==copied,"Active workflow persistence");switchWorkflow(p,w.id);deleteWorkflow(p,copied);check(activeWorkflow(p).id==w.id&&p.workflows.size()==1,"Delete workflow");rejects([&]{deleteWorkflow(p,w.id);});
    Json schema={{"object","Events"},{"entries",5},{"columns",Json::array({{{"name","px"},{"backendType","double"},{"unit","GeV"},{"unitKnown",true}},{{"name","py"},{"backendType","double"},{"unit","GeV"},{"unitKnown",true}}})}};
    auto s=datasetSchema(schema);auto pt=unary("sqrt",binary("add",unary("square",columnExpression("px")),unary("square",columnExpression("py"))));
    check(inferExpression(pt,s).dimension==energy,"pT dimensions");rejects([&]{(void)inferExpression(binary("add",columnExpression("px"),literalExpression(1,"mm")),s);});rejects([&]{(void)inferExpression(columnExpression("missing"),s);});
    Workflow a{newId(),"Analysis",{rootNode("Source",Id("s")),rootNode("Define",Id("d")),rootNode("Filter",Id("f")),rootNode("Histo1D",Id("h")),rootNode("Fit",Id("fit"))},{}};
    a.nodes[0].extensions["config"]={{"schema",schema},{"datasetId","input"},{"object","Events"}};
    a.nodes[1].extensions["config"]={{"name","pT"},{"expression",pt}};a.nodes[2].extensions["config"]={{"expression",binary("gt",columnExpression("pT"),literalExpression(1,"GeV"))}};
    a.nodes[3].extensions["config"]={{"expression",columnExpression("pT")},{"bins",20},{"lower",0},{"upper",20}};
    a.nodes[4].extensions["config"]={{"model","gaussian"}};
    for(std::size_t i=1;i<a.nodes.size();++i)a.connections.push_back({a.nodes[i-1].id,Id("out"),a.nodes[i].id,Id("in")});
    check(lowerRoot(a).at("nodes").size()==5,"Lowering");auto sci=scientificJson(a);auto fit=dependencyJson(a,Id("fit"));auto filter=dependencyJson(a,Id("f"));
    a.nodes[3].extensions["presentation"]={{"title","New title"}};check(scientificJson(a)==sci,"Plot title altered scientific identity");
    a.nodes[3].extensions["config"]["bins"]=30;check(dependencyJson(a,Id("f"))==filter,"Histogram edit invalidated upstream");check(dependencyJson(a,Id("fit"))!=fit,"Histogram edit failed to invalidate fit");
    fit=dependencyJson(a,Id("fit"));a.nodes[2].extensions["config"]["expression"]["args"][1]["value"]=2;check(dependencyJson(a,Id("fit"))!=fit,"Cut did not invalidate downstream");
    check(serialize(workflowFromJson(workflowJson(a)))==serialize(a),"ROOT workflow roundtrip");
    std::cout<<"PASS command history (6 operations), workflows, AST, hashing, stale propagation, reload\n";return 0;
}catch(const std::exception& e){std::cerr<<e.what()<<'\n';return 1;}}
