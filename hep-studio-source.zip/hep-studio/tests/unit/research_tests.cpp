#include "core/research/research.hpp"
#include "core/research/campaign.hpp"
#include "core/editing/editing.hpp"
#include <fstream>
#include <iostream>
using namespace hep;
static void check(bool value,const char* message){if(!value)throw std::runtime_error(message);}
int main(int argc,char** argv){try{
    auto w=researchExample();const auto plan=lowerResearch(w);
    if(argc==2){std::ofstream(argv[1])<<plan.dump(2);return 0;}
    check(plan["nodes"].size()==8,"typed research lowering");const auto before=scientificJson(w);const auto source=dependencyJson(w,w.nodes.front().id);
    auto fullModel=w;fullModel.nodes.front().extensions["config"]["model"]="sm-full";
    check(lowerResearch(fullModel)["nodes"][0]["config"]["model"]=="sm-full","unrestricted SM model lowering");
    check(scientificJson(fullModel)!=before&&dependencyJson(fullModel,fullModel.nodes.back().id)!=dependencyJson(w,w.nodes.back().id),"model selection did not invalidate downstream science");
    Project modelProject{newId(),"Model persistence",{fullModel},{}};check(serialize(parseProject(serialize(modelProject)))==serialize(modelProject),"selected model roundtrip");
    auto badModel=w;badModel.nodes.front().extensions["config"]["model"]="unidentified-ufo";bool rejectedModel=false;try{lowerResearch(badModel);}catch(const std::exception&){rejectedModel=true;}check(rejectedModel,"unidentified UFO model accepted");
    w.nodes[1].extensions["config"]["workers"]=4;check(scientificJson(w)==before,"physical shower workers changed scientific identity");
    w.nodes[2].extensions["config"]["card"]["builtin"]="ideal-muon";check(dependencyJson(w,w.nodes.front().id)==source,"detector variation invalidated MadGraph");check(scientificJson(w)!=before,"detector variation did not invalidate science");
    const auto physics=scientificJson(w);w.nodes.back().x=300;w.nodes.back().extensions["presentation"]={{"title","cosmetic"}};check(scientificJson(w)==physics,"layout invalidated research");
    auto cardWorkflow=w;cardWorkflow.nodes[2].extensions["config"]["card"]={{"resourceVersion",1},{"resourceId","identified-card"},{"sha256","identified-content"},{"path","/first/location.tcl"}};
    const auto cardIdentity=scientificJson(cardWorkflow);cardWorkflow.nodes[2].extensions["config"]["card"]["path"]="/relinked/location.tcl";check(scientificJson(cardWorkflow)==cardIdentity,"physical card relink changed science");
    cardWorkflow.nodes[2].extensions["config"]["card"]["sha256"]="different-content";check(scientificJson(cardWorkflow)!=cardIdentity,"changed detector content did not invalidate science");
    Project p{newId(),"Research persistence",{w},{}};p.extensions["researchVersion"]=1;p.extensions["scans"]=Json::array();
    check(serialize(parseProject(serialize(p)))==serialize(p),"research project compatibility roundtrip");
    auto invalid=w;invalid.nodes[3].ports.front().type=domain("EventStream");bool rejected=false;try{lowerResearch(invalid);}catch(const std::exception&){rejected=true;}check(rejected,"generator and reconstructed collections were implicitly interchangeable");
    const auto selection=w.nodes[4].id;const auto nominalParent=dependencyJson(w,w.nodes.front().id);
    w.extensions["systematics"]=Json::array({{{"id","cut"},{"kind","parameter"},{"nominal",10},{"affectedNodes",Json::array({selection.value})},{"correlation",{{"group","cut-study"},{"acrossSamples","correlated"}}},{"interpretation","no statistical prior"},{"variations",Json::array({{{"label","up"},{"bindings",Json::array({{{"nodeId",selection.value},{"pointer","/expression/args/1/value"},{"value",20.}}})}}})}}});
    lowerResearch(w);check(dependencyJson(w,w.nodes.front().id)==nominalParent,"downstream systematic invalidated generator");
    auto varied=varyParameter(w,{selection,"/expression/args/1/value","MeV"},20000.);check(varied.nodes[4].extensions["config"]["expression"]["args"][1]["value"]==20.,"scan binding units");
    auto scan=scanWorkflows(w,{{"axes",Json::array({{{"nodeId",selection.value},{"pointer","/expression/args/1/value"},{"unit","GeV"},{"spacing","linear"},{"lower",10.},{"upper",30.},{"count",3}}})}});
    check(scan.size()==3,"generic scan cardinality");check(dependencyJson(scan[0],scan[0].nodes.front().id)==dependencyJson(scan[2],scan[2].nodes.front().id),"cut scan invalidated upstream");
    rejected=false;try{varyParameter(w,{w.nodes[1].id,"/workers","1"},2);}catch(const std::exception&){rejected=true;}check(rejected,"CPU count became a scan physics parameter");
    check(!parameterBindings(w.nodes.front()).empty(),"parameter metadata missing");
    rejected=false;try{varyParameter(w,{w.nodes.front().id,"/events","1"},1e30);}catch(const std::exception&){rejected=true;}check(rejected,"unrepresentable integer scan value accepted");
    auto systematicUnits=w;systematicUnits.extensions["systematics"][0]["variations"][0]["bindings"][0]["unit"]="MeV";systematicUnits.extensions["systematics"][0]["variations"][0]["bindings"][0]["value"]=20000.;
    check(lowerResearch(systematicUnits)["systematics"][0]["variations"][0]["bindings"][0]["value"]==20.,"systematic units were not lowered canonically");
    Workflow templates{newId(),"Explicit likelihood",{}, {}};
    for(const auto* kind:{"TemplateSet","BinnedLikelihood","Inference"})templates.nodes.push_back(researchNode(kind,newId()));
    for(std::size_t i=1;i<templates.nodes.size();++i)templates.connections.push_back({templates.nodes[i-1].id,Id("out"),templates.nodes[i].id,Id("in")});
    const auto templatePlan=lowerResearch(templates);check(templatePlan["requiredLibraries"]==Json::array({"HistFactory","ROOT","RooFit","RooStats"}),"template capability lowering");
    for(const auto& [kind,semantic]:std::vector<std::pair<std::string,std::string>>{{"Photons","RecoPhotonCollection"},{"Tracks","RecoTrackCollection"}}){
        const auto objects=researchNode(kind,newId());check(objects.ports.back().type==domain(semantic),"reconstructed photon/track identity");
        auto copy=researchExample();copy.nodes.erase(copy.nodes.begin()+3,copy.nodes.end());copy.connections.erase(copy.connections.begin()+2,copy.connections.end());auto collection=researchNode(kind,newId());copy.connections.push_back({copy.nodes.back().id,Id("out"),collection.id,Id("in")});copy.nodes.push_back(collection);auto prop=researchNode("Property",newId(),0,0,semantic);copy.connections.push_back({collection.id,Id("out"),prop.id,Id("in")});copy.nodes.push_back(prop);check(lowerResearch(copy)["nodes"].size()==5,"photon/track lowering");
    }
    check(inferExpression(columnExpression("btag"),reconstructedSchema(false,"RecoJetCollection")).dimension==dimensionless,"btag capability dimension");
    rejected=false;try{inferExpression(columnExpression("btag"),reconstructedSchema(false,"RecoMuonCollection"));}catch(const std::exception&){rejected=true;}check(rejected,"jet tagging implicitly available on muons");
    check(inferExpression(columnExpression("isolation"),reconstructedSchema(false,"RecoPhotonCollection")).dimension==dimensionless,"photon isolation capability");
    check(templatePlan["requiredThreads"]==1,"likelihood uses a centrally allocated budget");
    const auto templateIdentity=scientificJson(templates);templates.nodes.front().x=100.;check(scientificJson(templates)==templateIdentity,"template layout changed science");
    templates.nodes[1].extensions["config"]["muMax"]=10.;check(scientificJson(templates)!=templateIdentity,"likelihood settings did not invalidate inference");
    Project statisticalProject{newId(),"Template persistence",{templates},{}};
    check(serialize(parseProject(serialize(statisticalProject)))==serialize(statisticalProject),"template project roundtrip");
    auto mixed=templates;mixed.nodes[1].ports.front().type=domain("EventStream");
    rejected=false;try{lowerResearch(mixed);}catch(const std::exception&){rejected=true;}check(rejected,"event stream accepted as histogram templates");
    Workflow overlap{newId(),"Overlap removal",{}, {}};
    auto reco=researchNode("RecoSource",Id("reco")),jets=researchNode("Jets",Id("jets")),photons=researchNode("Photons",Id("photons"));
    auto refCut=researchNode("CollectionFilter",Id("ref-cut"),0,0,"RecoPhotonCollection");
    overlap.nodes={reco,jets,photons,refCut};overlap.connections={{reco.id,Id("out"),jets.id,Id("in")},{reco.id,Id("out"),photons.id,Id("in")},{photons.id,Id("out"),refCut.id,Id("in")}};
    const auto unedited=scientificJson(overlap);History overlapHistory;
    auto clean=researchNode("OverlapRemoval",Id("clean"),0,0,"RecoJetCollection","RecoPhotonCollection");
    overlapHistory.executeBatch(overlap,{NodeEdit{std::nullopt,clean,{}},EdgeEdit{{jets.id,Id("out"),clean.id,Id("in")},true},EdgeEdit{{refCut.id,Id("out"),clean.id,Id("reference")},true}});
    auto loweredOverlap=lowerResearch(overlap);for(const auto& item:loweredOverlap["nodes"])if(item["id"]=="clean")check(item["input"]=="jets"&&item["reference"]=="ref-cut","binary collection ports were conflated");
    const auto cleanDependency=dependencyJson(overlap,clean.id),jetDependency=dependencyJson(overlap,jets.id);
    overlap.nodes[3].extensions["config"]["expression"]["args"][1]["value"]=20.;
    check(dependencyJson(overlap,clean.id)!=cleanDependency&&dependencyJson(overlap,jets.id)==jetDependency,"reference selection invalidation crossed wrong dependency branch");
    overlap.nodes[3].extensions["config"]=refCut.extensions["config"];
    const auto combined=scientificJson(overlap);check(overlapHistory.undo(overlap)&&scientificJson(overlap)==unedited,"compound overlap creation undo");
    auto bad=researchNode("OverlapRemoval",Id("bad"),0,0,"RecoJetCollection","RecoPhotonCollection");
    rejected=false;try{overlapHistory.executeBatch(overlap,{NodeEdit{std::nullopt,bad,{}},EdgeEdit{{Id("missing"),Id("out"),bad.id,Id("in")},true}});}catch(const std::exception&){rejected=true;}
    check(rejected&&scientificJson(overlap)==unedited&&overlapHistory.canRedo(),"failed compound edit did not roll back atomically");
    check(overlapHistory.redo(overlap)&&scientificJson(overlap)==combined,"compound overlap creation redo");
    overlap.nodes.back().extensions["config"]["radius"]=-1.;rejected=false;try{lowerResearch(overlap);}catch(const std::exception&){rejected=true;}check(rejected,"negative overlap radius accepted");
    overlap.nodes.back().extensions["config"]["radius"]=0.4;
    Project overlapProject{newId(),"Overlap persistence",{overlap},{}};check(serialize(parseProject(serialize(overlapProject)))==serialize(overlapProject),"typed binary collection project roundtrip");
    const auto leptons=researchNode("CollectionCombine",Id("leptons"),0,0,"RecoMuonCollection","RecoElectronCollection");
    check(leptons.ports.back().type==domain("RecoLeptonCollection"),"mixed leptons lost their semantic union type");
    check(researchNode("Pairs",Id("pairs"),0,0,"RecoLeptonCollection").ports.front().type==domain("RecoLeptonCollection"),"charged-lepton union cannot form typed pairs");
    rejected=false;try{researchNode("CollectionCombine",newId(),0,0,"RecoJetCollection","RecoPhotonCollection");}catch(const std::exception&){rejected=true;}check(rejected,"incompatible collection types silently combined");
    Workflow combination{newId(),"Lepton union",{reco,researchNode("Muons",Id("muons")),researchNode("Electrons",Id("electrons")),leptons},
                         {{reco.id,Id("out"),Id("muons"),Id("in")},{reco.id,Id("out"),Id("electrons"),Id("in")},{Id("muons"),Id("out"),leptons.id,Id("in")},{Id("electrons"),Id("out"),leptons.id,Id("reference")}}};
    lowerResearch(combination);const auto unionIdentity=scientificJson(combination);combination.nodes.back().x=123.;check(scientificJson(combination)==unionIdentity,"union layout invalidated science");
    combination.nodes.back().extensions["config"]["duplicates"]="allow";rejected=false;try{lowerResearch(combination);}catch(const std::exception&){rejected=true;}check(rejected,"double-counting union policy silently accepted");
    std::cout<<"PASS typed research, seed/budget identity, stage invalidation, binary collections and persistence\n";
}catch(const std::exception& error){std::cerr<<error.what()<<'\n';return 1;}}
