#include "core/collider/collider.hpp"
#include "core/scheduler/placement.hpp"
#include "core/editing/editing.hpp"
#include <fstream>
#include <algorithm>
#include <iostream>
using namespace hep;
static void check(bool v,const char* what){if(!v)throw std::runtime_error(what);}
template<class F>void rejects(F f){try{f();}catch(const std::exception&){return;}throw std::runtime_error("Expected rejection");}
static Workflow pipeline(){
    Workflow w{Id("collider-workflow"),"Leading jet pT",{}, {}};
    for(const auto* kind:{"Pythia","ClusterJets","CollectionFilter","CollectionSort","CollectionTake","Property"})w.nodes.push_back(colliderNode(kind,Id(kind)));
    w.nodes.push_back(rootNode("Histo1D",Id("hist")));
    w.nodes.front().extensions["config"]["events"]=100;
    w.nodes.back().extensions["config"]={{"expression",columnExpression("value")},{"bins",50},{"lower",0},{"upper",500},{"normalization","counts"},{"flow","separate"}};
    for(std::size_t i=1;i<w.nodes.size();++i)w.connections.push_back({w.nodes[i-1].id,Id("out"),w.nodes[i].id,Id("in")});
    return w;
}
int main(int argc,char** argv){try{
    auto w=pipeline();if(argc==2){std::ofstream(argv[1])<<workflowJson(w).dump(2);return 0;}
    const auto plan=lowerCollider(w);check(plan["nodes"].size()==7,"lowering");
    auto original=scientificJson(w),source=dependencyJson(w,Id("Pythia")),hist=dependencyJson(w,Id("hist"));
    w.nodes[1].x=987;w.nodes[1].extensions["presentation"]={{"title","jet cosmetics"}};check(scientificJson(w)==original,"layout invalidated science");
    w.nodes[1].extensions["config"]["R"]=0.6;check(dependencyJson(w,Id("Pythia"))==source,"R invalidated generator");check(dependencyJson(w,Id("hist"))!=hist,"R failed to invalidate histogram");
    auto parallel=w;parallel.nodes[0].extensions["config"]["workers"]=2;check(scientificJson(parallel)==scientificJson(w),"worker count must not change science");check(dependencyJson(parallel,Id("hist"))==dependencyJson(w,Id("hist")),"worker count must not invalidate descendants");
    auto invalidWorkers=parallel;invalidWorkers.nodes[0].extensions["config"]["workers"]=1.5;rejects([&]{lowerCollider(invalidWorkers);});
    auto seeded=w;seeded.nodes[0].extensions["config"]["seedStrategy"]="project-derived";check(scientificJson(seeded,"1")!=scientificJson(seeded,"2"),"project seed scientific identity");
    Project p{newId(),"Portable collider",{w},{}};p.extensions["resources"]["sample"]={{"logicalUri","hep://sample/qcd"},{"locations",Json::array({{{"runtimeId","wsl"},{"kind","wsl-linux"},{"path","/samples/qcd.hepmc"}}})}};
    check(serialize(parseProject(serialize(p)))==serialize(p),"resource/project roundtrip");
    auto legacyProject=Json::parse(serialize(p));auto& legacyNodes=legacyProject["workflows"][0]["nodes"];auto& legacyConfig=(*std::find_if(legacyNodes.begin(),legacyNodes.end(),[](const Json& node){return node.at("typeId")=="hep.collider.Pythia";}))["config"];legacyConfig.erase("streamPolicy");legacyConfig.erase("partitionEvents");legacyConfig["workers"]=2;
    auto migrated=parseProject(legacyProject.dump());auto& migratedConfig=std::find_if(migrated.workflows[0].nodes.begin(),migrated.workflows[0].nodes.end(),[](const Node& node){return node.typeId=="hep.collider.Pythia";})->extensions["config"];
    check(migratedConfig.at("logicalStreams")==2,"legacy logical stream migration");const auto migratedHash=scientificJson(migrated.workflows[0]);migratedConfig["workers"]=4;
    check(scientificJson(migrated.workflows[0])==migratedHash,"legacy workers invalidated scientific identity");
    const auto before=scientificJson(p.workflows[0]);p.extensions["resources"]["sample"]["locations"][0]["path"]="D:/relocated.hepmc";check(scientificJson(p.workflows[0])==before,"physical relocation affected science");
    Json libs;for(const auto& x:plan["requiredLibraries"])libs[x.get<std::string>()]={{"available",true},{"version","test"}};
    WorkerCandidate native{"native","Windows",libs,{},4,true},wsl{"wsl","Linux",libs,{},4,true};
    auto parallelPlacement=placeWorkflow(lowerCollider(parallel),{native,wsl},{});check(parallelPlacement.stages[0]["threads"]==2,"parallel plan budget");
    auto insufficient=native;insufficient.availableThreads=1;rejects([&]{placeWorkflow(lowerCollider(parallel),{insufficient},{});});
    auto placement=placeWorkflow(plan,{native,wsl},{{"wsl","wsl-linux","/huge.hepmc",true,200000000000ULL}});
    check(placement.workerId=="wsl"&&placement.transfers.empty(),"200GB sample locality");
    rejects([&]{placeWorkflow(plan,{native,wsl},{{"wsl","wsl-linux","/huge.hepmc",true,200000000000ULL}},"native");});
    wsl.healthy=false;rejects([&]{placeWorkflow(plan,{wsl},{});});
    Json old={{"libraries",libs}};auto now=old;now["libraries"]["PYTHIA"]["version"]="different";check(environmentDifferences(old,now).size()==1,"environment diff");
    auto bad=w;bad.nodes[1].ports.front().type=domain("Histogram1D");rejects([&]{lowerCollider(bad);});
    std::cout<<"PASS collider contracts, scientific hashing, resources, placement, environment locks\n";
}catch(const std::exception& e){std::cerr<<e.what()<<'\n';return 1;}}
