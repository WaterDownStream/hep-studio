#include "core/units/units.hpp"
#include "core/graph/graph.hpp"
#include "core/project/project.hpp"
#include "core/compiler/compiler.hpp"
#include <iostream>
#include <functional>
#include <cmath>
#include <algorithm>
#include <stdexcept>
namespace {
int passed=0;
void check(bool condition,const char* message){if(!condition)throw std::runtime_error(message);}
void throws(const std::function<void()>& fn){try{fn();}catch(const std::exception&){return;}throw std::runtime_error("Expected an exception");}
void test(const char* name,const std::function<void()>& fn){fn();++passed;std::cout<<"PASS "<<name<<'\n';}
}
int main(){
    using namespace hep;
    try{
        test("unit conversion and mixed-scale addition",[]{
            check(std::abs(Quantity(500,unit("MeV")).convertedTo(unit("GeV")).value-0.5)<1e-12,"MeV conversion");
            check(std::abs((Quantity(1,unit("GeV"))+Quantity(500,unit("MeV"))).value-1.5)<1e-12,"Mixed sum");
            check(Quantity(2,unit("cm")).convertedTo(unit("mm")).value==20,"Length scale");
            check(unit("ns").dimension==timeDimension&&unit("rad").dimension==angle,"Time/angle");
            check(std::abs(unit("pb").scale*unit("fb^-1").scale-1000)<1e-9,"Cross section luminosity normalization");
        });
        test("incompatible units and nonfinite quantities rejected",[]{
            throws([]{(void)(Quantity(1,unit("GeV"))+Quantity(1,unit("mm")));});
            throws([]{(void)Quantity(INFINITY,unit("GeV"));});
            throws([]{(void)unit("not-a-unit");});
        });
        test("IDs are stable and checked",[]{check(Id("source-1")==Id("source-1"),"ID equality");check(newId()!=newId(),"ID uniqueness");throws([]{(void)Id("../bad");});});
        test("primitive and domain type compatibility",[]{
            check(compatible(scalar(energy),scalar(energy)),"energy compatible");
            check(!compatible(scalar(energy),scalar(length)),"dimensions mismatch");
            check(!compatible(domain("Histogram1D"),domain("ParticleCollection")),"domain mismatch");
            for(int i=0;i<15;++i)check(primitiveFromName(primitiveName(static_cast<Primitive>(i)))==static_cast<Primitive>(i),"primitive roundtrip");
        });
        test("valid particle and jet graphs",[]{check(validate(mockWorkflow()).empty(),"particle graph");check(validate(mockWorkflow(true)).empty(),"jet graph");});
        test("invalid typed connection rejected transactionally",[]{
            auto w=mockWorkflow();auto jet=mockNode("JetCluster",newId());w.nodes.push_back(jet);
            const auto before=serialize(w);
            const auto issue=connect(w,{w.nodes[2].id,Id("out"),jet.id,Id("in")});
            check(issue&&issue->code=="type_mismatch","histogram to jet must fail");check(serialize(w)==before,"rejection must not mutate graph");
            check(!connect(w,{w.nodes[0].id,Id("out"),jet.id,Id("in")}),"particle to jet must pass");
        });
        test("cycles, duplicate IDs and occupied inputs rejected",[]{
            auto w=mockWorkflow();check(connect(w,{w.nodes[0].id,Id("out"),w.nodes[1].id,Id("in")}).has_value(),"occupied input");
            w.connections.clear();w.nodes={mockNode("Filter",Id("a")),mockNode("Filter",Id("b"))};
            w.connections={{Id("a"),Id("out"),Id("b"),Id("in")},{Id("b"),Id("out"),Id("a"),Id("in")}};
            throws([&]{(void)topologicalOrder(w);});check(!validate(w).empty(),"cycle validation");
            w.nodes.push_back(w.nodes.front());check(!validate(w).empty(),"duplicate node");
        });
        test("missing node, wrong direction and required input validation",[]{
            auto w=mockWorkflow();w.connections.clear();check(!validate(w).empty(),"missing required input");
            check(connect(w,{Id("missing"),Id("out"),w.nodes[1].id,Id("in")}).has_value(),"dangling edge");
            check(connect(w,{w.nodes[1].id,Id("in"),w.nodes[2].id,Id("in")}).has_value(),"direction");
        });
        test("workflow round trip and order-independent canonical JSON",[]{
            auto w=mockWorkflow();const auto text=serialize(w);
            check(serialize(workflowFromJson(Json::parse(text)))==text,"roundtrip");
            std::reverse(w.nodes.begin(),w.nodes.end());std::reverse(w.connections.begin(),w.connections.end());
            check(serialize(w)==text,"stable ordering");
        });
        test("unknown fields survive nested round trip",[]{
            auto j=workflowJson(mockWorkflow());j["future"]={{"science",42}};j["nodes"][0]["futureNode"]=true;
            j["nodes"][0]["ports"][0]["type"]["futureCapability"]="x";
            j["connections"][0]["futureEdge"]="opaque";
            check(workflowJson(workflowFromJson(j))==j,"unknown fields preserved");
        });
        test("quantity parameter units and serialization",[]{
            auto w=mockWorkflow();Parameter p{"threshold",scalar(energy),25.,20.,"GeV","run","user","Energy threshold",0.,100.};
            check(p.changed(),"changed-from-default");w.nodes[0].parameters.push_back(p);
            check(validate(w).empty(),"valid quantity parameter");check(serialize(workflowFromJson(workflowJson(w)))==serialize(w),"parameter roundtrip");
            w.nodes[0].parameters[0].units="mm";check(!validate(w).empty(),"parameter mismatch");
        });
        test("project round trip with run snapshot and full-width seed",[]{
            Project p{newId(),"Study",{mockWorkflow()}, {}};
            Run r{newId(),"Completed",workflowJson(p.workflows.front()),"recorded-hash"};r.seed="18446744073709551615";
            p.runs.push_back(r);const auto text=serialize(p);check(serialize(parseProject(text))==text,"project roundtrip");
            p.runs.push_back(r);throws([&]{(void)parseProject(serialize(p));});
        });
        test("unsupported schemas and malformed projects fail closed",[]{
            auto p=Project{newId(),"Study",{mockWorkflow()}, {}};auto j=projectJson(p);j["schemaVersion"]=2;
            throws([&]{(void)projectFromJson(j);});throws([]{(void)parseProject("{}");});throws([]{(void)parseProject("{\"name\":1,\"name\":2}");});
            auto w=workflowJson(mockWorkflow());w["nodes"][0]["ports"][0]["direction"]="bidirectional";
            throws([&]{(void)workflowFromJson(w);});
        });
        test("mock compiler refuses tampered contracts and unsupported nodes",[]{
            auto w=mockWorkflow();const auto plan=MockLowerer{}.lower(w);check(plan.orderedNodes.size()==3,"plan nodes");
            w.nodes[0].typeId="root.Source";throws([&]{(void)MockLowerer{}.lower(w);});
            w=mockWorkflow();w.nodes[0].deterministic=false;throws([&]{(void)MockLowerer{}.lower(w);});
        });
    }catch(const std::exception& e){std::cerr<<"FAIL after "<<passed<<" tests: "<<e.what()<<'\n';return 1;}
    std::cout<<passed<<" core tests passed\n";
}
