import unittest,tempfile,sys,threading,json,math
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[2]/'plugins/root'))
import backend
from fixtures import create_fixture

def col(n):return {'op':'column','name':n}
def literal(v,u='1'):return {'op':'literal','value':v,'unit':u}
def expr(op,*args):return {'op':op,'args':list(args)}
PT=expr('sqrt',expr('add',expr('square',col('px')),expr('square',col('py'))))
def plan(schema,threshold=1):
    return {'version':1,'nodes':[
        {'id':'source','kind':'Source','config':{'datasetId':'sample','object':'Events','schema':schema,'fingerprint':schema['fingerprint']}},
        {'id':'pt','kind':'Define','input':'source','config':{'name':'pT','expression':PT}},
        {'id':'cut','kind':'Filter','input':'pt','config':{'expression':expr('gt',col('pT'),literal(threshold,'GeV'))}},
        {'id':'hist','kind':'Histo1D','input':'cut','config':{'expression':col('pT'),'edges':[0,5,10,15,20]}},
        {'id':'count','kind':'Count','input':'cut','config':{}},
        {'id':'mean','kind':'Mean','input':'pt','config':{'expression':col('pT')}},
        {'id':'sum','kind':'Sum','input':'pt','config':{'expression':col('pT')}}]}
class BackendTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        try:backend.initialize()
        except ImportError:raise unittest.SkipTest('PyROOT unavailable')
        cls.tmp=tempfile.TemporaryDirectory();cls.path=create_fixture(Path(cls.tmp.name)/'known.root',10000);cls.schema=backend.schema(cls.path,'Events')
    @classmethod
    def tearDownClass(cls):cls.tmp.cleanup()
    def test_capability_and_inspection(self):
        self.assertTrue(backend.initialize()['available']);objects=backend.inspect(self.path)['objects'];self.assertTrue(any(o['path']=='calibration/gaussian' for o in objects))
    def test_schema_and_bounded_preview(self):
        self.assertEqual(self.schema['entries'],10000);self.assertEqual(next(c for c in self.schema['columns'] if c['name']=='px')['unit'],'GeV')
        p=backend.preview(self.path,'Events',9995,5,['px','py']);self.assertEqual(p['represented'],5);self.assertEqual(p['rows'][0],[3.,4.])
    def test_physics_regression_and_shared_loop(self):
        r=backend.execute(plan(self.schema),{'sample':{'location':self.path}},threading.Event(),lambda _:None)
        self.assertEqual(r['results']['hist']['values'],[0.,2000.,2000.,2000.]);self.assertEqual(r['results']['count']['value'],6000)
        self.assertAlmostEqual(r['results']['mean']['value'],7.1);self.assertAlmostEqual(r['results']['sum']['value'],71000)
        self.assertEqual(r['eventLoops'],1);self.assertEqual(r['sources'][0]['fingerprint'],self.schema['fingerprint'])
        self.assertIn('.Define(',r['generatedCode']);self.assertIn('.Filter(',r['generatedCode'])
    def test_fit_covariance(self):
        f,_=backend.CACHE.open(self.path);r=backend.fit_histogram(f.Get('calibration/gaussian'),{'model':'gaussian','lower':-4,'upper':4,'initial':[900,0,1],'bounds':[[0,2000],[-2,2],[.1,3]]})
        self.assertTrue(r['converged']);self.assertAlmostEqual(r['parameters'][1]['value'],.4,places=3);self.assertAlmostEqual(r['parameters'][2]['value'],1.1,places=3);self.assertEqual(len(r['covariance']),3)
    def test_parameter_bounds_are_honored(self):
        f,_=backend.CACHE.open(self.path)
        result=backend.fit_histogram(f.Get('calibration/gaussian'),{'model':'gaussian','initial':[900,-.2,1],'bounds':[[0,2000],[-1,0],[.1,3]]})
        self.assertLessEqual(result['parameters'][1]['value'],1e-8);self.assertIn('B',result['options']);self.assertTrue(result['warning'])
        import ROOT
        h=ROOT.TH1D('bounded_polynomial','',20,0,5);h.SetDirectory(0)
        for i in range(1,21):h.SetBinContent(i,10+2*h.GetBinCenter(i));h.SetBinError(i,1)
        result=backend.fit_histogram(h,{'model':'polynomial','order':1,'initial':[10,.2],'bounds':[[0,100],[0,.5]]})
        self.assertLessEqual(result['parameters'][1]['value'],.50000001);self.assertIn('F',result['options'])
    def test_exponential_polynomial_and_failed_fit(self):
        import ROOT
        for model,formula,expected in [('exponential',lambda x:math.exp(3-.4*x),[3,-.4]),('polynomial',lambda x:10+2*x,[10,2])]:
            h=ROOT.TH1D('test_'+model,'',50,0,5);h.SetDirectory(0)
            for i in range(1,51):v=formula(h.GetBinCenter(i));h.SetBinContent(i,v);h.SetBinError(i,math.sqrt(v))
            fit=backend.fit_histogram(h,{'model':model,'order':1,'initial':expected})
            self.assertTrue(fit['converged']);self.assertAlmostEqual(fit['parameters'][1]['value'],expected[1],places=3)
        h=ROOT.TH1D('empty_test','',10,0,1);h.SetDirectory(0)
        fit=backend.fit_histogram(h,{'model':'gaussian'});self.assertFalse(fit['converged']);self.assertTrue(fit['warning']);json.dumps(fit,allow_nan=False)
    def test_weight_normalization_flow_and_histo2d(self):
        p=plan(self.schema);p['nodes'][3]['config'].update({'weight':literal(2),'normalization':'unit-area','edges':[0,10,15],'flow':'fold'})
        p['nodes'].append({'id':'h2','kind':'Histo2D','input':'pt','config':{'expression':col('px'),'yExpression':col('py'),'edges':[0,4,10],'yEdges':[0,5,20]}})
        r=backend.execute(p,{'sample':{'location':self.path}},threading.Event(),lambda _:None)
        self.assertAlmostEqual(sum(r['results']['hist']['values']),1);self.assertEqual(r['results']['hist']['overflow'],4000)
        self.assertEqual(sum(sum(row) for row in r['results']['h2']['values']),10000);self.assertEqual(r['eventLoops'],1)
    def test_dimensions_and_unknown_columns(self):
        columns={'px':('px',(1,0,0,0),False,False)}
        with self.assertRaises(ValueError):backend.expression(expr('add',col('px'),literal(1,'mm')),columns)
        with self.assertRaises(ValueError):backend.expression(col('system("bad")'),columns)
        with self.assertRaises(ValueError):backend.expression({'op':'raw','args':[col('px')]},columns)
    def test_change_detection_and_cancellation(self):
        p=plan(self.schema);p['nodes'][0]['config']['fingerprint']={'size':1}
        with self.assertRaisesRegex(ValueError,'changed'):backend.execute(p,{'sample':{'location':self.path}},threading.Event(),lambda _:None)
        cancel=threading.Event();cancel.set()
        with self.assertRaises(InterruptedError):backend.execute(plan(self.schema),{'sample':{'location':self.path}},cancel,lambda _:None)
    def test_integer_numeric_promotion(self):
        import ROOT,array
        path=str(Path(self.tmp.name)/'integers.root');f=ROOT.TFile(path,'RECREATE');tree=ROOT.TTree('Events','integers');x=array.array('i',[30000]);y=array.array('i',[40000]);tree.Branch('x',x,'x/I');tree.Branch('y',y,'y/I');tree.Fill();tree.Write();f.Close()
        s=backend.schema(path,'Events');self.assertTrue(all(c['coreType']=='Int32' for c in s['columns']))
        p={'nodes':[{'id':'s','kind':'Source','config':{'datasetId':'i','object':'Events','schema':s}},
                    {'id':'norm','kind':'Mean','input':'s','config':{'expression':expr('sqrt',expr('add',expr('square',col('x')),expr('square',col('y'))))}},
                    {'id':'ratio','kind':'Mean','input':'s','config':{'expression':expr('div',col('x'),col('y'))}}]}
        r=backend.execute(p,{'i':{'location':path}},threading.Event(),lambda _:None)
        self.assertEqual(r['results']['norm']['value'],50000);self.assertAlmostEqual(r['results']['ratio']['value'],.75)
    def test_missing_file(self):
        with self.assertRaisesRegex(ValueError,'unavailable'):backend.inspect(str(Path(self.tmp.name)/'absent.root'))
    def test_rntuple(self):
        import ROOT,numpy as np
        path=str(Path(self.tmp.name)/'ntuple.root')
        if not hasattr(ROOT,'RNTupleWriter'):self.skipTest('RNTupleWriter not available')
        with ROOT.RNTupleWriter.Recreate([('double','px'),('double','py')],'Tracks',path) as writer:
            entry=writer.CreateEntry()
            for px,py in [(3.,4.),(5.,12.)]:
                entry['px']=px;entry['py']=py;writer.Fill(entry)
        s=backend.schema(path,'Tracks');self.assertEqual(s['format'],'RNTuple');self.assertEqual(s['entries'],2)
        p=backend.preview(path,'Tracks',0,2,['px','py']);self.assertEqual(p['rows'],[[3.,4.],[5.,12.]])
        self.assertEqual(backend.preview(path,'Tracks',1,1,['px','py'])['rows'],[[5.,12.]])
if __name__=='__main__':
    try:backend.initialize()
    except ImportError:print('SKIP: ROOT is unavailable');sys.exit(77)
    unittest.main(verbosity=2)
