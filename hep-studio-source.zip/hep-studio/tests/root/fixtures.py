from pathlib import Path
import sys,math,array,json

def create_fixture(path,entries=10000):
    import ROOT
    f=ROOT.TFile(str(path),'RECREATE');tree=ROOT.TTree('Events','Known momentum values')
    px=array.array('d',[0]);py=array.array('d',[0]);eta=array.array('d',[0]);weight=array.array('d',[0])
    for name,val in [('px',px),('py',py),('eta',eta),('weight',weight)]:tree.Branch(name,val,name+'/D')
    known=[(3.,4.),(0.,0.),(5.,12.),(8.,15.),(.3,.4)]
    for i in range(entries):
        px[0],py[0]=known[i%5];eta[0]=(i%7-3)*.4;weight[0]=1.;tree.Fill()
    tree.Write();ROOT.TObjString(json.dumps({'px':'GeV','py':'GeV','eta':'1','weight':'1'})).Write('hep_units')
    d=f.mkdir('calibration');d.cd();h=ROOT.TH1D('gaussian','Deterministic Gaussian',100,-5,5)
    # Analytic expected bin counts with Poisson-like errors, not random samples.
    for i in range(1,101):
        x=h.GetBinCenter(i);v=1000*math.exp(-.5*((x-.4)/1.1)**2);h.SetBinContent(i,v);h.SetBinError(i,math.sqrt(max(v,1)))
    h.SetEntries(27573);h.Write();f.Close()
    return str(path)
if __name__=='__main__':create_fixture(sys.argv[1],int(sys.argv[2]) if len(sys.argv)>2 else 10000)
