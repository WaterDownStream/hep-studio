"""Reproducible local measurements, not pass/fail performance thresholds."""
import sys,time,json,statistics,threading,copy,platform
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[2]/'plugins/root'))
import backend
from test_backend import plan
path=sys.argv[1]
t=time.perf_counter();capability=backend.initialize();startup=time.perf_counter()-t

def measure(fn,n=5):
    times=[];value=None
    for _ in range(n):
        start=time.perf_counter();value=fn();times.append((time.perf_counter()-start)*1000)
    return {'firstMs':times[0],'medianMs':statistics.median(times),'samplesMs':times},value
inspection,_=measure(lambda:backend.inspect(path));schema_t,schema=measure(lambda:backend.schema(path,'Events'));preview,_=measure(lambda:backend.preview(path,'Events',0,50))
p=plan(schema)
execution,result=measure(lambda:backend.execute(copy.deepcopy(p),{'sample':{'location':path}},threading.Event(),lambda _:None),3)
try:
    import resource
    memory={'peakRssMiB':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss/(1024 if sys.platform!='darwin' else 1024*1024),'strategy':'OS process peak RSS, includes ROOT import, Cling/JIT and all measurements'}
except ImportError:memory={'available':False}
report={'platform':platform.platform(),'python':sys.version,'root':capability,'fixtureEntries':schema['entries'],'fixtureBytes':Path(path).stat().st_size,'startupSeconds':startup,'inspection':inspection,'schema':schema_t,'preview50':preview,'histogramAndAggregates':execution,'lastEventLoopSeconds':result['eventLoopSeconds'],'lastEventThroughput':result['throughputEntriesPerSecond'],'eventLoopsPerRun':result['eventLoops'],'memory':memory,'notes':['Single scientific thread; warm OS cache after first read.','First execution includes JIT; warm execution rebooks actions but reuses ROOT process.','All histogram/Count/Mean/Sum actions share one event loop.','Benchmark bypasses IPC; desktop integration tests exercise actual worker transport.']}
print(json.dumps(report,indent=2))
