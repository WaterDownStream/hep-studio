"""Real-library tests. Missing native collider engine produces an explicit skip."""
import json,os,sys,threading,unittest,tempfile,copy,subprocess,time,math
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT/'plugins'/'collider'))
import backend
cap=backend.initialize()
if not cap['available']:
    print('SKIP real collider integration:',cap['reason']);sys.exit(77)

class ColliderTests(unittest.TestCase):
    def request(self,operation,payload):
        return backend.dispatch({'id':'test','operation':operation,'payload':payload},threading.Event(),lambda _:None)
    def workflow(self):return json.loads((ROOT/'examples'/'collider-workflow.json').read_text())
    def test_logical_streams_worker_independence_and_shards(self):
        w=self.workflow();source=next(n for n in w['nodes'] if n['typeId']=='hep.collider.Pythia')
        source['config'].update(events=25,streamPolicy='logical-blocks-v2',partitionEvents=8)
        outputs=[]
        for workers in (1,2,4):
            source['config']['workers']=workers
            outputs.append(self.request('execute',{'workflow':w,'allocatedThreads':workers}))
        for r in outputs[1:]:
            self.assertEqual(r['results'],outputs[0]['results']);self.assertEqual(r['seed'],outputs[0]['seed'])
            for metric in ('generated','accepted','sumWeights','sumWeightsSquared'):self.assertEqual(r['metrics'][metric],outputs[0]['metrics'][metric])
        with tempfile.TemporaryDirectory() as tmp:
            path=Path(tmp)/'sample.hepsample.json';store=copy.deepcopy(source);store.update(id='store',typeId='hep.collider.StoreHepMC',config={'resourceId':'sample'})
            port=copy.deepcopy(source['ports'][0]);port.update(id='in',direction='input');store['ports']=[port,copy.deepcopy(source['ports'][0])]
            w['nodes'].append(store);w['connections'].append({'fromNode':source['id'],'fromPort':'out','toNode':'store','toPort':'in'})
            r=self.request('execute',{'workflow':w,'allocatedThreads':4,'resources':{'sample':{'path':str(path)}}})
            manifest=json.loads(path.read_text());self.assertTrue(manifest['complete']);self.assertEqual(len(manifest['shards']),4)
            self.assertEqual(r['results'],outputs[0]['results'])
            w['nodes'].pop();w['connections'].pop();source.update(typeId='hep.collider.HepMCSource',config={'resourceId':'sample'})
            reused=self.request('execute',{'workflow':w,'resources':{'sample':{'path':str(path)}}})
            self.assertEqual(reused['results']['hist']['values'],r['results']['hist']['values'])
            self.assertEqual(reused['metrics']['accepted'],25)
            exported=Path(tmp)/'export.hepmc';result=self.request('exportSample',{'path':str(path),'destination':str(exported)});self.assertEqual(result['eventCount'],25)
            single=self.request('execute',{'workflow':w,'resources':{'sample':{'path':str(exported)}}});self.assertEqual(single['results']['hist']['values'],reused['results']['hist']['values'])
            with self.assertRaisesRegex(ValueError,'already exists'):self.request('exportSample',{'path':str(path),'destination':str(exported)})
            # A controlled real HepMC weight fixture tests the native reader/TH1 path.
            lines=exported.read_text().splitlines();weights=[2.0,-1.0,0.5,3.0,0.0]*5;weight_index=0
            for i,line in enumerate(lines):
                if line.startswith('W '):lines[i]='W '+str(weights[weight_index]);weight_index+=1
            self.assertEqual(weight_index,25);exported.write_text('\n'.join(lines)+'\n')
            weighted=copy.deepcopy(w);cluster=next(n for n in weighted['nodes'] if n['typeId']=='hep.collider.ClusterJets')
            count=copy.deepcopy(next(n for n in weighted['nodes'] if n['typeId']=='hep.collider.Property'));count.update(id='jet-count',typeId='hep.collider.CollectionCount',config={})
            histogram=next(n for n in weighted['nodes'] if n['id']=='hist');histogram['config']={'expression':{'op':'literal','value':1,'unit':'1'},'bins':2,'lower':0,'upper':2,'normalization':'counts','flow':'separate'}
            weighted['nodes']=[copy.deepcopy(source),cluster,count,histogram];weighted['connections']=[{'fromNode':source['id'],'fromPort':'out','toNode':cluster['id'],'toPort':'in'},{'fromNode':cluster['id'],'fromPort':'out','toNode':count['id'],'toPort':'in'},{'fromNode':count['id'],'fromPort':'out','toNode':'hist','toPort':'in'}]
            observed=self.request('execute',{'workflow':weighted,'resources':{'sample':{'path':str(exported)}}})
            self.assertAlmostEqual(observed['metrics']['sumWeights'],sum(weights));self.assertAlmostEqual(observed['metrics']['sumWeightsSquared'],sum(x*x for x in weights))
            h=observed['results']['hist'];self.assertEqual(h['entries'],25);self.assertAlmostEqual(h['values'][1],sum(weights));self.assertAlmostEqual(h['errors'][1]**2,sum(x*x for x in weights));self.assertEqual(h['underflow'],0);self.assertEqual(h['overflow'],0)
            shard=path.parent/manifest['shards'][1]['location'];shard.write_bytes(shard.read_bytes()[:100])
            with self.assertRaisesRegex(ValueError,'corrupt'):self.request('execute',{'workflow':w,'resources':{'sample':{'path':str(path)}}})

    def test_parallel_partitions_match_independent_serial_runs(self):
        from parallel import partitions
        w=self.workflow();source=next(n for n in w['nodes'] if n['typeId']=='hep.collider.Pythia')
        source['config'].update(events=21,workers=2,seed='900000000',seedStrategy='fixed')
        parallel=self.request('execute',{'workflow':w,'allocatedThreads':2})
        again=self.request('execute',{'workflow':w,'allocatedThreads':2})
        self.assertEqual(parallel['metrics']['accepted'],21)
        self.assertEqual(parallel['metrics']['workerProcesses'],2)
        self.assertEqual(parallel['metrics']['bulkEventsThroughIPC'],0)
        self.assertEqual(parallel['results'],again['results'])
        self.assertEqual(len(parallel['events']),1)
        parts=partitions(900000000,21,2);self.assertEqual([p['seed'] for p in parts],[900000000,1])
        serial=[]
        for p in parts:
            child=copy.deepcopy(w);next(n for n in child['nodes'] if n['typeId']=='hep.collider.Pythia')['config'].update(workers=1,events=p['events'],seed=str(p['seed']))
            serial.append(self.request('execute',{'workflow':child}))
        expected=[sum(r['results']['hist']['values'][i] for r in serial) for i in range(len(parallel['results']['hist']['values']))]
        self.assertEqual(parallel['results']['hist']['values'],expected)
        self.assertEqual(parallel['seed']['partitions'],parts)
        self.assertIn('Logical streams',parallel['generatedCode'])
        with self.assertRaisesRegex(ValueError,'Broker allocation'):self.request('execute',{'workflow':w,'allocatedThreads':1})
        preview=self.request('eventPreview',{'workflow':w,'previewEvents':2,'allocatedThreads':1})
        self.assertEqual(preview['metrics']['threads'],1)

    def test_parallel_weighted_normalization_and_scalar_reduction(self):
        w=self.workflow();source=next(n for n in w['nodes'] if n['typeId']=='hep.collider.Pythia');source['config'].update(events=24,workers=2)
        hist=next(n for n in w['nodes'] if n['id']=='hist');hist['config'].update(edges=[0,40,50,80],flow='fold',normalization='density',weight={'op':'literal','value':2,'unit':'1'})
        edge=next(e for e in w['connections'] if e['toNode']=='hist')
        for kind in ('Count','Mean','Sum','Min','Max'):
            node=copy.deepcopy(hist);node.update(id=kind,typeId='hep.root.'+kind);node['config']={'expression':{'op':'column','name':'value'}};node['ports'][1]['type']['name']='ScalarResult'
            w['nodes'].append(node);w['connections'].append(dict(edge,toNode=kind))
        r=self.request('execute',{'workflow':w,'allocatedThreads':2});parts=r['seed']['partitions'];serial=[]
        for part in parts:
            child=copy.deepcopy(w);next(n for n in child['nodes'] if n['typeId']=='hep.collider.Pythia')['config'].update(events=part['events'],workers=1,seedStrategy='fixed',seed=str(part['seed']))
            next(n for n in child['nodes'] if n['id']=='hist')['config'].update(normalization='counts',flow='separate')
            serial.append(self.request('execute',{'workflow':child}))
        for op in ('Count','Sum','Min','Max'):
            values=[s['results'][op]['value'] for s in serial];expected=(min if op=='Min' else max if op=='Max' else sum)(values)
            self.assertAlmostEqual(r['results'][op]['value'],expected)
        count=sum(s['results']['Count']['value'] for s in serial);total=sum(s['results']['Sum']['value'] for s in serial)
        self.assertAlmostEqual(r['results']['Mean']['value'],total/count)
        values=[sum(s['results']['hist']['values'][i] for s in serial) for i in range(3)]
        errors2=[sum(s['results']['hist']['errors'][i]**2 for s in serial) for i in range(3)]
        for i,flow in ((0,'underflow'),(-1,'overflow')):
            values[i]+=sum(s['results']['hist'][flow] for s in serial);errors2[i]+=sum(s['results']['hist'][flow+'Error']**2 for s in serial)
        total=sum(values)
        for i,width in enumerate((40,10,30)):
            self.assertAlmostEqual(r['results']['hist']['values'][i],values[i]/total/width)
            self.assertAlmostEqual(r['results']['hist']['errors'][i],math.sqrt(errors2[i])/total/width)

    @unittest.skipUnless(sys.platform=='linux','Process-death inspection uses Linux /proc')
    def test_parent_death_stops_parallel_children(self):
        with tempfile.TemporaryDirectory() as tmp:
            pidfile=Path(tmp)/'pids.json';script=Path(tmp)/'parent.py'
            script.write_text("import sys,json,threading,os;from pathlib import Path\n"
                +"sys.path.insert(0,"+repr(str(ROOT/'plugins/collider'))+");import backend\n"
                +"backend.initialize();w=json.loads(Path("+repr(str(ROOT/'examples/collider-workflow.json'))+").read_text())\n"
                +"next(n for n in w['nodes'] if n['typeId']=='hep.collider.Pythia')['config'].update(events=100000,workers=2)\n"
                +"sys.path.insert(0,"+repr(str(ROOT/'tests/collider'))+");from process_monitor import host_pid\n"
                +"def report(m):\n if len(m.get('workerPids',[]))!=2:return\n ids=[host_pid(pid) for pid in m['workerPids']]\n if any(pid is None for pid in ids):return\n Path("+repr(str(pidfile))+").with_suffix('.tmp').write_text(json.dumps(ids));os.replace(Path("+repr(str(pidfile))+").with_suffix('.tmp'),Path("+repr(str(pidfile))+"))\n"
                +"backend.dispatch({'id':'orphan-test','operation':'execute','payload':{'workflow':w,'allocatedThreads':2}},threading.Event(),report)\n")
            parent=subprocess.Popen([sys.executable,str(script)],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
            try:
                deadline=time.monotonic()+15
                while not pidfile.exists() and time.monotonic()<deadline and parent.poll() is None:time.sleep(.05)
                self.assertTrue(pidfile.exists(),'Child workers did not start')
                # Read after killing the writer to avoid an in-progress update.
                parent.kill();parent.wait(timeout=3);pids=json.loads(pidfile.read_text())
                def running(pid):
                    try:return Path('/proc/'+str(pid)+'/stat').read_text().split(') ',1)[1][0]!='Z'
                    except (FileNotFoundError,ProcessLookupError):return False
                deadline=time.monotonic()+5
                while any(running(pid) for pid in pids) and time.monotonic()<deadline:time.sleep(.05)
                self.assertFalse(any(running(pid) for pid in pids),'Native children survived parent death')
                self.assertEqual(len(pids),2)
            finally:
                if parent.poll() is None:parent.kill();parent.wait(timeout=3)

    def test_parallel_environment_mismatch_rejected(self):
        w=self.workflow();next(n for n in w['nodes'] if n['typeId']=='hep.collider.Pythia')['config'].update(events=4,workers=2)
        original=backend.CAPABILITY['environment']['id']
        try:
            backend.CAPABILITY['environment']['id']='hep-env://test/changed-parent'
            with self.assertRaisesRegex((RuntimeError,ValueError),'environment differs'):self.request('execute',{'workflow':w,'allocatedThreads':2})
        finally:backend.CAPABILITY['environment']['id']=original

    def test_parallel_cancellation_and_failed_child(self):
        w=self.workflow();source=next(n for n in w['nodes'] if n['typeId']=='hep.collider.Pythia');source['config'].update(events=100000,workers=2)
        cancel=threading.Event();timer=threading.Timer(.5,cancel.set);timer.start();start=time.monotonic()
        try:
            with self.assertRaises(InterruptedError):backend.dispatch({'id':'cancel','operation':'execute','payload':{'workflow':w,'allocatedThreads':2}},cancel,lambda _:None)
        finally:timer.cancel()
        self.assertLess(time.monotonic()-start,8)
        source['config']['advanced']={'Nonexistent:setting':1}
        with self.assertRaisesRegex((ValueError,RuntimeError),'Unknown/unsupported'):self.request('execute',{'workflow':w,'allocatedThreads':2})

    def test_cancel_merge_and_persistence(self):
        import shutil
        with tempfile.TemporaryDirectory() as tmp:
            w=self.workflow();source=next(n for n in w['nodes'] if n['typeId']=='hep.collider.Pythia');source['config'].update(events=4,workers=2,streamPolicy='logical-blocks-v2',partitionEvents=2)
            store=copy.deepcopy(source);store.update(id='store',typeId='hep.collider.StoreHepMC',config={'resourceId':'sample'})
            port=copy.deepcopy(source['ports'][0]);port.update(id='in',direction='input');store['ports']=[port,copy.deepcopy(source['ports'][0])]
            w['nodes'].append(store);w['connections'].append({'fromNode':source['id'],'fromPort':'out','toNode':'store','toPort':'in'})
            destination=Path(tmp)/'sample.hepsample.json';payload={'workflow':w,'allocatedThreads':2,'resources':{'sample':{'path':str(destination)}}}
            for stage in ('Merging compact results','Committing sample shards'):
                cancel=threading.Event()
                def progress(value):
                    if value.get('stage')==stage:cancel.set()
                with self.assertRaises(InterruptedError):backend.dispatch({'id':'stage-cancel','operation':'execute','payload':payload},cancel,progress)
                self.assertFalse(destination.exists());self.assertEqual(list(Path(tmp).iterdir()),[])
            # Actual filesystem capacity is insufficient for this estimated sample.
            source['config'].update(events=shutil.disk_usage(tmp).free//(1024*1024)+100,partitionEvents=1000000)
            with self.assertRaisesRegex(ValueError,'Insufficient disk'):self.request('execute',payload)
            self.assertFalse(destination.exists());self.assertEqual(list(Path(tmp).iterdir()),[])
    @unittest.skipUnless(sys.platform=='linux','Linux kill integration')
    def test_killed_parallel_child_fails_and_restarts(self):
        import signal
        w=self.workflow();source=next(n for n in w['nodes'] if n['typeId']=='hep.collider.Pythia');source['config'].update(events=10000,workers=2)
        killed=[];start=time.monotonic()
        def progress(value):
            if not killed and len(value.get('workerPids',[]))==2:
                pid=value['workerPids'][0];os.kill(pid,signal.SIGKILL);killed.append(pid)
        with self.assertRaises((RuntimeError,EOFError,ValueError)):backend.dispatch({'id':'kill-one','operation':'execute','payload':{'workflow':w,'allocatedThreads':2}},threading.Event(),progress)
        self.assertTrue(killed);self.assertLess(time.monotonic()-start,15)
        source['config'].update(events=4);self.assertEqual(self.request('execute',{'workflow':w,'allocatedThreads':2})['metrics']['accepted'],4)

    def test_fastjet_known_vectors(self):
        for algorithm in ('antikt','kt','cambridge'):
            r=self.request('clusterFixture',{'particles':[[40,0,0,40],[10,0,0,10],[-30,0,0,30]],'config':{'algorithm':algorithm,'R':.4}})
            self.assertEqual(len(r['jets']),2);self.assertAlmostEqual(r['jets'][0]['pt'],50);self.assertEqual(set(r['jets'][0]['constituents']),{0,1})
    def test_capabilities_and_settings(self):
        for lib in ('PYTHIA','FastJet','HepMC3','ROOT'):self.assertTrue(cap['libraries'][lib]['available']);self.assertTrue(cap['libraries'][lib]['version'])
        result=self.request('settings',{'search':'TimeShower:alphaS','changedOnly':False})
        self.assertGreater(result['total'],0);self.assertIn('default',result['settings'][0])
    def test_real_pipeline_and_reproducible_seed(self):
        w=self.workflow();a=self.request('execute',{'workflow':w,'projectSeed':'42'});b=self.request('execute',{'workflow':w,'projectSeed':'42'})
        self.assertEqual(a['metrics']['accepted'],100);self.assertEqual(a['metrics']['bulkEventsThroughIPC'],0)
        self.assertGreater(sum(a['results']['hist']['values']),0);self.assertLessEqual(a['results']['hist']['entries'],100)
        self.assertEqual(a['results']['hist']['values'],b['results']['hist']['values'])
        self.assertEqual(len(a['events']),1);self.assertTrue(a['events'][0]['particles']);self.assertTrue(a['events'][0]['vertices'])
        self.assertTrue(a['environment']['id'].startswith('hep-env://'));self.assertIn('Random:seed',a['generatedConfiguration'])
    def test_preview_and_invalid_configuration(self):
        w=self.workflow();r=self.request('eventPreview',{'workflow':w,'previewEvents':3})
        self.assertTrue(r['preview']);self.assertEqual(r['metrics']['accepted'],3);self.assertEqual(len(r['events']),3)
        for n in w['nodes']:
            if n['typeId']=='hep.collider.Pythia':n['config']['rawOverrides']=['Beams:eCM = 7']
        with self.assertRaisesRegex(ValueError,'conflicts'):self.request('execute',{'workflow':w})
    def test_seed_derivation(self):
        c={'seedStrategy':'project-derived'}
        self.assertEqual(backend.derive_seed('123',c,'x'),backend.derive_seed('123',c,'x'))
        self.assertNotEqual(backend.derive_seed('123',c,'x')[0],backend.derive_seed('123',c,'y')[0])
    def test_hepmc_materialization_reuse_and_corruption(self):
        with tempfile.TemporaryDirectory() as tmp:
            path=Path(tmp)/'events.hepmc';w=self.workflow();source=next(n for n in w['nodes'] if n['typeId']=='hep.collider.Pythia');source['config']['events']=8
            store=copy.deepcopy(source);store.update(id='store',typeId='hep.collider.StoreHepMC',name='Stored sample',config={'resourceId':'sample'})
            port=copy.deepcopy(source['ports'][0]);port.update(id='in',name='Input',direction='input')
            store['ports']=[port,copy.deepcopy(source['ports'][0])];w['nodes'].append(store)
            w['connections'].append({'fromNode':source['id'],'fromPort':'out','toNode':'store','toPort':'in'})
            result=self.request('execute',{'workflow':w,'resources':{'sample':{'path':str(path)}}})
            self.assertEqual(result['samples'][0]['eventCount'],8);self.assertEqual(len(result['samples'][0]['sha256']),64)
            w['nodes'].pop();w['connections'].pop();source.update(typeId='hep.collider.HepMCSource',config={'resourceId':'sample'})
            reused=self.request('execute',{'workflow':w,'resources':{'sample':{'path':str(path),'sha256':result['samples'][0]['sha256']}}})
            self.assertEqual(reused['metrics']['accepted'],8);self.assertEqual(result['results']['hist']['values'],reused['results']['hist']['values'])
            self.assertEqual(reused['inputResources']['sample']['hashStrategy'],'sha256-full')
            text=path.read_text();path.write_text(text[:len(text)//2])
            with self.assertRaisesRegex(ValueError,'Incomplete'):self.request('execute',{'workflow':w,'resources':{'sample':{'path':str(path)}}})
            rows=text.splitlines();events=[i for i,line in enumerate(rows) if line.startswith('E ')];rows[events[1]]='E 1 1 9999999';path.write_text('\n'.join(rows)+'\n')
            with self.assertRaisesRegex(ValueError,'Malformed'):self.request('execute',{'workflow':w,'resources':{'sample':{'path':str(path)}}})
    def test_installed_pdf_and_external_generation(self):
        if not cap['libraries']['LHAPDF']['available']:self.skipTest('LHAPDF not installed')
        sets=self.request('pdfSets',{})['sets']
        if not any(s['name']=='CT14lo' for s in sets):self.skipTest('CT14lo validation set not installed; no implicit download')
        curve=self.request('pdfEvaluate',{'set':'CT14lo','member':0,'flavour':21,'xMin':.001,'xMax':.8,'Q':91.1876,'points':5})
        self.assertEqual(len(curve['points']),5);self.assertAlmostEqual(curve['points'][0][1],33.913182,places=5)
        with self.assertRaisesRegex(ValueError,'member'):self.request('pdfEvaluate',{'set':'CT14lo','member':10000})
        if not cap['libraries']['PYTHIA']['externalLHAPDF']:self.skipTest('Installed PYTHIA lacks supported external PDF interface')
        w=self.workflow();next(n for n in w['nodes'] if n['typeId']=='hep.collider.Pythia')['config'].update(events=5,pdf={'set':'CT14lo','member':0})
        r=self.request('execute',{'workflow':w});self.assertEqual(r['metrics']['accepted'],5)
        self.assertIn('CT14lo_0000.dat',r['generator']['pdfIdentity']['files'])
    def test_out_of_range_settings_are_not_clamped(self):
        with self.assertRaisesRegex(ValueError,'outside'):self.request('settings',{'config':{'advanced':{'TimeShower:alphaSvalue':100}}})
    def test_exported_cpp_matches_worker_histogram(self):
        if not os.environ.get('HEP_REFERENCE_COMPILER'):self.skipTest('Reference C++ compiler paths not configured')
        w=self.workflow();next(n for n in w['nodes'] if n['typeId']=='hep.collider.Pythia')['config'].update(streamPolicy='logical-blocks-v2',partitionEvents=12,events=25,workers=2)
        next(n for n in w['nodes'] if n['id']=='hist')['config'].update(edges=[0,40,80],weight={'op':'literal','value':0.1,'unit':'1'},flow='fold',normalization='density')
        r=self.request('execute',{'workflow':w,'allocatedThreads':2})
        with tempfile.TemporaryDirectory() as tmp:
            tmp=Path(tmp);source=tmp/'reference.cpp';exe=tmp/'reference';output=tmp/'result.root';source.write_text(r['generatedCode'])
            includes=os.environ['HEP_REFERENCE_INCLUDES'].split('|');libraries=os.environ['HEP_REFERENCE_LIBRARIES'].split('|')
            paths=sorted({str(Path(lib).parent) for lib in libraries})
            subprocess.run([os.environ['HEP_REFERENCE_COMPILER'],'-std=c++17',str(source),'-o',str(exe),*['-I'+i for i in includes],*libraries,*['-Wl,-rpath,'+p for p in paths]],check=True,capture_output=True,timeout=60)
            subprocess.run([str(exe),str(output)],check=True,capture_output=True,timeout=60)
            import ROOT as root
            f=root.TFile.Open(str(output));hist=f.Get('hist')
            for i in range(1,hist.GetNbinsX()+1):
                self.assertAlmostEqual(hist.GetBinContent(i),r['results']['hist']['values'][i-1],places=12)
                self.assertAlmostEqual(hist.GetBinError(i),r['results']['hist']['errors'][i-1],places=12)
            f.Close()

if __name__=='__main__':unittest.main()
