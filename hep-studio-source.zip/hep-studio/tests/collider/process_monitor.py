"""Translate a local PID when /proc is mounted from an outer PID namespace."""
import os,sys
from pathlib import Path

def host_pid(pid):
    if sys.platform!='linux' or os.readlink('/proc/self')==str(os.getpid()):return pid
    namespace=os.readlink('/proc/self/ns/pid')
    for entry in Path('/proc').iterdir():
        if not entry.name.isdecimal():continue
        try:
            if os.readlink(entry/'ns/pid')!=namespace:continue
            fields=next(line for line in (entry/'status').read_text().splitlines() if line.startswith('NSpid:')).split()
            if int(fields[-1])==pid:return int(entry.name)
        except (OSError,StopIteration):continue
    return None
