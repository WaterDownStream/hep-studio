"""Release throughput matrix with real broker admission and sampled process-tree RAM."""
import argparse,datetime,json,os,platform,subprocess,sys,tempfile,time
from pathlib import Path
import psutil
from process_monitor import host_pid

def main():
    p=argparse.ArgumentParser();p.add_argument('--budget-runner',required=True);p.add_argument('--events',type=int,default=16384);p.add_argument('--workers',type=int,nargs='+',default=[1,2,4,7,8]);p.add_argument('--output',type=Path,required=True);a=p.parse_args()
    hardware=json.loads(subprocess.check_output([a.budget_runner],text=True));cpus=os.cpu_count();cpu=platform.processor()
    if Path('/proc/cpuinfo').exists():cpu=next(s.split(':',1)[1].strip() for s in Path('/proc/cpuinfo').read_text().splitlines() if s.startswith('model name'))
    report={'monitorVersion':2,'timestamp':datetime.datetime.now(datetime.timezone.utc).isoformat(),'buildType':'Release','cpu':cpu,'hostLogicalCpus':cpus,'reportedPhysicalCores':psutil.cpu_count(logical=False),'platform':platform.platform(),'brokerHardware':hardware,'cpuQuota':Path('/sys/fs/cgroup/cpu.max').read_text().strip() if Path('/sys/fs/cgroup/cpu.max').exists() else None,'eventCount':a.events,'streamPolicy':'logical-blocks-v2','partitionEvents':2048,'seed':1,'measurements':[],'skipped':[], 'notes':['Broker admission is mandatory. One effective CPU is reserved for the UI where possible.','CPU is sampled process-tree CPU time; RAM samples every 50 ms. RSS double-counts shared pages; PSS is included on Linux.','Cases run sequentially; each worker executes identical logical blocks. Scientific SDK versions/hashes are in each environment.']}
    if a.output.exists():
        previous=json.loads(a.output.read_text())
        if previous.get('monitorVersion')!=2:raise ValueError('Old process monitor report; choose a new output')
        if previous.get('eventCount')!=a.events or previous.get('cpu')!=cpu:raise ValueError('Existing report describes another benchmark; choose a new output')
        report=previous
    baseline={row['case']:row['wallSeconds'] for row in report['measurements'] if row['workers']==1}
    for case in ('generation','generation-fastjet','full-histogram','full-persisted'):
        for workers in a.workers:
            if any(row['case']==case and row['workers']==workers for row in report['measurements']):continue
            if workers>max(1,hardware['logicalCpus']-1):report['skipped'].append({'case':case,'workers':workers,'reason':'Exceeds Resource Broker UI-reserved CPU budget'});continue
            with tempfile.TemporaryDirectory() as tmp:
                result=Path(tmp)/'result.json';log=a.output.with_suffix('.'+case+'-'+str(workers)+'.log')
                command=[a.budget_runner,str(workers),sys.executable,str(Path(__file__).with_name('benchmark.py')),'--case',case,'--events',str(a.events),'--workers',str(workers),'--directory',tmp,'--output',str(result)]
                with log.open('w') as output:
                    process=subprocess.Popen(command,stdout=output,stderr=subprocess.STDOUT);root=None
                    # /proc may expose host PIDs while subprocess uses a nested PID namespace.
                    observed_pid=host_pid(process.pid)
                    cpu_times={};peak_rss=peak_pss=0;start=time.monotonic()
                    while process.poll() is None:
                        rss=pss=0
                        try:
                            if root is None:
                                observed_pid=host_pid(process.pid)
                                if observed_pid is None:raise psutil.NoSuchProcess(process.pid)
                                root=psutil.Process(observed_pid)
                            tree=[root]+root.children(recursive=True)
                        except psutil.Error:tree=[]
                        for child in tree:
                            try:
                                t=child.cpu_times();cpu_times[(child.pid,child.create_time())]=t.user+t.system;memory=child.memory_full_info();rss+=memory.rss;pss+=getattr(memory,'pss',0)
                            except psutil.Error:pass
                        peak_rss=max(peak_rss,rss);peak_pss=max(peak_pss,pss)
                        if time.monotonic()-start>3600:process.kill();raise TimeoutError('Benchmark exceeded one hour')
                        time.sleep(.05)
                    if process.returncode:raise RuntimeError('Benchmark failed; see '+str(log))
                if not cpu_times:raise RuntimeError('Process monitoring produced no valid samples')
                row=json.loads(result.read_text());wall=row['wallSeconds'];rate=row['events']/wall
                if workers==1:baseline[case]=wall
                row.update(workers=workers,wallEventsPerSecond=rate,speedup=baseline[case]/wall,parallelEfficiency=baseline[case]/wall/workers,cpuSecondsSampled=sum(cpu_times.values()),cpuUtilizationPercent=sum(cpu_times.values())/wall*100,peakProcessTreeRss=peak_rss,peakProcessTreePss=peak_pss,mergeSeconds=row['metrics'].get('mergeSeconds',0),startupSecondsSum=sum(x.get('startupSeconds',0) for x in row['partitionRuns']),initializationAndSetupSecondsSum=sum(x.get('initializationAndSetupSeconds',0) for x in row['partitionRuns']),controlBytes=sum(x.get('controlBytes',0) for x in row['partitionRuns']))
                for part in row['partitionRuns']:part.pop('diagnostics',None)
                report['measurements'].append(row);a.output.write_text(json.dumps(report,indent=2)+'\n');print(case,workers,round(rate,1),flush=True)
    a.output.write_text(json.dumps(report,indent=2)+'\n')
if __name__=='__main__':main()
