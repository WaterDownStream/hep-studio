"""Compare serial/process-partition wall throughput on the same installed stack."""
import argparse,datetime,json,os,platform,subprocess,sys,tempfile
from pathlib import Path

def main():
    parser=argparse.ArgumentParser();parser.add_argument('--events',type=int,default=2000);parser.add_argument('--workers',type=int,nargs='+',default=[1,2]);parser.add_argument('--output',type=Path,required=True);args=parser.parse_args()
    if not 1<=args.events<=1000000 or any(not 1<=w<=32 or w>args.events for w in args.workers):parser.error('Invalid events/worker count')
    cpu=platform.processor()
    if Path('/proc/cpuinfo').exists():cpu=next((line.split(':',1)[1].strip() for line in Path('/proc/cpuinfo').read_text().splitlines() if line.startswith('model name')),cpu)
    report={'measuredAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'cpu':cpu,'platform':platform.platform(),'buildConfiguration':os.environ.get('HEP_BENCHMARK_BUILD_TYPE','unspecified'),'measurements':[],
            'notes':['Same pipeline and event target; worker count changes random samples.','Wall rate includes child startup, initialization, transfer, reduction and finalization.','RSS is per process. Sum of individual peaks is an upper bound, not a simultaneous measured peak.','No performance guarantee across hosts or event counts.']}
    with tempfile.TemporaryDirectory() as tmp:
        for workers in args.workers:
            result=Path(tmp)/'result.json';log=args.output.with_suffix('.workers-'+str(workers)+'.log')
            with log.open('w') as stream:subprocess.run([sys.executable,str(Path(__file__).with_name('benchmark.py')),'--case','full-histogram','--events',str(args.events),'--workers',str(workers),'--directory',tmp,'--output',str(result)],stdout=stream,stderr=subprocess.STDOUT,check=True,timeout=600)
            row=json.loads(result.read_text());row['wallEventsPerSecond']=row['events']/row['wallSeconds']
            row['sumOfProcessPeakRssUpperBoundBytes']=row['peakRssBytes']+sum(p.get('peakRssBytes') or 0 for p in row['partitionRuns'])
            for part in row['partitionRuns']:part.pop('diagnostics',None)
            report['measurements'].append(row)
            args.output.write_text(json.dumps(report,indent=2)+'\n')
    print(args.output)

if __name__=='__main__':main()
