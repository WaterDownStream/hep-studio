"""Installation policy and archive tests; no network or scientific results mocked."""
import io,os,sys,tarfile,tempfile,threading,unittest
from pathlib import Path
from unittest.mock import patch
sys.path.insert(0,str(Path(__file__).resolve().parents[2]/'plugins/lhapdf'))
import manager

class Download(io.BytesIO):
    def __init__(self,data):super().__init__(data);self.headers={'Content-Length':str(len(data))}

def archive(name='TestSet/TestSet.info'):
    out=io.BytesIO()
    with tarfile.open(fileobj=out,mode='w:gz') as tar:
        entry=tarfile.TarInfo(name);data=b'Description: installation-policy fixture\n';entry.size=len(data);tar.addfile(entry,io.BytesIO(data))
    return out.getvalue()

class PdfManagerTests(unittest.TestCase):
    def test_requires_explicit_action(self):
        with patch.object(manager.urllib.request,'urlopen',side_effect=AssertionError('No download allowed')):
            with self.assertRaisesRegex(ValueError,'explicit'):manager.install({'set':'CT14lo'},threading.Event(),lambda _:None)
    def test_bounded_atomic_install_and_no_overwrite(self):
        with tempfile.TemporaryDirectory() as tmp,patch.dict(os.environ,{'HEP_PDF_HOME':tmp}):
            with patch.object(manager.urllib.request,'urlopen',return_value=Download(archive())):
                result=manager.install({'set':'TestSet','approved':True,'maxDownloadMiB':1},threading.Event(),lambda _:None)
            self.assertEqual(len(result['archiveSha256']),64);self.assertTrue((Path(tmp)/'TestSet/TestSet.info').is_file())
            with self.assertRaisesRegex(ValueError,'already installed'):manager.install({'set':'TestSet','approved':True},threading.Event(),lambda _:None)
    def test_rejects_archive_escape_and_cleans_staging(self):
        with tempfile.TemporaryDirectory() as tmp,patch.dict(os.environ,{'HEP_PDF_HOME':tmp}),patch.object(manager.urllib.request,'urlopen',return_value=Download(archive('TestSet/../outside'))):
            with self.assertRaisesRegex(ValueError,'Unsafe'):manager.install({'set':'TestSet','approved':True},threading.Event(),lambda _:None)
            self.assertEqual(list(Path(tmp).iterdir()),[])
    def test_cancelled_install_has_no_partial_set(self):
        stop=threading.Event();stop.set()
        with tempfile.TemporaryDirectory() as tmp,patch.dict(os.environ,{'HEP_PDF_HOME':tmp}),patch.object(manager.urllib.request,'urlopen',return_value=Download(archive())):
            with self.assertRaises(InterruptedError):manager.install({'set':'TestSet','approved':True},stop,lambda _:None)
            self.assertEqual(list(Path(tmp).iterdir()),[])

if __name__=='__main__':unittest.main()
