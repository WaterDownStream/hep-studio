#include "runtime/resource_broker/broker.hpp"
#include <QCoreApplication>
#include <QProcess>
#include <QTimer>
#include <iostream>
int main(int argc,char** argv){
    QCoreApplication app(argc,argv);hep::ResourceBroker broker;
    if(argc<3){std::cout<<hep::hardwareJson(broker.hardware()).dump()<<std::endl;return 0;}
    bool ok=false;const unsigned workers=QString::fromUtf8(argv[1]).toUInt(&ok);
    if(!ok)return 2;auto lease=broker.acquire({workers,std::uint64_t(workers)*512*1024*1024});
    if(!lease){std::cerr<<"Resource Broker refused benchmark budget"<<std::endl;return 3;}
    QProcess process;process.setProcessChannelMode(QProcess::ForwardedChannels);
    QObject::connect(&process,qOverload<int,QProcess::ExitStatus>(&QProcess::finished),&app,[&](int code,QProcess::ExitStatus){broker.release(lease->id);app.exit(code);});
    QObject::connect(&process,&QProcess::errorOccurred,&app,[&](QProcess::ProcessError error){if(error==QProcess::FailedToStart)app.exit(4);});
    QTimer::singleShot(3600000,&app,[&]{process.kill();});
    QStringList arguments;for(int i=3;i<argc;++i)arguments.push_back(QString::fromUtf8(argv[i]));
    process.start(QString::fromUtf8(argv[2]),arguments);return app.exec();
}
