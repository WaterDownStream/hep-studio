"""Recompute the frozen closure comparison from its two recorded Release matrices."""
import json,statistics
from pathlib import Path
repo=Path(__file__).resolve().parents[2];folder=repo/'docs/developer'
baseline=json.loads((folder/'part4-closure-part3-baseline-release.json').read_text());current=json.loads((folder/'part4-closure-part4-current-release.json').read_text())
assert len(baseline['measurements'])==len(current['measurements'])==16
for field in ('cpu','cpuQuota','eventCount','streamPolicy','partitionEvents','seed','brokerHardware','buildType','platform'):
    assert baseline[field]==current[field],field+' differs'
lookup={(r['case'],r['workers']):r for r in baseline['measurements']};rows=[]
for b in current['measurements']:
    a=lookup[(b['case'],b['workers'])]
    assert a['events']==b['events']==16384 and a['threadCount']==b['threadCount']==b['workers']
    for field in ('libraries','platform','architecture','compiler','cppStandard','python','adapterVersion'):
        assert a['environment'][field]==b['environment'][field],'SDK/runtime metadata differs: '+field
    streams=lambda r:[{k:p[k] for k in ('index','seed','events','firstEvent') if k in p} for p in r['partitionRuns']]
    assert streams(a)==streams(b),'Logical streams differ'
    for field in ('accepted','attempts','failed','generated','sumWeights','sumWeightsSquared'):
        assert a['metrics'][field]==b['metrics'][field],'Scientific generation accumulator differs: '+field
    assert b['metrics'].get('bulkEventsThroughIPC',0)==0
    row={'case':b['case'],'workers':b['workers'],'baselineEventsPerSecond':a['wallEventsPerSecond'],'currentEventsPerSecond':b['wallEventsPerSecond'],
         'baselineWallSeconds':a['wallSeconds'],'currentWallSeconds':b['wallSeconds'],'wallChangePercent':100*(b['wallSeconds']/a['wallSeconds']-1),
         'baselinePeakPssMiB':a['peakProcessTreePss']/1048576,'currentPeakPssMiB':b['peakProcessTreePss']/1048576 if b['peakProcessTreePss']>0 else None,
         'baselinePeakRssMiB':a['peakProcessTreeRss']/1048576,'currentPeakRssMiB':b['peakProcessTreeRss']/1048576,
         'cpuUtilizationPercent':b['cpuUtilizationPercent'],'parallelEfficiency':b['parallelEfficiency'],'startupSecondsSum':b['startupSecondsSum'],
         'mergeMilliseconds':b['mergeSeconds']*1000,'controlKiB':b['controlBytes']/1024,'sampleMiB':b['sampleBytes']/1048576}
    rows.append(row)
result={'status':'VERIFIED','sameHostAndInstalledSdk':True,'sameWorkloadAndLogicalStreams':True,'historicalIntelHostRecreated':False,'cpu':current['cpu'],
        'eventCount':16384,'workers':[1,2,4,7],'skippedWorkerCount':8,'skipReason':'Eight effective CPUs with one UI reservation',
        'measurements':rows,'medianWallChangePercent':statistics.median(r['wallChangePercent'] for r in rows),
        'minimumWallChangePercent':min(r['wallChangePercent'] for r in rows),'maximumWallChangePercent':max(r['wallChangePercent'] for r in rows),
        'maximumCurrentPeakPssMiB':max((r['currentPeakPssMiB'] for r in rows if r['currentPeakPssMiB'] is not None),default=None),'maximumCurrentPeakRssMiB':max(r['currentPeakRssMiB'] for r in rows),'maximumCurrentCpuUtilizationPercent':max(r['cpuUtilizationPercent'] for r in rows),
        'limitations':['Single trials on a shared VM; no statistical performance confidence interval','Fixed eight logical blocks limit seven-worker efficiency','Historical Intel absolute timings are not a same-hardware comparison','Part 4 PSS returned zero and is unavailable; use measured RSS, which double-counts shared pages','No Windows/WSL or macOS performance claim']}
(folder/'part4-closure-performance-comparison.json').write_text(json.dumps(result,indent=2)+'\n')
lines=['# Part 4 closure: controlled Part 3 Release replay','',f"CPU: {current['cpu']}; Release; 16,384 events per case; 1/2/4/7 workers.",'Seed 1, project seed 42, logical-blocks-v2, 2,048 events per block. Both engines use the same installed SDK/compiler/Python and CPU quota.','',
       'The preserved Part 3 source and current Part 4 source execute the unchanged original benchmark scripts and collider example. The historical Intel host was unavailable, so no cross-hardware regression claim is made.','',
       '| Case | Workers | Part 3 events/s | Part 4 events/s | Wall change | CPU % | Peak RSS MiB | Merge ms | Control KiB |',
       '| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |']
for r in rows:lines.append(f"| {r['case']} | {r['workers']} | {r['baselineEventsPerSecond']:.1f} | {r['currentEventsPerSecond']:.1f} | {r['wallChangePercent']:+.2f}% | {r['cpuUtilizationPercent']:.1f} | {r['currentPeakRssMiB']:.1f} | {r['mergeMilliseconds']:.2f} | {r['controlKiB']:.1f} |")
lines+=['',f"Median wall-time change: {result['medianWallChangePercent']:+.2f}%; individual changes range from {result['minimumWallChangePercent']:+.2f}% to {result['maximumWallChangePercent']:+.2f}%.",
        'These are single trials, not a confidence interval. Positive values mean slower Part 4 wall time. The full JSON reports retain startup/setup, CPU, memory, environment fingerprints and physical output sizes.',
        '100% CPU means one occupied CPU. RSS includes shared pages more than once; 50 ms sampling can miss short-lived peaks. Baseline PSS is retained, but the Part 4 sampler returned zero PSS, which is unavailable rather than zero physical memory. Eight workers are rejected to preserve the UI CPU. Eight fixed logical blocks explain the four/seven-worker plateau.',
        'Persisted HepMC cases write approximately 3.5 GiB as deterministic shards, without serial eager merging or bulk event IPC. This is disk output, not GUI transfer.',
        'No build or regression jobs ran alongside the measurements. Routine status queries and requested three-minute source checkpoints remained active. A launcher invoked without its SDK environment exited before admission; its separate diagnostic log contains no benchmark row.',
        'Windows/WSL storage/control overhead and macOS performance remain UNVERIFIED.']
(folder/'part4-closure-performance.md').write_text('\n'.join(lines)+'\n')
print(json.dumps({k:result[k] for k in ('medianWallChangePercent','minimumWallChangePercent','maximumWallChangePercent','maximumCurrentPeakPssMiB','maximumCurrentCpuUtilizationPercent')}))
