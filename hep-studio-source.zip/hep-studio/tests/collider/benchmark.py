"""Reproducible isolated-process collider measurements; requires real libraries.

HEP_COLLIDER_ENGINE=... python tests/collider/benchmark.py --events 2000 --output report.json
Windows/WSL measurements are never inferred from Linux measurements.
"""
import argparse,copy,datetime,json,os,platform,resource,subprocess,sys,tempfile,threading,time
from pathlib import Path
REPO=Path(__file__).resolve().parents[2]

def run_case(case,count,output,directory,workers):
    sys.path.insert(0,str(REPO/'plugins/collider'));import backend
    start=time.perf_counter();cap=backend.initialize();startup=time.perf_counter()-start
    if not cap['available']:raise RuntimeError(cap['reason'])
    w=json.loads((REPO/'examples/collider-workflow.json').read_text());source=next(n for n in w['nodes'] if n['typeId']=='hep.collider.Pythia');source['config']['events']=count;source['config']['workers']=1 if case in ('preview','hepmc-read') else workers;source['config'].update(streamPolicy='logical-blocks-v2',partitionEvents=2048)
    if case in ('generation','generation-fastjet','hepmc-write'):
        kinds={'hep.collider.Pythia'}
        if case=='generation-fastjet':kinds.add('hep.collider.ClusterJets')
        w['nodes']=[n for n in w['nodes'] if n['typeId'] in kinds];ids={n['id'] for n in w['nodes']};w['connections']=[e for e in w['connections'] if e['fromNode'] in ids and e['toNode'] in ids]
    payload={'workflow':w,'projectSeed':'42','allocatedThreads':workers};sample=Path(directory)/'benchmark.hepmc'
    if case in ('hepmc-write','full-persisted'):
        store=copy.deepcopy(source);store.update(id='store',typeId='hep.collider.StoreHepMC',config={'resourceId':'sample'})
        port=copy.deepcopy(source['ports'][0]);port.update(id='in',name='Input',direction='input');store['ports']=[port,copy.deepcopy(source['ports'][0])]
        w['nodes'].append(store);w['connections'].append({'fromNode':source['id'],'fromPort':'out','toNode':'store','toPort':'in'})
        payload['resources']={'sample':{'path':str(sample)}}
    if case=='hepmc-read':
        source.update(typeId='hep.collider.HepMCSource',config={'resourceId':'sample'});payload['resources']={'sample':{'path':str(sample)}}
    if case=='preview':payload['previewEvents']=10
    began=time.perf_counter();r=backend.dispatch({'id':'benchmark','operation':'eventPreview' if case=='preview' else 'execute','payload':payload},threading.Event(),lambda _:None);wall=time.perf_counter()-began
    rss=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss*(1 if sys.platform=='darwin' else 1024)
    row={'case':case,'events':r['metrics']['accepted'],'wallSeconds':wall,'engineLoadSeconds':startup,
         'metrics':r['metrics'],'peakRssBytes':rss,'compactResultBytes':len(json.dumps(r).encode()),
         'sampleBytes':sum(s.get('sizeBytes',0) for s in r.get('samples',[])),'environment':cap['environment'],'threadCount':r['metrics']['threads'],'partitionRuns':r.get('partitionRuns',[])}
    if case.startswith('hepmc-'):row['sampleBytes']=sample.stat().st_size;row['MiBPerSecond']=row['sampleBytes']/wall/1024**2
    Path(output).write_text(json.dumps(row,indent=2)+'\n')

def main():
    parser=argparse.ArgumentParser();parser.add_argument('--events',type=int,default=2000);parser.add_argument('--output',required=True);parser.add_argument('--case');parser.add_argument('--directory');parser.add_argument('--workers',type=int,default=1);args=parser.parse_args()
    if args.case:return run_case(args.case,args.events,args.output,args.directory,args.workers)
    if not 1<=args.events<=1000000:parser.error('Choose 1..1000000 events')
    cpu=platform.processor()
    if Path('/proc/cpuinfo').exists():
        cpu=next((line.split(':',1)[1].strip() for line in Path('/proc/cpuinfo').read_text().splitlines() if line.startswith('model name')),cpu)
    result={'measuredAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'buildConfiguration':os.environ.get('HEP_BENCHMARK_BUILD_TYPE','unspecified'),'platform':platform.platform(),'cpu':cpu,'logicalCpus':os.cpu_count(),'eventsRequested':args.events,
            'measurements':[],'windowsWslControlOverhead':{'measured':False,'reason':'Requires a native Windows/WSL host'},
            'windowsWslLargeTransfer':{'measured':False,'reason':'Requires a native Windows/WSL host'},
            'notes':[f'Requested generator workers: {args.workers}; one scientific thread per process.','Each case is a fresh process. Wall time includes generator initialization and result conversion.',
                     'Engine-loop rate excludes generator initialization; RSS includes libraries and the Python host.','No comparison across different hardware is implied.']}
    with tempfile.TemporaryDirectory() as tmp:
        for case in ('generation','generation-fastjet','full-histogram','preview','hepmc-write','hepmc-read'):
            output=Path(tmp)/(case+'.json');log=Path(args.output).with_suffix('.'+case+'.log')
            with log.open('w') as stream:subprocess.run([sys.executable,__file__,'--case',case,'--workers',str(args.workers),'--events',str(min(args.events,100) if case.startswith('hepmc') else args.events),'--output',str(output),'--directory',tmp],stdout=stream,stderr=subprocess.STDOUT,check=True,timeout=600)
            result['measurements'].append(json.loads(output.read_text()))
            Path(args.output).write_text(json.dumps(result,indent=2)+'\n')
    print(args.output)

if __name__=='__main__':main()
