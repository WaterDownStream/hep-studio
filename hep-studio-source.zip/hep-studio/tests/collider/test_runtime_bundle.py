import importlib.util,json,tarfile,tempfile,unittest,os,subprocess,sys
from pathlib import Path
from unittest.mock import patch
path=Path(__file__).resolve().parents[2]/'runtime/environment/admin.py';spec=importlib.util.spec_from_file_location('runtime_admin',path);admin=importlib.util.module_from_spec(spec);spec.loader.exec_module(admin)
@unittest.skipUnless(os.name=='posix','Bundle installation runs inside Linux/WSL, not native Windows')
class RuntimeBundleTests(unittest.TestCase):
 def test_repair_preserves_data_and_atomic_current(self):
  with tempfile.TemporaryDirectory() as tmp:
   root=Path(tmp);payload=root/'payload';payload.mkdir();(payload/'worker.py').write_text('version 1');manifest=admin.create(payload,{'id':'test-fixture'})
   bundle=root/'bundle.tar'
   with tarfile.open(bundle,'w') as tar:
    for file in payload.iterdir():tar.add(file,arcname=file.name)
   home=root/'home';home.mkdir();(home/'project.hep.json').write_text('user data')
   target=root/'hep';a=admin.install(target,bundle);old=(target/'current').resolve();(old/'worker.py').write_text('corrupt')
   with self.assertRaisesRegex(ValueError,'corrupt'):admin.verify(old)
   b=admin.install(target,bundle);self.assertEqual(a['runtimeVersion'],b['runtimeVersion']);self.assertNotEqual(old,(target/'current').resolve());self.assertTrue(old.exists());self.assertEqual((home/'project.hep.json').read_text(),'user data')
   admin.verify((target/'current').resolve())
   with tarfile.open(bundle,'w') as tar:
    info=tarfile.TarInfo('../home/project.hep.json');tar.addfile(info)
   current=(target/'current').resolve()
   with self.assertRaises(ValueError):admin.install(target,bundle)
   self.assertEqual(current,(target/'current').resolve())
 def test_incompatible_update_and_disk_refusal_preserve_active(self):
  with tempfile.TemporaryDirectory() as tmp:
   root=Path(tmp);payload=root/'payload';payload.mkdir();(payload/'worker.py').write_text('version 1');admin.create(payload,{'id':'first'})
   bundle=root/'bundle.tar'
   def pack():
    with tarfile.open(bundle,'w') as tar:
     for file in payload.iterdir():tar.add(file,arcname=file.name)
   pack();target=root/'hep';first=admin.install(target,bundle)
   (payload/'worker.py').write_text('version 2');admin.create(payload,{'id':'second'});pack()
   second=admin.install(target,bundle);self.assertNotEqual(first['runtimeVersion'],second['runtimeVersion']);active=(target/'current').resolve()
   with patch.object(admin.shutil,'disk_usage',return_value=type('Space',(),{'free':1})()):
    with self.assertRaisesRegex(ValueError,'Insufficient'):admin.install(target,bundle)
   manifest=json.loads((payload/'runtime-manifest.json').read_text());manifest['protocolVersion']=999;(payload/'runtime-manifest.json').write_text(json.dumps(manifest));pack()
   with self.assertRaisesRegex(ValueError,'Incompatible'):admin.install(target,bundle)
   self.assertEqual((target/'current').resolve(),active);self.assertEqual(admin.verify(active)['environment']['id'],'second')
 def test_image_layout_uses_current_release(self):
  with tempfile.TemporaryDirectory() as tmp:
   root=Path(tmp)/'hep';root.mkdir();(root/'worker').mkdir();(root/'worker/backend.py').write_text('payload');(root/'admin.py').write_text(path.read_text());(root/'environment-build.json').write_text(json.dumps({'environment':{'id':'fixture'}}))
   subprocess.run([sys.executable,str(path.with_name('initialize_layout.py')),str(root)],check=True,capture_output=True)
   release=(root/'current').resolve();self.assertTrue((root/'worker').is_symlink());self.assertEqual((root/'worker/backend.py').read_text(),'payload');self.assertTrue((root/'admin.py').is_file());self.assertFalse((root/'admin.py').is_symlink());self.assertEqual(admin.verify(release)['environment']['id'],'fixture')
if __name__=='__main__':unittest.main()
