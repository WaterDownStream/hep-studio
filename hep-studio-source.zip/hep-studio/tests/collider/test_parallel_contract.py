"""Deterministic transport/transaction faults, independent of scientific libraries."""
import copy,io,json,queue,struct,sys,tempfile,threading,unittest
from pathlib import Path
from unittest.mock import patch
sys.path.insert(0,str(Path(__file__).resolve().parents[2]/'plugins/collider'))
import parallel,samples
class ParallelContract(unittest.TestCase):
 def test_logical_streams_and_legacy(self):
  config={'streamPolicy':'logical-blocks-v2','partitionEvents':7}
  expected=parallel.logical_partitions(900000000,20,config)
  self.assertEqual([x['seed'] for x in expected],[900000000,1,2]);self.assertEqual([x['firstEvent'] for x in expected],[0,7,14])
  for workers in (1,2,4,8):self.assertEqual(expected,parallel.logical_partitions(900000000,20,dict(config,workers=workers)))
  legacy={'streamPolicy':'legacy-streams-v1','logicalStreams':2}
  for workers in (1,4):self.assertEqual(parallel.partitions(42,20,2),parallel.logical_partitions(42,20,dict(legacy,workers=workers)))
 def test_malformed_incomplete_and_version_frames(self):
  packets=[b'\x00\x00',struct.pack('!I',parallel.MAX_FRAME+1),struct.pack('!I',5)+b'xx',struct.pack('!I',2)+b'[]']
  value=json.dumps({'protocolVersion':2,'kind':'hello'}).encode();packets.append(struct.pack('!I',len(value))+value)
  for packet in packets:
   messages=queue.Queue();parallel._reader(io.BytesIO(packet),messages);self.assertIsInstance(messages.get_nowait(),Exception)
 def test_weighted_aggregation(self):
  hist={'kind':'Histogram1D','dimension':[1,0,0,0],'edges':[0,1,2],'values':[2,-1],'errors':[2,1],'entries':4,'underflow':3,'overflow':-2,'underflowError':3,'overflowError':2,'statistics':[1,5,-.5,-1.75]}
  result={'results':{'h':hist},'executionPlan':{'nodes':[]},'metrics':{'generated':4,'accepted':4,'attempts':4,'failed':0,'sumWeights':2,'sumWeightsSquared':18,'eventLoopSeconds':1},'generator':{},'diagnostics':''}
  other=copy.deepcopy(result);other['results']['h'].update(values=[.5,4],errors=[.5,4],statistics=[4.5,16.25,6.25,9.125])
  parts=parallel.partitions(1,8,2);r=parallel.merge([result,other],{},parts,2)
  h=r['results']['h'];self.assertEqual(h['values'],[2.5,3]);self.assertAlmostEqual(h['errors'][0]**2,4.25);self.assertAlmostEqual(h['errors'][1]**2,17)
  self.assertEqual(h['entries'],8);self.assertEqual(h['underflow'],6);self.assertEqual(h['overflow'],-4);self.assertAlmostEqual(h['underflowError']**2,18)
  self.assertEqual(h['statistics'],[5.5,21.25,5.75,7.375]);self.assertEqual(r['metrics']['sumWeightsSquared'],36)
  cancelled=threading.Event();cancelled.set()
  with self.assertRaises(InterruptedError):parallel.merge([result,other],{},parts,2,cancelled)
 def test_sample_cancel_disk_and_incomplete_restart(self):
  with tempfile.TemporaryDirectory() as tmp:
   path=Path(tmp)/'sample.json';payload={'workflow':{'nodes':[{'typeId':'hep.collider.StoreHepMC','config':{'resourceId':'s'}}]},'resources':{'s':{'path':str(path)}}};parts=parallel.partitions(1,1,1);cancel=threading.Event()
   with patch.object(samples.shutil,'disk_usage',return_value=type('Space',(),{'free':1})()):
    with self.assertRaisesRegex(ValueError,'Insufficient'):samples.Transaction(payload,parts,cancel)
   tx=samples.Transaction(payload,parts,cancel);child=tx.child_payload(payload,parts[0]);shard=Path(child['resources']['s']['path']);shard.write_text('HepMC::Asciiv3-END_EVENT_LISTING\n')
   cancel.set()
   try:
    with self.assertRaises(InterruptedError):tx.commit(parts,[{'samples':[{'resourceId':'s','path':str(shard),'eventCount':1}]}],{})
   finally:tx.close()
   self.assertFalse(path.exists());self.assertEqual(list(Path(tmp).iterdir()),[])
   # Simulate an ungraceful death: abandoned staging cannot be opened as a committed sample.
   cancel.clear();abandoned=samples.Transaction(payload,parts,cancel)
   with self.assertRaises(FileNotFoundError):samples.load(path,cancel)
   restarted=samples.Transaction(payload,parts,cancel);restarted.close();abandoned.close()
if __name__=='__main__':unittest.main()
