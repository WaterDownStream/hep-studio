#!/usr/bin/env python3
"""Explicit maintainer build/export. Does not install or alter any WSL distro."""
import argparse,hashlib,json,subprocess
from pathlib import Path
parser=argparse.ArgumentParser();parser.add_argument('--output',type=Path,required=True);parser.add_argument('--jobs',type=int,default=2);args=parser.parse_args()
repo=Path(__file__).resolve().parents[2];tag='hep-studio-runtime:local'
subprocess.run(['docker','build','-f',str(repo/'packaging/wsl/Dockerfile'),'--build-arg','BUILD_JOBS='+str(args.jobs),'-t',tag,str(repo)],check=True)
container=subprocess.check_output(['docker','create',tag],text=True).strip()
try:
    subprocess.run(['docker','export','-o',str(args.output),container],check=True)
finally:subprocess.run(['docker','rm',container],check=True)
digest=hashlib.sha256()
with args.output.open('rb') as stream:
    while block:=stream.read(1024*1024):digest.update(block)
args.output.with_suffix(args.output.suffix+'.json').write_text(json.dumps({'format':'HEPStudioRuntime-rootfs-v1','sha256':digest.hexdigest(),'sizeBytes':args.output.stat().st_size,'platformVerification':'not verified by export'},indent=2)+'\n')
