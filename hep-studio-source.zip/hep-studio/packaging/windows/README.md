# windows packaging

No distributable installer is implemented in Phase 0. Build the native developer
targets using the root README. See STATUS.md for tested platform coverage and
THIRD_PARTY_NOTICES.md before preparing binary releases.
