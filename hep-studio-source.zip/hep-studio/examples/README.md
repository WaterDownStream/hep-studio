# Example projects

Open a `.hep.json` file from the desktop Project menu. Research examples were
serialized by the C++ core and executed on the recorded Linux SDK. Select that
SDK in **Research → Runtime** to rerun; historical compact results can be viewed
without regenerating or locating the original worker-side event files.

| Example | Workflow | Recorded evidence |
| --- | --- | --- |
| `research-dilepton.hep.json` | 1,000 photon-only e⁺e⁻ → μ⁺μ⁻ events at 100 GeV → shower → CMS reference card → opposite-sign reconstructed muons → mass histogram → Gaussian RooFit | Fit parameters, covariance, pulls and immutable Run |
| `research-template-study.hep.json` | Separate τ-pair signal and prompt dimuon background → reconstruction → luminosity-scaled templates → explicit shared luminosity nuisance and MC statistics → HistFactory CLs | Source Runs, template references and inference Run |
| `research-scan.hep.json` | Three muon-pT thresholds (0, 20, 40 GeV) over the same reconstructed sample | Completed point Runs, upstream cache reuse and scan yields |

These are small software/reference studies, not experimental measurements. The
tau signal has few selected events; finite MC errors and asymptotic-coverage
limitations are retained in the result. Signal and background use different
hard processes and distinct generator/shower/detector seeds. The template model
explicitly assumes independent effective MC counts and ±2% standard-normal
luminosity variation; HEP Studio does not infer those assumptions from a histogram.

In the template project, switch between the two source workflows and the
statistical workflow. In the scan project, **Campaigns → Run example scan**
executes the recorded axis configuration through the ordinary scan engine.
**Plot recorded scan** displays the saved point Runs. The nominal workflow is
not changed by a scan. Use **Runs / provenance** and **Diagnostics** to inspect
results, export Run evidence, and view equivalent configuration. Worker-side
cards require the corresponding cache; compact Run evidence remains in the project.

`docs/developer/part4-examples-validation.json` records executed values and the
frozen environment. To recreate the examples as a developer, build
`hep-research-examples`, configure the scientific SDK, and run:

```sh
build/bin/hep-benchmark-budget 2 python3 tests/research/validate_examples.py \
  --build build --directory /path/to/example-validation
```

This explicit integration command is separate from ordinary dependency-free CI.
`mock-particles.hep.json` and `mock-jets.hep.json` remain Phase 0 mock-contract
examples; they contain no scientific historical results. The collider example
is described in `docs/user/collider-studio.md`.
