#!/usr/bin/env python3
"""Measure worker-local vs mounted HepMC analysis; never a platform certificate."""
import argparse,copy,hashlib,json,os,platform,shutil,sys,tempfile,threading,time,uuid
from pathlib import Path

def elapsed(action):
    start=time.perf_counter();value=action();return value,time.perf_counter()-start

def checksum(path):
    digest=hashlib.sha256()
    with Path(path).open('rb') as stream:
        while block:=stream.read(1024*1024):digest.update(block)
    return digest.hexdigest()

def filesystem(path):
    mounts=Path('/proc/self/mountinfo')
    if not mounts.exists():return {'type':None,'mountPoint':None}
    candidates=[]
    for line in mounts.read_text().splitlines():
        fields=line.split();separator=fields.index('-');mount=Path(fields[4].replace('\\040',' ').replace('\\134','\\'))
        if path.is_relative_to(mount):candidates.append((len(str(mount)),{'type':fields[separator+1],'mountPoint':str(mount),'source':fields[separator+2]}))
    return max(candidates,key=lambda row:row[0])[1] if candidates else {'type':None,'mountPoint':None}

def source_workflow(workflow,events):
    result=copy.deepcopy(workflow)
    source=next(n for n in result['nodes'] if n['typeId']=='hep.collider.Pythia')
    source['config'].update(events=events,workers=1,streamPolicy='logical-blocks-v2',partitionEvents=min(events,2048))
    return result,source

def run(args):
    if not 1<=args.events<=100000:raise ValueError('Choose 1..100000 events')
    if not 1<=args.transfer_mib<=4096:raise ValueError('Choose 1..4096 MiB transfer size')
    native=args.native_root.resolve();mounted=args.mounted_root.resolve()
    if native==mounted:raise ValueError('Native and mounted benchmark locations must differ')
    if not native.is_dir() or not mounted.is_dir():raise ValueError('Create/select existing benchmark roots')
    is_wsl='microsoft' in platform.release().lower()
    if args.require_wsl and (not is_wsl or not str(mounted).startswith('/mnt/') or str(native).startswith('/mnt/')):
        raise ValueError('WSL acceptance requires an actual WSL kernel, native Linux storage and a Windows-backed /mnt/<drive> path')
    sys.path.insert(0,str(args.worker_directory.resolve()))
    import backend
    cap=backend.initialize()
    if not cap.get('available'):raise RuntimeError(cap.get('reason','Collider runtime unavailable'))
    cancellation=threading.Event();request_id=0
    def execute(payload):
        nonlocal request_id
        request_id+=1
        return backend.dispatch({'id':'locality-'+str(request_id),'operation':'execute','payload':payload},cancellation,lambda _:None)
    workflow,source=source_workflow(json.loads(args.workflow.read_text()),args.events)
    receipt={'format':'hep-studio-locality-acceptance','version':1,'status':'UNVERIFIED',
             'platform':platform.platform(),'kernel':platform.release(),'wslKernel':is_wsl,'comparisonKind':'WSL-storage' if args.require_wsl else 'local-control',
             'timestamp':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),'environment':cap['environment'],
             'events':args.events,'locations':{'native':{'path':str(native),'filesystem':filesystem(native)},'mounted':{'path':str(mounted),'filesystem':filesystem(mounted)}},'measurements':[],
             'notes':['Single trials include manifest/shard identity verification; report event-loop time separately.',
                      'Cache state is uncontrolled; this is not a cold-disk or dedicated-host benchmark.',
                      'Analysis reads files in place. Histogram/summary results are compact; particle streams do not enter IPC.']}
    with tempfile.TemporaryDirectory(prefix='hep-acceptance-',dir=native) as local_dir,tempfile.TemporaryDirectory(prefix='hep-acceptance-',dir=mounted) as mounted_dir:
        local=Path(local_dir);other=Path(mounted_dir);sample=local/'sample.hepsample.json'
        stored=copy.deepcopy(workflow);store=copy.deepcopy(source);store.update(id='acceptance-store',typeId='hep.collider.StoreHepMC',config={'resourceId':'sample'})
        port=copy.deepcopy(source['ports'][0]);port.update(id='in',name='Input',direction='input');store['ports']=[port,copy.deepcopy(source['ports'][0])]
        stored['nodes'].append(store);stored['connections'].append({'fromNode':source['id'],'fromPort':'out','toNode':store['id'],'toPort':'in'})
        generated,seconds=elapsed(lambda:execute({'workflow':stored,'resources':{'sample':{'path':str(sample)}},'allocatedThreads':1}))
        materialized=generated['samples'][0];receipt['generation']={'wallSeconds':seconds,'sizeBytes':materialized['sizeBytes'],'metrics':generated['metrics']}
        assert generated['metrics']['accepted']==args.events
        manifest=json.loads(sample.read_text());copied=other/sample.name
        def copy_sample():
            shutil.copy2(sample,copied)
            folders={Path(s['location']).parts[0] for s in manifest['shards']}
            for folder in folders:shutil.copytree(local/folder,other/folder)
        _,copy_seconds=elapsed(copy_sample)
        receipt['sampleCopyToMounted']={'bytes':materialized['sizeBytes'],'wallSeconds':copy_seconds,'MiBPerSecond':materialized['sizeBytes']/copy_seconds/1024**2}
        analysis=copy.deepcopy(workflow);input_node=next(n for n in analysis['nodes'] if n['id']==source['id']);input_node.update(typeId='hep.collider.HepMCSource',config={'resourceId':'sample'})
        reference=None
        for location,path in [('WSL-native' if args.require_wsl else 'native-local-control',sample),('Windows-mounted' if args.require_wsl else 'alternate-local-control',copied)]:
            result,seconds=elapsed(lambda:execute({'workflow':analysis,'resources':{'sample':{'path':str(path),'eventCount':args.events}},'allocatedThreads':1}))
            if reference is None:reference=result['results']
            elif reference!=result['results']:raise RuntimeError('Locality changed scientific histogram results')
            receipt['measurements'].append({'operation':'HepMC → FastJet → selection → histogram','location':location,'wallSeconds':seconds,
                'eventLoopSeconds':result['metrics']['eventLoopSeconds'],'eventsPerSecond':args.events/seconds,
                'compactResultBytes':len(json.dumps(result).encode()),'bulkEventsThroughIPC':result['metrics']['bulkEventsThroughIPC'],
                'peakRssBytes':None,'memoryNote':'Use the host process monitor for process-tree peak memory; not fabricated here'})
    # The Windows wrapper reads this file via the WSL filesystem share using a
    # native FileStream. This explicit transfer is separate from normal worker IPC.
    transfer=native/('acceptance-transfer-'+uuid.uuid4().hex+'.bin')
    try:
        block=os.urandom(1024*1024)
        with transfer.open('xb') as stream:
            for _ in range(args.transfer_mib):stream.write(block)
            stream.flush();os.fsync(stream.fileno())
        receipt['nativeWindowsTransferFixture']={'path':str(transfer),'sizeBytes':transfer.stat().st_size,'sha256':checksum(transfer),
            'retained':args.keep_transfer,'note':'Windows native copy measurement must be supplied by the host wrapper; not measured in Linux'}
    finally:
        if not args.keep_transfer:transfer.unlink(missing_ok=True)
    receipt['automatedStatus']='PASS'
    return receipt

def main():
    p=argparse.ArgumentParser();p.add_argument('--worker-directory',type=Path,default=Path('/opt/hep/worker'));p.add_argument('--workflow',type=Path,required=True)
    p.add_argument('--native-root',type=Path,required=True);p.add_argument('--mounted-root',type=Path,required=True);p.add_argument('--events',type=int,default=1000)
    p.add_argument('--transfer-mib',type=int,default=256);p.add_argument('--keep-transfer',action='store_true');p.add_argument('--output',type=Path)
    p.add_argument('--require-wsl',action='store_true')
    args=p.parse_args();wire=os.dup(1);os.dup2(2,1)
    try:result=run(args);code=0
    except Exception as error:result={'status':'UNVERIFIED','automatedStatus':'FAIL','error':str(error)};code=1
    text=json.dumps(result,indent=2,allow_nan=False)+'\n'
    if args.output:args.output.write_text(text)
    with os.fdopen(wire,'w') as stream:stream.write(text)
    return code
if __name__=='__main__':sys.exit(main())
