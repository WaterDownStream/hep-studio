#include "core/collider/collider.hpp"
#include "core/editing/editing.hpp"
#include "core/graph/graph.hpp"
#include "core/project/project.hpp"
#include "runtime/environment/managed_runtime.hpp"
#include "runtime/resource_broker/broker.hpp"
#include "runtime/project_store.hpp"
#include "runtime/root/service.hpp"
#include <QCoreApplication>
#include <QDateTime>
#include <QElapsedTimer>
#include <QEventLoop>
#include <QFile>
#include <QFileInfo>
#include <QProcess>
#include <QSaveFile>
#include <QStandardPaths>
#include <QSysInfo>
#include <QTimer>
#include <algorithm>
#include <cmath>
#include <exception>
#include <functional>
#include <iostream>
#include <stdexcept>

namespace {
using hep::Json;
bool await(const std::function<bool()>& predicate,int timeout){
    if(predicate())return true;
    QEventLoop loop;QTimer poll,deadline;deadline.setSingleShot(true);std::exception_ptr failure;
    QObject::connect(&poll,&QTimer::timeout,&loop,[&]{try{if(predicate())loop.quit();}catch(...){failure=std::current_exception();loop.quit();}});
    QObject::connect(&deadline,&QTimer::timeout,&loop,&QEventLoop::quit);
    poll.start(10);deadline.start(timeout);loop.exec();if(failure)std::rethrow_exception(failure);return predicate();
}
void require(bool value,const std::string& reason){if(!value)throw std::runtime_error(reason);}
void histogramEquivalent(const Json& actual,const Json& expected){
    require(actual.size()==expected.size(),"Result count changed after HepMC reuse");
    for(const auto& [id,result]:expected.items()){
        const auto& reused=actual.at(id);
        for(const auto* key:{"kind","edges","values","entries","underflow","overflow","dimension","normalization","flowPolicy"})
            require(reused.at(key)==result.at(key),std::string("HepMC histogram changed: ")+key);
        auto close=[](double a,double b){return std::abs(a-b)<=1e-12*std::max({1.,std::abs(a),std::abs(b)});};
        const auto& errors=reused.at("errors");const auto& expectedErrors=result.at("errors");require(errors.size()==expectedErrors.size(),"Uncertainty shape changed");
        for(std::size_t i=0;i<errors.size();++i)require(close(errors[i],expectedErrors[i]),"HepMC uncertainty changed");
        for(const auto* key:{"underflowError","overflowError"})require(close(reused.at(key),result.at(key)),std::string("HepMC uncertainty changed: ")+key);
        for(const auto* key:{"mean","rms"})require(close(reused.at(key),result.at(key)),std::string("HepMC statistic changed: ")+key);
        const auto& a=reused.at("statistics");const auto& b=result.at("statistics");require(a.size()==b.size(),"Statistics shape changed");
        for(std::size_t i=0;i<a.size();++i)require(close(a[i],b[i]),"HepMC weighted statistic changed");
    }
}
}
int main(int argc,char** argv){
    QCoreApplication app(argc,argv);app.setOrganizationName("HEPStudio");app.setApplicationName("HostAcceptance");
    const auto arguments=app.arguments();
    if(arguments.size()>1&&arguments[1]=="--echo-arguments"){Json echoed=Json::array();for(int i=2;i<arguments.size();++i)echoed.push_back(arguments[i].toStdString());std::cout<<echoed.dump()<<std::endl;return 0;}
    auto option=[&](const QString& name,const QString& fallback=QString{}){const auto i=arguments.indexOf(name);return i>=0&&i+1<arguments.size()?arguments[i+1]:fallback;};
    const auto output=option("--output","host-acceptance.json");
    Json receipt={{"format","hep-studio-host-acceptance"},{"version",1},{"status","UNVERIFIED"},
        {"timestamp",QDateTime::currentDateTimeUtc().toString(Qt::ISODateWithMs).toStdString()},
        {"os",QSysInfo::prettyProductName().toStdString()},{"architecture",QSysInfo::currentCpuArchitecture().toStdString()},
        {"tests",Json::array()},{"interactiveUiAcceptance",{{"status","UNVERIFIED"}}}};
    hep::ResourceBroker broker;receipt["hardware"]=hep::hardwareJson(broker.hardware());
    hep::RootService worker;hep::ManagedRuntime runtime;
    auto save=[&]{QSaveFile file(output);const auto text=receipt.dump(2)+"\n";if(!file.open(QIODevice::WriteOnly)||file.write(text.data(),static_cast<qint64>(text.size()))!=static_cast<qint64>(text.size())||!file.commit())throw std::runtime_error("Cannot save acceptance receipt");};
    bool passed=true;
    auto test=[&](const std::string& name,const std::function<Json()>& body){
        QElapsedTimer timer;timer.start();Json row={{"name",name}};
        try{row["details"]=body();row["status"]="PASS";}
        catch(const std::exception& error){row["status"]="FAIL";row["error"]=error.what();passed=false;}
        row["wallMilliseconds"]=timer.elapsed();receipt["tests"].push_back(row);save();
    };
    try{
#ifdef Q_OS_WIN
        runtime.detect();require(await([&]{const auto state=runtime.status().value("state","");return state=="Healthy"||state=="Needs installation"||state=="Unavailable"||state=="Incompatible";},150000),"WSL detection timed out");
        receipt["managedRuntime"]=runtime.status();require(runtime.ready(),"Managed WSL2 runtime is not healthy; use the native runtime setup UI first");
        worker.configureCommand(runtime.executable(),runtime.workerArguments(),"hep.collider/1");
#else
        auto python=option("--python",QStandardPaths::findExecutable("python3"));
        worker.configure(python,QCoreApplication::applicationDirPath()+"/collider_worker/worker.py","hep.collider/1");
#endif
        worker.start();require(await([&]{return worker.state()=="Healthy"||worker.state()=="Unavailable"||worker.state()=="Crashed";},35000),"Worker startup timed out");
        require(worker.state()=="Healthy"&&worker.capability().value("available",false),worker.error().toStdString());
        receipt["capability"]=worker.capability();
        QFile workflowFile(option("--workflow"));require(workflowFile.open(QIODevice::ReadOnly),"Choose the repository collider-workflow.json fixture with --workflow");
        const auto bytes=workflowFile.readAll();auto workflow=hep::workflowFromJson(Json::parse(bytes.constData(),bytes.constData()+bytes.size()));
        hep::Node* generator=nullptr;for(auto& node:workflow.nodes)if(node.typeId=="hep.collider.Pythia")generator=&node;
        require(generator!=nullptr,"Fixture has no PYTHIA generator");generator->extensions["config"].update({{"events",100},{"partitionEvents",25},{"streamPolicy","logical-blocks-v2"},{"workers",1}});
        auto operation=[&](const std::string& name,const Json& payload,const std::string& fault=std::string{}){
            const unsigned threads=payload.value("allocatedThreads",1U);auto lease=broker.acquire({threads,std::uint64_t(threads)*512*1024*1024});require(lease.has_value(),"Resource Broker refused acceptance budget");
            try{
                require(worker.request(name,payload),worker.error().toStdString());QElapsedTimer timer;timer.start();bool injected=false;QProcess killer;
                const bool finished=await([&]{
                    if(!injected&&worker.busy()&&fault=="kill-child"){
                        const auto pids=worker.metrics().value("workerPids",Json::array());
                        if(!pids.empty()){
                            const auto pid=pids[0].get<int>();require(pid>1,"Invalid child PID for fault injection");
#ifdef Q_OS_WIN
                            killer.start(runtime.executable(),{"--distribution","HEPStudioRuntime","--exec","/usr/bin/kill","-KILL",QString::number(pid)});
#else
                            killer.start("/usr/bin/kill",{"-KILL",QString::number(pid)});
#endif
                            injected=true;
                        }
                    }else if(!injected&&!fault.empty()&&worker.busy()&&(worker.metrics().value("accepted",0)>0||timer.elapsed()>1500)){injected=true;if(fault=="cancel")worker.cancel();else worker.crash();}
                    return !worker.busy();
                },120000);
                if(killer.state()!=QProcess::NotRunning)await([&]{return killer.state()==QProcess::NotRunning;},3000);
                broker.release(lease->id);require(finished,"Operation timed out");
                if(!fault.empty()){require(injected,"Fault injection did not happen");require(worker.result().empty()&&!worker.error().isEmpty(),"Interrupted operation returned valid results");}
                else require(worker.error().isEmpty(),worker.error().toStdString());
                return Json{{"result",worker.result()},{"transport",worker.transportMetrics()},{"wallMilliseconds",timer.elapsed()},{"state",worker.state().toStdString()}};
            }catch(...){broker.release(lease->id);if(worker.busy())worker.crash();throw;}
        };
        test("capability-discovery",[&]{for(const auto* name:{"ROOT","PYTHIA","HepMC3","FastJet","LHAPDF"})require(worker.capability().at("libraries").at(name).value("available",false),std::string(name)+" unavailable");return worker.capability().at("environment");});
        test("preview-not-run",[&]{auto result=operation("eventPreview",{{"workflow",hep::workflowJson(workflow)},{"previewEvents",2},{"allocatedThreads",1}});require(result.at("result").at("metrics").at("accepted")==2,"Preview event count mismatch");return result;});
        Json reference,lastFull;const auto identity=hep::scientificJson(workflow).dump();
        const unsigned maximum=std::max(1U,broker.hardware().logicalCpus-1);
        for(const unsigned threads:{1U,2U,4U}){
            if(threads>maximum){receipt["tests"].push_back({{"name","worker-count-"+std::to_string(threads)},{"status","SKIP"},{"reason","Above UI-reserved host budget"}});continue;}
            test("worker-count-"+std::to_string(threads),[&]{generator->extensions["config"]["workers"]=threads;require(hep::scientificJson(workflow).dump()==identity,"Worker count altered scientific identity");auto result=operation("execute",{{"workflow",hep::workflowJson(workflow)},{"allocatedThreads",threads}});require(result.at("result").at("metrics").at("accepted")==100,"Full event count mismatch");const auto values=result.at("result").at("results");if(reference.is_null())reference=values;else require(values==reference,"Worker-count invariance failed");require(result.at("transport").at("controlReceivedBytes").get<std::uint64_t>()<2*1024*1024,"Unexpectedly large control result");lastFull=result.at("result");return result;});
        }
        test("project-save-reload-and-export",[&]{require(!lastFull.is_null(),"No completed full Run");
            hep::Run run{hep::newId(),"Completed",hep::workflowJson(workflow),hep::workflowHash(hep::scientificJson(workflow)).toStdString()};run.result=lastFull;run.environment=worker.capability().at("environment").at("id");run.extensions["frozenEnvironment"]=worker.capability().at("environment");
            hep::Project project{hep::newId(),"Host acceptance",{workflow},{run}};
            const auto base=QFileInfo(output).absolutePath();const auto path=base+"/acceptance-project.hep.json";hep::saveProject(project,path);const auto reloaded=hep::loadProject(path);require(hep::serialize(project)==hep::serialize(reloaded),"Saved project changed");
            const auto code=lastFull.at("generatedCode").get<std::string>();require(code.find("int main(")!=std::string::npos,"Standalone C++ unavailable");QSaveFile file(base+"/acceptance-reference.cpp");require(file.open(QIODevice::WriteOnly),"Cannot export reference C++");require(file.write(code.data(),static_cast<qint64>(code.size()))==static_cast<qint64>(code.size())&&file.commit(),"C++ export failed");return Json{{"project",path.toStdString()},{"cpp",(base+"/acceptance-reference.cpp").toStdString()},{"resultAssociatedWithRun",true}};});
        test("parallel-hepmc-materialization-reuse-export",[&]{
            auto stored=workflow;const auto id=hep::newId().value;const auto destination=operation("prepareSample",{{"resourceId",id}}).at("result").at("sampleDestination");
            auto store=hep::colliderNode("StoreHepMC",hep::Id("acceptance-store"));store.extensions["config"]["resourceId"]=id;stored.nodes.push_back(store);stored.connections.push_back({generator->id,hep::Id("out"),store.id,hep::Id("in")});
            const unsigned threads=std::min(2U,maximum);for(auto& node:stored.nodes)if(node.typeId=="hep.collider.Pythia")node.extensions["config"]["workers"]=threads;
            const Json resources={{id,{{"path",destination.at("path")}}}};auto result=operation("execute",{{"workflow",hep::workflowJson(stored)},{"resources",resources},{"allocatedThreads",threads}});
            require(result.at("result").at("samples").size()==1,"Sample was not published");
            auto source=hep::colliderNode("HepMCSource",generator->id);source.extensions["config"]["resourceId"]=id;auto reused=workflow;for(auto& node:reused.nodes)if(node.id==generator->id)node=source;
            const auto analysis=operation("execute",{{"workflow",hep::workflowJson(reused)},{"resources",resources},{"allocatedThreads",1}});histogramEquivalent(analysis.at("result").at("results"),reference);
            const auto exportPath=destination.at("path").get<std::string>()+".single.hepmc";const auto exported=operation("exportSample",{{"path",destination.at("path")},{"destination",exportPath}});
            return Json{{"sample",result.at("result").at("samples")[0]},{"transport",result.at("transport")},{"export",exported},{"comparisonTolerance","Bins/counts exact; uncertainties and moments absolute/relative 1e-12 for square-root rounding, HepMC ASCII decimal roundtrip and sequential shard summation"},{"note","Acceptance artifacts remain in the worker runtime; no bulk copy to UI"}};
        });
        generator->extensions["config"]["workers"]=1;generator->extensions["config"]["events"]=1000000;generator->extensions["config"]["partitionEvents"]=1000000;
        test("cancellation",[&]{return operation("execute",{{"workflow",hep::workflowJson(workflow)},{"allocatedThreads",1}},"cancel");});
        if(worker.state()!="Healthy"){worker.restart();require(await([&]{return worker.state()=="Healthy";},35000),"Restart after cancellation failed");}
        test("worker-crash",[&]{return operation("execute",{{"workflow",hep::workflowJson(workflow)},{"allocatedThreads",1}},"crash");});
        test("worker-restart",[&]{worker.restart();require(await([&]{return worker.state()=="Healthy";},35000),"Restart after crash failed");require(worker.capability().at("environment")==receipt.at("capability").at("environment"),"Environment changed across restart");return worker.capability().at("environment");});
        if(maximum>=2){
            generator->extensions["config"]["workers"]=2;generator->extensions["config"]["partitionEvents"]=4096;
            test("parallel-child-crash",[&]{return operation("execute",{{"workflow",hep::workflowJson(workflow)},{"allocatedThreads",2}},"kill-child");});
            test("recovery-after-child-crash",[&]{worker.restart();require(await([&]{return worker.state()=="Healthy";},35000),"Restart after child crash failed");generator->extensions["config"].update({{"events",100},{"workers",1},{"partitionEvents",25}});auto result=operation("execute",{{"workflow",hep::workflowJson(workflow)},{"allocatedThreads",1}});require(result.at("result").at("results")==reference,"Recovery changed histogram");return result;});
        }
        test("control-roundtrip",[&]{Json times=Json::array();for(int i=0;i<10;++i){const auto result=operation("settings",{{"search","Random:seed"},{"changedOnly",false}});times.push_back(result.at("wallMilliseconds"));}return Json{{"operation","settings metadata"},{"milliseconds",times},{"note","Includes adapter work and 10 ms poll granularity; not bare pipe latency"}};});
        test("pdf-discovery",[&]{return operation("pdfSets",Json::object());});
        test("pdf-evaluation-offline",[&]{const auto sets=operation("pdfSets",Json::object()).at("result").at("sets");require(!sets.empty(),"Install/select a PDF set explicitly in HEP Studio before offline PDF acceptance");const auto name=option("--pdf-set",QString::fromStdString(sets[0].at("name")));return operation("pdfEvaluate",{{"set",name.toStdString()},{"member",0},{"flavour",21},{"Q",91.1876},{"xMin",0.001},{"xMax",0.8},{"points",20}});});
        receipt["automatedStatus"]=passed?"PASS":"FAIL";
        receipt["status"]="UNVERIFIED";receipt["note"]="Automated worker tests alone do not certify interactive desktop/repair/filesystem acceptance. Run the host wrapper and checklist.";
        save();worker.shutdown();return passed?0:1;
    }catch(const std::exception& error){receipt["error"]=error.what();receipt["automatedStatus"]="FAIL";try{save();}catch(...){std::cerr<<"Receipt write failed\n";}std::cerr<<error.what()<<'\n';return 1;}
}
