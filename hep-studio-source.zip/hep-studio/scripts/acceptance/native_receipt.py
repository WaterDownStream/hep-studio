#!/usr/bin/env python3
"""Run native host acceptance, retain exact platform evidence, never infer UI acceptance."""
import argparse,datetime,json,os,platform,subprocess,sys
from pathlib import Path

def command(arguments,timeout=240):
    try:
        process=subprocess.run(arguments,capture_output=True,text=True,timeout=timeout)
        return {'arguments':arguments,'exitCode':process.returncode,'stdout':process.stdout[-131072:],'stderr':process.stderr[-65536:]}
    except (OSError,subprocess.TimeoutExpired) as error:return {'arguments':arguments,'exitCode':None,'error':str(error)}

def main():
    p=argparse.ArgumentParser();p.add_argument('--bin-directory',type=Path,required=True);p.add_argument('--repository',type=Path,required=True)
    p.add_argument('--output-directory',type=Path,required=True);p.add_argument('--required-platform',choices=['Darwin','Linux'],required=True)
    a=p.parse_args();a.output_directory.mkdir(parents=True,exist_ok=True)
    receipt={'format':'hep-studio-native-acceptance','version':1,'status':'UNVERIFIED','timestamp':datetime.datetime.now(datetime.timezone.utc).isoformat(),
             'os':platform.platform(),'machine':platform.machine(),'logicalCpus':os.cpu_count(),'tests':[],'interactiveUiAcceptance':'UNVERIFIED'}
    if platform.system()!=a.required_platform:
        receipt['error']='Wrong host platform: required '+a.required_platform
    else:
        if platform.system()=='Darwin':
            receipt['osBuild']=command(['sw_vers']);receipt['cpu']=command(['sysctl','-n','machdep.cpu.brand_string'])
            receipt['ram']=command(['sysctl','-n','hw.memsize']);receipt['gpu']=command(['system_profiler','SPDisplaysDataType','-json'],60)
        else:
            receipt['cpu']=command(['lscpu']);receipt['ram']=command(['free','-b'])
        env=os.environ.copy();env['HEP_REQUIRE_COLLIDER']='1'
        worker=a.output_directory/'worker-acceptance.json'
        worker.unlink(missing_ok=True)
        result=command([str(a.bin_directory/'hep-host-acceptance'),'--workflow',str(a.repository/'examples/collider-workflow.json'),'--output',str(worker)])
        if worker.exists():
            try:
                receipt['worker']=json.loads(worker.read_text())
                if not isinstance(receipt['worker'],dict) or receipt['worker'].get('automatedStatus')!='PASS':result.update(exitCode=1,error='Worker acceptance receipt is not a pass')
            except (OSError,ValueError) as error:result.update(exitCode=1,error='Invalid worker acceptance receipt: '+str(error))
        else:result.update(exitCode=1,error='Missing worker acceptance receipt')
        receipt['tests'].append({'name':'native-coordinator-worker',**result})
        try:
            ui=subprocess.run([str(a.bin_directory/'hep-studio-tests'),'-o',str(a.output_directory/'desktop-tests.txt')+',txt'],env=env,timeout=420)
            receipt['tests'].append({'name':'native-desktop-integration','exitCode':ui.returncode})
        except (OSError,subprocess.TimeoutExpired) as error:receipt['tests'].append({'name':'native-desktop-integration','exitCode':None,'error':str(error)})
    receipt['automatedStatus']='PASS' if receipt['tests'] and all(t.get('exitCode')==0 for t in receipt['tests']) else 'FAIL'
    filename=a.output_directory/('macos-acceptance.json' if a.required_platform=='Darwin' else 'linux-acceptance.json')
    filename.write_text(json.dumps(receipt,indent=2)+'\n');print(filename)
    return 0 if receipt['automatedStatus']=='PASS' else 1
if __name__=='__main__':sys.exit(main())
