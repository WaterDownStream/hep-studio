﻿param(
    [Parameter(Mandatory=$true)][string]$BinDirectory,
    [string]$Repository = (Split-Path (Split-Path $PSScriptRoot -Parent) -Parent),
    [string]$OutputDirectory = (Join-Path $PWD 'hep-host-evidence'),
    [string]$RuntimeImage,
    [string]$InstallDirectory = (Join-Path $env:LOCALAPPDATA 'HEPStudio\Runtime'),
    [string]$RepairBundle,
    [int]$Events = 1000,
    [int]$TransferMiB = 256,
    [switch]$SkipFilesystemBenchmark
)
# Windows PowerShell 5.1 and PowerShell 7. No Linux shell command strings.
$ErrorActionPreference = 'Stop'
$distribution = 'HEPStudioRuntime'
New-Item -ItemType Directory -Force -Path $OutputDirectory | Out-Null
$OutputDirectory = (Resolve-Path $OutputDirectory).Path
$report = [ordered]@{
    format='hep-studio-windows-acceptance'; version=1; status='UNVERIFIED'
    timestamp=[DateTime]::UtcNow.ToString('o'); tests=@(); filesystemBenchmark=$null
    interactiveUiAcceptance='UNVERIFIED'
    repairFlowStatus='UNVERIFIED'; importFlowStatus='UNVERIFIED'
}
function Save-Receipt {
    $text = $report | ConvertTo-Json -Depth 100
    [IO.File]::WriteAllText((Join-Path $OutputDirectory 'windows-acceptance.json'), $text, (New-Object Text.UTF8Encoding($false)))
}
function Quote-NativeArgument([string]$Value) {
    $builder = New-Object Text.StringBuilder
    [void]$builder.Append('"'); $backslashes=0
    foreach ($character in $Value.ToCharArray()) {
        if ($character -eq '\') { $backslashes++; continue }
        if ($character -eq '"') { [void]$builder.Append(('\' * ($backslashes*2+1))); [void]$builder.Append('"') }
        else { [void]$builder.Append(('\' * $backslashes)); [void]$builder.Append($character) }
        $backslashes=0
    }
    [void]$builder.Append(('\' * ($backslashes*2))); [void]$builder.Append('"')
    return $builder.ToString()
}
function Invoke-Bounded([string]$Program,[string[]]$Arguments,[int]$TimeoutSeconds=240) {
    $start = New-Object Diagnostics.ProcessStartInfo
    $start.FileName=$Program; $start.Arguments=(($Arguments | ForEach-Object { Quote-NativeArgument $_ }) -join ' ')
    $start.UseShellExecute=$false; $start.CreateNoWindow=$true
    $start.RedirectStandardOutput=$true; $start.RedirectStandardError=$true
    $start.StandardOutputEncoding=New-Object Text.UTF8Encoding($false)
    $start.StandardErrorEncoding=New-Object Text.UTF8Encoding($false)
    $process = New-Object Diagnostics.Process; $process.StartInfo=$start
    $timer=[Diagnostics.Stopwatch]::StartNew()
    try {
        if (-not $process.Start()) { throw 'Process launch failed' }
        $stdout=$process.StandardOutput.ReadToEndAsync(); $stderr=$process.StandardError.ReadToEndAsync()
        $timedOut=-not $process.WaitForExit($TimeoutSeconds*1000)
        if ($timedOut) { $process.Kill(); [void]$process.WaitForExit(3000) }
        $outText=''; $errText=''
        if ($stdout.Wait(3000)) { $outText=$stdout.Result }
        if ($stderr.Wait(3000)) { $errText=$stderr.Result }
        return @{exitCode= $(if ($timedOut) {-1} else {$process.ExitCode}); timedOut=$timedOut
            wallSeconds=$timer.Elapsed.TotalSeconds; stdout=$outText; stderr=$errText}
    } finally { $process.Dispose() }
}
function Wsl-Path([string]$Path) {
    $resolved=(Resolve-Path $Path).Path
    if ($resolved -notmatch '^([A-Za-z]):[\\/](.*)$') { throw 'Use a local drive path; UNC/network paths are not supported by this harness' }
    return '/mnt/'+$Matches[1].ToLower()+'/'+$Matches[2].Replace('\','/')
}
function Record([string]$Name,$Result) {
    $report.tests+=@(@{name=$Name;status=$(if ($Result.exitCode -eq 0) {'PASS'} else {'FAIL'});details=$Result})
    Save-Receipt
}
try {
    if ([Environment]::OSVersion.Platform -ne 'Win32NT') { throw 'Run on an actual Windows 11 x86-64 host' }
    $os=Get-CimInstance Win32_OperatingSystem
    $report.os=@{caption=$os.Caption;version=$os.Version;build=$os.BuildNumber;architecture=$os.OSArchitecture}
    $report.cpu=@(Get-CimInstance Win32_Processor | Select-Object Name,Architecture,NumberOfCores,NumberOfLogicalProcessors)
    $report.ramBytes=[UInt64](Get-CimInstance Win32_ComputerSystem).TotalPhysicalMemory
    $report.gpu=@(Get-CimInstance Win32_VideoController | Select-Object Name,DriverVersion)
    if ($os.Caption -notmatch 'Windows 11' -or $os.OSArchitecture -notmatch '64' -or @($report.cpu | Where-Object {$_.Architecture -ne 9}).Count -ne 0) { throw 'This acceptance gate requires Windows 11 x86-64' }
    $argumentCases=@('C:\HEP space\trailing\','quote"inside','literal$()','','unicode-π')
    $argv=Invoke-Bounded (Join-Path $BinDirectory 'hep-host-acceptance.exe') (@('--echo-arguments')+$argumentCases) 30
    if ($argv.exitCode -ne 0 -or (($argv.stdout | ConvertFrom-Json | ConvertTo-Json -Compress) -ne ($argumentCases | ConvertTo-Json -Compress))) { throw 'Structured process argument roundtrip failed' }
    Record 'native-argument-roundtrip' $argv
    $wsl=(Get-Command wsl.exe -ErrorAction SilentlyContinue).Source
    if (-not $wsl) { $report.setupAction='Use HEP Studio Scientific Runtime → Enable WSL2. Administrator approval/reboot may be required.'; throw 'WSL unavailable' }
    $report.wslVersion=Invoke-Bounded $wsl @('--version') 30
    $listing=Invoke-Bounded $wsl @('--list','--verbose') 30; Record 'wsl-detection' $listing
    $listText=$listing.stdout.Replace([string][char]0,'')
    $installed=$listText -match '(?m)HEPStudioRuntime\s+\S+\s+2\s*$'
    if (-not $installed -and $RuntimeImage) {
        if ($listText -match 'HEPStudioRuntime') { throw 'Runtime exists but is not WSL2; never overwrite/unregister it' }
        $RuntimeImage=(Resolve-Path $RuntimeImage).Path
        New-Item -ItemType Directory -Force -Path $InstallDirectory | Out-Null
        $import=Invoke-Bounded $wsl @('--import',$distribution,$InstallDirectory,$RuntimeImage,'--version','2') 900
        Record 'explicit-runtime-import' $import
        if ($import.exitCode -ne 0) { throw 'Runtime import failed; inspect evidence' }
        $report.importFlowStatus='PASS'
        $installed=$true
    }
    if (-not $installed) { $report.setupAction='Install a trusted test image using the native Runtime UI, or pass -RuntimeImage. OS setup may need elevation/reboot.'; throw 'Managed WSL2 runtime absent' }
    $report.distribution=$distribution
    $prefix=@('--distribution',$distribution,'--exec')
    $healthBefore=Invoke-Bounded $wsl ($prefix+@('/opt/hep/bin/python','/opt/hep/health.py')) 150
    Record 'runtime-health-before' $healthBefore
    if ($RepairBundle -and $healthBefore.exitCode -ne 0) { $report.tests[-1].status='OBSERVED'; $report.tests[-1].note='Unhealthy initial runtime is the explicit repair test input' }
    if ($RepairBundle) {
        # Explicit update only. Sentinel is harness-owned; user projects/data are
        # never removed, and this script never unregisters a distribution.
        $sentinel='/home/hep/HEPStudio/acceptance-sentinel-'+[Guid]::NewGuid().ToString('N')
        $create='import pathlib,sys; p=pathlib.Path(sys.argv[1]); p.parent.mkdir(parents=True,exist_ok=True); p.write_text("preserve-user-data")'
        $seed=Invoke-Bounded $wsl ($prefix+@('/usr/bin/python3','-c',$create,$sentinel)) 30;Record 'repair-data-sentinel' $seed
        if ($seed.exitCode -ne 0) { throw 'Could not create repair data sentinel' }
        $bundlePath=Wsl-Path $RepairBundle
        $repair=Invoke-Bounded $wsl @('--distribution',$distribution,'--user','root','--exec','/usr/bin/python3','/opt/hep/admin.py','--install',$bundlePath) 900
        Record 'explicit-runtime-repair-update' $repair
        $verify='import pathlib,sys; p=pathlib.Path(sys.argv[1]); assert p.read_text()=="preserve-user-data"; p.unlink()'
        $preserved=Invoke-Bounded $wsl ($prefix+@('/usr/bin/python3','-c',$verify,$sentinel)) 30
        Record 'repair-preserves-user-data' $preserved
        $report.repairFlowStatus=$(if ($repair.exitCode -eq 0 -and $preserved.exitCode -eq 0) {'PASS'} else {'FAIL'})
    }
    $health=Invoke-Bounded $wsl ($prefix+@('/opt/hep/bin/python','/opt/hep/health.py')) 150;Record 'runtime-health-after' $health
    if ($health.exitCode -ne 0) { throw 'Runtime unhealthy; repair a trusted bundle through the native UI' }
    $report.runtime=$health.stdout | ConvertFrom-Json
    if ($healthBefore.exitCode -eq 0) {
        $report.previousRuntime=$healthBefore.stdout | ConvertFrom-Json
        $report.runtimeVersionChanged=($report.previousRuntime.runtimeVersion -ne $report.runtime.runtimeVersion)
        $report.scientificEnvironmentChanged=($report.previousRuntime.environment.id -ne $report.runtime.environment.id)
    }
    $probe=Join-Path $OutputDirectory 'worker-acceptance.json'
    if (Test-Path $probe) { Remove-Item $probe }
    $control=Invoke-Bounded (Join-Path $BinDirectory 'hep-host-acceptance.exe') @('--workflow',(Join-Path $Repository 'examples\collider-workflow.json'),'--output',$probe) 420
    Record 'native-coordinator-wsl-science' $control
    if (-not (Test-Path $probe)) { throw 'Missing worker acceptance receipt' }
    $report.worker=Get-Content -Raw $probe | ConvertFrom-Json
    if ($report.worker.automatedStatus -ne 'PASS') { throw 'Worker acceptance receipt contains failures' }
    $previousRequired=$env:HEP_REQUIRE_COLLIDER; $env:HEP_REQUIRE_COLLIDER='1'
    try { Record 'native-desktop-integration' (Invoke-Bounded (Join-Path $BinDirectory 'hep-studio-tests.exe') @('-o',(Join-Path $OutputDirectory 'desktop-tests.txt')+',txt') 420) }
    finally { if ($null -eq $previousRequired) { Remove-Item Env:HEP_REQUIRE_COLLIDER -ErrorAction SilentlyContinue } else { $env:HEP_REQUIRE_COLLIDER=$previousRequired } }
    if (-not $SkipFilesystemBenchmark) {
        $nativeRoot='/home/hep/HEPStudio/acceptance'
        Record 'locality-root' (Invoke-Bounded $wsl ($prefix+@('/usr/bin/mkdir','-p',$nativeRoot)) 30)
        $script=Wsl-Path (Join-Path $Repository 'scripts\wsl\locality_probe.py');$workflow=Wsl-Path (Join-Path $Repository 'examples\collider-workflow.json')
        $locality=Invoke-Bounded $wsl ($prefix+@('/opt/hep/bin/python',$script,'--workflow',$workflow,'--native-root',$nativeRoot,'--mounted-root',(Wsl-Path $OutputDirectory),'--events',[string]$Events,'--transfer-mib',[string]$TransferMiB,'--keep-transfer','--require-wsl')) 1800
        Record 'wsl-filesystem-comparison' $locality
        if ($locality.exitCode -eq 0) {
            $report.filesystemBenchmark=$locality.stdout | ConvertFrom-Json
            $fixture=$report.filesystemBenchmark.nativeWindowsTransferFixture
            if ($fixture.path -notmatch '^/home/hep/HEPStudio/acceptance/acceptance-transfer-[a-f0-9]+\.bin$') { throw 'Unexpected transfer fixture path' }
            $unc='\\wsl.localhost\'+$distribution+$fixture.path.Replace('/','\')
            $destination=Join-Path $OutputDirectory 'native-transfer.bin'
            $timer=[Diagnostics.Stopwatch]::StartNew();$input=$null;$output=$null
            try { $input=[IO.File]::OpenRead($unc);$output=[IO.File]::Create($destination);$input.CopyTo($output,1048576);$output.Flush($true) }
            finally { if ($output) {$output.Dispose()};if ($input) {$input.Dispose()} }
            $seconds=$timer.Elapsed.TotalSeconds
            $digest=(Get-FileHash -Algorithm SHA256 $destination).Hash.ToLower()
            $report.nativeWindowsOutputTransfer=@{bytes=$fixture.sizeBytes;wallSeconds=$seconds;MiBPerSecond=$fixture.sizeBytes/$seconds/1048576;sha256=$digest;verified=($digest -eq $fixture.sha256);route='WSL filesystem share → native Windows FileStream'}
            if ($digest -ne $fixture.sha256) { throw 'Native transfer checksum mismatch' }
            # Delete only the exact harness-created transfer fixture.
            Record 'transfer-fixture-cleanup' (Invoke-Bounded $wsl ($prefix+@('/usr/bin/python3','-c','import pathlib,sys; pathlib.Path(sys.argv[1]).unlink()',[string]$fixture.path)) 30)
            Remove-Item $destination
        }
    } else { $report.filesystemBenchmark=@{status='UNVERIFIED';reason='Explicitly skipped'} }
    $report.automatedStatus=$(if (@($report.tests | Where-Object {$_.status -eq 'FAIL'}).Count -eq 0) {'PASS'} else {'FAIL'})
} catch { $report.error=$_.Exception.Message; $report.automatedStatus='FAIL' }
finally { Save-Receipt }
Write-Host (Join-Path $OutputDirectory 'windows-acceptance.json')
if ($report.automatedStatus -ne 'PASS') { exit 1 }
