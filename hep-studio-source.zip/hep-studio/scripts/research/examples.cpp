#include "core/research/research.hpp"
#include "core/research/campaign.hpp"
#include "core/editing/editing.hpp"
#include "runtime/project_store.hpp"
#include <QCoreApplication>
#include <QDateTime>
#include <filesystem>
#include <fstream>
#include <iostream>
using namespace hep;
static void write(const std::filesystem::path& path,const Json& value){std::ofstream stream(path);stream<<value.dump(2)<<'\n';if(!stream)throw std::runtime_error("Could not save example artifact");}
static Run completed(const Project& project,const Workflow& workflow,const std::string& id,const Json& record){
    const auto& result=record.at("result");
    if(result.value("preview",false)||!result.value("valid",false)||result.value("partial",false))throw std::runtime_error("Example requires a complete, valid full Run");
    Run run{Id(id),"Completed",workflowJson(workflow),workflowHash(scientificJson(workflow,project.seed)).toStdString()};
    run.backend="hep.research/1";run.environment=result.at("environment").at("id");run.seed=project.seed;run.started=record.at("started");run.ended=record.at("ended");run.result=result;run.resources=record.at("resources");
    run.extensions["frozenEnvironment"]=result.at("environment");run.extensions["workflowRevision"]=workflowHash(workflowJson(workflow)).toStdString();
    Json hashes=Json::object();for(const auto& node:workflow.nodes)hashes[node.id.value]=workflowHash(dependencyJson(workflow,node.id,project.seed)).toStdString();run.extensions["nodeHashes"]=hashes;return run;
}
static Workflow sample(const std::string& role,bool tau){
    auto w=researchExample();w.id=Id("example-"+role);w.name=tau?"Signal: tau pairs → reconstructed dimuons":"Background: prompt reconstructed dimuons";
    for(std::size_t i=0;i<w.nodes.size();++i)w.nodes[i].id=Id("example-"+role+"-"+std::to_string(i));
    w.connections.clear();
    for(std::size_t i=1;i<w.nodes.size();++i)w.connections.push_back({w.nodes[i-1].id,Id("out"),w.nodes[i].id,Id("in")});
    auto& generator=w.nodes[0].extensions["config"];generator["events"]=1000;generator["seed"]=tau?24679:24680;generator["process"]["outgoing"]=Json::array({tau?-15:-13,tau?15:13});
    auto& shower=w.nodes[1].extensions["config"];shower.update({{"seed",tau?"732":"731"},{"seedStrategy","fixed"},{"isr",false},{"fsr",false},{"mpi",false},{"hadronisation",true},{"partitionEvents",250},{"workers",2}});
    w.nodes[2].extensions["config"]["seed"]=tau?24679:24680;w.nodes[4].extensions["config"]["expression"]["args"][1]["value"]=0.;
    w.nodes.back().extensions["config"].update({{"bins",1},{"lower",0.},{"upper",120.},{"yieldMode","luminosity"},{"luminosityFb",.01}});
    for(std::size_t i=0;i<w.nodes.size();++i){w.nodes[i].x=40+static_cast<double>(i%3)*260;w.nodes[i].y=85+static_cast<double>(i/3)*160;}
    lowerResearch(w);return w;
}
static Project templates(){
    Project p{Id("example-template-study"),"Tau-pair signal / prompt dimuon background",{sample("signal",true),sample("background",false)}, {}};p.seed="42";
    Workflow w{Id("example-statistical-model"),"Explicit template likelihood",{}, {}};
    for(const auto* kind:{"TemplateSet","BinnedLikelihood","Inference"})w.nodes.push_back(researchNode(kind,Id("example-model-"+std::to_string(w.nodes.size()))));
    for(std::size_t i=1;i<w.nodes.size();++i)w.connections.push_back({w.nodes[i-1].id,Id("out"),w.nodes[i].id,Id("in")});
    w.nodes[1].extensions["config"].update({{"muMax",100.},{"mcStat","poisson-gamma"},{"mcStatAssumption","independent-effective-counts"},{"nuisances",Json::array({{{"kind","normalization"},{"samples",Json::array({"signal","background"})},{"correlationGroup","luminosity"},{"constraint","gaussian-standard-normal"},{"variationMeaning","minus-plus-one-sigma"},{"down",.98},{"up",1.02}}})}});
    w.nodes[2].extensions["config"]["points"]=200;
    p.workflows.push_back(w);p.extensions={{"researchVersion",1},{"activeWorkflow",w.id.value}};return p;
}
int main(int argc,char** argv){QCoreApplication app(argc,argv);try{
    if(argc!=3)throw std::invalid_argument("Usage: hep-research-examples prepare|finalize|model-reference DIRECTORY");
    const std::filesystem::path folder=argv[2];std::filesystem::create_directories(folder);auto p=templates();
    if(std::string(argv[1])=="prepare"){
        Json specifications=Json::array();for(std::size_t i=0;i<2;++i){const auto& w=p.workflows[i];specifications.push_back({{"role",i==0?"signal":"background"},{"plan",lowerResearch(w)},{"scientificHash",workflowHash(scientificJson(w,p.seed)).toStdString()},{"workflowRevision",workflowHash(workflowJson(w)).toStdString()}});}
        write(folder/"template-specifications.json",specifications);
        auto a=sample("dilepton",false);a.name="Reconstructed dimuon response and RooFit";a.nodes.back().extensions["config"].update({{"bins",40},{"lower",80.},{"upper",120.},{"yieldMode","raw-weights"}});auto fit=researchNode("RooFit",Id("example-dilepton-fit"));a.connections.push_back({a.nodes.back().id,Id("out"),fit.id,Id("in")});a.nodes.push_back(fit);
        Project dilepton{Id("example-dilepton-study"),"Example A: reconstructed dilepton fit",{a},{}};dilepton.seed="42";dilepton.extensions={{"researchVersion",1},{"activeWorkflow",a.id.value}};write(folder/"research-dilepton.hep.json",projectJson(dilepton));write(folder/"dilepton-specification.json",{{"plan",lowerResearch(a)},{"scientificHash",workflowHash(scientificJson(a,dilepton.seed)).toStdString()},{"workflowRevision",workflowHash(workflowJson(a)).toStdString()}});
        auto c=sample("cut-scan",false);c.name="Reconstructed muon-threshold scan";Project scan{Id("example-research-scan"),"Example C: threshold scan with stage reuse",{c},{}};scan.seed="42";scan.extensions={{"researchVersion",1},{"activeWorkflow",c.id.value},{"recommendedScan",{{"axes",Json::array({{{"nodeId",c.nodes[4].id.value},{"pointer","/expression/args/1/value"},{"unit","GeV"},{"spacing","linear"},{"lower",0.},{"upper",40.},{"count",3}}})}}}};write(folder/"research-scan.hep.json",projectJson(scan));
        Json points=Json::array();const auto specification=scan.extensions.at("recommendedScan");const auto workflows=scanWorkflows(c,specification);
        for(std::size_t i=0;i<workflows.size();++i){const auto& point=workflows[i];Json hashes=Json::object();for(const auto& node:point.nodes)hashes[node.id.value]=workflowHash(dependencyJson(point,node.id,scan.seed)).toStdString();const auto hash=workflowHash(scientificJson(point,scan.seed)).toStdString();points.push_back({{"runId","example-scan-point-"+std::to_string(i)},{"workflowSnapshot",workflowJson(point)},{"scientificHash",hash},{"nodeHashes",hashes},{"payload",{{"plan",lowerResearch(point)},{"scientificHash",hash},{"workflowRevision",workflowHash(workflowJson(point)).toStdString()},{"projectSeed",scan.seed},{"allocatedThreads",2}}}});}
        write(folder/"scan-specification.json",{{"scan",{{"id","example-cut-scan"},{"axes",specification.at("axes")},{"workflowId",c.id.value},{"workflowHash",workflowHash(scientificJson(c,scan.seed)).toStdString()}}},{"points",points}});
    }else if(std::string(argv[1])=="model-reference"){
        auto nominal=sample("model-reference",false);nominal.nodes[0].extensions["config"].update({{"events",20},{"parameters",{{"sminputs:1",132.507}}}});nominal.nodes[1].extensions["config"].update({{"hadronisation",false},{"partitionEvents",25}});nominal.nodes[2].extensions["config"]["card"]={{"builtin","ideal-muon"}};nominal.nodes.back().extensions["config"].update({{"bins",20},{"lower",90.},{"upper",110.},{"yieldMode","cross-section-pb"}});
        const auto axis=Json{{"axes",Json::array({{{"nodeId",nominal.nodes.front().id.value},{"pointer","/parameters/sminputs:1"},{"unit","1"},{"values",Json::array({120.,132.507,145.})}}})}};
        Json points=Json::array();const auto expanded=scanWorkflows(nominal,axis);for(std::size_t i=0;i<expanded.size();++i){const auto& point=expanded[i];const auto hash=workflowHash(scientificJson(point,"42")).toStdString();points.push_back({{"runId","model-reference-"+std::to_string(i)},{"workflowSnapshot",workflowJson(point)},{"scientificHash",hash},{"payload",{{"plan",lowerResearch(point)},{"scientificHash",hash},{"workflowRevision",workflowHash(workflowJson(point)).toStdString()},{"projectSeed","42"},{"allocatedThreads",2}}}});}
        write(folder/"model-reference-specification.json",{{"scan",{{"id","model-reference"},{"configuration",axis}}},{"points",points}});
    }else if(std::string(argv[1])=="finalize"){
        Json records;std::ifstream(folder/"template-results.json")>>records;
        auto& model=p.workflows.back();Json refs=Json::array();for(std::size_t i=0;i<2;++i){const std::string role=i==0?"signal":"background";const auto& record=records.at(role);const auto& result=record.at("result");if(!result.at("valid").get<bool>())throw std::runtime_error("Example scientific run is invalid");const auto& w=p.workflows[i];const auto hid=w.nodes.back().id.value;
            Run run=completed(p,w,"example-run-"+role,record);
            refs.push_back({{"id",role},{"role",role},{"reference",{{"runId",run.id.value},{"nodeId",hid},{"inputIdentity",workflowHash(result.at("results").at(hid)).toStdString()}}}});p.runs.push_back(run);
        }
        model.nodes[0].extensions["config"]["samples"]=refs;p.extensions["preferredResearchEnvironment"]=p.runs[0].result.at("environment");write(folder/"research-template-study.hep.json",projectJson(p));
        Json inputs=Json::object();for(const auto& run:p.runs){const auto w=workflowFromJson(run.workflowSnapshot);const auto hid=w.nodes.back().id.value;const auto& h=run.result.at("results").at(hid);inputs[run.id.value+"/"+hid]={{"runStatus",run.status},{"runValid",true},{"inputIdentity",workflowHash(h).toStdString()},{"histogram",h},{"sourceRun",{{"id",run.id.value},{"backend",run.backend},{"environment",run.environment},{"workflowScientificHash",run.workflowHash},{"environmentId",run.environment},{"seed",run.seed},{"started",run.started},{"ended",run.ended}}}};}
        write(folder/"template-model-specification.json",{{"plan",lowerResearch(model)},{"templateInputs",inputs},{"scientificHash",workflowHash(scientificJson(model,p.seed)).toStdString()},{"workflowRevision",workflowHash(workflowJson(model)).toStdString()}});
        if(std::filesystem::exists(folder/"template-inference.json")){Json result;std::ifstream(folder/"template-inference.json")>>result;p.runs.push_back(completed(p,model,"example-run-inference",{{"result",result},{"started",records.at("inferenceStarted")},{"ended",records.at("inferenceEnded")},{"resources",records.at("signal").at("resources")}}));write(folder/"research-template-study.hep.json",projectJson(p));}
        if(std::filesystem::exists(folder/"dilepton-result.json")){Json record;std::ifstream(folder/"dilepton-result.json")>>record;Json value;std::ifstream(folder/"research-dilepton.hep.json")>>value;auto example=projectFromJson(value);example.runs.clear();example.runs.push_back(completed(example,example.workflows.front(),"example-run-dilepton",record));write(folder/"research-dilepton.hep.json",projectJson(example));}
        if(std::filesystem::exists(folder/"scan-result.json")){Json result;std::ifstream(folder/"scan-result.json")>>result;if(!result.value("valid",false)||result.at("scan").at("state")!="completed")throw std::runtime_error("Example scan did not complete");Json value;std::ifstream(folder/"research-scan.hep.json")>>value;auto example=projectFromJson(value);example.runs.clear();for(const auto& point:result.at("pointRuns")){const auto w=workflowFromJson(point.at("workflow"));auto run=completed(example,w,point.at("id"),{{"result",point.at("result")},{"started",point.at("started")},{"ended",point.at("ended")},{"resources",records.at("signal").at("resources")}});run.extensions["scanId"]=result.at("scan").at("id");example.runs.push_back(run);}auto receipt=result.at("scan");receipt["configuration"]=example.extensions.at("recommendedScan");receipt["projectId"]=example.id.value;receipt["projectSeed"]=example.seed;receipt["baseWorkflow"]=workflowJson(example.workflows.front());receipt["frozenEnvironment"]=example.runs.front().extensions.at("frozenEnvironment");receipt["pointRunIds"]=Json::array();receipt["expectedRunHashes"]=Json::object();for(const auto& run:example.runs){receipt["pointRunIds"].push_back(run.id.value);receipt["expectedRunHashes"][run.id.value]=run.workflowHash;}example.extensions["scans"]=Json::array({receipt});write(folder/"research-scan.hep.json",projectJson(example));}
    }else throw std::invalid_argument("Unknown example writer operation");
    std::cout<<"Saved research example specifications/state\n";return 0;
}catch(const std::exception& error){std::cerr<<error.what()<<'\n';return 1;}}
