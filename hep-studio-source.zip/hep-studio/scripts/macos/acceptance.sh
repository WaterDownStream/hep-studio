#!/bin/sh
# Developer host acceptance; the native desktop remains the ordinary user flow.
set -eu
if [ "$#" -lt 2 ]; then
  echo "Usage: $0 /path/to/build/bin /path/to/evidence-directory" >&2
  exit 2
fi
repo_dir=$(CDPATH= cd -- "$(dirname -- "$0")/../.." && pwd)
exec python3 "$repo_dir/scripts/acceptance/native_receipt.py" --required-platform Darwin \
  --bin-directory "$1" --repository "$repo_dir" --output-directory "$2"
