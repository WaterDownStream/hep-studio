#!/usr/bin/env python3
"""Pinned workspace-only SDK build. No package installation or remote shell script."""
import argparse,hashlib,io,json,os,platform,shutil,subprocess,tarfile,urllib.request
from pathlib import Path

SOURCES=[
    ('madgraph','3.6.7','https://codeload.github.com/mg5amcnlo/mg5amcnlo/tar.gz/0e6c945573c8bab6246b9a172c219a7754125f51','411964296c01ad4bed8a13e9993f16ba1ee470377c7a73252b44d446d23c2281','0e6c945573c8bab6246b9a172c219a7754125f51'),
    ('delphes','3.5.1','https://codeload.github.com/delphes/delphes/tar.gz/28658365abeb71ee36dfc739f9670c1514c0cb10','563d9f592d0d84c9269fa9c2cce68a047c263d12e52b4bf9937f0931d5d0a129','28658365abeb71ee36dfc739f9670c1514c0cb10')]

def digest(path):
    h=hashlib.sha256()
    with Path(path).open('rb') as stream:
        while block:=stream.read(1024*1024):h.update(block)
    return h.hexdigest()

def fetch(url,path,expected,offline):
    if not path.exists():
        if offline:raise FileNotFoundError('Offline archive absent: '+str(path))
        temporary=path.with_suffix(path.suffix+'.partial')
        try:
            with urllib.request.urlopen(url,timeout=90) as source,temporary.open('wb') as target:
                while block:=source.read(1024*1024):target.write(block)
            if digest(temporary)!=expected:raise ValueError('Archive SHA256 mismatch: '+url)
            temporary.replace(path)
        finally:temporary.unlink(missing_ok=True)
    if digest(path)!=expected:raise ValueError('Cached archive SHA256 mismatch: '+str(path))

def run(arguments,env,cwd=None,timeout=1800):
    subprocess.run([str(x) for x in arguments],env=env,cwd=cwd,check=True,timeout=timeout)

def main():
    p=argparse.ArgumentParser();p.add_argument('--prefix',type=Path,required=True);p.add_argument('--cache',type=Path,required=True)
    p.add_argument('--root-prefix',type=Path,required=True);p.add_argument('--fortran',type=Path)
    p.add_argument('--jobs',type=int,default=2);p.add_argument('--offline',action='store_true');a=p.parse_args()
    prefix=a.prefix.resolve();cache=a.cache.resolve();root=a.root_prefix.resolve()
    if not 1<=a.jobs<=max(1,(os.cpu_count() or 1)-1):raise ValueError('Build jobs exceed UI-reserved host CPU count')
    cache.mkdir(parents=True,exist_ok=True);prefix.mkdir(parents=True,exist_ok=True)
    compiler=str(a.fortran.resolve()) if a.fortran else shutil.which('gfortran')
    if not compiler:raise RuntimeError('Fortran compiler missing; supply --fortran from an installed or payload-only extracted compiler. No privileged installer is invoked.')
    manifest={'version':1,'platform':platform.platform(),'sourceVerification':'Pinned upstream HTTPS/commit and recorded archive SHA256; no independent publisher signature claim',
              'compiler':subprocess.check_output([compiler,'--version'],text=True).splitlines()[0],'compilerExecutable':compiler,'rootPrefix':str(root),'sources':[]}
    for name,version,url,sha,commit in SOURCES:
        archive=cache/(name+'-'+version+'.tar.gz');fetch(url,archive,sha,a.offline)
        destination=prefix/name
        if not destination.exists():
            pending=prefix/(name+'.extracting');pending.mkdir()
            try:
                with tarfile.open(archive) as source:source.extractall(pending,filter='data')
                directories=list(pending.iterdir())
                if len(directories)!=1 or not directories[0].is_dir():raise ValueError('Unexpected archive layout')
                directories[0].rename(destination)
            finally:shutil.rmtree(pending,ignore_errors=True)
        manifest['sources'].append({'name':name,'version':version,'url':url,'sha256':sha,'commit':commit})
    # A PyPI ROOT wheel's root-config can contain a mock_site_packages prefix.
    # Correct only its reported paths in a local wrapper; leave the SDK untouched.
    tools=prefix/'bin';tools.mkdir(exist_ok=True);wrapper=tools/'root-config'
    wrapper.write_text('#!/usr/bin/env python3\nimport subprocess,sys\nr=subprocess.run(['+repr(str(root/'bin/root-config'))+']+sys.argv[1:],capture_output=True)\nsys.stdout.buffer.write(r.stdout.replace(b"/mock_site_packages/ROOT/",b"/"));sys.stderr.buffer.write(r.stderr);sys.exit(r.returncode)\n');wrapper.chmod(0o755)
    env=os.environ.copy();env['PATH']=str(tools)+os.pathsep+str(root/'bin')+os.pathsep+env.get('PATH','')
    env['ROOTSYS']=str(root);env['LD_LIBRARY_PATH']=os.pathsep.join([str(root/'lib'),str(root.parent/'root.libs'),env.get('LD_LIBRARY_PATH','')])
    env['OMP_NUM_THREADS']=env['OPENBLAS_NUM_THREADS']='1'
    # This builds core readers/library only; the optional ROOT Eve display is
    # irrelevant to the native HEP Studio renderer and absent from some SDKs.
    run(['make','-j',a.jobs,'DelphesHepMC3','DelphesLHEF','libDelphes.so','ClassesDict_rdict.pcm','ExRootAnalysisDict_rdict.pcm','ModulesDict_rdict.pcm','FastJetDict_rdict.pcm'],env,prefix/'delphes')
    manifest['rootVersion']=subprocess.check_output([str(wrapper),'--version'],text=True).strip()
    manifest['delphesLibrarySha256']=digest(prefix/'delphes/libDelphes.so')
    manifest['madgraphGitCheckoutWarning']='Tagged Git source includes release utility and can label its banner a development checkout; validation is not production-distribution certification.'
    (prefix/'research-sdk.json').write_text(json.dumps(manifest,indent=2)+'\n')
    print(prefix/'research-sdk.json')

if __name__=='__main__':main()
