#!/usr/bin/env python3
"""Maintainer build recipe for the Linux SDK used by Part 3 integration tests.

Downloads are explicit: invoke this script to build a scientific runtime.
Source archives are checksum-verified and retained for audit/source distribution.
"""
import argparse,hashlib,json,shutil,subprocess,tarfile,urllib.request
from pathlib import Path

SOURCES={
 'pythia':('pythia8mc','8.318.0','26e8b38592e2c45cfc46235ac2efb9031781adfe7bf824cb68d29b2108232b57'),
 'hepmc':('pyhepmc','2.16.1','7586baa7b1bcbd56636766e2bebf7457da9ec2f4f19bd683950915939b435d60'),
 'lhapdf':('https://gitlab.com/hepcedar/lhapdf/-/archive/lhapdf-6.5.6/lhapdf-lhapdf-6.5.6.tar.gz','6.5.6','165143a5487d845d22e2d4dbe4ab4f51f09571756e80f71e3eacd7d412efb5d8')}

def obtain(name,cache):
    package,version,checksum=SOURCES[name];archive=cache/(name+'-'+version+'.tar.gz')
    if not archive.exists():
        if package.startswith('https:'):url=package
        else:
            with urllib.request.urlopen(f'https://pypi.org/pypi/{package}/{version}/json',timeout=30) as response:info=json.load(response)
            url=next(x['url'] for x in info['urls'] if x['packagetype']=='sdist')
        with urllib.request.urlopen(url,timeout=60) as source,archive.open('wb') as output:shutil.copyfileobj(source,output,1024*1024)
    if hashlib.sha256(archive.read_bytes()).hexdigest()!=checksum:raise RuntimeError('Source checksum mismatch: '+str(archive))
    folder=cache/(name+'-source')
    if not folder.exists():
        folder.mkdir()
        with tarfile.open(archive) as tar:tar.extractall(folder,filter='data')
    return next(p for p in folder.iterdir() if p.is_dir())

def recipe(name,source):
    head='cmake_minimum_required(VERSION 3.24)\nproject(HEPScience LANGUAGES CXX)\nset(CMAKE_CXX_STANDARD 17)\n'
    if name=='pythia':return head+'''file(GLOB SOURCES pythia8318/src/*.cc)
add_library(pythia8 SHARED ${SOURCES})
target_include_directories(pythia8 PUBLIC pythia8318/plugins/python/include)
target_compile_definitions(pythia8 PRIVATE NOPLUGIN XMLDIR="share/Pythia8/xmldoc" FJCORE_HAVE_LIMITED_THREAD_SAFETY)
install(TARGETS pythia8 LIBRARY DESTINATION lib)
install(DIRECTORY pythia8318/plugins/python/include/Pythia8 pythia8318/plugins/python/include/Pythia8Plugins DESTINATION include)
install(DIRECTORY pythia8318/share/Pythia8 DESTINATION share)
'''
    if name=='hepmc':return head+'''file(GLOB SOURCES extern/HepMC3/src/*.cc)
add_library(HepMC3 SHARED ${SOURCES})
target_include_directories(HepMC3 PUBLIC extern/HepMC3/include)
target_compile_definitions(HepMC3 PRIVATE HepMC3_EXPORTS=1)
install(TARGETS HepMC3 LIBRARY DESTINATION lib)
install(DIRECTORY extern/HepMC3/include/HepMC3 DESTINATION include)
'''
    version=source/'include/LHAPDF/Version.h.in';(source/'include/LHAPDF/Version.h').write_text(version.read_text().replace('#undef LHAPDF_VERSION\n','#define LHAPDF_VERSION "6.5.6"\n').replace('#undef LHAPDF_VERSION_CODE','#define LHAPDF_VERSION_CODE 60506'))
    return head+'''file(GLOB SOURCES src/*.cc src/yamlcpp/*.cpp)
list(FILTER SOURCES EXCLUDE REGEX "LHAGlue.cc$")
add_library(LHAPDF SHARED ${SOURCES})
target_include_directories(LHAPDF PUBLIC include PRIVATE src/yamlcpp)
target_compile_definitions(LHAPDF PRIVATE YAML_NAMESPACE=LHAPDF_YAML LHAPDF_INSTALL_PREFIX="${CMAKE_INSTALL_PREFIX}" LHAPDF_DATA_PREFIX="${CMAKE_INSTALL_PREFIX}/share")
install(TARGETS LHAPDF LIBRARY DESTINATION lib)
install(DIRECTORY include/LHAPDF DESTINATION include)
install(FILES lhapdf.conf pdfsets.index DESTINATION share/LHAPDF)
'''

def main():
    parser=argparse.ArgumentParser();parser.add_argument('--prefix',type=Path,required=True);parser.add_argument('--cache',type=Path,required=True);parser.add_argument('--jobs',type=int,default=2);parser.add_argument('--cmake',default='cmake');args=parser.parse_args()
    args.cache.mkdir(parents=True,exist_ok=True);manifest={}
    for name in SOURCES:
        source=obtain(name,args.cache);(source/'CMakeLists.txt').write_text(recipe(name,source));build=args.cache/(name+'-build')
        subprocess.run([args.cmake,'-S',str(source),'-B',str(build),'-DCMAKE_BUILD_TYPE=Release','-DCMAKE_INSTALL_PREFIX='+str(args.prefix.resolve())],check=True)
        subprocess.run([args.cmake,'--build',str(build),'--parallel',str(args.jobs)],check=True)
        subprocess.run([args.cmake,'--install',str(build)],check=True)
        manifest[name]={'source':SOURCES[name][0],'sourceVersion':SOURCES[name][1],'sha256':SOURCES[name][2]}
    (args.prefix/'build-sources.json').write_text(json.dumps(manifest,indent=2)+'\n')

if __name__=='__main__':main()
