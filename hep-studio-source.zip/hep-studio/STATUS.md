# HEP Studio — PART 4 COMPLETE (frozen release candidate)

## Closure result — 2026-10-04

**PART 4 COMPLETE under the explicitly frozen scope.** All eight closure checks
pass to the available Linux extent; unavailable external hosts are not blockers.
Release candidate: **`part4-rc1`**. This source state is frozen. Part 5 is not
started and requires new authorization.

- Final required-SDK regression: **20/20 pass**, zero failures or scientific skips,
  **211.71 s**. Logs: `docs/developer/part4-closure-final-regression-tests.txt`.
- Real MadGraph → PYTHIA → Delphes → reconstructed selection → materialized
  systematic templates → HistFactory/RooFit/RooStats completes. Native round-trip
  preserves three workflows and three immutable Runs exactly. The independently
  executable statistical export matches every CLs point and both limits exactly.
- The two-axis scan verifies **Completed / Completed / Failed / Missing** through
  real execution, rejected configuration, controlled cancellation and checksum
  recovery. Failed/missing points remain invalid and the partial scan is labelled
  interrupted. RooStats negative-CLs underflow is now rejected explicitly.
- Original Part 3 Release workload replayed: **16,384 events**, seed 1, project
  seed 42, 2,048-event logical blocks, **1/2/4/7 workers**, four pipeline cases.
  **32/32 admitted measurements** pass across archived Part 3 and current Part 4
  against the same current AMD host/installed SDK. Median Part 4 wall change:
  **−0.54%**, range **−3.79% to +1.18%**. No consistent regression is observed in
  these single trials. Generated/accepted counts, weight sums and logical streams
  match. Eight workers remain excluded by the UI reservation.
- Peak sampled current process-tree RSS: **1,885.4 MiB**; shared pages are counted
  repeatedly. Current PSS returned zero and is **unavailable**, not zero RAM.
  Baseline PSS and all raw CPU/startup/merge/storage/control measurements remain.
  Historical Intel hardware was unavailable; its absolute timings are not treated
  as a direct same-machine comparison.
- Linux scientific and offscreen native desktop execution: **VERIFIED**.
  Windows/WSL and macOS execution: **UNVERIFIED external acceptance**. The existing
  host harnesses remain; no cross-platform validation is inferred from Linux.
- **Explicitly deferred and not blockers:** general UFO coverage, NLO generation,
  matching/merging. No Geant4, ML, local LLMs, SciSpec generalization or Part 5 work.
- ROOT remains an alpha SDK; asymptotic sparse-bin/boundary coverage is unverified.
  Historical pre-fix wide-range limits must be inspected/rerun; immutable history
  is preserved. Consolidated evidence: `docs/developer/part4-closure.json`,
  `part4-closure.md` and `part4-closure-performance.md`.

## Frozen closure scope — 2026-10-04

- Part 4 scope is frozen. The final closure pass covers regressions, the original
  Part 3 Release workload, native project round-trip, the complete research chain,
  a two-axis scan and independently executable statistical export.
- **Explicitly deferred, not Part 4 completion blockers:** general UFO coverage,
  NLO generation, and matching/merging. Existing supported LO SM references remain.
- **UNVERIFIED external acceptance:** Windows 11/WSL and macOS. Suitable hosts
  remain unavailable; their preserved acceptance harnesses are required on those
  hosts, but their absence does not block this frozen Linux closure.
- No Geant4, ML, local LLMs, SciSpec generalization or Part 5 work is authorized
  by this closure. Development stops at the preserved Part 4 release candidate.
- Initial closure regression: **20/20 suites pass**, 202.74 s. A real closure
  inference exposed RooStats negative-CLs underflow being accepted as finite;
  the validity check now rejects it. Final regression **20/20 passes**, 211.71 s,
  with required scientific libraries and no skips. `part4-closure-final-regression-tests.txt`.
- Real 1,000-event signal and background samples pass the complete generated
  systematic-template/HistFactory chain. Native save/reload preserves three
  workflows and three immutable Runs exactly. Independent PyROOT statistical
  export matches every CLs point and both limits exactly in this environment.
  A two-dimensional scan preserves two successful points, one real invalid-range
  failure and one never-published missing point after controlled cancellation.
  Evidence: `docs/developer/part4-closure-workflow.json` and the accompanying
  complete project, standalone export, logs and scan recovery receipt.
- The historical Part 3 benchmark host was Intel Xeon Platinum 8573C; the current
  host is AMD EPYC 9V74. The original workload and preserved Part 3 source are
  replayed against the same current SDK/host for a controlled code comparison;
  the historical machine is not claimed to have been recreated.

Explicit Part 4 authorization supersedes the earlier prohibition. Original master
specification and the supplied Part 4 work order remain authoritative. Part 1–3
history: `docs/developer/part3-status.md`; foundations are preserved.

## Initial scientific checkpoint — 2026-09-30

**Verified on Linux**
- All 13 Part 1–3 CTest suites pass (83.16 s), before scientific integration edits.
  Log: `docs/developer/part4-entry-regression-tests.txt`.
- Official pinned MadGraph 3.6.7 and Delphes 3.5.1 Git sources downloaded; exact
  commits, URLs, SHA256 and build-script review recorded in `research-dependencies.json`.
  Ubuntu gfortran 13.3 packages match repository SHA256; payload extraction only,
  no privileged installation or package scripts. Compiler and both backends execute.
- Real fixed-seed 100-event MadGraph photon-only e+e- → mu+mu- at 100 GeV:
  9.2699 ± 0.013836 pb versus massless QED 9.28931948 pb; five-integration-error
  tolerance passes. LHE event count, charges and four-momentum closure pass.
- Genuine Delphes ideal response yields 200 muons/100 events; pT and dimuon mass
  checks pass. Seeded upstream CMS card yields 188 muons, 89 dimuon events,
  mean mass 100.075 GeV, RMS 1.085 GeV. This is a software/response reference,
  not experimental CMS detector validation. `part4-reference-results.json`
  records numerical tolerances and artifact/card identities.

**Implemented / verified integration**
- Reference validation script, deterministic fixture and ideal-response card.
- Integration interfaces identified in `docs/architecture/research-pipeline.md`.
- Typed MadGraph/LHE/shower/Delphes/reconstructed collection contracts and lowering;
  generator/reconstruction mixing is rejected. Worker budget stays outside physics identity.
- Real native LHE shower, stable logical ranges, isolated subprocess lifeline and
  checksum-verified stage transactions. Backend numerical test passes fresh 1/2-worker
  shower/reconstruction: 100 dimuons, raw integral 926.990032, sumw2 8593.105198,
  cross-section integral 9.26990032 pb, one shared RDataFrame loop, zero bulk IPC events.
  A genuine FSR-enabled fresh 1/2-worker comparison also passes, including inspected events.
- Real Qt desktop acceptance passes MadGraph → shower → Delphes → selection/pairs
  → mass histogram, bounded preview, save/reload, stale propagation, cached rerun,
  comparison, three-point immutable scan and systematic undo/redo. Offscreen Linux
  evidence is not a human/hardware acceptance claim.
- Real RooFit Gaussian/exponential recovery and RooStats one-channel CLs, q₀ discovery,
  profile interval and explicit Gaussian background constraint pass numerical checks
  (`part4-statistics-validation.json`). Sparse-sample coverage is unverified.
- Typed unit-aware scan grids, explicit systematic descriptors, checksum-verified point
  publication/recovery and resume are implemented. Kill/cancel recovery contracts pass.
  Normalization bin/error/sumw2 audit and cut-stage cache reuse pass. Standalone PyROOT
  histogram export executes and matches every worker bin/error; upstream configuration
  is recorded, statistical export declarations remain informational.
- Runtime SDK manifest selection and scoped worker environment configuration implemented.
  WSL bundle recipe/research health boundary extended; image/host execution unverified.
- Recovery checkpoint: all 17 existing CTest suites pass on Linux (15 core/backend/
  runtime suites: 71.98 s; desktop/lifecycle acceptance: 54.16 s). Logs are
  `part4-restored-regression-tests.txt` and `part4-restored-desktop-tests.txt`.
- Real HistFactory template likelihood adapter and typed template/model/inference
  nodes implemented. Numerical one-bin CLs reference, shared normalization/shape
  nuisances, explicit gamma MC statistics and executable standalone PyROOT export
  pass (`part4-template-validation.json`). A two-bin Poisson reference and genuine
  bin-redistribution shape variation also pass. Qt template acceptance passes
  execution, missing-reference rejection, source-Run compatibility/immutability,
  save/reload, downstream staleness, undo/redo, comparison and export. A full
  18-suite regression recheck passes (130.43 s). Subsequent recorded-card/evidence
  desktop acceptance also passes, together with the template workflow (24.26 s).
- Bounded recorded-card inspection verifies text checksums without reading bulk
  event artifacts. Run-evidence JSON export preserves the complete immutable Run
  and inspected generation/detector cards. Corrupt/oversized/path-escape requests
  are rejected. Fortran version/entrypoint identity participates in the environment.
- Release 1,000-event MG → FSR shower → CMS → dimuon histogram reference: cold
  16.936 s (59.0 input events/s), verified reuse 0.238 s, startup 1.346 s,
  peak sampled process-tree PSS 463.3 MiB. Two-thread broker lease; concurrent
  acceptance/build work and startup/JIT limit interpretation. This is not a
  steady-state production benchmark. `part4-release-benchmark.json` records context.
- Dependency-absent build/regression passes: 13 suites pass and five scientific
  suites explicitly skip, 14.74 s. `part4-portable-tests.txt` records this evidence.
- Statistical Inspector shows parameter tables, bounded correlation matrices,
  pulls/CLs and native PNG/PDF export. One-axis scan plots use completed immutable
  point Runs, convert display units, exclude invalid points and do not rerun science.
  Qt template/reconstructed/scan acceptance passes (22.93 s); focused core,
  contracts, numerical-template and desktop-smoke suites pass (5.28 s).
- Real shipped reference examples pass 1,000-event tau-signal/prompt-dimuon
  background generation/reconstruction, explicit HistFactory inference and a
  reconstructed Gaussian RooFit (mean 100.025 GeV, sigma 1.053 GeV). Samples use
  disjoint hard processes and distinct logical seeds. Saved example projects,
  replay recipes and limitations accompany `part4-examples-validation.json`.
- Three-point shipped cut-scan execution passes with all invariant upstream
  stages reused; Qt example reopen/plot/Run-preservation acceptance passes (1.43 s).
- Typed photons/tracks, lepton/photon isolation and jet-tag properties are added
  without conflating semantic types. Deterministic Delphes-class records verify
  exact weighted bins, sumw2, unsupported-property rejection and standalone export.
  Expanded real RooFit references recover Breit-Wigner, polynomial, histogram
  mixture and product models. Fixed-PDF optimizer claims are rejected and pulls
  outside a selected fit range are omitted.
- Identified custom detector bundles are relinkable logical resources. Qt
  selection/relink/change/undo tests pass; backend response reuse after actual
  relocation and changed-dependency rejection pass. Only identified bounded Tcl
  dependencies are privately copied. Compiler/partial-SDK capability states
  distinguish missing and broken installations.
- Live research cancellation/crash/restart/save/reload acceptance passes while
  preserving a prior Completed Run (5.39 s with example/card acceptance). Nine
  dependency-free hardening contracts pass, including explicit scan environment
  failure, mixed completed/failed points, disk-full and unpublishable symlinks.
- Updated Release reference: cold 15.480 s, verified reuse 0.180 s, RooFit 0.465 s,
  RooStats CLs 0.370 s, two normalization endpoints 0.188 s, three analysis scan
  points 0.584 s. Stage timings/broker hardware/memory/limitations are recorded in
  `part4-release-hardening-benchmark.json` and `part4-performance.md`.

**Unverified / limitations**
- Native Windows/WSL and macOS host runs remain outstanding; acceptance harnesses
  are preserved. Their absence no longer blocks authorized Linux Part 4 work.
- Existing ROOT PyPI SDK is alpha. MadGraph Git checkout reports a development
  banner despite the pinned official release tag; neither is a production SDK.
- Local upstream archive hashes are recorded; no independent publisher signature
  was verified. The documented Delphes tarball returns HTTP 404; official pinned
  repository source is used. No Geant4, ML, LLM, HPC or Part 5 work is started.

## Current checkpoint — 2026-10-01

- Full Linux Debug regression: **19/19 suites pass**, 152.71 s. Evidence:
  `docs/developer/part4-final-regression-tests.txt`.
- Scientific-dependency-absent build/regression: **13 pass / 6 explicit skips**,
  16.73 s. Native core, transport, Qt example/card acceptance and smoke run;
  ROOT/collider/research numerical tests skip honestly. Evidence:
  `part4-portable-final-tests.txt`.
- Real RooFit call-budget exhaustion returns status 604, invalid/non-converged result
  and warnings. Scans retain failed fit diagnostics and mark those points Failed.
- Source provenance now includes pinned MadGraph/Delphes source receipts and the
  actual LO/Common source/template fingerprint; LHE initialization PDF identities
  are recorded. Neither a complete compiler/SDK closure nor cross-version bitwise
  equivalence is claimed. Relative private MadGraph output avoids embedding cache
  paths in generated commands.
- Compiler fault injection exposed an upstream export-stage fallback. The
  adapter now selects the identified compiler before export, verifies/records
  make options and isolates compiler settings from the shared SDK. Ten
  dependency-free recovery/compiler contracts pass. Real three-point SM/QED
  parameter scan, unpublished failed compilation, retained diagnostics and
  unchanged shared SDK configuration pass (`part4-model-scan-validation.json`).
  Full compiler-hardening regression: **19/19 pass**, 151.69 s
  (`part4-compiler-regression-tests.txt`).
- Typed binary overlap removal works through core, a common lazy RDataFrame
  collection prepass, standalone export and no-code UI. Controlled Delphes-class
  records verify exact weighted bins/sumw2, reference variations, wrapped phi,
  strict boundaries, one event loop and equivalent export. Core dependency/
  rollback tests and Qt atomic undo/redo/save/reload acceptance pass. Evidence:
  `part4-overlap-core-tests.txt`, `part4-overlap-desktop-tests.txt` and
  `part4-reconstructed-validation.json`. Full regression **19/19 pass**, 168.06 s;
  dependency-absent regression **13 pass / 6 explicit skips**, 16.70 s. Linux
  Release core/worker build passes. Logs use the `part4-overlap-*` prefix.
- Compatible collection union and a distinct mixed electron/muon lepton type
  pass exact union/deduplication weights, same-/mixed-flavour pair bins and eight
  standalone reference exports. A separately cut reference-event action and the
  primary histogram share one loop without accidentally sharing event cuts.
  Core typing and Qt grouped undo/redo/save/reload acceptance pass. Final full
  Linux regression: **19/19 pass**, 184.86 s; dependency-absent regression:
  **13 pass / 6 explicit skips**, 16.86 s. Release core/worker build and four
  core suites pass (desktop is exercised by the Debug build). Evidence uses
  the `part4-collections-*` prefix and `part4-reconstructed-validation.json`.

Remaining subset/acceptance work is explicit in `docs/backends/statistics.md`,
`docs/backends/delphes.md` and the platform harnesses. General UFO/NLO/matching,
arbitrary heterogeneous object combinations and arbitrary raw RooFit source are
not implemented. Production-scale tuning
and sparse-bin statistical coverage are unverified. Part 5 has not started.

## Continuation checkpoint — 2026-10-03

- Repository restored from its saved checkpoint; pinned research/collider SDKs
  and Qt payloads rebuilt without system package installation. ROOT, RooFit,
  RooStats/HistFactory and reconstructed-object numerical references pass again.
- Core-only Release baseline: nine pass / six explicit skips. Fixed a research
  integration test that assumed a directory named `build`; source adapters now
  work across build configurations (`part4-recovery-core-tests.txt`).
- Added identified `sm` / `sm-full` LO model selection. Fixed ignored dependent
  SLHA overrides and explicitly refreshes derived parameters with the upstream
  model equations before generation. Final cards/defaults/changes are recorded.
  Generated model import caches no longer change scientific source identity.
- Three genuine QED references pass: restricted massless SM, unrestricted SM
  with a controlled 20 GeV muon mass, and a changed electromagnetic coupling.
  Cross sections, LHE mass shell/momentum closure, derived W mass, cache reuse,
  shared-SDK isolation and unpublished restricted edits pass. Evidence:
  `part4-model-selection-validation.json`; decision: ADR-028.
- Core typing/persistence/invalidation and 11 recovery/model contracts pass.
  Qt model-choice undo/redo/save/reload acceptance passes. Full restored Linux
  Debug regression: **20/20 suites pass**, 191.09 s; no scientific suite skipped.
  Evidence: `part4-model-regression-tests.txt`. SDK/payload recovery provenance is
  recorded in `part4-recovery-dependencies.json`.
- Release core-only regression: **9 pass / 7 explicit skips**, 1.19 s. Native
  dependency-absent Debug desktop build/regression: **13 pass / 7 explicit
  skips**, 16.96 s (`part4-model-portable-tests.txt`). Qt model editing and
  desktop smoke also pass after eliminating an unrelated hidden-pane type warning.
- Real three-point coupling scan and deliberate compilation failure pass again
  with the refreshed effective cards, immutable point recovery and retained raw
  diagnostics (`part4-model-scan-refresh-tests.txt`). Part 4 remains in progress;
  external-platform limitations above still apply.

## Research acceptance hardening — 2026-10-03

- Entry regression passes **20/20** existing Linux suites, 183.39 s, with all
  scientific dependencies required (`part4-entry-completion-tests.txt`).
- Real multichannel HistFactory inference passes an independent summed Poisson
  reference, shared versus independent nuisance groups, observed counts and
  executable standalone export. Channel disjointness requires explicit consent;
  duplicate histogram reuse is rejected. Legacy one-channel identities are
  unchanged. Evidence: `part4-template-validation.json`, ADR-029.
- Desktop acceptance passes a real four-point two-axis RooStats scan, channel
  consent undo/redo, immutable Run history, save/reload, missing/failed point
  display and native PNG/PDF export (6.63 s). Two-axis plotting uses discrete
  numerical coordinates, not interpolation (`part4-multichannel-desktop-tests.txt`).
- Standalone reconstructed PyROOT now executes native ROOT fits and structured
  RooFit/RooStats actions. Real CMS-response histogram identity, fit parameters,
  errors/status and CLs limit agree with the worker; changed input checksums fail
  before analysis. Raw fit histograms stay separate from display normalization.
  Evidence: `part4-statistical-export-tests.txt`, `part4-pipeline-validation.json`.
- Final scientific/native Debug regression: **20/20 pass**, 221.21 s, no
  scientific skips (`part4-research-acceptance-tests.txt`). Dependency-absent
  native desktop: **13 pass / 7 explicit skips**, 17.54 s. Release core-only:
  **9 pass / 7 explicit skips**, 1.29 s. New plot-only hit-testing/PNG/PDF and
  missing-value contracts run even without scientific dependencies. Updated
  worker engine and broker runner also build in Release mode.
- Current Release reference: 1,000-event cold pipeline **15.209 s / 65.8 input
  events/s**, verified cache reuse 0.198 s, peak sampled PSS 646.8 MiB. Two-thread
  broker lease; startup/JIT still matter. This is a bounded reference, not
  production throughput (`part4-current-release-benchmark.json`). Final evidence
  categories and remaining unsupported subsets are in `part4-research-acceptance.json`.
