#include "apps/desktop/bridge.hpp"
#include "core/graph/graph.hpp"
#include "core/analysis/analysis.hpp"
#include "core/collider/collider.hpp"
#include "runtime/project_store.hpp"
#include <QCoreApplication>
#include <QStandardPaths>
#include <QFileInfo>
#include <QDir>
#include <QSettings>
#include <algorithm>
namespace hep {
Bridge::Bridge(QObject* parent) : QObject(parent),project_{newId(),"Untitled study",{mockWorkflow()},{}},coordinator_(this) {
    const auto folder=QStandardPaths::writableLocation(QStandardPaths::AppDataLocation);
    QDir().mkpath(folder);recoveryPath_=folder+"/recovery.hep.json";
    autosave_.setSingleShot(true);autosave_.setInterval(500);
    connect(&autosave_,&QTimer::timeout,this,&Bridge::checkpoint);
    connect(&coordinator_,&Coordinator::changed,this,[this]{
        emit runtimeChanged();if(!coordinator_.error().isEmpty())setNotice(coordinator_.error());
    });
    connect(&coordinator_,&Coordinator::finalized,this,[this]{
        if(coordinator_.lastRun())project_.runs.push_back(*coordinator_.lastRun());
        checkpoint();emit modelChanged();
    });
    connect(QCoreApplication::instance(),&QCoreApplication::aboutToQuit,this,&Bridge::checkpoint);
    connect(&root_,&RootService::changed,this,[this]{emit runtimeChanged();});
    connect(&root_,&RootService::finished,this,&Bridge::rootFinished);
    connect(&collider_,&RootService::changed,this,[this]{emit runtimeChanged();});
    connect(&collider_,&RootService::finished,this,&Bridge::colliderFinished);
    auto python=qEnvironmentVariable("HEP_COLLIDER_PYTHON");if(python.isEmpty())python=QStandardPaths::findExecutable("python3");if(python.isEmpty())python=QStandardPaths::findExecutable("python");
    collider_.configure(python,QCoreApplication::applicationDirPath()+"/collider_worker/worker.py","hep.collider/1");
    research_.configure(python,QCoreApplication::applicationDirPath()+"/research_worker/worker.py","hep.research/1");
    connect(&research_,&RootService::changed,this,[this]{recordScanPoint();emit runtimeChanged();});
    connect(&research_,&RootService::finished,this,&Bridge::researchFinished);
    connect(&managedRuntime_,&ManagedRuntime::changed,this,[this]{
        emit runtimeChanged();
#ifdef Q_OS_WIN
        if(managedRuntime_.ready()&&!collider_.busy()){
            collider_.configureCommand(managedRuntime_.executable(),managedRuntime_.workerArguments(),"hep.collider/1");collider_.restart();
        }
        if(managedRuntime_.ready()&&!research_.busy()&&managedRuntime_.status().value("health",Json::object()).value("researchAvailable",false)){
            research_.configureCommand(managedRuntime_.executable(),managedRuntime_.researchWorkerArguments(),"hep.research/1");research_.restart();
        }
#endif
    });
    restartWorker();root_.start();
#ifdef Q_OS_WIN
    managedRuntime_.detect();
#else
    collider_.start();const auto sdkManifest=QSettings().value("researchSdkManifest").toString();if(!sdkManifest.isEmpty()&&QFileInfo::exists(sdkManifest))configureResearchSdk(QUrl::fromLocalFile(sdkManifest));research_.start();managedRuntime_.detect();
#endif
}
QString Bridge::projectName() const {return QString::fromStdString(project_.name);}
QVariantList Bridge::nodes() const {
    QVariantList result;
    for(const auto& n : workflow().nodes) {
        bool stale=false;const auto* r=selectedRun(primaryRun_);
        if(r&&r->extensions.contains("nodeHashes"))stale=r->extensions["nodeHashes"].value(n.id.value,"")!=workflowHash(dependencyJson(workflow(),n.id,project_.seed)).toStdString();
        QVariantList ports;
        for(const auto& p : n.ports) ports.push_back(QVariantMap{{"id",QString::fromStdString(p.id.value)},{"direction",p.direction==Direction::Input?"input":"output"},{"type",QString::fromStdString(p.type.name)}});
        result.push_back(QVariantMap{{"id",QString::fromStdString(n.id.value)},{"name",QString::fromStdString(n.name)},{"kind",QString::fromStdString(n.typeId)},{"x",n.x},{"y",n.y},{"ports",ports},{"stale",stale}});
    }return result;
}
QVariantList Bridge::edges() const {
    QVariantList result;
    for(const auto& c : workflow().connections) {
        const auto* a=findNode(workflow(),c.fromNode);const auto* b=findNode(workflow(),c.toNode);
        if(a&&b)result.push_back(QVariantMap{{"from",QString::fromStdString(a->id.value)},{"to",QString::fromStdString(b->id.value)},{"x1",a->x+218},{"y1",a->y+86},{"x2",b->x},{"y2",b->y+86}});
    }return result;
}
QVariantList Bridge::issues() const {
    QVariantList result;
    for(const auto& i : validate(workflow())) result.push_back(QVariantMap{{"code",QString::fromStdString(i.code)},{"message",QString::fromStdString(i.message)}});
    return result;
}
QVariantList Bridge::runs() const {
    QVariantList result;
    const auto hash=workflowHash(scientificJson(workflow(),project_.seed)).toStdString();
    for(auto it=project_.runs.rbegin();it!=project_.runs.rend();++it)result.push_back(QVariantMap{
        {"id",QString::fromStdString(it->id.value)},{"status",QString::fromStdString(it->status)},
        {"started",QString::fromStdString(it->started)},{"stale",it->workflowHash!=hash}});
    return result;
}
QString Bridge::inspector() const {
    if(selected_.isEmpty())return "Select a node to inspect its typed ports and execution semantics.";
    const auto* n=findNode(workflow(),Id(selected_.toStdString()));
    if(!n)return "Select a node.";
    QString text=QString::fromStdString(n->name)+"\n\n"+QString::fromStdString(n->typeId)+"\nVersion "+QString::number(n->version)+"\n\n";
    for(const auto& p : n->ports)text+=(p.direction==Direction::Input?"IN  ":"OUT  ")+QString::fromStdString(p.type.name)+"\n";
    text+="\nDeterministic: "+QString(n->deterministic?"yes":"no")+"\nThread-safe: "+QString(n->threadSafe?"yes":"no")+"\n\nROOT nodes execute through the isolated backend. Mock nodes remain architecture tests only.";
    return text;
}
QString Bridge::progressText() const {if(research_.busy()){const auto& m=research_.metrics();return research_.stage()+" · "+QString::number(m.value("accepted",std::uint64_t(0)))+" events";}if(collider_.busy()){const auto& m=collider_.metrics();return collider_.stage()+" · "+QString::number(m.value("accepted",std::uint64_t(0)))+" / "+QString::number(m.value("target",std::uint64_t(0)))+" events · "+QString::number(m.value("eventsPerSecond",0.),'f',1)+" events/s";}if(root_.busy())return root_.stage();return QString::number(coordinator_.done())+" / "+QString::number(coordinator_.total())+" mock steps";}
double Bridge::progress() const {if(collider_.busy()){const auto& m=collider_.metrics();return m.value("target",0.)?m.value("accepted",0.)/m.value("target",1.):0.;}return coordinator_.total()?static_cast<double>(coordinator_.done())/coordinator_.total():0;}
QString Bridge::logs() const {
    QString result;
    for(const auto& row : coordinator_.logs())result+=QString::fromStdString(row.at("timestamp").get<std::string>()+"  "+row.at("severity").get<std::string>()+"  ["+row.at("subsystem").get<std::string>()+"] "+row.at("message").get<std::string>())+"\n";
    result+=root_.diagnostics()+"\n"+collider_.diagnostics()+"\n"+research_.diagnostics();return result;
}
QString Bridge::resources() const {const auto& h=coordinator_.broker().hardware();return QString::fromStdString(h.platform)+" · "+QString::fromStdString(h.architecture)+"\n"+QString::number(h.logicalCpus)+" logical CPUs\n"+(h.physicalMemoryBytes?QString::number(static_cast<double>(*h.physicalMemoryBytes)/(1024*1024*1024),'f',1)+" GiB physical RAM":"RAM unknown")+"\nMock worker: 1 allocated thread\nGPU / NUMA: not detected";}
bool Bridge::recoveryAvailable() const {return QFileInfo::exists(recoveryPath_);}
void Bridge::setNotice(const QString& text) {notice_=text;emit noticeChanged();}
void Bridge::edited() {emit modelChanged();autosave_.start();}
void Bridge::newProject(bool jets) {
    if(busy())return;
    histories_.clear();
    project_={newId(),jets?"Mock jet study":"Mock particle study",{mockWorkflow(jets)}, {}};selected_.clear();colliderPreview_=Json::object();
    setNotice("New mock study. Save it to keep a named copy.");edited();
}
void Bridge::addNode(const QString& kind) {
    if(busy())return;
    try{auto n=mockNode(kind.toStdString(),newId(),40+static_cast<double>(workflow().nodes.size()%3)*260,270+static_cast<double>(workflow().nodes.size()/3)*145);selected_=QString::fromStdString(n.id.value);history().execute(workflow(),NodeEdit{std::nullopt,n,{}});edited();}
    catch(const std::exception& e){setNotice(QString::fromUtf8(e.what()));}
}
void Bridge::select(const QString& id) {selected_=id;emit modelChanged();}
void Bridge::moveNode(const QString& id,double x,double y) {
    if(busy())return;
    for(auto& n : workflow().nodes)if(n.id.value==id.toStdString()){const auto nx=std::clamp(x,0.,3500.),ny=std::clamp(y,0.,1800.);if(n.x!=nx||n.y!=ny)history().execute(workflow(),MoveEdit{n.id,n.x,n.y,nx,ny});edited();return;}
}
void Bridge::removeSelected() {
    if(busy()||selected_.isEmpty())return;
    const auto id=Id(selected_.toStdString());
    const auto* node=findNode(workflow(),id);if(!node)return;
    std::vector<Connection> removed;for(const auto& c:workflow().connections)if(c.fromNode==id||c.toNode==id)removed.push_back(c);
    history().execute(workflow(),NodeEdit{*node,std::nullopt,removed});selected_.clear();colliderPreview_=Json::object();edited();
}
void Bridge::disconnectInput(const QString& id) {
    if(busy())return;
    auto edges=workflow().connections;for(const auto& c:edges)if(c.toNode.value==id.toStdString())history().execute(workflow(),EdgeEdit{c,false});edited();
}
bool Bridge::connectNodes(const QString& from,const QString& to) {
    if(busy())return false;
    try {
        history().execute(workflow(),EdgeEdit{{Id(from.toStdString()),Id("out"),Id(to.toStdString()),Id("in")},true});
        setNotice("Connected compatible ports.");edited();return true;
    }catch(const std::exception& e){setNotice(QString::fromUtf8(e.what()));return false;}
}
bool Bridge::save(const QUrl& file) {
    try{if(!file.isLocalFile())throw std::invalid_argument("Choose a local project file");saveProject(project_,file.toLocalFile());setNotice("Project saved.");return true;}
    catch(const std::exception& e){setNotice(QString::fromUtf8(e.what()));return false;}
}
bool Bridge::open(const QUrl& file) {
    if(busy())return false;
    try{if(!file.isLocalFile())throw std::invalid_argument("Choose a local project file");auto loaded=loadProject(file.toLocalFile());project_=std::move(loaded);histories_.clear();selected_.clear();colliderPreview_=Json::object();schema_=Json::object();rootObjects_=Json::array();preview_=Json::object();researchPreview_=Json::object();
        if(project_.extensions.contains("scans"))for(auto& scan:project_.extensions["scans"])if(scan.value("state",std::string())=="running")scan["state"]="interrupted";
        setNotice("Project opened.");edited();return true;}
    catch(const std::exception& e){setNotice(QString::fromUtf8(e.what()));return false;}
}
void Bridge::recover() {open(QUrl::fromLocalFile(recoveryPath_));}
void Bridge::run() {for(const auto& n:workflow().nodes)if(n.typeId.starts_with("hep.research.")){runResearch();return;}for(const auto& n:workflow().nodes)if(n.typeId.starts_with("hep.collider.")){runCollider();return;}if(!workflow().nodes.empty()&&workflow().nodes.front().typeId.starts_with("hep.root.")){runRoot();return;}if(project_.environment!="hep-env://mock/1"){setNotice("This project requires an unsupported environment; its pin was preserved.");return;}if(coordinator_.submit(workflow(),project_.seed)){setNotice("Running mock lifecycle test — no simulated events or physics results.");checkpoint();}}
void Bridge::cancel(){if(research_.busy())research_.cancel();else if(collider_.busy())collider_.cancel();else if(root_.busy())root_.cancel();else coordinator_.cancel();}
void Bridge::crashWorker(){if(research_.busy())research_.crash();else if(collider_.busy())collider_.crash();else if(root_.busy())root_.crash();else coordinator_.killWorker();}
QString Bridge::workerPath() const {
    return QCoreApplication::applicationDirPath()+"/hep-worker"
#ifdef Q_OS_WIN
    ".exe"
#endif
    ;
}
void Bridge::restartWorker(){coordinator_.launch(workerPath());}
void Bridge::checkpoint() {
    try {
        auto recovery=project_;
        if(coordinator_.activeRun()) {
            auto interrupted=*coordinator_.activeRun();interrupted.status="Interrupted";interrupted.ended=ipc::utcNow();
            interrupted.result={{"mockOnly",true},{"valid",false},{"partial",true},{"reason","Recovered active job after application exit"}};
            recovery.runs.push_back(interrupted);
        }
        if(colliderRun_){auto r=*colliderRun_;r.status="Interrupted";r.ended=ipc::utcNow();r.result={{"valid",false},{"partial",true}};recovery.runs.push_back(r);}
        if(rootRun_){auto r=*rootRun_;r.status="Interrupted";r.ended=ipc::utcNow();r.result={{"valid",false},{"partial",true}};recovery.runs.push_back(r);}
        if(researchRun_){auto r=*researchRun_;r.status="Interrupted";r.ended=ipc::utcNow();r.result={{"valid",false},{"partial",true}};recovery.runs.push_back(r);}
        if(recovery.extensions.contains("scans"))for(auto& scan:recovery.extensions["scans"])if(scan.value("state",std::string())=="running")scan["state"]="interrupted";
        saveProject(recovery,recoveryPath_);
    }catch(const std::exception& e){setNotice("Autosave failed: "+QString::fromUtf8(e.what()));}
}
}
