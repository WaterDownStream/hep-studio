#pragma once
#include "runtime/coordinator/coordinator.hpp"
#include "core/project/project.hpp"
#include <QVariantList>
#include <QUrl>
#include "core/editing/editing.hpp"
#include "runtime/root/service.hpp"
#include "runtime/environment/managed_runtime.hpp"
#include <map>
namespace hep {
class Bridge final : public QObject {
    Q_OBJECT
    Q_PROPERTY(QString projectName READ projectName NOTIFY modelChanged)
    Q_PROPERTY(QVariantList nodes READ nodes NOTIFY modelChanged)
    Q_PROPERTY(QVariantList edges READ edges NOTIFY modelChanged)
    Q_PROPERTY(QVariantList issues READ issues NOTIFY modelChanged)
    Q_PROPERTY(QVariantList runs READ runs NOTIFY modelChanged)
    Q_PROPERTY(QString inspector READ inspector NOTIFY modelChanged)
    Q_PROPERTY(QString workerState READ workerState NOTIFY runtimeChanged)
    Q_PROPERTY(QString jobState READ jobState NOTIFY runtimeChanged)
    Q_PROPERTY(QString progressText READ progressText NOTIFY runtimeChanged)
    Q_PROPERTY(double progress READ progress NOTIFY runtimeChanged)
    Q_PROPERTY(bool busy READ busy NOTIFY runtimeChanged)
    Q_PROPERTY(QString notice READ notice NOTIFY noticeChanged)
    Q_PROPERTY(QString logs READ logs NOTIFY runtimeChanged)
    Q_PROPERTY(QString resources READ resources CONSTANT)
    Q_PROPERTY(QString selectedId READ selectedId NOTIFY modelChanged)
    Q_PROPERTY(bool recoveryAvailable READ recoveryAvailable NOTIFY modelChanged)
    Q_PROPERTY(QVariantList workflows READ workflows NOTIFY modelChanged)
    Q_PROPERTY(QString activeWorkflowId READ activeWorkflowId NOTIFY modelChanged)
    Q_PROPERTY(bool canUndo READ canUndo NOTIFY modelChanged)
    Q_PROPERTY(bool canRedo READ canRedo NOTIFY modelChanged)
    Q_PROPERTY(QString datasetInfo READ datasetInfo NOTIFY modelChanged)
    Q_PROPERTY(QString rootStatus READ rootStatus NOTIFY runtimeChanged)
    Q_PROPERTY(QVariantList rootObjects READ rootObjects NOTIFY modelChanged)
    Q_PROPERTY(QVariantList columns READ columns NOTIFY modelChanged)
    Q_PROPERTY(QVariantMap previewData READ previewData NOTIFY modelChanged)
    Q_PROPERTY(QVariantList plotSeries READ plotSeries NOTIFY modelChanged)
    Q_PROPERTY(QVariantList fitCurve READ fitCurve NOTIFY modelChanged)
    Q_PROPERTY(QString fitDiagnostics READ fitDiagnostics NOTIFY modelChanged)
    Q_PROPERTY(QString generatedCode READ generatedCode NOTIFY modelChanged)
    Q_PROPERTY(QString provenance READ provenance NOTIFY modelChanged)
    Q_PROPERTY(QString comparison READ comparison NOTIFY modelChanged)
    Q_PROPERTY(QVariantMap selectedConfig READ selectedConfig NOTIFY modelChanged)
    Q_PROPERTY(QString selectedKind READ selectedKind NOTIFY modelChanged)
    Q_PROPERTY(QVariantMap plotSettings READ plotSettings NOTIFY modelChanged)
    Q_PROPERTY(QVariantMap pdfData READ pdfData NOTIFY modelChanged)
    Q_PROPERTY(QVariantMap managedRuntime READ managedRuntime NOTIFY runtimeChanged)
    Q_PROPERTY(QVariantMap colliderInfo READ colliderInfo NOTIFY runtimeChanged)
    Q_PROPERTY(QVariantList colliderEvents READ colliderEvents NOTIFY modelChanged)
    Q_PROPERTY(bool colliderPreviewActive READ colliderPreviewActive NOTIFY modelChanged)
    Q_PROPERTY(QVariantMap generatorSettings READ generatorSettings NOTIFY modelChanged)
    Q_PROPERTY(QString executionPlacement READ executionPlacement NOTIFY modelChanged)
    Q_PROPERTY(QVariantList samples READ samples NOTIFY modelChanged)
    Q_PROPERTY(QVariantMap researchInfo READ researchInfo NOTIFY runtimeChanged)
    Q_PROPERTY(QVariantMap researchPreview READ researchPreview NOTIFY modelChanged)
    Q_PROPERTY(QVariantList parameterBindings READ parameterBindings NOTIFY modelChanged)
    Q_PROPERTY(QVariantList scans READ scans NOTIFY modelChanged)
    Q_PROPERTY(QVariantList systematics READ systematics NOTIFY modelChanged)
    Q_PROPERTY(QVariantList histogramReferences READ histogramReferences NOTIFY modelChanged)
    Q_PROPERTY(QVariantMap statisticalResult READ statisticalResult NOTIFY modelChanged)
    Q_PROPERTY(QVariantMap recommendedScan READ recommendedScan NOTIFY modelChanged)
public:
    explicit Bridge(QObject* parent=nullptr);
    QString projectName() const;
    QVariantList nodes() const;
    QVariantList edges() const;
    QVariantList issues() const;
    QVariantList runs() const;
    QString inspector() const;
    QString workerState() const {return coordinator_.workerState();}
    QString jobState() const {return research_.busy()?research_.stage():collider_.busy()?collider_.stage():root_.busy()?root_.stage():coordinator_.jobState();}
    QString progressText() const;
    double progress() const;
    bool busy() const {return coordinator_.busy()||root_.busy()||collider_.busy()||research_.busy();}
    QString notice() const {return notice_;}
    QString logs() const;
    QString resources() const;
    QString selectedId() const {return selected_;}
    bool recoveryAvailable() const;
    Q_INVOKABLE void newProject(bool jets=false);
    Q_INVOKABLE void addNode(const QString& kind);
    Q_INVOKABLE void select(const QString& id);
    Q_INVOKABLE void moveNode(const QString& id,double x,double y);
    Q_INVOKABLE void removeSelected();
    Q_INVOKABLE void disconnectInput(const QString& id);
    Q_INVOKABLE bool connectNodes(const QString& from,const QString& to);
    Q_INVOKABLE bool save(const QUrl& file);
    Q_INVOKABLE bool open(const QUrl& file);
    Q_INVOKABLE void recover();
    Q_INVOKABLE void run();
    Q_INVOKABLE void cancel();
    Q_INVOKABLE void crashWorker();
    Q_INVOKABLE void restartWorker();
    Q_INVOKABLE void checkpoint();
    Q_INVOKABLE void setNotice(const QString&);
    QVariantList workflows()const;
    QString activeWorkflowId()const;
    bool canUndo()const;bool canRedo()const;
    QString rootStatus()const;QString datasetInfo()const;
    QVariantList rootObjects()const;QVariantList columns()const;QVariantMap previewData()const;
    QVariantList plotSeries()const;QVariantList fitCurve()const;
    QString fitDiagnostics()const;QString generatedCode()const;QString provenance()const;QString comparison()const;
    QVariantMap selectedConfig()const;QString selectedKind()const;QVariantMap plotSettings()const;
    Q_INVOKABLE void switchToWorkflow(const QString& id);
    Q_INVOKABLE void createWorkflow(const QString& name);
    Q_INVOKABLE void renameWorkflow(const QString& name);
    Q_INVOKABLE void duplicateWorkflow();
    Q_INVOKABLE void deleteWorkflow();
    Q_INVOKABLE void undo();Q_INVOKABLE void redo();
    Q_INVOKABLE void inspectRoot(const QUrl& file);
    Q_INVOKABLE void selectRootObject(const QString& path,const QString& kind);
    Q_INVOKABLE void previewRoot(int offset,int limit);
    Q_INVOKABLE void setColumnUnit(const QString& column,const QString& unit);
    Q_INVOKABLE void addAnalysisNode(const QString& kind,const QVariantMap& config);
    Q_INVOKABLE void updateAnalysisNode(const QVariantMap& config);
    Q_INVOKABLE void chooseRuns(int primary,int overlay);
    Q_INVOKABLE void restartRoot();
    Q_INVOKABLE QString expressionSummary(const QVariantMap&)const;
    Q_INVOKABLE void setPlotSettings(const QVariantMap& settings);
    Q_INVOKABLE void exportCode(const QUrl& file);
    QVariantMap pdfData()const;
    Q_INVOKABLE void queryPdfSets();
    Q_INVOKABLE void evaluatePdf(const QString& set,int member,int flavour,double xmin,double xmax,double q);
    Q_INVOKABLE void installPdf(const QString& set);
    QVariantMap managedRuntime()const;
    Q_INVOKABLE void detectManagedRuntime();
    Q_INVOKABLE void setupWsl();
    Q_INVOKABLE void repairRuntimeBundle(const QUrl& file);
    Q_INVOKABLE void installRuntimeImage(const QUrl& file);
    QVariantMap colliderInfo()const;QVariantList colliderEvents()const;QVariantMap generatorSettings()const;
    QString executionPlacement()const;QVariantList samples()const;
    Q_INVOKABLE void newColliderWorkflow(bool example=true);
    Q_INVOKABLE void addColliderNode(const QString& kind);
    Q_INVOKABLE void previewCollider(int events=10);
    Q_INVOKABLE void queryGeneratorSettings(const QString& search,bool changedOnly=false);
    Q_INVOKABLE void restartCollider();
    Q_INVOKABLE void pinEnvironment();
    Q_INVOKABLE void exportHepMCSample(const QString& id,const QUrl& file);
    Q_INVOKABLE void storeHepMC(const QUrl& file);
    Q_INVOKABLE void storeRuntimeSample();
    Q_INVOKABLE void openHepMC(const QUrl& file);
    Q_INVOKABLE void reuseSample(const QString& resourceId);
    Q_INVOKABLE void relinkSample(const QString& resourceId,const QUrl& file);
    Q_INVOKABLE void exportGeneratorConfiguration(const QUrl& file);
    bool colliderPreviewActive()const{return colliderPreview_.value("preview",false);}
    RootService& colliderService(){return collider_;}
    RootService& rootService(){return root_;}
    RootService& researchService(){return research_;}
    QVariantMap researchInfo()const;QVariantMap researchPreview()const;
    QVariantList parameterBindings()const;QVariantList scans()const;QVariantList systematics()const;
    QVariantList histogramReferences()const;
    QVariantMap statisticalResult()const;
    QVariantMap recommendedScan()const;
    Q_INVOKABLE QVariantMap parameterScanPlot(const QString& scanId,const QString& quantity)const;
    Q_INVOKABLE void runParameterScan(const QVariantMap& specification);
    Q_INVOKABLE void setSystematics(const QVariantList& specifications);
    Q_INVOKABLE void configureResearchSdk(const QUrl& manifest);
    Q_INVOKABLE void recoverResearchScans();
    Q_INVOKABLE void newResearchWorkflow();
    Q_INVOKABLE void newTemplateWorkflow();
    Q_INVOKABLE void addResearchNode(const QString& kind);
    Q_INVOKABLE QVariantList researchCollections()const;
    Q_INVOKABLE void addOverlapRemoval(const QString& reference);
    Q_INVOKABLE void addCollectionCombine(const QString& reference);
    Q_INVOKABLE void previewResearch(int events=10);
    Q_INVOKABLE void previewReconstruction(int offset=0,int limit=20);
    Q_INVOKABLE void restartResearch();
    Q_INVOKABLE void inspectResearchCards();
    Q_INVOKABLE void exportResearchEvidence(const QUrl& file);
    Q_INVOKABLE void selectDetectorCard(const QUrl& file);
    Coordinator& coordinator(){return coordinator_;}
    Project& project(){return project_;}
    QString workerPath() const;
signals:
    void modelChanged();void runtimeChanged();void noticeChanged();
private:
    void addBinaryResearchNode(const std::string& kind,const QString& reference);
    Workflow& workflow(){return hep::activeWorkflow(project_);}
    const Workflow& workflow() const {return hep::activeWorkflow(project_);}
    void edited();
    History& history(){return histories_[workflow().id.value];}
    void rootFinished(bool success,bool cancelled);
    void runRoot();
    void runCollider(bool preview=false,int events=10);
    void colliderFinished(bool success,bool cancelled);
    void runResearch(bool preview=false,int events=10);
    void researchFinished(bool success,bool cancelled);
    void recordScanPoint();
    void installSource(const Json& schema);
    const Run* selectedRun(int index)const;
    Json hashes()const;
    Json displayedResults()const;
    std::map<std::string,History> histories_;
    RootService root_;
    ManagedRuntime managedRuntime_;
    RootService collider_;Json colliderPreview_=Json::object(),generatorSettings_=Json::object(),pdfData_=Json::object();
    std::string pendingSampleId_;bool openingSample_{false};Json pendingSampleLocation_=Json::object();
    std::optional<Run> colliderRun_;std::optional<ResourceLease> colliderLease_;
    Json rootObjects_=Json::array(),schema_=Json::object(),preview_=Json::object(),storedHistogram_=Json::object();
    QString rootPath_,rootObject_;int primaryRun_{0},overlayRun_{-1};
    std::optional<Run> rootRun_;
    std::optional<ResourceLease> rootLease_;
    RootService research_;Json researchPreview_=Json::object();
    std::optional<Run> researchRun_;std::optional<ResourceLease> researchLease_;
    Json activeScan_=Json::object();

    Project project_;
    Coordinator coordinator_;
    QString selected_,notice_,recoveryPath_;
    QTimer autosave_;
};
}
