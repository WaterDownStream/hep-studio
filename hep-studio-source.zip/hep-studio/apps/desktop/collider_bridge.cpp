#include "apps/desktop/bridge.hpp"
#include "core/collider/collider.hpp"
#include "core/scheduler/placement.hpp"
#include "core/graph/graph.hpp"
#include "runtime/project_store.hpp"
#include <QCoreApplication>
#include <QStandardPaths>
#include <QJsonDocument>
#include <QFileInfo>
#include <QDir>
#include <QRegularExpression>
#include <QSaveFile>
#include <algorithm>
namespace hep {
static QVariant variant(const Json& j){return QJsonDocument::fromJson(QByteArray::fromStdString(j.dump())).toVariant();}
QVariantMap Bridge::pdfData()const{return variant(pdfData_).toMap();}
void Bridge::queryPdfSets(){if(!busy()&&!collider_.request("pdfSets",Json::object()))setNotice(collider_.error());}
void Bridge::evaluatePdf(const QString& set,int member,int flavour,double xmin,double xmax,double q){if(!busy()&&!collider_.request("pdfEvaluate",{{"set",set.toStdString()},{"member",member},{"flavour",flavour},{"xMin",xmin},{"xMax",xmax},{"Q",q},{"points",150}}))setNotice(collider_.error());}
void Bridge::installPdf(const QString& set){if(!busy()&&!collider_.request("pdfInstall",{{"set",set.toStdString()},{"approved",true},{"maxDownloadMiB",100}}))setNotice(collider_.error());}
QVariantMap Bridge::managedRuntime()const{return variant(managedRuntime_.status()).toMap();}
void Bridge::detectManagedRuntime(){if(!busy())managedRuntime_.detect();}
void Bridge::setupWsl(){if(!busy())managedRuntime_.requestWslSetup();}
void Bridge::repairRuntimeBundle(const QUrl& file){if(!busy()&&file.isLocalFile()){collider_.shutdown();managedRuntime_.installBundle(file.toLocalFile());}}
void Bridge::installRuntimeImage(const QUrl& file){if(!busy()&&file.isLocalFile())managedRuntime_.importImage(file.toLocalFile(),QStandardPaths::writableLocation(QStandardPaths::GenericDataLocation)+"/HEPStudio/WSL");}
QVariantMap Bridge::colliderInfo()const{auto c=collider_.capability();c["state"]=collider_.state().toStdString();c["error"]=collider_.error().toStdString();c["metrics"]=collider_.metrics();c["transport"]=collider_.transportMetrics();return variant(c).toMap();}
QVariantList Bridge::colliderEvents()const{
    if(colliderPreview_.contains("events"))return variant(colliderPreview_["events"]).toList();
    const auto* r=selectedRun(primaryRun_);return r?variant(r->result.value("events",Json::array())).toList():QVariantList();
}
QVariantMap Bridge::generatorSettings()const{return variant(generatorSettings_).toMap();}
QString Bridge::executionPlacement()const{const auto* r=selectedRun(primaryRun_);return r?QString::fromStdString(r->extensions.value("placement",Json::object()).dump(2)):"Run to inspect actual placement.";}
QVariantList Bridge::samples()const{
    Json out=Json::array();const auto resources=project_.extensions.value("resources",Json::object());for(const auto& [id,r]:resources.items()){
        auto row=r;row["id"]=id;row["available"]=false;
        for(const auto& l:r.value("locations",Json::array()))if(l.value("runtimeId","")=="native")row["available"]=QFileInfo::exists(QString::fromStdString(l.value("path","")));
        out.push_back(row);
    }return variant(out).toList();
}
void Bridge::newColliderWorkflow(bool example){
    if(busy())return;
    createWorkflow("Collider analysis");colliderPreview_=Json::object();
    addColliderNode("Pythia");
    if(example){for(const auto* kind:{"ClusterJets","CollectionFilter","CollectionSort","CollectionTake","Property","Histo1D"})addColliderNode(kind);}
}
void Bridge::addColliderNode(const QString& kind){
    if(busy())return;
    try{
        const auto k=kind.toStdString();const bool root=k=="Histo1D"||k=="Define"||k=="Filter"||k=="Fit"||k=="Count"||k=="Mean"||k=="Sum";
        auto n=root?rootNode(k,newId()):colliderNode(k,newId());
        if(k=="Histo1D")n.extensions["config"]={{"expression",columnExpression("value")},{"bins",50},{"lower",0.},{"upper",500.},{"normalization","counts"},{"flow","separate"}};
        if(k=="Fit")n.extensions["config"]={{"model","gaussian"}};
        if(k=="Define")n.extensions["config"]={{"name","observable"},{"expression",columnExpression("value")}};
        if(k=="Filter")n.extensions["config"]={{"expression",{{"op","gt"},{"args",Json::array({columnExpression("value"),literalExpression(30,"GeV")})}}}};
        std::optional<Id> input;
        for(const auto& port:n.ports)if(port.direction==Direction::Input){
            for(const auto& candidate:workflow().nodes)for(const auto& output:candidate.ports)if(output.direction==Direction::Output&&output.type==port.type){
                if(!input||candidate.id.value==selected_.toStdString())input=candidate.id;
            }
            if(!input)throw std::invalid_argument("Add/select a compatible upstream node first");
        }
        n.x=40+static_cast<double>(workflow().nodes.size()%3)*260;n.y=85+static_cast<double>(workflow().nodes.size()/3)*160;
        history().execute(workflow(),NodeEdit{std::nullopt,n,{}});
        if(input)history().execute(workflow(),EdgeEdit{{*input,Id("out"),n.id,Id("in")},true});
        selected_=QString::fromStdString(n.id.value);edited();
    }catch(const std::exception& e){setNotice(e.what());}
}
void Bridge::runCollider(bool preview,int events){
    if(busy())return;
    try{
        auto lowering=lowerCollider(workflow());if(preview)lowering["requiredThreads"]=1;const auto& capability=collider_.capability();
        unsigned workers=1;
        if(!preview)for(const auto& node:workflow().nodes)if(node.typeId=="hep.collider.Pythia"){
            const auto count=node.extensions.at("config").value("workers",1);
            if(count<1||count>32)throw std::invalid_argument("Generator workers must be in [1,32]");
            workers=static_cast<unsigned>(count);
        }
        const std::uint64_t memory=std::uint64_t(workers)*512*1024*1024;
        const auto runtimeId=capability.value("runtimeId","native");const auto env=capability.value("environment",Json::object());
        WorkerCandidate worker{runtimeId,env.value("platform",""),capability.value("libraries",Json::object()),env,std::max(1U,coordinator_.broker().hardware().logicalCpus-1),collider_.state()=="Healthy"};
        Json resources=Json::object();std::vector<ResourceLocation> locations;
        for(const auto& node:workflow().nodes)if(node.typeId=="hep.collider.HepMCSource"||node.typeId=="hep.collider.StoreHepMC"){
            const auto id=node.extensions.at("config").at("resourceId").get<std::string>();const auto& r=project_.extensions.at("resources").at(id);bool found=false;
            for(const auto& l:r.at("locations"))if(l.value("runtimeId","")==runtimeId){
                const bool available=runtimeId!="native"||QFileInfo::exists(QString::fromStdString(l.at("path")));
                if(node.typeId=="hep.collider.HepMCSource")locations.push_back({runtimeId,l.value("kind","local"),l.at("path"),available,r.value("sizeBytes",std::uint64_t(0))});
                resources[id]={{"path",l.at("path")},{"eventCount",r.value("eventCount",std::uint64_t(1000000000))},{"sha256",r.value("sha256",std::string())},{"identity",r.value("identity",Json::object())}};found=true;break;
            }
            if(!found)throw std::invalid_argument("Sample unavailable in this runtime; relink its physical location");
        }
        const auto placement=placeWorkflow(lowering,{worker},locations,workflow().extensions.value("placementOverride",std::string()));
        const auto preferred=project_.extensions.value("preferredEnvironment",Json::object());const auto differences=environmentDifferences(preferred,env);
        colliderLease_=coordinator_.broker().acquire({workers,memory});if(!colliderLease_)throw std::runtime_error("Scientific thread/memory budget is busy");
        Json payload={{"workflow",workflowJson(workflow())},{"projectSeed",project_.seed},{"resources",resources},{"previewEvents",events},{"allocatedThreads",workers},{"environmentDifference",differences}};
        if(!collider_.request(preview?"eventPreview":"execute",payload)){coordinator_.broker().release(colliderLease_->id);colliderLease_.reset();throw std::runtime_error(collider_.error().toStdString());}
        colliderPreview_=Json::object();
        if(!preview){
            colliderRun_=Run{newId(),"Running",workflowJson(workflow()),workflowHash(scientificJson(workflow(),project_.seed)).toStdString()};
            auto& run=*colliderRun_;run.started=ipc::utcNow();run.backend="hep.collider/1";run.environment=env.value("id","");run.seed=project_.seed;
            run.resources=hardwareJson(coordinator_.broker().hardware());run.resources["allocatedThreads"]=workers;run.resources["reservedMemoryBytes"]=memory;
            run.extensions["nodeHashes"]=hashes();run.extensions["workflowRevision"]=workflowHash(run.workflowSnapshot).toStdString();run.extensions["placement"]=placement.json();run.extensions["frozenEnvironment"]=env;run.extensions["environmentDifference"]=differences;
            if(preferred.empty())project_.extensions["preferredEnvironment"]=env;
            checkpoint();
        }
        setNotice(differences.empty()?(preview?"PREVIEW — no publication Run":"Collider Run started"):"Environment differs from the preferred environment. Differences are recorded in provenance.");
    }catch(const std::exception& e){if(colliderLease_&&!collider_.busy()){coordinator_.broker().release(colliderLease_->id);colliderLease_.reset();}setNotice(e.what());}
}
void Bridge::previewCollider(int events){runCollider(true,events);}
void Bridge::colliderFinished(bool success,bool cancelled){
    if(colliderLease_){coordinator_.broker().release(colliderLease_->id);colliderLease_.reset();}
    if(colliderRun_){
        auto& run=*colliderRun_;run.status=success?"Completed":cancelled?"Cancelled":collider_.state()=="Crashed"?"Interrupted":"Failed";run.ended=ipc::utcNow();
        run.extensions["transport"]=collider_.transportMetrics();
        run.result=success?collider_.result():Json{{"valid",false},{"partial",true},{"message",collider_.error().toStdString()}};
        run.logs.push_back({{"timestamp",ipc::utcNow()},{"severity",success?"Info":"Error"},{"subsystem","Collider"},{"message",collider_.diagnostics().toStdString()}});
        if(success)for(const auto& sample:run.result.value("samples",Json::array())){
            auto& r=project_.extensions["resources"][sample.at("resourceId").get<std::string>()];r.update(sample);r.erase("path");r["creationRun"]=run.id.value;
        }
        project_.runs.push_back(run);colliderRun_.reset();primaryRun_=0;storedHistogram_=Json::object();checkpoint();
    }else if(success){
        if(collider_.operation()=="eventPreview")colliderPreview_=collider_.result();
        if(collider_.operation()=="settings")generatorSettings_=collider_.result();
        if(collider_.operation().starts_with("pdf"))pdfData_.update(collider_.result());
        if(collider_.operation()=="prepareSample"){
            const auto& destination=collider_.result().at("sampleDestination");const auto id=destination.at("resourceId").get<std::string>();
            project_.extensions["resources"][id]={{"logicalUri","hep://sample/"+id},{"name","Generated sample "+id.substr(0,8)},{"format","HepMC3"},{"locations",Json::array({{{"runtimeId",destination.at("runtimeId")},{"kind","local"},{"path",destination.at("path")}}})}};
            addColliderNode("StoreHepMC");if(selectedKind()=="StoreHepMC"){auto c=selectedConfig();c["resourceId"]=QString::fromStdString(id);updateAnalysisNode(c);}
        }
        if(collider_.operation()=="inspectSample"&&!pendingSampleId_.empty()){
            auto& resource=project_.extensions["resources"][pendingSampleId_];const auto previousHash=resource.value("sha256",resource.value("identity",Json::object()).value("sha256",std::string()));
            resource["identity"]=collider_.result().at("sampleIdentity");resource["sizeBytes"]=resource["identity"]["sizeBytes"];resource["locations"]=Json::array({pendingSampleLocation_});
            if(resource["identity"].value("hashStrategy",std::string())=="sha256-full")resource["sha256"]=resource["identity"]["sha256"];else resource.erase("sha256");
            if(!previousHash.empty()&&previousHash!=resource["identity"].at("sha256").get<std::string>())resource["contentChangedSinceCreation"]=true;
            for(auto& w:project_.workflows)for(auto& n:w.nodes)if(n.typeId=="hep.collider.HepMCSource"&&n.extensions.at("config").value("resourceId",std::string())==pendingSampleId_){
                auto c=n.extensions.at("config");const auto before=c; c["resourceContentHash"]=resource["identity"]["sha256"];
                if(c!=before)histories_[w.id.value].execute(w,ConfigEdit{n.id,before,c});
            }
            if(openingSample_)reuseSample(QString::fromStdString(pendingSampleId_));else edited();
        }
    }
    pendingSampleId_.clear();openingSample_=false;
    setNotice(success?(collider_.operation()=="eventPreview"?"PREVIEW complete — not a scientific Run":"Collider operation completed"):collider_.error());emit modelChanged();emit runtimeChanged();
}
void Bridge::queryGeneratorSettings(const QString& search,bool changedOnly){
    if(busy())return;
    Json payload={{"search",search.toStdString()},{"changedOnly",changedOnly}};
    for(const auto& n:workflow().nodes)if(n.typeId=="hep.collider.Pythia"){payload["config"]=n.extensions.at("config");break;}
    if(!collider_.request("settings",payload))setNotice(collider_.error());
}
void Bridge::restartCollider(){if(!busy())collider_.restart();}
void Bridge::pinEnvironment(){if(busy()||!collider_.capability().value("available",false))return;project_.extensions["preferredEnvironment"]=collider_.capability().at("environment");edited();setNotice("Preferred environment updated. Historical Run environments are unchanged.");}
void Bridge::exportHepMCSample(const QString& id,const QUrl& file){
    if(busy()||!file.isLocalFile())return;
    try{
        const auto runtime=collider_.capability().value("runtimeId",std::string("native"));
        const auto& resource=project_.extensions.at("resources").at(id.toStdString());
        for(const auto& location:resource.at("locations"))if(location.value("runtimeId",std::string("native"))==runtime){
            const auto destination=ManagedRuntime::resourceLocation(file.toLocalFile(),runtime);
            if(!collider_.request("exportSample",{{"path",location.at("path")},{"destination",destination.at("path")}})){setNotice(collider_.error());}
            return;
        }
        setNotice("Sample unavailable in this runtime; relink it before export.");
    }catch(const std::exception& error){setNotice(error.what());}
}
void Bridge::storeHepMC(const QUrl& file){
    if(busy()||!file.isLocalFile())return;
    const auto id=newId().value;
    project_.extensions["resources"][id]={{"logicalUri","hep://sample/"+id},{"name",QFileInfo(file.toLocalFile()).fileName().toStdString()},{"format","HepMC3"},{"locations",Json::array({{{"runtimeId","native"},{"kind","local"},{"path",file.toLocalFile().toStdString()}}})}};
    addColliderNode("StoreHepMC");if(selectedKind()=="StoreHepMC"){auto c=selectedConfig();c["resourceId"]=QString::fromStdString(id);updateAnalysisNode(c);}
}
void Bridge::openHepMC(const QUrl& file){
    if(busy()||!file.isLocalFile())return;
    const auto id=newId().value;
    project_.extensions["resources"][id]={{"logicalUri","hep://sample/"+id},{"name",QFileInfo(file.toLocalFile()).fileName().toStdString()},{"format","HepMC3"},{"locations",Json::array({{{"runtimeId","native"},{"kind","local"},{"path",file.toLocalFile().toStdString()}}})}};
    relinkSample(QString::fromStdString(id),file);openingSample_=true;
}
void Bridge::reuseSample(const QString& id){if(busy())return;
    if(!project_.extensions.value("resources",Json::object()).contains(id.toStdString())){setNotice("Unknown sample");return;}
    const auto& r=project_.extensions.at("resources").at(id.toStdString());const auto hash=r.value("sha256",r.value("identity",Json::object()).value("sha256",std::string()));
    createWorkflow("Stored sample analysis");addColliderNode("HepMCSource");auto c=selectedConfig();c["resourceId"]=id;c["resourceContentHash"]=QString::fromStdString(hash);updateAnalysisNode(c);}
void Bridge::storeRuntimeSample(){if(!busy()&&!collider_.request("prepareSample",{{"resourceId",newId().value}}))setNotice(collider_.error());}
void Bridge::relinkSample(const QString& id,const QUrl& file){
    if(busy()||!file.isLocalFile())return;
    try{pendingSampleLocation_=ManagedRuntime::resourceLocation(file.toLocalFile(),collider_.capability().value("runtimeId",std::string("native")));pendingSampleId_=id.toStdString();
        const auto& resource=project_.extensions.at("resources").at(pendingSampleId_);
        const bool full=resource.contains("sha256")||resource.value("identity",Json::object()).value("hashStrategy",std::string())=="sha256-full";
        if(!collider_.request("inspectSample",{{"path",pendingSampleLocation_.at("path")},{"fullChecksum",full}})){pendingSampleId_.clear();setNotice(collider_.error());}
    }catch(const std::exception& e){pendingSampleId_.clear();setNotice(e.what());}
}
void Bridge::exportGeneratorConfiguration(const QUrl& file){
    const auto* run=selectedRun(primaryRun_);if(!run||!file.isLocalFile())return;
    const auto text=QByteArray::fromStdString(run->result.value("generatedConfiguration",std::string()));QSaveFile output(file.toLocalFile());
    if(!output.open(QIODevice::WriteOnly)||output.write(text)!=text.size()||!output.commit())setNotice("Generator configuration export failed");else setNotice("Generator configuration exported");
}
}
