import QtQuick
import QtQuick.Controls
import QtQuick.Layouts
import QtQuick.Dialogs
import HEPStudio 1.0

ColumnLayout {
    id:pane
    property var config:studio.selectedConfig
    property string kind:studio.selectedKind
    function set(key,value){var c=JSON.parse(JSON.stringify(config));c[key]=value;studio.updateAnalysisNode(c)}
    function model(kind) {
        function parameter(v,lo,hi){return {value:v,lower:lo,upper:hi}}
        var mean=parameter(100,80,120),width=parameter(1,0.01,20)
        var value=kind==="Exponential"?{kind:kind,slope:parameter(-0.01,-1,0)}:kind==="Polynomial"?{kind:kind,coefficients:[parameter(0,-0.01,0.01)]}:kind==="Gaussian + Exponential"?{kind:"Sum",components:[{kind:"Gaussian",mean:mean,sigma:width},{kind:"Exponential",slope:parameter(-0.01,-1,0)}],fractions:[parameter(0.8,0,1)]}:kind==="BreitWigner"?{kind:kind,mean:mean,width:width}:{kind:"Gaussian",mean:mean,sigma:width}
        pane.set("model",value)
    }
    function fitParameters(){
        var rows=[]
        function visit(m,path){Object.keys(m||{}).forEach(function(k){var v=m[k],ptr=path.concat([k]);if(v&&typeof v==="object"){if(v.value!==undefined&&v.lower!==undefined)rows.push({path:ptr,name:ptr.join(" / "),parameter:v});else visit(v,ptr)}})}
        visit(config.model||{},[]);return rows
    }
    function setFitParameter(path,key,value){var c=JSON.parse(JSON.stringify(config)),p=c.model;path.forEach(function(k){p=p[k]});p[key]=value;studio.updateAnalysisNode(c)}
    function formula(){editor.expression=JSON.parse(JSON.stringify(config.expression||{op:"column",name:"value"}));formulaDialog.open()}
    Dialog {id:formulaDialog;title:"Structured physics expression";modal:true;anchors.centerIn:parent;width:700;height:580;standardButtons:Dialog.Ok|Dialog.Cancel;ExpressionEditor{id:editor;anchors.fill:parent}onAccepted:pane.set("expression",editor.expression)}
    FileDialog{id:codeSave;title:"Export equivalent configuration";fileMode:FileDialog.SaveFile;onAccepted:studio.exportCode(selectedFile)}
    FileDialog{id:evidenceSave;title:"Export Run evidence";fileMode:FileDialog.SaveFile;nameFilters:["Run evidence (*.json)"];onAccepted:studio.exportResearchEvidence(selectedFile)}
    FileDialog{id:sdkSelect;title:"Select scientific SDK manifest";nameFilters:["Scientific SDK (research-sdk.json)"];onAccepted:studio.configureResearchSdk(selectedFile)}
    FileDialog{id:cardSelect;title:"Select or relink trusted Delphes card bundle";nameFilters:["Delphes card (*.tcl)"];onAccepted:studio.selectDetectorCard(selectedFile)}
    FileDialog{id:figureSave;title:"Export figure";fileMode:FileDialog.SaveFile;nameFilters:["PNG (*.png)","PDF (*.pdf)"];onAccepted:plot.exportFigure(selectedFile)}
    Dialog{id:overlapDialog;property string binaryKind:"OverlapRemoval";title:binaryKind==="OverlapRemoval"?"Remove overlapping objects":"Combine reconstructed collections";modal:true;anchors.centerIn:parent;width:460;standardButtons:Dialog.Ok|Dialog.Cancel
        ColumnLayout{anchors.fill:parent
            Label{text:overlapDialog.binaryKind==="OverlapRemoval"?"Keep selected objects only when no reference object lies within ΔR < radius.":"Combine compatible objects, or electrons and muons as leptons. Each original object appears once; primary ordering comes first.";wrapMode:Text.Wrap;Layout.fillWidth:true}
            Label{text:"Reference collection"}
            ComboBox{id:overlapReference;Layout.fillWidth:true;textRole:"label";model:{var nodes=studio.nodes;return studio.researchCollections().filter(function(c){return c.id!==studio.selectedId})}}
        }
        onAccepted:{if(overlapReference.currentIndex>=0){var reference=overlapReference.model[overlapReference.currentIndex].id;if(binaryKind==="OverlapRemoval")studio.addOverlapRemoval(reference);else studio.addCollectionCombine(reference)}}
    }
    RowLayout {
        Button{text:"New research workflow";enabled:!studio.busy;onClicked:studio.newResearchWorkflow()}
        Button{text:"New template likelihood";enabled:!studio.busy;onClicked:studio.newTemplateWorkflow()}
        ComboBox{id:addKind;model:["MadGraph","Shower","Delphes","Muons","Electrons","Jets","Photons","Tracks","MissingET","CollectionFilter","CollectionSort","CollectionTake","OverlapRemoval","CollectionCombine","Pairs","Property","CollectionCount","HT","Histo1D","Filter","Define","Fit","RooFit","RooStats","TemplateSet","BinnedLikelihood","Inference","Count"]}
        Button{text:"Add";enabled:!studio.busy;onClicked:{if(addKind.currentText==="OverlapRemoval"||addKind.currentText==="CollectionCombine"){overlapDialog.binaryKind=addKind.currentText;overlapDialog.open()}else studio.addResearchNode(addKind.currentText)}}
        Item{Layout.fillWidth:true}
        Button{text:"Generate PREVIEW";enabled:!studio.busy&&!studio.nodes.some(function(n){return n.kind==="hep.research.TemplateSet"});onClicked:studio.previewResearch(10)}
        Button{text:"Full Run";enabled:!studio.busy;onClicked:studio.run()}
        Button{text:"Cancel";enabled:studio.busy;onClicked:studio.cancel()}
    }
    RowLayout {
        Layout.fillHeight:true
        ScrollView {
            Layout.preferredWidth:250;Layout.fillHeight:true;clip:true
            ColumnLayout{width:parent.width
                Repeater{model:studio.nodes;delegate:Button{required property var modelData;text:modelData.name+(modelData.stale?" · STALE":"");Layout.fillWidth:true;highlighted:studio.selectedId===modelData.id;onClicked:studio.select(modelData.id)}}
                Label{text:studio.researchInfo.error||"";color:"#e9ad79";wrapMode:Text.Wrap;Layout.fillWidth:true}
            }
        }
        ColumnLayout {
            Layout.fillWidth:true;Layout.fillHeight:true
            TabBar{id:tabs;Layout.fillWidth:true;TabButton{text:"Configure"}TabButton{text:"Preview / Objects"}TabButton{text:"Plot"}TabButton{text:"Statistics"}TabButton{text:"Runs / Provenance"}TabButton{text:"Campaigns"}TabButton{text:"Runtime"}}
            StackLayout {
                currentIndex:tabs.currentIndex;Layout.fillWidth:true;Layout.fillHeight:true
                ScrollView {
                    clip:true
                    ColumnLayout{width:parent.width;spacing:12
                        Label{text:pane.kind||"Create a research workflow";font.pixelSize:22}
                        Label{text:"Generator particles and reconstructed objects have distinct types. Scientific backends execute in an isolated worker.";wrapMode:Text.Wrap;Layout.fillWidth:true;color:"#9eafbf"}
                        TabBar{id:detail;visible:pane.kind==="MadGraph";TabButton{text:"Essential"}TabButton{text:"Advanced"}TabButton{text:"Research"}}
                        GridLayout{columns:2;visible:pane.kind==="MadGraph"&&detail.currentIndex===0
                            Label{text:"Reference process"}
                            ComboBox{model:["e+ e− → μ+ μ− (photon only)","pp → Z / γ* → μ+ μ−","pp → t t̄","pp → W+ W−","pp → Z Z"]
                                onActivated:{var c=JSON.parse(JSON.stringify(pane.config));c.process={incoming:currentIndex===0?[-11,11]:[2212,2212],outgoing:currentIndex===2?[6,-6]:currentIndex===3?[24,-24]:currentIndex===4?[23,23]:[-13,13],exclude:currentIndex===0?[23]:[]};c.beam={ids:c.process.incoming,energiesGeV:currentIndex===0?[50,50]:[6800,6800]};studio.updateAnalysisNode(c)}}
                            Label{text:"Beam energy A / B [GeV]"}
                            RowLayout{TextField{text:String(((pane.config.beam||{}).energiesGeV||[50,50])[0]||50);validator:DoubleValidator{bottom:0.001} onEditingFinished:{var b=JSON.parse(JSON.stringify(pane.config.beam));b.energiesGeV[0]=Number(text);pane.set("beam",b)}}TextField{text:String(((pane.config.beam||{}).energiesGeV||[50,50])[1]||50);validator:DoubleValidator{bottom:0.001} onEditingFinished:{var b=JSON.parse(JSON.stringify(pane.config.beam));b.energiesGeV[1]=Number(text);pane.set("beam",b)}}}
                            Label{text:"Events"}SpinBox{from:1;to:100000000;editable:true;value:pane.config.events||100;onValueModified:pane.set("events",value)}
                            Label{text:"Integration seed"}SpinBox{from:1;to:30081;editable:true;value:pane.config.seed||24680;onValueModified:pane.set("seed",value)}
                            Label{text:"Model (LO)"}ComboBox{objectName:"madgraphModelSelector";model:["SM — default restrictions","SM — unrestricted parameters"];currentIndex:pane.config.model==="sm-full"?1:0;onActivated:pane.set("model",currentIndex===1?"sm-full":"sm")}
                        }
                        ColumnLayout{visible:pane.kind==="MadGraph"&&detail.currentIndex===1
                            Label{text:"Model parameters use SLHA block:index bindings. Run-card changes are recorded in provenance.";wrapMode:Text.Wrap;Layout.fillWidth:true}
                            Label{text:pane.config.model==="sm-full"?"External SM parameters can be changed. Derived quantities remain model-controlled.":"Default SM restrictions fix some light-particle masses and couplings. Choose the unrestricted model to vary external parameters. Fixed or derived entries are rejected.";wrapMode:Text.Wrap;Layout.fillWidth:true;color:"#9eafbf"}
                            RowLayout{TextField{id:paramKey;placeholderText:"sminputs:1"}TextField{id:paramValue;placeholderText:"132.507";validator:DoubleValidator{}}Button{text:"Set parameter";onClicked:{var p=JSON.parse(JSON.stringify(pane.config.parameters||{}));p[paramKey.text]=Number(paramValue.text);pane.set("parameters",p)}}}
                            RowLayout{TextField{id:cutKey;placeholderText:"ptl"}TextField{id:cutValue;placeholderText:"0";validator:DoubleValidator{}}Button{text:"Set generation cut";onClicked:{var p=JSON.parse(JSON.stringify(pane.config.runCard||{}));p[cutKey.text]=Number(cutValue.text);pane.set("runCard",p)}}}
                        }
                        GridLayout{columns:2;visible:pane.kind==="Shower"
                            Label{text:"Shower physics"}RowLayout{CheckBox{text:"ISR";checked:pane.config.isr!==false;onClicked:pane.set("isr",checked)}CheckBox{text:"FSR";checked:pane.config.fsr!==false;onClicked:pane.set("fsr",checked)}CheckBox{text:"MPI";checked:pane.config.mpi!==false;onClicked:pane.set("mpi",checked)}}
                            Label{text:"Hadronisation"}CheckBox{checked:pane.config.hadronisation!==false;onClicked:pane.set("hadronisation",checked)}
                            Label{text:"Master shower seed"}TextField{text:String(pane.config.seed||"1");validator:IntValidator{bottom:1;top:900000000} onEditingFinished:pane.set("seed",text)}
                            Label{text:"Logical events per stream"}SpinBox{from:1;to:1000000;value:pane.config.partitionEvents||4096;onValueModified:pane.set("partitionEvents",value)}
                            Label{text:"Physical workers"}SpinBox{from:1;to:32;value:pane.config.workers||1;onValueModified:pane.set("workers",value)}
                            Label{text:"Randomness"}Label{text:"Logical ranges and seeds stay fixed when worker count changes.";wrapMode:Text.Wrap;Layout.preferredWidth:360}
                        }
                        GridLayout{columns:2;visible:pane.kind==="Delphes"
                            Label{text:"Detector card"}ComboBox{model:["CMS","ideal-muon","Custom identified bundle"];currentIndex:(pane.config.card||{}).resourceId?2:(pane.config.card||{}).builtin==="ideal-muon"?1:0;onActivated:{if(currentIndex<2)pane.set("card",{builtin:currentText});else cardSelect.open()}}
                            Label{text:"Detector master seed"}SpinBox{from:1;to:2147483647;editable:true;value:pane.config.seed||24680;onValueModified:pane.set("seed",value)}
                            Label{text:"Interpretation"}Label{text:"Ideal-muon is a numerical reference, not a realistic detector.";wrapMode:Text.Wrap;Layout.preferredWidth:360}
                            Button{text:"Select / relink custom card…";onClicked:cardSelect.open()}Label{text:(pane.config.card||{}).resourceId?((pane.config.card||{}).name+" · identified bundle"):"Tcl cards execute configuration: select trusted files.";wrapMode:Text.Wrap;Layout.preferredWidth:360}
                        }
                        RowLayout{visible:pane.kind==="CollectionFilter"||pane.kind==="Filter"||pane.kind==="Define"||pane.kind==="Histo1D";Button{text:"Build expression…";onClicked:pane.formula()}Label{text:studio.expressionSummary(pane.config.expression||{})}}
                        RowLayout{visible:pane.kind==="Pairs";CheckBox{text:"Opposite sign";checked:pane.config.oppositeSign!==false;onClicked:pane.set("oppositeSign",checked)}CheckBox{text:"Same flavour";checked:pane.config.sameFlavour!==false;onClicked:pane.set("sameFlavour",checked)}}
                        RowLayout{visible:pane.kind==="CollectionSort"||pane.kind==="Property";Label{text:"Property"}ComboBox{model:studio.columns.map(function(c){return c.name}).filter(function(n){return n!=="weight"&&n!=="value"});currentIndex:Math.max(0,model.indexOf(pane.config.property));onActivated:pane.set("property",currentText)}}
                        RowLayout{visible:pane.kind==="CollectionTake";Label{text:"Leading N"}SpinBox{from:1;to:10000;value:pane.config.count||1;onValueModified:pane.set("count",value)}}
                        RowLayout{visible:pane.kind==="OverlapRemoval";Label{text:"ΔR radius"}TextField{text:String(pane.config.radius===undefined?0.4:pane.config.radius);validator:DoubleValidator{bottom:0;top:10}onEditingFinished:pane.set("radius",Number(text))}Label{text:"Remove when ΔR < radius"}}
                        Label{visible:pane.kind==="CollectionCombine";text:"Ordered union: primary, then reference; each original object once. Sort explicitly for leading/subleading analysis.";wrapMode:Text.Wrap;Layout.fillWidth:true}
                        GridLayout{columns:2;visible:pane.kind==="Histo1D"
                            Label{text:"Bins"}SpinBox{from:1;to:4096;value:pane.config.bins||40;onValueModified:pane.set("bins",value)}
                            Label{text:"Range [canonical units]"}RowLayout{TextField{text:String(pane.config.lower===undefined?80:pane.config.lower);onEditingFinished:pane.set("lower",Number(text))}TextField{text:String(pane.config.upper===undefined?120:pane.config.upper);onEditingFinished:pane.set("upper",Number(text))}}
                            Label{text:"Yield convention"}ComboBox{model:["raw-weights","cross-section-pb","luminosity"];currentIndex:Math.max(0,model.indexOf(pane.config.yieldMode||"raw-weights"));onActivated:pane.set("yieldMode",currentText)}
                            Label{text:"Luminosity [fb⁻¹]";visible:pane.config.yieldMode==="luminosity"}TextField{visible:pane.config.yieldMode==="luminosity";text:String(pane.config.luminosityFb||100);onEditingFinished:pane.set("luminosityFb",Number(text))}
                        }
                        ColumnLayout{visible:pane.kind==="RooFit"
                            Label{text:"Structured RooFit model";font.bold:true}
                            ComboBox{model:["Gaussian","BreitWigner","Exponential","Polynomial","Gaussian + Exponential"];onActivated:pane.model(currentText)}
                            ComboBox{model:["sumw2","poisson"];currentIndex:pane.config.errorModel==="poisson"?1:0;onActivated:pane.set("errorModel",currentText)}
                            Label{text:"Poisson requires unscaled integer observations. Weighted simulation uses explicit SumW2 covariance correction.";wrapMode:Text.Wrap;Layout.fillWidth:true}
                            Repeater{model:pane.fitParameters();delegate:RowLayout{
                                required property var modelData
                                Label{text:modelData.name;Layout.preferredWidth:150}
                                TextField{placeholderText:"Initial";text:String(modelData.parameter.value);validator:DoubleValidator{} onEditingFinished:pane.setFitParameter(modelData.path,"value",Number(text))}
                                TextField{placeholderText:"Lower bound";text:String(modelData.parameter.lower);validator:DoubleValidator{} onEditingFinished:pane.setFitParameter(modelData.path,"lower",Number(text))}
                                TextField{placeholderText:"Upper bound";text:String(modelData.parameter.upper);validator:DoubleValidator{} onEditingFinished:pane.setFitParameter(modelData.path,"upper",Number(text))}
                                CheckBox{text:"Fixed";checked:modelData.parameter.constant===true;onClicked:pane.setFitParameter(modelData.path,"constant",checked)}
                            }}
                            RowLayout{Label{text:"Polynomial order";visible:(pane.config.model||{}).kind==="Polynomial"}SpinBox{visible:(pane.config.model||{}).kind==="Polynomial";from:1;to:5;value:((pane.config.model||{}).coefficients||[]).length;onValueModified:{var m=JSON.parse(JSON.stringify(pane.config.model));while(m.coefficients.length<value)m.coefficients.push({value:0,lower:-0.001,upper:0.001});m.coefficients=m.coefficients.slice(0,value);pane.set("model",m)}}}
                            Label{text:"Constraints are explicit auxiliary measurements; none are inferred from systematic labels.";wrapMode:Text.Wrap;Layout.fillWidth:true}
                        }
                        ColumnLayout{visible:pane.kind==="TemplateSet";Layout.fillWidth:true
                            Label{text:"Use immutable completed histogram Runs. Signal/background are expected counts at the chosen luminosity; observed data are integer counts. Fold flows upstream or exclude unfolded flow bins.";wrapMode:Text.Wrap;Layout.fillWidth:true}
                            RowLayout{TextField{id:sampleId;placeholderText:"Unique sample identity"}ComboBox{id:sampleRole;model:["signal","background","observed"]}TextField{id:sampleChannel;objectName:"templateChannel";placeholderText:"Channel (default: analysis)"}}
                            ComboBox{id:templateReference;Layout.fillWidth:true;model:studio.histogramReferences;textRole:"label"}
                            CheckBox{id:expectedCounts;text:"Explicitly interpret this histogram as expected event counts (for sources without luminosity metadata)";visible:sampleRole.currentText!=="observed"}
                            Button{objectName:"addTemplate";text:"Add template";enabled:templateReference.count>0&&sampleId.text.length>0;onClicked:{var samples=JSON.parse(JSON.stringify(pane.config.samples||[]));var sample={id:sampleId.text,role:sampleRole.currentText,reference:templateReference.model[templateReference.currentIndex].reference};if(sampleChannel.text.trim().length>0)sample.channel=sampleChannel.text.trim();if(expectedCounts.checked&&sample.role!=="observed")sample.interpretation="expected-event-counts";samples.push(sample);pane.set("samples",samples)}}
                            CheckBox{objectName:"channelIndependence";text:"These channels contain disjoint event categories (independent Poisson counts)";checked:pane.config.channelIndependence==="disjoint-event-categories";onClicked:pane.set("channelIndependence",checked?"disjoint-event-categories":"")}
                            Label{text:"Channels may use different observables and bins. Every channel needs background; observed mode needs data in every channel. Shared correlation groups couple nuisances across channels.";wrapMode:Text.Wrap;Layout.fillWidth:true}
                            Repeater{model:pane.config.samples||[];delegate:RowLayout{required property var modelData;required property int index;Label{text:(modelData.channel||"analysis")+" / "+modelData.id+" / "+modelData.role;Layout.fillWidth:true}Button{text:"Remove";onClicked:{var rows=JSON.parse(JSON.stringify(pane.config.samples));rows.splice(index,1);pane.set("samples",rows)}}}}
                        }
                        ColumnLayout{visible:pane.kind==="BinnedLikelihood";Layout.fillWidth:true
                            GridLayout{columns:2
                                Label{text:"Dataset role"}ComboBox{model:["background-asimov","observed-counts"];currentIndex:pane.config.datasetRole==="observed-counts"?1:0;onActivated:pane.set("datasetRole",currentText)}
                                Label{text:"Signal-strength maximum"}TextField{text:String(pane.config.muMax||5);validator:DoubleValidator{bottom:1.0001} onEditingFinished:pane.set("muMax",Number(text))}
                                Label{text:"Template MC statistics"}ComboBox{model:["none","poisson-gamma"];currentIndex:pane.config.mcStat==="poisson-gamma"?1:0;onActivated:pane.set("mcStat",currentText)}
                            }
                            CheckBox{visible:pane.config.mcStat==="poisson-gamma";text:"I explicitly assume independent effective MC counts";checked:pane.config.mcStatAssumption==="independent-effective-counts";onClicked:pane.set("mcStatAssumption",checked?"independent-effective-counts":"")}
                            Label{text:"Nuisances are explicit auxiliary constraints, never inferred from a variation label. Sparse-data asymptotic coverage remains unverified.";wrapMode:Text.Wrap;Layout.fillWidth:true}
                            RowLayout{ComboBox{id:templateNuisanceKind;model:["normalization","shape"]}TextField{id:constraintGroup;placeholderText:"Correlation group"}TextField{id:constraintSamples;placeholderText:"Affected sample IDs, comma separated"}}
                            RowLayout{visible:templateNuisanceKind.currentText==="normalization";Label{text:"Minus / plus 1σ scales"}TextField{id:constraintDown;text:"0.9";validator:DoubleValidator{bottom:0.0001;top:1}}TextField{id:constraintUp;text:"1.1";validator:DoubleValidator{bottom:1}}}
                            RowLayout{visible:templateNuisanceKind.currentText==="shape";TextField{id:shapeId;placeholderText:"Systematic identity"}TextField{id:shapeDown;text:"down";placeholderText:"Minus 1σ variation label"}TextField{id:shapeUp;text:"up";placeholderText:"Plus 1σ variation label"}}
                            CheckBox{id:constraintConsent;text:"Use a standard-normal Gaussian auxiliary constraint; endpoints mean −1σ / +1σ"}
                            Button{text:"Add explicit nuisance";enabled:constraintConsent.checked&&constraintGroup.text.length>0;onClicked:{var rows=JSON.parse(JSON.stringify(pane.config.nuisances||[]));var n={kind:templateNuisanceKind.currentText,samples:constraintSamples.text.split(",").map(function(s){return s.trim()}).filter(function(s){return s.length>0}),correlationGroup:constraintGroup.text,constraint:"gaussian-standard-normal",variationMeaning:"minus-plus-one-sigma"};if(n.kind==="normalization"){n.down=Number(constraintDown.text);n.up=Number(constraintUp.text)}else{n.systematicId=shapeId.text;n.downLabel=shapeDown.text;n.upLabel=shapeUp.text}rows.push(n);pane.set("nuisances",rows)}}
                            Repeater{model:pane.config.nuisances||[];delegate:RowLayout{required property var modelData;required property int index;Label{text:modelData.correlationGroup+" / "+modelData.kind+" / "+modelData.samples.join(", ");Layout.fillWidth:true}Button{text:"Remove";onClicked:{var rows=JSON.parse(JSON.stringify(pane.config.nuisances));rows.splice(index,1);pane.set("nuisances",rows)}}}}
                        }
                        GridLayout{columns:2;visible:pane.kind==="Inference"
                            Label{text:"Confidence level"}TextField{text:String(pane.config.confidenceLevel||0.95);validator:DoubleValidator{bottom:0.5001;top:0.9999} onEditingFinished:pane.set("confidenceLevel",Number(text))}
                            Label{text:"POI scan points"}SpinBox{from:10;to:200;value:pane.config.points||40;onValueModified:pane.set("points",value)}
                            Label{text:"Method"}Label{text:"RooStats asymptotic CLs, one-sided qμ. Expected bands and fit/covariance status are recorded.";wrapMode:Text.Wrap;Layout.preferredWidth:360}
                        }
                        GridLayout{columns:2;visible:pane.kind==="RooStats"
                            Label{text:"Signal yield"}Label{text:"From luminosity-normalized histogram integral"}
                            Label{text:"Expected background"}TextField{text:String(pane.config.background||20);validator:DoubleValidator{bottom:0.000001} onEditingFinished:pane.set("background",Number(text))}
                            Label{text:"Dataset role"}ComboBox{model:["asimov","observed-counts"];currentIndex:pane.config.datasetRole==="observed-counts"?1:0;onActivated:pane.set("datasetRole",currentText)}
                            Label{text:"Observed / Asimov count"}TextField{text:String(pane.config.observed===undefined?20:pane.config.observed);validator:DoubleValidator{bottom:0} onEditingFinished:pane.set("observed",Number(text))}
                            Label{text:"Confidence level"}TextField{text:String(pane.config.confidenceLevel||0.95);validator:DoubleValidator{bottom:0.5001;top:0.9999} onEditingFinished:pane.set("confidenceLevel",Number(text))}
                            Label{text:"Signal-strength maximum"}TextField{text:String(pane.config.muMax||5);validator:DoubleValidator{bottom:0.0001} onEditingFinished:pane.set("muMax",Number(text))}
                            Label{text:"Additional calculations"}RowLayout{CheckBox{text:"Discovery q₀";checked:pane.config.calculateDiscovery===true;onClicked:pane.set("calculateDiscovery",checked)}CheckBox{text:"Profile interval";checked:pane.config.calculateInterval===true;onClicked:pane.set("calculateInterval",checked)}}
                            Label{text:"Asymptotic CLs"}Label{text:"One-channel positive-yield model, one-sided qμ. Sparse-data coverage is unverified.";wrapMode:Text.Wrap;Layout.preferredWidth:360}
                        }
                        Label{text:JSON.stringify(pane.config,null,2);visible:pane.kind!=="MadGraph"||detail.currentIndex===2;wrapMode:Text.Wrap;font.family:"Monospace";font.pixelSize:11;Layout.fillWidth:true}
                    }
                }
                ColumnLayout{
                    Label{text:"INSPECTION / PREVIEW — bounded data; not a publication Run";font.bold:true;color:"#e9ad79"}
                    Button{text:"Preview reconstructed events";enabled:!studio.busy;onClicked:studio.previewReconstruction(0,20)}
                    ScrollView{Layout.fillWidth:true;Layout.fillHeight:true;TextArea{readOnly:true;selectByMouse:true;text:JSON.stringify(studio.researchPreview,null,2);font.family:"Monospace";wrapMode:TextEdit.Wrap}}
                }
                ColumnLayout{RowLayout{Button{text:"Export figure…";onClicked:figureSave.open()}CheckBox{text:"Log Y";checked:plot.logY;onClicked:plot.logY=checked}}HistogramPlot{id:plot;Layout.fillWidth:true;Layout.fillHeight:true;series:studio.plotSeries;curve:studio.fitCurve;title:studio.plotSettings.title||"Reconstructed analysis";xLabel:studio.plotSettings.xLabel||"Observable"}Label{text:studio.fitDiagnostics;wrapMode:Text.Wrap;Layout.fillWidth:true}}
                StatisticalInspector{}
                ColumnLayout{
                    RowLayout{ComboBox{id:primary;model:studio.runs;textRole:"status";onActivated:studio.chooseRuns(currentIndex,overlay.currentIndex-1)}ComboBox{id:overlay;model:["No overlay"].concat(studio.runs.map(function(r,i){return "Run "+(studio.runs.length-i)}));onActivated:studio.chooseRuns(primary.currentIndex,currentIndex-1)}Button{text:"Export configuration…";onClicked:codeSave.open()}Button{text:"Inspect recorded cards";enabled:!studio.busy;onClicked:studio.inspectResearchCards()}Button{text:"Export Run evidence…";onClicked:evidenceSave.open()}}
                    TabBar{id:runTabs;TabButton{text:"Differences"}TabButton{text:"Provenance"}TabButton{text:"Equivalent code"}}
                    ScrollView{Layout.fillWidth:true;Layout.fillHeight:true;TextArea{readOnly:true;selectByMouse:true;wrapMode:TextEdit.Wrap;font.family:"Monospace";text:runTabs.currentIndex===0?studio.comparison:runTabs.currentIndex===1?studio.provenance:studio.generatedCode}}
                }
                ScrollView {clip:true
                    ColumnLayout {width:parent.width;spacing:12
                        Label{text:"Parameter scans";font.pixelSize:20}
                        Button{text:"Run example scan";visible:studio.recommendedScan.axes!==undefined;enabled:!studio.busy;onClicked:studio.runParameterScan(studio.recommendedScan)}
                        Label{text:"Each point is an immutable Run. Points execute sequentially within one central resource allocation; upstream scientific artifacts are reused when their identities match.";wrapMode:Text.Wrap;Layout.fillWidth:true}
                        ComboBox{id:scanBinding;Layout.fillWidth:true;model:studio.parameterBindings.filter(function(p){return typeof p.value==="number"});textRole:"label"}
                        RowLayout{Label{text:"Range"}TextField{id:scanLower;placeholderText:"Lower";text:"10";validator:DoubleValidator{}}TextField{id:scanUpper;placeholderText:"Upper";text:"40";validator:DoubleValidator{}}SpinBox{id:scanCount;from:2;to:64;value:3}ComboBox{id:scanSpacing;model:["linear","log"]}}
                        CheckBox{id:scanTwoAxes;objectName:"scanTwoAxes";text:"Scan a second parameter"}
                        ComboBox{id:scanSecondBinding;objectName:"scanSecondBinding";visible:scanTwoAxes.checked;Layout.fillWidth:true;model:scanBinding.model;textRole:"label"}
                        RowLayout{visible:scanTwoAxes.checked;Label{text:"Second range"}TextField{id:scanSecondLower;text:"0.2";validator:DoubleValidator{}}TextField{id:scanSecondUpper;text:"0.6";validator:DoubleValidator{}}SpinBox{id:scanSecondCount;from:2;to:32;value:3}ComboBox{id:scanSecondSpacing;model:["linear","log"]}}
                        Label{text:"Grid: "+scanCount.value*(scanTwoAxes.checked?scanSecondCount.value:1)+" points (maximum 64)";color:scanCount.value*(scanTwoAxes.checked?scanSecondCount.value:1)>64?"#ef8b89":"#a9bdce"}
                        Button{text:"Inspect interrupted scans";enabled:!studio.busy;onClicked:studio.recoverResearchScans()}
                        Button{objectName:"runParameterScan";text:"Run scan";enabled:!studio.busy&&scanBinding.count>0&&scanCount.value*(scanTwoAxes.checked?scanSecondCount.value:1)<=64&&(!scanTwoAxes.checked||scanSecondBinding.currentIndex!==scanBinding.currentIndex);onClicked:{var p=scanBinding.model[scanBinding.currentIndex];var axes=[{nodeId:p.nodeId,pointer:p.pointer,unit:p.unit,spacing:scanSpacing.currentText,lower:Number(scanLower.text),upper:Number(scanUpper.text),count:scanCount.value}];if(scanTwoAxes.checked){var q=scanSecondBinding.model[scanSecondBinding.currentIndex];axes.push({nodeId:q.nodeId,pointer:q.pointer,unit:q.unit,spacing:scanSecondSpacing.currentText,lower:Number(scanSecondLower.text),upper:Number(scanSecondUpper.text),count:scanSecondCount.value})}studio.runParameterScan({axes:axes})}}
                        RowLayout{ComboBox{id:scanChartId;model:studio.scans;textRole:"id"}ComboBox{id:scanQuantity;model:["histogram-integral","cross-section-pb","upper-limit","significance"]}Button{text:"Plot recorded scan";enabled:scanChartId.count>0;onClicked:scanCurve.plotData=studio.parameterScanPlot(scanChartId.currentText,scanQuantity.currentText)}}
                        ColumnLayout{id:scanCurve;property var plotData:({});Layout.fillWidth:true
                            Label{text:scanCurve.plotData.error||((scanCurve.plotData.notice||"")+" Excluded points: "+(scanCurve.plotData.excludedPoints||0));wrapMode:Text.Wrap;Layout.fillWidth:true}
                            ScientificCurve{visible:!scanCurve.plotData.error&&scanCurve.plotData.curve!==undefined;Layout.fillWidth:true;Layout.preferredHeight:340;points:scanCurve.plotData.curve||[];title:scanCurve.plotData.title||"Parameter scan";xLabel:scanCurve.plotData.xLabel||"Parameter";yLabel:scanCurve.plotData.yLabel||"Value"}
                            ScientificGrid{visible:!scanCurve.plotData.error&&scanCurve.plotData.grid!==undefined;Layout.fillWidth:true;Layout.preferredHeight:400;plotData:scanCurve.plotData}
                        }
                        Label{text:"Systematic templates";font.pixelSize:20}
                        ComboBox{id:systKind;model:["normalization","parameter"]}
                        ComboBox{id:systBinding;visible:systKind.currentText==="parameter";Layout.fillWidth:true;model:scanBinding.model;textRole:"label"}
                        ComboBox{id:systHist;objectName:"systematicHistogramSelector";visible:systKind.currentText==="normalization";model:studio.nodes.filter(function(n){return n.kind==="hep.root.Histo1D"});textRole:"name"}
                        RowLayout{TextField{id:systName;placeholderText:"Name, e.g. luminosity"}TextField{id:systGroup;placeholderText:"Correlation group"}}
                        RowLayout{Label{text:systKind.currentText==="normalization"?"Down / up scale":"Down / up value"}TextField{id:systDown;text:"0.98";validator:DoubleValidator{}}TextField{id:systUp;text:"1.02";validator:DoubleValidator{}}}
                        TextField{id:systInterpretation;Layout.fillWidth:true;placeholderText:"Interpretation, e.g. sensitivity envelope; no statistical prior"}
                        Button{text:"Add explicit variation";enabled:!studio.busy&&systName.text.length>0&&systGroup.text.length>0&&systInterpretation.text.length>0&&(systKind.currentText==="normalization"?systHist.count>0:systBinding.count>0);onClicked:{
                            var kind=systKind.currentText,p=systBinding.model[systBinding.currentIndex],id=kind==="normalization"?systHist.model[systHist.currentIndex].id:p.nodeId
                            var descriptor={id:"syst-"+Date.now(),name:systName.text,kind:kind,nominal:kind==="normalization"?1:p.value,affectedNodes:[id],correlation:{group:systGroup.text,acrossSamples:"explicit group; no automatic prior"},interpretation:systInterpretation.text,variations:[]}
                            ;[ ["down",Number(systDown.text)],["up",Number(systUp.text)] ].forEach(function(v){descriptor.variations.push(kind==="normalization"?{label:v[0],factor:v[1]}:{label:v[0],bindings:[{nodeId:p.nodeId,pointer:p.pointer,unit:p.unit,value:v[1]}]})})
                            var all=JSON.parse(JSON.stringify(studio.systematics));all.push(descriptor);studio.setSystematics(all)
                        }}
                        Label{text:"Templates retain their correlation identities. No quadrature sum or statistical prior is silently assigned.";wrapMode:Text.Wrap;Layout.fillWidth:true}
                        Repeater{model:studio.systematics;delegate:RowLayout{required property var modelData;required property int index;Label{text:modelData.name+" · "+modelData.kind+" · "+modelData.interpretation;wrapMode:Text.Wrap;Layout.fillWidth:true}Button{text:"Remove";enabled:!studio.busy;onClicked:{var all=JSON.parse(JSON.stringify(studio.systematics));all.splice(index,1);studio.setSystematics(all)}}}}
                        Repeater{model:studio.scans;delegate:RowLayout{required property var modelData;Label{text:modelData.id+" · "+modelData.state}Button{text:"Resume / verify points";enabled:!studio.busy;onClicked:studio.runParameterScan({resumeScanId:modelData.id})}}}
                        Label{text:JSON.stringify(studio.scans,null,2);wrapMode:Text.Wrap;font.family:"Monospace";Layout.fillWidth:true}
                    }
                }
                ScrollView{ColumnLayout{width:parent.width;Label{text:"Research runtime · "+(studio.researchInfo.state||"Unavailable");font.pixelSize:20}Repeater{model:["ROOT","MadGraph","PYTHIA","HepMC3","Delphes","LHAPDF","RooFit","RooStats","HistFactory"];delegate:Label{required property string modelData;property var lib:(studio.researchInfo.libraries||{})[modelData]||{};text:modelData+" · "+(lib.status||"Unavailable")+" · "+(lib.version||"");color:lib.available?"#66d4bd":"#e9ad79"}}Button{text:"Select SDK…";enabled:!studio.busy;onClicked:sdkSelect.open()}Button{text:"Restart research worker";enabled:!studio.busy;onClicked:studio.restartResearch()}Label{text:JSON.stringify(studio.researchInfo.environment||{},null,2);wrapMode:Text.Wrap;font.family:"Monospace";font.pixelSize:11;Layout.fillWidth:true}}}
            }
        }
    }
    Label{text:studio.progressText;visible:studio.busy;color:"#66d4bd"}
}
