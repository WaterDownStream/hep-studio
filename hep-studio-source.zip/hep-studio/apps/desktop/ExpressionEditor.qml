import QtQuick
import QtQuick.Controls
import QtQuick.Layouts

ColumnLayout {
    id: editor
    property var expression: ({op: "column", name: "px"})
    property var selectedPath: []
    property var flat: []
    property var selected: ({})
    readonly property var operations: ["column","literal","add","sub","mul","div","square","sqrt","abs","neg","sin","cos","exp","log","min","max","gt","ge","lt","le","eq","ne","and","or","not","index","deltaPhi","deltaR","transverseMass"]
    function refresh() {
        var rows=[]
        function walk(n,p) {rows.push({path:p,node:n,depth:p.length});for(var i=0;i<(n.args||[]).length;i++)walk(n.args[i],p.concat([i]))}
        walk(expression,[]);flat=rows
        var n=expression;for(var k=0;k<selectedPath.length;k++){if(!n.args||!n.args[selectedPath[k]]){selectedPath=[];n=expression;break}n=n.args[selectedPath[k]]}
        selected=n;operation.currentIndex=Math.max(0,operations.indexOf(n.op));number.text=String(n.value===undefined?1:n.value);unit.currentIndex=Math.max(0,unit.model.indexOf(n.unit||"1"));column.currentIndex=Math.max(0,column.model.indexOf(n.name||""))
    }
    function replace(n) {
        var tree=JSON.parse(JSON.stringify(expression))
        if(selectedPath.length===0) tree=n
        else {var p=tree;for(var i=0;i<selectedPath.length-1;i++)p=p.args[selectedPath[i]];p.args[selectedPath[selectedPath.length-1]]=n}
        expression=tree
    }
    function chooseOperation(op) {
        if(op==="literal"){replace({op:op,value:1,unit:"1"});return}
        if(op==="column"){replace({op:op,name:column.model.length?column.model[0]:"px"});return}
        var count=["square","sqrt","abs","neg","sin","cos","exp","log","not"].indexOf(op)>=0?1:2
        if(op==="deltaR"||op==="transverseMass")count=4
        var args=[];for(var i=0;i<count;i++)args.push(selected.args&&selected.args[i]?selected.args[i]:{op:"literal",value:1,unit:"1"})
        replace({op:op,args:args})
    }
    onExpressionChanged: refresh()
    Component.onCompleted: refresh()
    Label {text:"Select a part of the formula, then choose its operation, column, or value.";wrapMode:Text.Wrap;Layout.fillWidth:true;color:"#9eafbf"}
    RowLayout {
        Button {text:"pT preset";onClicked:{editor.selectedPath=[];editor.expression={op:"sqrt",args:[{op:"add",args:[{op:"square",args:[{op:"column",name:"px"}]},{op:"square",args:[{op:"column",name:"py"}]}]}]}}}
        Button {text:"Cut preset";onClicked:{editor.selectedPath=[];editor.expression={op:"gt",args:[{op:"column",name:"pT"},{op:"literal",value:1,unit:"GeV"}]}}}
        Label {text:studio.expressionSummary(editor.expression);color:"#66d4bd";font.pixelSize:11}
    }
    ListView {
        Layout.fillWidth:true;Layout.preferredHeight:190;clip:true;model:editor.flat
        ScrollBar.vertical:ScrollBar {}
        delegate:ItemDelegate {
            required property var modelData
            width:ListView.view.width;height:30
            text:"    ".repeat(modelData.depth)+(modelData.node.op==="column"?modelData.node.name:modelData.node.op==="literal"?modelData.node.value+" "+(modelData.node.unit||"1"):modelData.node.op)
            highlighted:JSON.stringify(editor.selectedPath)===JSON.stringify(modelData.path)
            onClicked:{editor.selectedPath=modelData.path;editor.refresh()}
        }
    }
    RowLayout {
        ComboBox {id:operation;model:editor.operations;onActivated:editor.chooseOperation(currentText);Layout.preferredWidth:100}
        ComboBox {id:column;visible:editor.selected.op==="column";Layout.fillWidth:true;model:studio.columns.map(function(c){return c.name});onActivated:editor.replace({op:"column",name:currentText})}
        TextField {id:number;visible:editor.selected.op==="literal";Layout.preferredWidth:100;validator:DoubleValidator {}onEditingFinished:if(isFinite(Number(text)))editor.replace({op:"literal",value:Number(text),unit:unit.currentText})}
        ComboBox {id:unit;visible:editor.selected.op==="literal";model:["1","eV","keV","MeV","GeV","TeV","mm","cm","m","ns","s","rad"];onActivated:editor.replace({op:"literal",value:Number(number.text),unit:currentText})}
        Button {text:"Add condition";visible:editor.selected.op==="and"||editor.selected.op==="or";onClicked:{var n=JSON.parse(JSON.stringify(editor.selected));n.args.push({op:"gt",args:[{op:"column",name:"pT"},{op:"literal",value:1,unit:"GeV"}]});editor.replace(n)}}
    }
    Label {text:editor.selected.op==="and"?"ALL conditions (AND)":editor.selected.op==="or"?"ANY condition (OR)":editor.selected.op==="not"?"Invert condition (NOT)":"Units and types are checked before execution.";color:"#9eafbf"}
}
