import QtQuick
import QtQuick.Controls
import QtQuick.Layouts
ColumnLayout {
    id:pdf
    property var points:studio.pdfData.points||[]
    onPointsChanged:plot.requestPaint()
    Dialog {id:confirm;title:"Install this PDF set?";modal:true;anchors.centerIn:parent;standardButtons:Dialog.Ok|Dialog.Cancel;Label{text:"Download from the LHAPDF catalogue (up to 100 MiB).\nInstalled sets work offline. Existing sets are preserved."}onAccepted:studio.installPdf(installName.text)}
    RowLayout {
        Button{text:"Refresh installed sets";enabled:!studio.busy;onClicked:studio.queryPdfSets()}
        ComboBox{id:setChoice;model:studio.pdfData.sets||[];textRole:"name";valueRole:"name";Layout.fillWidth:true}
        Label{text:"Member"}SpinBox{id:member;from:0;to:setChoice.currentIndex>=0&&setChoice.model.length?Math.max(0,(setChoice.model[setChoice.currentIndex].members||1)-1):0}
    }
    Label {text:setChoice.currentIndex>=0&&setChoice.model.length?(setChoice.model[setChoice.currentIndex].description||"")+" · data version "+setChoice.model[setChoice.currentIndex].dataVersion+" · "+((setChoice.model[setChoice.currentIndex].sizeBytes||0)/1048576).toFixed(1)+" MiB":"No installed sets. Select an explicit download below.";wrapMode:Text.Wrap;Layout.fillWidth:true;color:"#9eafbf"}
    RowLayout {
        Label{text:"Flavour (PDG)"}SpinBox{id:flavour;from:-6;to:22;value:21;editable:true}
        Label{text:"Q [GeV]"}TextField{id:q;text:"91.1876";Layout.preferredWidth:100}
        Label{text:"x range"}TextField{id:xmin;text:"0.001";Layout.preferredWidth:90}TextField{id:xmax;text:"0.8";Layout.preferredWidth:90}
        Button{text:"Evaluate x f(x,Q)";enabled:!studio.busy&&setChoice.currentIndex>=0;onClicked:studio.evaluatePdf(setChoice.currentValue,member.value,flavour.value,Number(xmin.text),Number(xmax.text),Number(q.text))}
    }
    Canvas {
        id:plot;Layout.fillWidth:true;Layout.fillHeight:true
        onWidthChanged:requestPaint();onHeightChanged:requestPaint()
        onPaint:{
            var c=getContext("2d");c.reset();c.fillStyle="#ffffff";c.fillRect(0,0,width,height);var left=60,right=width-25,top=40,bottom=height-40;c.strokeStyle="#344454";c.strokeRect(left,top,right-left,bottom-top);c.fillStyle="#243443";c.font="13px sans-serif";c.fillText("x f(x,Q) · "+(studio.pdfData.set||""),left,23);c.fillText("x (log scale)",width/2,bottom+28)
            if(pdf.points.length<2)return
            var points=pdf.points,lo=Math.log(points[0][0]),hi=Math.log(points[points.length-1][0]),max=0,min=0
            for(var i=0;i<points.length;i++){max=Math.max(max,points[i][1]);min=Math.min(min,points[i][1])}
            if(max===min)max=min+1;c.fillText(max.toPrecision(4),3,top+4);c.fillText(min.toPrecision(3),3,bottom);c.fillText(points[0][0].toPrecision(3),left,bottom+16);c.fillText(points[points.length-1][0].toPrecision(3),right-40,bottom+16)
            c.strokeStyle="#078873";c.lineWidth=2;c.beginPath()
            for(var j=0;j<points.length;j++){var x=left+(Math.log(points[j][0])-lo)/(hi-lo)*(right-left),y=bottom-(points[j][1]-min)/(max-min)*(bottom-top);if(j===0)c.moveTo(x,y);else c.lineTo(x,y)}c.stroke()
        }
    }
    RowLayout {TextField{id:installName;placeholderText:"Exact PDF set name";Layout.fillWidth:true}Button{text:"Install PDF set…";enabled:!studio.busy&&installName.text.length>0;onClicked:confirm.open()}}
    Label{text:"EXPLORER — not a publication Run. Values come from LHAPDF; out-of-domain requests are rejected.";color:"#9eafbf";wrapMode:Text.Wrap;Layout.fillWidth:true}
}
