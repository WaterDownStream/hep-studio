#include "apps/desktop/bridge.hpp"
#include "core/research/research.hpp"
#include "core/research/campaign.hpp"
#include "core/collider/collider.hpp"
#include "core/graph/graph.hpp"
#include "core/units/units.hpp"
#include "core/scheduler/placement.hpp"
#include "runtime/project_store.hpp"
#include <QCoreApplication>
#include <QFileInfo>
#include <QJsonDocument>
#include <QFile>
#include <QSaveFile>
#include <QDir>
#include <QDirIterator>
#include <QCryptographicHash>
#include <QSettings>
#include <algorithm>
#include <numeric>
#include <cmath>
namespace hep {
static QVariant variant(const Json& j){return QJsonDocument::fromJson(QByteArray::fromStdString(j.dump())).toVariant();}
static Json resolveTemplates(const Project& project,const Json& plan){
    Json inputs=Json::object();
    for(const auto& node:plan.at("nodes"))if(node.at("kind")=="TemplateSet")for(const auto& sample:node.at("config").at("samples")){
        const auto& ref=sample.at("reference");const auto runId=ref.at("runId").get<std::string>(),nodeId=ref.at("nodeId").get<std::string>();
        const auto run=std::find_if(project.runs.begin(),project.runs.end(),[&](const Run& r){return r.id.value==runId;});
        if(run==project.runs.end()||run->status!="Completed"||!run->result.value("valid",true)||run->result.value("partial",false))throw std::invalid_argument("Template Run unavailable, incomplete or invalid");
        const auto& histogram=run->result.at("results").at(nodeId);
        if(histogram.value("kind","")!="Histogram1D")throw std::invalid_argument("Select an identified one-dimensional histogram template");
        const auto identity=workflowHash(histogram).toStdString();
        if(ref.contains("inputIdentity")&&ref.at("inputIdentity")!=identity)throw std::invalid_argument("Template histogram identity differs from the immutable reference");
        inputs[runId+"/"+nodeId]={{"runStatus",run->status},{"runValid",true},{"histogram",histogram},{"inputIdentity",identity},{"systematics",run->result.value("systematics",Json::object())},
            {"sourceRun",{{"id",run->id.value},{"workflowScientificHash",run->workflowHash},{"environmentId",run->environment},{"environment",run->extensions.value("frozenEnvironment",Json::object())},{"backend",run->backend},{"seed",run->seed},{"started",run->started},{"ended",run->ended}}}};
    }
    return inputs;
}
QVariantList Bridge::histogramReferences()const{
    Json rows=Json::array();
    for(const auto& run:project_.runs)try{
        if(run.status!="Completed"||!run.result.is_object()||!run.result.value("valid",true)||run.result.value("partial",false)||!run.result.contains("results")||!run.result.at("results").is_object())continue;
        for(const auto& [id,result]:run.result.at("results").items())try{
            if(!result.is_object()||result.value("kind","")!="Histogram1D")continue;
            const auto values=result.at("values").get<std::vector<double>>();
            rows.push_back({{"label",run.id.value.substr(0,8)+" / "+id.substr(0,8)+" / "+result.value("yieldMode",std::string("unspecified yield"))},
                {"reference",{{"runId",run.id.value},{"nodeId",id},{"inputIdentity",workflowHash(result).toStdString()}}},
                {"integral",std::accumulate(values.begin(),values.end(),0.)},{"yieldMode",result.value("yieldMode",std::string())}});
        }catch(const std::exception&){/* Malformed old result is not offered as a template. */}
    }catch(const std::exception&){/* Unknown historical result fields remain preserved. */}
    return variant(rows).toList();
}
QVariantMap Bridge::researchInfo()const{auto c=research_.capability();c["state"]=research_.state().toStdString();c["error"]=research_.error().toStdString();c["metrics"]=research_.metrics();return variant(c).toMap();}
QVariantMap Bridge::researchPreview()const{return variant(researchPreview_).toMap();}
QVariantMap Bridge::recommendedScan()const{return variant(project_.extensions.value("recommendedScan",Json::object())).toMap();}
QVariantMap Bridge::statisticalResult()const{
    try{
        const auto results=displayedResults();const auto selected=selected_.toStdString();
        const auto statistical=[](const Json& r){return r.is_object()&&(r.value("kind","")=="FitResult"||r.value("kind","")=="HypothesisResult");};
        if(results.contains(selected)&&statistical(results.at(selected)))return variant(results.at(selected)).toMap();
        for(const auto& [id,r]:results.items())if(statistical(r))return variant(r).toMap();
    }catch(const std::exception&){}
    return {};
}
QVariantMap Bridge::parameterScanPlot(const QString& scanId,const QString& quantity)const{
    try{
        Json specification;for(const auto& scan:project_.extensions.value("scans",Json::array()))if(scan.at("id")==scanId.toStdString())specification=scan;
        if(specification.is_null())throw std::invalid_argument("Select a recorded scan");
        const auto& axes=specification.at("configuration").at("axes");if(axes.empty()||axes.size()>2)throw std::invalid_argument("Select a one- or two-axis scan; three-axis records remain available in provenance");
        const auto coordinate=[&](const Workflow& w,std::size_t i){
            const auto& axis=axes.at(i);const auto pointer=axis.at("pointer").get<std::string>();const auto* node=findNode(w,Id(axis.at("nodeId")));
            if(!node)throw std::invalid_argument("Scan node unavailable");
            std::optional<std::string> units;for(const auto& binding:hep::parameterBindings(*node))if(binding.name==pointer)units=binding.units;
            if(!units)throw std::invalid_argument("Scan parameter binding unavailable");
            const auto value=Quantity(node->extensions.at("config").at(Json::json_pointer(pointer)).get<double>(),unit(*units)).convertedTo(unit(axis.value("unit",std::string("1")))).value;
            if(!std::isfinite(value))throw std::invalid_argument("Nonfinite scan coordinate");
            return value;
        };
        const auto axisLabel=[&](std::size_t i){return axes[i].at("pointer").get<std::string>()+" ["+axes[i].value("unit",std::string("1"))+"]";};
        Json points=Json::array();std::string yLabel;unsigned excluded=0;
        for(const auto& run:project_.runs){
            if(run.extensions.value("scanId",std::string())!=scanId.toStdString())continue;
            try{
                const auto snapshot=workflowFromJson(run.workflowSnapshot);const auto x=coordinate(snapshot,0);const auto second=axes.size()==2?coordinate(snapshot,1):0.;
                std::optional<double> y;std::string label;
                const auto kind=quantity.toStdString();
                const bool complete=run.status=="Completed"&&run.result.value("valid",true)&&!run.result.value("partial",false);
                if(complete&&kind=="cross-section-pb")for(const auto& stage:run.result.value("stages",Json::array()))if(stage.at("kind")=="MadGraph"){y=stage.at("metadata").at("crossSectionPb").get<double>();label="Cross section [pb]";break;}
                const auto resultRows=complete?run.result.value("results",Json::object()):Json::object();
                for(const auto& [id,r]:resultRows.items()){
                    if(kind=="histogram-integral"&&r.value("kind","")=="Histogram1D"&&r.value("normalization","")=="counts"){
                        const auto values=r.at("values").get<std::vector<double>>();y=std::accumulate(values.begin(),values.end(),0.);label="In-range yield ("+r.value("yieldMode",std::string("counts"))+")";break;
                    }
                    if(kind=="upper-limit"&&r.value("kind","")=="HypothesisResult"&&r.value("valid",false)){y=r.at("upperLimit").get<double>();label="Signal-strength upper limit";break;}
                    if(kind=="significance"&&r.value("kind","")=="HypothesisResult"&&r.value("valid",false)&&r.contains("discovery")&&!r.at("discovery").is_null()){y=r.at("discovery").at("significanceSigma").get<double>();label="Discovery significance [sigma]";break;}
                    if(kind.starts_with("fit-parameter:")&&r.value("kind","")=="FitResult"&&r.value("valid",r.value("converged",false)))for(const auto& p:r.at("parameters"))if(p.at("name")==kind.substr(14)){y=p.at("value").get<double>();label="Fitted "+kind.substr(14);break;}
                }
                const bool valid=y&&std::isfinite(*y);if(!valid)++excluded;
                if(valid){if(!yLabel.empty()&&label!=yLabel)return QVariantMap{{"error","Scan outputs have differing yield conventions"}};yLabel=label;}
                if(axes.size()==1){if(valid)points.push_back(Json::array({x,*y}));}
                else points.push_back({{"x",x},{"y",second},{"value",valid?Json(*y):Json()},{"status",valid?"Completed":complete?"Quantity unavailable":run.status},{"runId",run.id.value}});
            }catch(const std::exception&){++excluded;}
        }
        if(axes.size()==2){
            // Frozen base workflows make uncommitted/interrupted cells visible.
            if(specification.contains("baseWorkflow"))for(const auto& w:scanWorkflows(workflowFromJson(specification.at("baseWorkflow")),specification.at("configuration"))){
                const auto x=coordinate(w,0),y=coordinate(w,1);const auto count=std::count_if(points.begin(),points.end(),[&](const Json& p){return p.at("x")==x&&p.at("y")==y;});
                if(count>1)throw std::invalid_argument("Duplicate recorded Runs at one scan coordinate");
                if(!count){points.push_back({{"x",x},{"y",y},{"value",nullptr},{"status","Missing"},{"runId",""}});++excluded;}
            }
            if(points.empty())throw std::invalid_argument("No recorded scan coordinates are available");
            std::vector<double> xs,ys;for(const auto& p:points){xs.push_back(p.at("x"));ys.push_back(p.at("y"));}
            const auto unique=[](auto& values){std::sort(values.begin(),values.end());values.erase(std::unique(values.begin(),values.end()),values.end());};unique(xs);unique(ys);
            if(xs.size()*ys.size()>64)throw std::invalid_argument("Scan display exceeds the bounded 64-point grid");
            return variant(Json{{"dimensions",2},{"grid",points},{"xValues",xs},{"yValues",ys},{"xLabel",axisLabel(0)},{"yLabel",axisLabel(1)},{"valueLabel",yLabel.empty()?quantity.toStdString():yLabel},{"excludedPoints",excluded},{"title","Parameter scan"},{"notice","Discrete recorded points; no interpolation. Crosses mark failed/missing/unavailable values."}}).toMap();
        }
        if(points.empty())throw std::invalid_argument("No completed, valid point contains this quantity");
        std::sort(points.begin(),points.end(),[](const Json& a,const Json& b){return a[0].get<double>()<b[0].get<double>();});
        return variant(Json{{"dimensions",1},{"curve",points},{"xLabel",axisLabel(0)},{"yLabel",yLabel},{"excludedPoints",excluded},{"title","Parameter scan"},{"notice","Lines guide the eye; failed/missing/nonfinite points are excluded."}}).toMap();
    }catch(const std::exception& error){return QVariantMap{{"error",QString::fromUtf8(error.what())}};}
}
QVariantList Bridge::parameterBindings()const{
    Json rows=Json::array();for(const auto& node:workflow().nodes)for(const auto& p:hep::parameterBindings(node))rows.push_back({{"nodeId",node.id.value},{"nodeName",node.name},{"label",node.name+" · "+p.name+" ["+p.units+"]"},{"pointer",p.name},{"value",p.value},{"unit",p.units},{"origin",p.origin}});return variant(rows).toList();
}
QVariantList Bridge::scans()const{return variant(project_.extensions.value("scans",Json::array())).toList();}
QVariantList Bridge::systematics()const{return variant(workflow().extensions.value("systematics",Json::array())).toList();}
void Bridge::setSystematics(const QVariantList& specifications){
    if(busy())return;
    try{auto after=workflow().extensions;after["systematics"]=validateSystematics(workflow(),Json::parse(QJsonDocument::fromVariant(specifications).toJson().toStdString()));history().execute(workflow(),WorkflowExtensionEdit{workflow().extensions,after});edited();}
    catch(const std::exception& error){setNotice(error.what());}
}
void Bridge::runParameterScan(const QVariantMap& specification){
    if(busy())return;
    try{
        auto config=Json::parse(QJsonDocument::fromVariant(specification).toJson().toStdString());Json resumed=Json::object();
        if(config.contains("resumeScanId")){
            const auto scanId=config.at("resumeScanId");for(const auto& row:project_.extensions.value("scans",Json::array()))if(row.at("id")==scanId)resumed=row;
            if(resumed.empty()||!resumed.contains("baseWorkflow")||!resumed.contains("pointRunIds"))throw std::invalid_argument("This scan lacks a resumable scientific checkpoint");
            if(resumed.at("projectId")!=project_.id.value)throw std::invalid_argument("Scan belongs to another project");
            if(!resumed.contains("frozenEnvironment")||!environmentDifferences(resumed.at("frozenEnvironment"),research_.capability().value("environment",Json::object())).empty())throw std::invalid_argument("Scan environment changed; preserve completed points and create a new scan under the new environment");
            config=resumed.at("configuration");
        }
        const auto base=resumed.empty()?workflow():workflowFromJson(resumed.at("baseWorkflow"));const auto seed=resumed.empty()?project_.seed:resumed.at("projectSeed").get<std::string>();
        auto workflows=scanWorkflows(base,config);Json points=Json::array();unsigned threads=1;std::size_t pointIndex=0;
        for(const auto& w:workflows){
            Json plan,payload;const bool research=std::any_of(w.nodes.begin(),w.nodes.end(),[](const Node& n){return n.typeId.starts_with("hep.research.");});
            const bool collider=std::any_of(w.nodes.begin(),w.nodes.end(),[](const Node& n){return n.typeId.starts_with("hep.collider.");});
            if(research){plan=lowerResearch(w);payload={{"plan",plan},{"resources",project_.extensions.value("resources",Json::object())},{"templateInputs",resolveTemplates(project_,plan)}};
                // Resolve physical locations independently of canonical point identity.
                for(auto& [id,resource]:payload["resources"].items())for(const auto& location:resource.value("locations",Json::array()))if(location.value("runtimeId","native")==research_.capability().value("runtimeId","native")){resource["path"]=location.at("path");break;}
            }else if(collider){plan=lowerCollider(w);payload={{"plan",plan},{"workflow",workflowJson(w)},{"resources",Json::object()}};
                if(std::any_of(w.nodes.begin(),w.nodes.end(),[](const Node& n){return n.typeId=="hep.collider.HepMCSource"||n.typeId=="hep.collider.StoreHepMC";}))throw std::invalid_argument("Collider sample scans require explicit resource placement; use a research source scan in this milestone");
            }else{plan=lowerRoot(w);plan["backend"]="hep.root/1";payload={{"plan",plan},{"datasets",project_.extensions.at("datasets")}};}
            threads=std::max(threads,plan.value("requiredThreads",1U));payload["projectSeed"]=seed;payload["scientificHash"]=workflowHash(scientificJson(w,seed)).toStdString();
            payload["workflowRevision"]=workflowHash(workflowJson(w)).toStdString();
            Json hashes=Json::object();for(const auto& n:w.nodes)hashes[n.id.value]=workflowHash(dependencyJson(w,n.id,seed)).toStdString();
            points.push_back({{"runId",resumed.empty()?newId().value:resumed.at("pointRunIds").at(pointIndex).get<std::string>()},{"workflowSnapshot",workflowJson(w)},{"scientificHash",payload["scientificHash"]},{"nodeHashes",hashes},{"payload",payload}});++pointIndex;
        }
        for(auto& point:points)point["payload"]["allocatedThreads"]=threads;
        researchLease_=coordinator_.broker().acquire({threads,std::uint64_t(threads+1)*512*1024*1024});if(!researchLease_)throw std::runtime_error("Scan exceeds the machine-wide scientific resource budget");
        Json expected=Json::object();for(const auto& point:points)expected[point.at("runId").get<std::string>()]=point.at("scientificHash");
        if(!resumed.empty()&&resumed.at("expectedRunHashes")!=expected)throw std::invalid_argument("Scientific scan identity differs from its frozen checkpoint");
        Json pointIds=Json::array();for(const auto& point:points)pointIds.push_back(point.at("runId"));
        activeScan_={{"id",resumed.empty()?newId().value:resumed.at("id").get<std::string>()},{"projectId",project_.id.value},{"workflowId",base.id.value},{"baseWorkflow",workflowJson(base)},{"projectSeed",seed},{"pointRunIds",pointIds},{"configuration",config},{"state","running"},{"pointCount",points.size()},{"expectedRunHashes",expected},{"frozenEnvironment",research_.capability().value("environment",Json::object())}};
        if(!research_.request("scan",{{"scan",activeScan_},{"points",points},{"resume",!resumed.empty()}}))throw std::runtime_error(research_.error().toStdString());
        if(resumed.empty())project_.extensions["scans"].push_back(activeScan_);else for(auto& row:project_.extensions["scans"])if(row.at("id")==activeScan_.at("id")){row=activeScan_;break;}
        checkpoint();emit modelChanged();setNotice("Parameter scan started; points use immutable Runs and one shared resource allocation");
    }catch(const std::exception& error){if(researchLease_&&!research_.busy()){coordinator_.broker().release(researchLease_->id);researchLease_.reset();}activeScan_=Json::object();setNotice(error.what());}
}
void Bridge::recordScanPoint(){
    if(activeScan_.empty()||!research_.metrics().contains("committedPoint"))return;
    try{
        const auto& row=research_.metrics().at("committedPoint");const auto id=row.at("id").get<std::string>();
        if(!activeScan_.at("expectedRunHashes").contains(id)||activeScan_.at("expectedRunHashes").at(id)!=row.at("workflowHash"))throw std::runtime_error("Scan worker returned an unexpected scientific Run identity");
        if(std::any_of(project_.runs.begin(),project_.runs.end(),[&](const Run& r){return r.id.value==id;}))return;
        Run run{Id(id),row.at("status"),row.at("workflow"),row.at("workflowHash")};run.backend=row.at("backend");run.environment=row.value("environment",std::string());run.seed=row.at("seed");run.started=row.at("started");run.ended=row.at("ended");run.result=row.at("result");
        run.resources=hardwareJson(coordinator_.broker().hardware());if(researchLease_)run.resources["allocatedThreads"]=researchLease_->allocation.threads;
        run.extensions["scanId"]=activeScan_.at("id");run.extensions["frozenEnvironment"]=research_.capability().value("environment",Json::object());
        if(row.contains("nodeHashes"))run.extensions["nodeHashes"]=row.at("nodeHashes");
        project_.runs.push_back(std::move(run));checkpoint();emit modelChanged();
    }catch(const std::exception& error){setNotice(error.what());research_.cancel();}
}
void Bridge::newResearchWorkflow(){
    if(busy())return;
    auto w=researchExample();for(std::size_t i=0;i<w.nodes.size();++i){w.nodes[i].x=40+static_cast<double>(i%3)*260;w.nodes[i].y=85+static_cast<double>(i/3)*160;}
    const auto id=w.id;project_.workflows.push_back(std::move(w));hep::switchWorkflow(project_,id);project_.extensions["researchVersion"]=1;selected_=QString::fromStdString(workflow().nodes.front().id.value);researchPreview_=Json::object();edited();
}
void Bridge::newTemplateWorkflow(){
    if(busy())return;
    Workflow w{newId(),"Template likelihood",{}, {}};
    for(const auto* kind:{"TemplateSet","BinnedLikelihood","Inference"})w.nodes.push_back(researchNode(kind,newId(),40+static_cast<double>(w.nodes.size())*260,85));
    for(std::size_t i=1;i<w.nodes.size();++i)w.connections.push_back({w.nodes[i-1].id,Id("out"),w.nodes[i].id,Id("in")});
    const auto id=w.id;project_.workflows.push_back(std::move(w));hep::switchWorkflow(project_,id);project_.extensions["researchVersion"]=1;selected_=QString::fromStdString(workflow().nodes.front().id.value);researchPreview_=Json::object();edited();
}
QVariantList Bridge::researchCollections()const{
    Json rows=Json::array();for(const auto& node:workflow().nodes)for(const auto& port:node.ports)
        if(port.direction==Direction::Output&&(port.type.name=="RecoMuonCollection"||port.type.name=="RecoElectronCollection"||port.type.name=="RecoLeptonCollection"||port.type.name=="RecoJetCollection"||port.type.name=="RecoPhotonCollection"||port.type.name=="RecoTrackCollection"))
            rows.push_back({{"id",node.id.value},{"label",node.name+" · "+node.id.value.substr(0,8)},{"type",port.type.name}});
    return variant(rows).toList();
}
void Bridge::addOverlapRemoval(const QString& reference){addBinaryResearchNode("OverlapRemoval",reference);}
void Bridge::addCollectionCombine(const QString& reference){addBinaryResearchNode("CollectionCombine",reference);}
void Bridge::addBinaryResearchNode(const std::string& kind,const QString& reference){
    if(busy())return;
    try{
        const auto* primary=findNode(workflow(),Id(selected_.toStdString()));const auto* ref=findNode(workflow(),Id(reference.toStdString()));
        if(!primary||!ref||primary->id==ref->id)throw std::invalid_argument("Select primary objects and a distinct reference collection");
        std::string primaryType,referenceType;for(const auto& port:primary->ports)if(port.direction==Direction::Output)primaryType=port.type.name;
        for(const auto& port:ref->ports)if(port.direction==Direction::Output)referenceType=port.type.name;
        auto node=researchNode(kind,newId(),primary->x+260,primary->y,primaryType,referenceType);
        history().executeBatch(workflow(),{NodeEdit{std::nullopt,node,{}},EdgeEdit{{primary->id,Id("out"),node.id,Id("in")},true},EdgeEdit{{ref->id,Id("out"),node.id,Id("reference")},true}});
        selected_=QString::fromStdString(node.id.value);edited();
    }catch(const std::exception& error){setNotice(error.what());}
}
void Bridge::addResearchNode(const QString& kind){
    if(busy())return;
    try{
        const auto k=kind.toStdString();std::string semantic="RecoMuonCollection";std::optional<Id> input;
        if(!selected_.isEmpty())if(const auto* node=findNode(workflow(),Id(selected_.toStdString())))for(const auto& p:node->ports)if(p.direction==Direction::Output)semantic=p.type.name;
        const bool root=k=="Histo1D"||k=="Fit"||k=="Filter"||k=="Define"||k=="Count";
        auto n=root?rootNode(k,newId()):researchNode(k,newId(),0,0,semantic);
        if(k=="Histo1D")n.extensions["config"]={{"expression",columnExpression("value")},{"bins",40},{"lower",80.},{"upper",120.},{"normalization","counts"},{"flow","separate"},{"yieldMode","raw-weights"}};
        for(const auto& p:n.ports)if(p.direction==Direction::Input){
            for(const auto& candidate:workflow().nodes)for(const auto& out:candidate.ports)if(out.direction==Direction::Output&&out.type==p.type){if(!input||candidate.id.value==selected_.toStdString())input=candidate.id;}
            if(!input)throw std::invalid_argument("Select a compatible upstream node first");
        }
        n.x=40+static_cast<double>(workflow().nodes.size()%3)*260;n.y=85+static_cast<double>(workflow().nodes.size()/3)*160;
        history().execute(workflow(),NodeEdit{std::nullopt,n,{}});if(input)history().execute(workflow(),EdgeEdit{{*input,Id("out"),n.id,Id("in")},true});
        selected_=QString::fromStdString(n.id.value);edited();
    }catch(const std::exception& error){setNotice(error.what());}
}
void Bridge::selectDetectorCard(const QUrl& file){
    if(busy()||!file.isLocalFile()||selectedKind()!="Delphes")return;
    try{
        const auto path=QFileInfo(file.toLocalFile()).canonicalFilePath();const auto directory=QFileInfo(path).canonicalPath();
        if(path.isEmpty()||!path.endsWith(".tcl"))throw std::invalid_argument("Select an available trusted .tcl detector card");
        Json dependencies=Json::object();qint64 bytes=0;QDirIterator iterator(directory,{"*.tcl"},QDir::Files,QDirIterator::Subdirectories);
        while(iterator.hasNext()){
            const auto input=iterator.next();const auto canonical=QFileInfo(input).canonicalFilePath();
            if(!canonical.startsWith(directory+"/"))throw std::invalid_argument("Detector card dependency escapes its bundle");
            QFile source(input);bytes+=source.size();if(dependencies.size()>=256||bytes>16*1024*1024||!source.open(QIODevice::ReadOnly))throw std::invalid_argument("Use a readable card bundle with at most 256 Tcl files / 16 MiB");
            dependencies[QDir(directory).relativeFilePath(input).toStdString()]=QCryptographicHash::hash(source.readAll(),QCryptographicHash::Sha256).toHex().toStdString();
        }
        const auto sha=dependencies.at(QFileInfo(path).fileName().toStdString()).get<std::string>();const auto bundle=workflowHash(dependencies).toStdString();const auto id="detector-card-"+bundle;
        auto locations=project_.extensions.value("resources",Json::object()).value(id,Json::object()).value("locations",Json::array());const auto runtime=research_.capability().value("runtimeId",std::string("native"));
        std::erase_if(locations.get_ref<Json::array_t&>(),[&](const Json& location){return location.value("runtimeId",std::string())==runtime;});locations.push_back(ManagedRuntime::resourceLocation(path,runtime));
        project_.extensions["resources"][id]={{"resourceVersion",1},{"logicalUri","hep://detector-card/"+bundle},{"format","Delphes-Tcl"},{"sha256",sha},{"sizeBytes",QFileInfo(path).size()},{"locations",locations}};
        auto config=selectedConfig();config["card"]=variant(Json{{"resourceVersion",1},{"resourceId",id},{"sha256",sha},{"dependencyChecksums",dependencies},{"name",QFileInfo(path).fileName().toStdString()}});updateAnalysisNode(config);
        setNotice("Trusted detector card identified. Selecting the same bundle at a new location relinks storage without changing science.");
    }catch(const std::exception& error){setNotice(error.what());}
}
void Bridge::runResearch(bool preview,int events){
    if(busy())return;
    try{
        auto plan=lowerResearch(workflow());if(preview)plan["requiredThreads"]=1;
        const auto& cap=research_.capability();const auto env=cap.value("environment",Json::object());const auto runtimeId=cap.value("runtimeId",std::string("native"));
        const auto threads=plan.at("requiredThreads").get<unsigned>();const std::uint64_t memory=std::uint64_t(threads)*512*1024*1024+512*1024*1024;
        WorkerCandidate candidate{runtimeId,env.value("platform",""),cap.value("libraries",Json::object()),env,std::max(1U,coordinator_.broker().hardware().logicalCpus-1),research_.state()=="Healthy"};
        Json resources=Json::object();std::vector<ResourceLocation> locations;
        for(const auto& n:workflow().nodes)if(n.typeId=="hep.research.LHESource"||n.typeId=="hep.research.RecoSource"||(n.typeId=="hep.research.Delphes"&&n.extensions.at("config").at("card").contains("resourceId"))){
            const auto& binding=n.typeId=="hep.research.Delphes"?n.extensions.at("config").at("card"):n.extensions.at("config");
            const auto id=binding.at("resourceId").get<std::string>();const auto& resource=project_.extensions.at("resources").at(id);bool found=false;
            for(const auto& location:resource.at("locations"))if(location.value("runtimeId","")==runtimeId){
                const auto path=location.at("path").get<std::string>();const bool available=runtimeId!="native"||QFileInfo::exists(QString::fromStdString(path));
                locations.push_back({runtimeId,location.value("kind","local"),path,available,resource.value("sizeBytes",std::uint64_t(0))});resources[id]=resource;resources[id]["path"]=path;found=true;break;
            }
            if(!found)throw std::invalid_argument("Sample unavailable in the chosen scientific runtime; relink its location");
        }
        const auto placement=placeWorkflow(plan,{candidate},locations);researchLease_=coordinator_.broker().acquire({threads,memory});
        if(!researchLease_)throw std::runtime_error("Research job exceeds the available machine-wide resource budget");
        const auto preferred=project_.extensions.value("preferredResearchEnvironment",Json::object());const auto differences=preferred.empty()?Json::array():environmentDifferences(preferred,env);
        const auto hash=workflowHash(scientificJson(workflow(),project_.seed)).toStdString();
        Json payload={{"plan",plan},{"resources",resources},{"templateInputs",resolveTemplates(project_,plan)},{"allocatedThreads",threads},{"projectSeed",project_.seed},{"preview",preview},{"previewEvents",std::clamp(events,1,20)},
            {"scientificHash",hash},{"workflowRevision",workflowHash(workflowJson(workflow())).toStdString()},
            {"expectedEnvironmentId",preferred.value("id",env.value("id",std::string()))},{"environmentPolicy","record-difference"}};
        if(!research_.request(preview?"preview":"execute",payload))throw std::runtime_error(research_.error().toStdString());
        researchPreview_=Json::object();
        if(!preview){
            researchRun_=Run{newId(),"Running",workflowJson(workflow()),hash};auto& run=*researchRun_;
            run.started=ipc::utcNow();run.backend="hep.research/1";run.environment=env.value("id","");run.seed=project_.seed;
            run.resources=hardwareJson(coordinator_.broker().hardware());run.resources["allocatedThreads"]=threads;run.resources["reservedMemoryBytes"]=memory;
            run.extensions["nodeHashes"]=hashes();run.extensions["workflowRevision"]=payload["workflowRevision"];run.extensions["placement"]=placement.json();run.extensions["frozenEnvironment"]=env;run.extensions["environmentDifference"]=differences;
            if(preferred.empty())project_.extensions["preferredResearchEnvironment"]=env;
            checkpoint();
        }
        setNotice(differences.empty()?(preview?"PREVIEW — not a publication Run":"Research Run started"):"Scientific environment differs. The difference is recorded in this Run.");
    }catch(const std::exception& error){if(researchLease_&&!research_.busy()){coordinator_.broker().release(researchLease_->id);researchLease_.reset();}setNotice(error.what());}
}
void Bridge::previewResearch(int events){runResearch(true,events);}
void Bridge::researchFinished(bool success,bool cancelled){
    if(researchLease_){coordinator_.broker().release(researchLease_->id);researchLease_.reset();}
    if(!activeScan_.empty()){
        auto receipt=activeScan_;receipt["state"]=success?"completed":cancelled?"cancelled":"interrupted";
        if(success){receipt=research_.result().at("scan");for(const auto& row:research_.result().at("pointRuns")){
            const auto id=row.at("id").get<std::string>();if(std::any_of(project_.runs.begin(),project_.runs.end(),[&](const Run& r){return r.id.value==id;}))continue;
            Run run{Id(row.at("id")),row.at("status"),row.at("workflow"),row.at("workflowHash")};run.backend=row.at("backend");run.environment=row.value("environment",std::string());run.seed=row.at("seed");run.started=row.at("started");run.ended=row.at("ended");run.result=row.at("result");run.extensions["scanId"]=receipt.at("id");run.extensions["frozenEnvironment"]=research_.capability().value("environment",Json::object());
            if(row.contains("nodeHashes"))run.extensions["nodeHashes"]=row.at("nodeHashes");
            project_.runs.push_back(std::move(run));
        }}
        for(auto& scan:project_.extensions["scans"])if(scan.at("id")==activeScan_.at("id")){scan=receipt;break;}
        activeScan_=Json::object();primaryRun_=0;checkpoint();
    }
    if(researchRun_){
        auto& run=*researchRun_;run.status=success?"Completed":cancelled?"Cancelled":research_.state()=="Crashed"?"Interrupted":"Failed";run.ended=ipc::utcNow();
        run.result=success?research_.result():Json{{"valid",false},{"partial",true},{"message",research_.error().toStdString()}};
        run.logs.push_back({{"timestamp",ipc::utcNow()},{"severity",success?"Info":"Error"},{"subsystem","Research"},{"message",research_.diagnostics().toStdString()}});
        run.extensions["transport"]=research_.transportMetrics();project_.runs.push_back(run);researchRun_.reset();primaryRun_=0;storedHistogram_=Json::object();checkpoint();
    }else if(success)researchPreview_=research_.result();
    setNotice(success?(research_.operation()=="preview"?"PREVIEW complete — no scientific Run":"Research operation completed"):research_.error());emit modelChanged();emit runtimeChanged();
}
void Bridge::previewReconstruction(int offset,int limit){
    if(busy())return;
    const auto* run=selectedRun(primaryRun_);if(!run||run->backend!="hep.research/1"||!run->result.contains("artifactReferences")){setNotice("Run a reconstructed workflow first");return;}
    const auto& references=run->result.at("artifactReferences");if(references.empty())return;
    if(!research_.request("dataPreview",{{"path",references[0].at("path")},{"object","Delphes"},{"offset",std::max(0,offset)},{"limit",std::clamp(limit,1,50)}}))setNotice(research_.error());
}
void Bridge::restartResearch(){if(!busy())research_.restart();}
void Bridge::inspectResearchCards(){
    if(busy())return;
    try{
        const auto* run=selectedRun(primaryRun_);if(!run||run->status!="Completed"||run->backend!="hep.research/1")throw std::invalid_argument("Select a completed research Run");
        Json artifacts=Json::array();for(const auto& stage:run->result.value("stages",Json::array())){
            if(stage.at("kind")=="MadGraph")artifacts.push_back({{"key",stage.at("artifactKey")},{"names",Json::array({"commands.mg5","run_card.dat","param_card.dat","proc_card_mg5.dat","me5_configuration.txt"})}});
            if(stage.at("kind")=="Delphes"&&!stage.at("logicalPartitions").empty())artifacts.push_back({{"key",stage.at("logicalPartitions")[0].at("identity")},{"names",Json::array({"cards/"+stage.at("detectorCard").at("name").get<std::string>()})}});
        }
        if(artifacts.empty())throw std::invalid_argument("This Run has no worker-local generation/detector cards");
        if(!research_.request("cards",{{"runId",run->id.value},{"artifacts",artifacts}}))throw std::runtime_error(research_.error().toStdString());
        setNotice("Inspecting checksum-verified recorded cards; event data stays in the scientific runtime");
    }catch(const std::exception& error){setNotice(error.what());}
}
void Bridge::exportResearchEvidence(const QUrl& url){
    try{
        const auto* run=selectedRun(primaryRun_);if(!run||!url.isLocalFile())throw std::invalid_argument("Select a Run and local evidence file");
        Json evidence={{"format","hep-run-evidence"},{"version",1},{"run",projectJson({project_.id,project_.name,{}, {*run}}).at("runs")[0]},{"recordedCards",Json::array()}};
        if(researchPreview_.value("runId",std::string())==run->id.value&&researchPreview_.contains("cards"))evidence["recordedCards"]=researchPreview_.at("cards");
        else evidence["exportWarning"]="Recorded card text is absent. Inspect cards for this Run before exporting; original identities remain in provenance.";
        QSaveFile file(url.toLocalFile());const auto data=QByteArray::fromStdString(evidence.dump(2));if(!file.open(QIODevice::WriteOnly)||file.write(data)!=data.size()||!file.commit())throw std::runtime_error("Could not save Run evidence");
        setNotice("Run evidence saved with immutable workflow, results, environment, provenance and available recorded cards");
    }catch(const std::exception& error){setNotice(error.what());}
}
void Bridge::configureResearchSdk(const QUrl& manifest){
    if(busy())return;
    try{
        if(!manifest.isLocalFile())throw std::invalid_argument("Select a local scientific SDK manifest");
        QFile file(manifest.toLocalFile());if(!file.open(QIODevice::ReadOnly)||file.size()>1024*1024)throw std::invalid_argument("Scientific SDK manifest unavailable or too large");
        const auto data=Json::parse(file.readAll().toStdString());if(data.at("version")!=1)throw std::invalid_argument("Scientific SDK manifest version is incompatible");
        const auto folder=QFileInfo(file).absolutePath();const auto madgraph=folder+"/madgraph",delphes=folder+"/delphes";
        if(!QFileInfo::exists(madgraph+"/bin/mg5_aMC")||!QFileInfo::exists(delphes+"/libDelphes.so"))throw std::invalid_argument("SDK is incomplete; repair its scientific libraries first");
        const auto compiler=QString::fromStdString(data.value("compilerExecutable",qEnvironmentVariable("HEP_FORTRAN_COMPILER").toStdString()));
        if(!QFileInfo::exists(compiler))throw std::invalid_argument("SDK Fortran entrypoint is missing; rebuild or repair the SDK manifest");
        QProcessEnvironment overrides;overrides.insert("HEP_MADGRAPH_PATH",madgraph);overrides.insert("HEP_DELPHES_PATH",delphes);overrides.insert("HEP_FORTRAN_COMPILER",compiler);
        if(data.contains("rootPrefix")){
            const auto root=QString::fromStdString(data.at("rootPrefix"));if(!QFileInfo::exists(root+"/lib"))throw std::invalid_argument("SDK ROOT runtime is unavailable");
            const auto parent=QFileInfo(root).absolutePath();overrides.insert("PYTHONPATH",parent+QDir::listSeparator()+qEnvironmentVariable("PYTHONPATH"));
            overrides.insert("LD_LIBRARY_PATH",root+"/lib"+QDir::listSeparator()+parent+"/root.libs"+QDir::listSeparator()+delphes+QDir::listSeparator()+qEnvironmentVariable("LD_LIBRARY_PATH"));
        }
        research_.configureEnvironment(overrides);QSettings settings;settings.setValue("researchSdkManifest",file.fileName());settings.sync();if(settings.status()!=QSettings::NoError)throw std::runtime_error("SDK selected but its preference could not be saved");research_.restart();setNotice("Scientific SDK selected; verifying capabilities in the isolated worker");
    }catch(const std::exception& error){setNotice(error.what());}
}
void Bridge::recoverResearchScans(){if(!busy()&&!research_.request("recoverScans",Json::object()))setNotice(research_.error());}
}
