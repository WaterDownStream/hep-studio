import QtQuick
import QtQuick.Controls
import QtQuick.Layouts
ColumnLayout {
    id:pane
    property var result:studio.statisticalResult
    property bool valid:result.kind==="FitResult"?result.converged===true&&result.covarianceStatus>=2:result.valid===true
    function correlation(i,j){var matrix=result.correlation||[];if(matrix[i]&&matrix[i][j]!==undefined)return matrix[i][j];var cov=result.covariance||[];if(!cov[i]||!cov[j]||!(cov[i][i]>0)||!(cov[j][j]>0))return null;return cov[i][j]/Math.sqrt(cov[i][i]*cov[j][j])}
    function pulls(){var hist=(studio.plotSeries||[])[0];if(!hist||!result.pulls)return [];return result.pulls.map(function(p,i){return p===null?null:[(hist.edges[i]+hist.edges[i+1])/2,p]})}
    function cls(){return (result.scan||[]).map(function(p){return [p.mu,p.CLs]})}
    Label{text:result.kind?(valid?"VALID NUMERICAL RESULT":"FAILED OR UNRELIABLE RESULT"):"Select a fit or inference Run";font.bold:true;color:valid?"#66d4bd":"#e9ad79"}
    Label{text:(result.warnings||[]).join("\n")||(result.warning||"");wrapMode:Text.Wrap;Layout.fillWidth:true}
    TabBar{id:tab;Layout.fillWidth:true;TabButton{text:"Parameters"}TabButton{text:"Correlations"}TabButton{text:result.kind==="FitResult"?"Pulls":"CLs scan"}}
    StackLayout{currentIndex:tab.currentIndex;Layout.fillWidth:true;Layout.fillHeight:true
        ColumnLayout{
            Label{text:"Best-fit parameter / value / uncertainty. Boundaries and covariance status remain in provenance.";wrapMode:Text.Wrap;Layout.fillWidth:true}
            ListView{Layout.fillWidth:true;Layout.fillHeight:true;clip:true;model:pane.result.parameters||[];delegate:RowLayout{required property var modelData;width:ListView.view.width;height:36;Label{text:modelData.name;Layout.fillWidth:true}Label{text:Number(modelData.value).toPrecision(7);Layout.preferredWidth:150}Label{text:"± "+Number(modelData.error).toPrecision(5);Layout.preferredWidth:150}}}
            Label{visible:pane.result.kind==="HypothesisResult";text:"Upper limit μ = "+String(pane.result.upperLimit)+"\nExpected median = "+String(pane.result.expectedMedianLimit);wrapMode:Text.Wrap;Layout.fillWidth:true}
        }
        ScrollView{clip:true
            ColumnLayout{
                Label{text:(pane.result.parameters||[]).length>32?"Matrix view is limited to 32 parameters. The complete covariance remains in Run evidence.":"Parameter order matches the table; undefined correlations are shown as —.";wrapMode:Text.Wrap}
                GridLayout{property int n:(pane.result.parameters||[]).length;visible:n>0&&n<=32;columns:n+1;rowSpacing:2;columnSpacing:2
                    Repeater{model:parent.visible?(parent.n+1)*(parent.n+1):0;delegate:Rectangle{required property int index;property int n:parent.n;property int row:Math.floor(index/(n+1))-1;property int col:index%(n+1)-1;property var value:row>=0&&col>=0?pane.correlation(row,col):null;implicitWidth:row<0||col<0?105:56;implicitHeight:36;color:value===null?"#202c37":value>=0?Qt.rgba(0.15,0.45,0.55,0.25+0.7*Math.abs(value)):Qt.rgba(0.65,0.28,0.18,0.25+0.7*Math.abs(value));Label{anchors.fill:parent;padding:3;horizontalAlignment:Text.AlignHCenter;verticalAlignment:Text.AlignVCenter;elide:Text.ElideRight;text:row<0&&col<0?"":row<0?pane.result.parameters[col].name:col<0?pane.result.parameters[row].name:value===null?"—":Number(value).toFixed(2)}}}
                }
            }
        }
        ColumnLayout{
            Label{text:pane.result.kind==="FitResult"?"Pulls use recorded bin uncertainties; undefined bins are omitted. They are diagnostics, not an assigned goodness-of-fit p-value.":"CLs versus signal strength. Sparse-data/boundary coverage is unverified; the scan must bracket the limit.";wrapMode:Text.Wrap;Layout.fillWidth:true}
            ScientificCurve{Layout.fillWidth:true;Layout.fillHeight:true;points:pane.valid?(pane.result.kind==="FitResult"?pane.pulls():pane.cls()):[];title:pane.result.kind==="FitResult"?"Fit pulls":"CLs scan";xLabel:pane.result.kind==="FitResult"?"Observable (canonical units)":"Signal strength μ";yLabel:pane.result.kind==="FitResult"?"Pull":"CLs"}
        }
    }
}
