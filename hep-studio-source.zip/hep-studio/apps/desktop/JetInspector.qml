import QtQuick
import QtQuick.Controls
Item {
    id:view
    property var event: ({})
    property var collection: {var keys=Object.keys(event.jetCollections||{});return keys.length?event.jetCollections[keys[0]]:({})}
    onCollectionChanged:scatter.requestPaint()
    Canvas {
        id:scatter;anchors.fill:parent
        onWidthChanged:requestPaint();onHeightChanged:requestPaint()
        onPaint:{
            var c=getContext("2d");c.reset();c.fillStyle="#111820";c.fillRect(0,0,width,height)
            var left=48,right=width-20,top=30,bottom=height-30
            function x(eta){return left+(eta+5)/10*(right-left)}
            function y(phi){return bottom-(phi+Math.PI)/(2*Math.PI)*(bottom-top)}
            c.strokeStyle="#778898";c.strokeRect(left,top,right-left,bottom-top)
            c.fillStyle="#ced9e3";c.font="12px sans-serif";c.fillText("η–φ constituents and jet axes (no geometrical boundaries)",left,18);c.fillText("η  −5 … +5",width/2,bottom+22);c.fillText("φ",12,height/2)
            var colors=["#66d4bd","#efad76","#a89ce8","#7bb5ed","#ea8dba"],jets=view.collection.jets||[],points=view.collection.particles||[],membership={}
            for(var j=0;j<jets.length;j++)for(var k=0;k<jets[j].constituents.length;k++)membership[jets[j].constituents[k]]=j
            for(var i=0;i<points.length;i++){var p=points[i];if(p.eta< -5||p.eta>5)continue;var group=membership[p.index];c.fillStyle=group===undefined?"#596779":colors[group%colors.length];c.beginPath();c.arc(x(p.eta),y(p.phi),Math.min(5,1+Math.sqrt(p.pt)/3),0,2*Math.PI);c.fill()}
            for(var a=0;a<jets.length;a++){var jet=jets[a];if(jet.eta< -5||jet.eta>5)continue;var px=x(jet.eta),py=y(jet.phi);c.strokeStyle=colors[a%colors.length];c.lineWidth=2;c.beginPath();c.moveTo(px-6,py);c.lineTo(px+6,py);c.moveTo(px,py-6);c.lineTo(px,py+6);c.stroke()}
        }
    }
}
