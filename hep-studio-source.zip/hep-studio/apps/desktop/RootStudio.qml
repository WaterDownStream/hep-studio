import QtQuick
import QtQuick.Controls
import QtQuick.Layouts
import QtQuick.Dialogs
import HEPStudio 1.0

ColumnLayout {
    id: rootStudio
    spacing:8
    FileDialog {id:rootFile;title:"Open or relink a ROOT dataset";nameFilters:["ROOT files (*.root)"];onAccepted:studio.inspectRoot(selectedFile)}
    FileDialog {id:figureFile;title:"Export figure";fileMode:FileDialog.SaveFile;defaultSuffix:"png";nameFilters:["PNG image (*.png)","PDF figure (*.pdf)"];onAccepted:studio.setNotice(plot.exportFigure(selectedFile)?"Figure exported":"Figure export failed")}
    FileDialog {id:codeFile;title:"Export equivalent PyROOT";fileMode:FileDialog.SaveFile;defaultSuffix:"py";nameFilters:["Python (*.py)"];onAccepted:studio.exportCode(selectedFile)}
    RowLayout {
        Layout.fillWidth:true
        Button {text:"Open ROOT / Relink…";enabled:!studio.busy;onClicked:rootFile.open()}
        Label {text:studio.rootStatus;Layout.fillWidth:true;elide:Text.ElideMiddle;font.pixelSize:11;color:"#9eafbf"}
        Button {text:"Restart ROOT";enabled:!studio.busy;onClicked:studio.restartRoot()}
    }
    Label {text:studio.datasetInfo;Layout.fillWidth:true;color:"#9eafbf";elide:Text.ElideMiddle}
    TabBar {id:rootTabs;Layout.fillWidth:true
        TabButton {text:"Data & preview"}
        TabButton {text:"Build analysis"}
        TabButton {text:"Plot & fit"}
        TabButton {text:"Runs & transparency"}
    }
    StackLayout {currentIndex:rootTabs.currentIndex;Layout.fillWidth:true;Layout.fillHeight:true
        SplitView {
            ColumnLayout {SplitView.preferredWidth:320
                Label {text:"ROOT OBJECTS";color:"#66d4bd"}
                ListView {Layout.fillWidth:true;Layout.fillHeight:true;clip:true;model:studio.rootObjects;ScrollBar.vertical:ScrollBar {}
                    delegate:ItemDelegate {required property var modelData;width:ListView.view.width;text:"  ".repeat(modelData.depth||0)+modelData.name+"  ·  "+modelData.kind;enabled:!studio.busy&&["dataset","histogram"].indexOf(modelData.kind)>=0;onClicked:studio.selectRootObject(modelData.path,modelData.kind)}
                }
                Label {text:"Choose a tree or ntuple to create a dataset source. A stored histogram can be viewed directly.";wrapMode:Text.Wrap;Layout.fillWidth:true;color:"#9eafbf"}
            }
            ColumnLayout {SplitView.fillWidth:true
                Label {text:"SCHEMA   ·   Assign units only when known";color:"#66d4bd"}
                ListView {Layout.fillWidth:true;Layout.preferredHeight:175;clip:true;model:studio.columns;ScrollBar.vertical:ScrollBar {}
                    delegate:RowLayout {required property var modelData;width:ListView.view.width;height:34
                        Label {text:modelData.name;Layout.preferredWidth:180;elide:Text.ElideRight}
                        Label {text:modelData.backendType;Layout.fillWidth:true;color:"#9eafbf";elide:Text.ElideRight}
                        Label {text:modelData.unitKnown?modelData.unit:"unit unknown";Layout.preferredWidth:100}
                        ComboBox {model:["1","GeV","MeV","TeV","mm","cm","m","ns","rad"];enabled:!studio.busy&&modelData.backendType!=="derived";onActivated:studio.setColumnUnit(modelData.name,currentText);implicitWidth:95}
                    }
                }
                RowLayout {
                    Label {text:"PREVIEW";color:"#e9bd72";font.bold:true}
                    Label {text:"Offset"}
                    TextField {id:offset;text:"0";validator:IntValidator{bottom:0}Layout.preferredWidth:85}
                    Label {text:"Entries"}
                    SpinBox {id:previewSize;from:1;to:500;value:50;editable:true;implicitWidth:110}
                    Button {text:"Load sample";enabled:!studio.busy;onClicked:studio.previewRoot(Number(offset.text),previewSize.value)}
                }
                Label {text:(studio.previewData.represented||0)+" entries represented / "+(studio.previewData.entries||0)+" total. Preview is not a scientific Run.";color:"#9eafbf"}
                ScrollView {Layout.fillWidth:true;Layout.fillHeight:true;clip:true
                    ListView {implicitWidth:Math.max(600,(studio.previewData.columns||[]).length*150);model:studio.previewData.rows||[];clip:true
                        header:Row {Repeater {model:studio.previewData.columns||[];delegate:Label {required property var modelData;text:modelData;width:150;height:34;color:"#66d4bd";elide:Text.ElideRight}}}
                        delegate:Row {required property var modelData;Repeater {model:modelData;delegate:Label {required property var modelData;text:JSON.stringify(modelData);width:150;height:28;elide:Text.ElideRight}}}
                    }
                }
            }
        }
        ColumnLayout {
            Label {text:"Select an upstream node, then add an observable, cut, or action. Select a histogram to add a fit.";wrapMode:Text.Wrap;Layout.fillWidth:true}
            RowLayout {
                Button {text:"New observable";enabled:!studio.busy;onClicked:builder.begin("Define",false)}
                Button {text:"Filter";enabled:!studio.busy;onClicked:builder.begin("Filter",false)}
                Button {text:"Histogram";enabled:!studio.busy;onClicked:builder.begin("Histo1D",false)}
                ComboBox {id:aggregate;model:["Count","Mean","Sum","Min","Max"]}
                Button {text:"Add action";enabled:!studio.busy;onClicked:builder.begin(aggregate.currentText,false)}
            }
            ListView {Layout.fillWidth:true;Layout.fillHeight:true;clip:true;model:studio.nodes
                delegate:ItemDelegate {required property var modelData;width:ListView.view.width;highlighted:studio.selectedId===modelData.id;text:modelData.name+(modelData.stale?"    STALE":"")+"  ·  "+modelData.kind;onClicked:studio.select(modelData.id)}
            }
            RowLayout {
                Button {text:"Edit selected definition";enabled:!studio.busy&&studio.selectedKind!==""&&studio.selectedKind!=="Source";onClicked:builder.begin(studio.selectedKind,true)}
                Button {text:"Fit selected histogram";enabled:!studio.busy;onClicked:builder.begin("Fit",false)}
                Button {text:"Remove selected";enabled:!studio.busy&&studio.selectedId!=="";onClicked:studio.removeSelected()}
                Button {text:"Run analysis";enabled:!studio.busy;highlighted:true;onClicked:studio.run()}
            }
            Label {text:studio.inspector;wrapMode:Text.Wrap;Layout.fillWidth:true;Layout.maximumHeight:120;clip:true;color:"#9eafbf"}
        }
        ColumnLayout {
            RowLayout {
                TextField {id:plotTitle;text:studio.plotSettings.title||"Histogram";placeholderText:"Plot title";Layout.fillWidth:true;onEditingFinished:rootStudio.savePlot()}
                TextField {id:axisTitle;text:studio.plotSettings.xLabel||"Observable (canonical units)";Layout.fillWidth:true;onEditingFinished:rootStudio.savePlot()}
                CheckBox {id:logY;text:"Log Y";checked:studio.plotSettings.logY||false;onToggled:rootStudio.savePlot()}
                Button {text:"Export…";onClicked:figureFile.open()}
            }
            RowLayout {
                Label{text:"Font"}SpinBox{id:fontSize;from:8;to:28;value:studio.plotSettings.fontSize||12;onValueModified:rootStudio.savePlot()}
                Label{text:"Legend"}ComboBox{id:legend;model:["right","left"];currentIndex:studio.plotSettings.legendPosition==="left"?1:0;onActivated:rootStudio.savePlot()}
                ComboBox{id:plotStyle;model:["step","bar"];currentIndex:studio.plotSettings.style==="bar"?1:0;onActivated:rootStudio.savePlot()}
                Label{text:"Presentation settings do not rerun the analysis.";color:"#9eafbf"}
            }
            HistogramPlot {id:plot;fontSize:fontSize.value;legendPosition:legend.currentText;style:plotStyle.currentText;Layout.fillWidth:true;Layout.fillHeight:true;series:studio.plotSeries;curve:studio.fitCurve;title:plotTitle.text;xLabel:axisTitle.text;logY:logY.checked}
            RowLayout {Button{text:"Zoom +";onClicked:plot.zoom(1.25)}Button{text:"Zoom −";onClicked:plot.zoom(.8)}Button{text:"←";onClicked:plot.pan(-.1)}Button{text:"→";onClicked:plot.pan(.1)}Button{text:"Reset view";onClicked:plot.resetView()}Button{text:"Add fit";enabled:!studio.busy;onClicked:builder.begin("Fit",false)}Label{text:"Select a histogram in Build analysis to view its result.";color:"#9eafbf"}}
            ScrollView {Layout.fillWidth:true;Layout.preferredHeight:130;TextArea {text:studio.fitDiagnostics;readOnly:true;selectByMouse:true;wrapMode:TextEdit.Wrap;font.family:"monospace"}}
        }
        ColumnLayout {
            RowLayout {
                Label {text:"Primary"}
                ComboBox {id:primary;model:studio.runs.map(function(r,i){return "Run "+(studio.runs.length-i)+" · "+r.status});Layout.fillWidth:true;onActivated:studio.chooseRuns(currentIndex,comparison.currentIndex-1)}
                Label {text:"Compare"}
                ComboBox {id:comparison;model:["None"].concat(studio.runs.map(function(r,i){return "Run "+(studio.runs.length-i)+" · "+r.status}));Layout.fillWidth:true;onActivated:studio.chooseRuns(primary.currentIndex,currentIndex-1)}
                Button {text:"Export code…";onClicked:codeFile.open()}
            }
            Label {text:"Compatible histograms overlay in Plot & fit. Runs retain their original graph, input fingerprint, settings and results.";color:"#9eafbf";wrapMode:Text.Wrap;Layout.fillWidth:true}
            TabBar {id:detailTabs;TabButton{text:"Differences"}TabButton{text:"Provenance"}TabButton{text:"Equivalent PyROOT"}}
            ScrollView {Layout.fillWidth:true;Layout.fillHeight:true;TextArea {text:detailTabs.currentIndex===0?studio.comparison:detailTabs.currentIndex===1?studio.provenance:studio.generatedCode;readOnly:true;selectByMouse:true;wrapMode:TextEdit.Wrap;font.family:"monospace"}}
        }
    }
    function savePlot(){studio.setPlotSettings({title:plotTitle.text,xLabel:axisTitle.text,logY:logY.checked,fontSize:fontSize.value,legendPosition:legend.currentText,style:plotStyle.currentText})}
    Dialog {
        id:builder;objectName:"analysisBuilder";title:kind+" definition";modal:true;anchors.centerIn:Overlay.overlay;width:690;height:Math.min(850,rootStudio.height+110)
        standardButtons:Dialog.Ok|Dialog.Cancel
        property string kind:"Define"
        property bool editing:false
        function begin(k,edit){kind=k;editing=edit;var c=edit?studio.selectedConfig:{};observableName.text=c.name||"pT";formula.expression=c.expression||{op:"column",name:k==="Define"?"px":"pT"};formula.selectedPath=[];bins.value=c.bins||40;lower.text=String(c.lower===undefined?0:c.lower);upper.text=String(c.upper===undefined?20:c.upper);edgeText.text=(c.edges||[]).join(", ");weight.currentIndex=c.weight&&c.weight.name?weight.model.indexOf(c.weight.name):0;normalization.currentIndex=Math.max(0,normalization.model.indexOf(c.normalization||"counts"));flow.currentIndex=c.flow==="fold"?1:0;fitModel.currentIndex=Math.max(0,fitModel.model.indexOf(c.model||"gaussian"));order.value=c.order||2;initial.text=(c.initial||[]).join(", ");bounds.text=(c.bounds||[]).map(function(b){return b.join(":")}).join(", ");open()}
        function numbers(text){return text.trim()===""?[]:text.split(",").map(Number)}
        onAccepted:{
            var c={}
            if(kind==="Define")c={name:observableName.text,expression:formula.expression}
            else if(kind==="Filter"||["Mean","Sum","Min","Max"].indexOf(kind)>=0)c={expression:formula.expression}
            else if(kind==="Histo1D"){c={expression:formula.expression,bins:bins.value,lower:Number(lower.text),upper:Number(upper.text),normalization:normalization.currentText,flow:flow.currentText};if(edgeText.text.trim()!=="")c.edges=numbers(edgeText.text);if(weight.currentIndex>0)c.weight={op:"column",name:weight.currentText}}
            else if(kind==="Fit"){c={model:fitModel.currentText,order:order.value};if(lower.text!==""&&upper.text!==""){c.lower=Number(lower.text);c.upper=Number(upper.text)}if(initial.text.trim()!=="")c.initial=numbers(initial.text);if(bounds.text.trim()!=="")c.bounds=bounds.text.split(",").map(function(b){return b.split(":").map(Number)})}
            if(editing)studio.updateAnalysisNode(c);else studio.addAnalysisNode(kind,c)
        }
        ScrollView {anchors.fill:parent;contentWidth:availableWidth
            ColumnLayout {width:builder.availableWidth;spacing:12
                TextField {id:observableName;visible:builder.kind==="Define";placeholderText:"Observable name";Layout.fillWidth:true}
                ExpressionEditor {id:formula;objectName:"formulaEditor";visible:builder.kind!=="Fit"&&builder.kind!=="Count";Layout.fillWidth:true}
                RowLayout {visible:builder.kind==="Histo1D"||builder.kind==="Fit"
                    Label {text:"Range"}TextField{id:lower;Layout.preferredWidth:100;validator:DoubleValidator{}}TextField{id:upper;Layout.preferredWidth:100;validator:DoubleValidator{}}
                    Label {text:"Bins";visible:builder.kind==="Histo1D"}SpinBox{id:bins;from:1;to:4096;value:40;editable:true;visible:builder.kind==="Histo1D"}
                }
                TextField {id:edgeText;visible:builder.kind==="Histo1D";placeholderText:"Optional explicit edges, comma separated (overrides bins/range)";Layout.fillWidth:true}
                RowLayout {visible:builder.kind==="Histo1D";Label{text:"Weight"}ComboBox{id:weight;model:["None"].concat(studio.columns.map(function(c){return c.name}));Layout.fillWidth:true}ComboBox{id:normalization;model:["counts","unit-area","density"]}ComboBox{id:flow;model:["separate","fold"]}}
                RowLayout {visible:builder.kind==="Fit";Label{text:"Model"}ComboBox{id:fitModel;model:["gaussian","exponential","polynomial"]}Label{text:"Order"}SpinBox{id:order;from:0;to:5;value:2;enabled:fitModel.currentText==="polynomial"}}
                TextField {id:initial;visible:builder.kind==="Fit";placeholderText:"Initial parameters, comma separated (optional)";Layout.fillWidth:true}
                TextField {id:bounds;visible:builder.kind==="Fit";placeholderText:"Bounds low:high, low:high, … (optional)";Layout.fillWidth:true}
                Label {visible:builder.kind==="Fit";text:"Gaussian: amplitude, mean, sigma. Exponential: intercept, slope in exp(p0+p1·x). Polynomial: coefficients from constant upward.";wrapMode:Text.Wrap;Layout.fillWidth:true}
                Label {text:"Run executes the analysis in the isolated ROOT worker. Editing this definition marks dependent results stale.";wrapMode:Text.Wrap;Layout.fillWidth:true;color:"#9eafbf"}
            }
        }
    }
}
