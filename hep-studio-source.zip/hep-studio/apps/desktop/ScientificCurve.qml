import QtQuick
import QtQuick.Controls
import QtQuick.Layouts
import QtQuick.Dialogs
import HEPStudio 1.0
ColumnLayout {
    id:pane
    property var points:[]
    property string title:"Scientific curve"
    property string xLabel:"Parameter"
    property string yLabel:"Value"
    function bounds(){var xs=points.filter(function(p){return p&&p.length===2&&p[0]!==null&&isFinite(p[0])}).map(function(p){return p[0]});if(!xs.length)return [0,1];var lo=Math.min.apply(null,xs),hi=Math.max.apply(null,xs);return lo===hi?[lo-0.5,hi+0.5]:[lo,hi]}
    FileDialog{id:save;fileMode:FileDialog.SaveFile;nameFilters:["PNG (*.png)","PDF (*.pdf)"];onAccepted:plot.exportFigure(selectedFile)}
    RowLayout{Label{text:pane.title;Layout.fillWidth:true;font.bold:true}Button{text:"Export…";enabled:pane.points.length>0;onClicked:save.open()}Button{text:"Reset view";onClicked:plot.resetView()}}
    HistogramPlot{id:plot;Layout.fillWidth:true;Layout.fillHeight:true;Layout.minimumHeight:200;title:pane.title;xLabel:pane.xLabel;curve:pane.points;series:pane.points.length?[{edges:pane.bounds(),values:[],errors:[],normalization:pane.yLabel,showStatistics:false,curveMarkers:true,legend:"Stored result"}]:[]
        MouseArea{anchors.fill:parent;acceptedButtons:Qt.LeftButton;property real previousX:0;onPressed:function(mouse){previousX=mouse.x}onPositionChanged:function(mouse){if(pressed){plot.pan((previousX-mouse.x)/width);previousX=mouse.x}}onWheel:function(wheel){plot.zoom(wheel.angleDelta.y>0?1.2:0.833333)}}
    }
}
