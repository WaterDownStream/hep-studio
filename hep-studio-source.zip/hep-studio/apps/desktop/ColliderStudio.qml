import QtQuick
import QtQuick.Controls
import QtQuick.Layouts
import QtQuick.Dialogs
import HEPStudio 1.0

ColumnLayout {
    id: pane
    property var config: studio.selectedConfig
    property string kind: studio.selectedKind
    property var processChoices: [{id:"qcd",label:"QCD — hard scattering"},{id:"dy",label:"Drell–Yan / Z / gamma*"},{id:"w",label:"W boson"},{id:"higgs",label:"Higgs — Standard Model"},{id:"top",label:"Top pair"},{id:"minimum-bias",label:"Minimum bias QCD"}]
    function set(key,value) {var c=JSON.parse(JSON.stringify(config));c[key]=value;studio.updateAnalysisNode(c)}
    function plotOption(key,value) {var c=JSON.parse(JSON.stringify(studio.plotSettings));c[key]=value;studio.setPlotSettings(c)}
    function expression() {formula.expression=JSON.parse(JSON.stringify(config.expression||{op:"column",name:"value"}));formulaDialog.open()}
    Dialog {id:wslSetup;title:"Enable Windows scientific runtime";modal:true;anchors.centerIn:parent;standardButtons:Dialog.Ok|Dialog.Cancel;Label{text:"Windows may download components, request administrator approval, and require a reboot.";wrapMode:Text.Wrap;width:460}onAccepted:studio.setupWsl()}
    FileDialog {id:sampleExport;title:"Export sample as one HepMC file";fileMode:FileDialog.SaveFile;nameFilters:["HepMC (*.hepmc)"];onAccepted:studio.exportHepMCSample(pane.relinkingSample,selectedFile)}
    FileDialog {id:runtimeBundle;title:"Repair / update runtime from trusted publisher bundle";nameFilters:["HEP runtime bundle (*.tar *.tar.gz)"];onAccepted:studio.repairRuntimeBundle(selectedFile)}
    FileDialog {id:runtimeImage;title:"Install HEP Studio runtime image";nameFilters:["Linux runtime image (*.tar *.tar.gz)"];onAccepted:studio.installRuntimeImage(selectedFile)}
    FileDialog {id:hepmcOpen;nameFilters:["HepMC3 / sample manifest (*.hepmc *.hepmc3 *.hepsample.json)"];onAccepted:studio.openHepMC(selectedFile)}
    FileDialog {id:hepmcSave;fileMode:FileDialog.SaveFile;defaultSuffix:"hepsample.json";onAccepted:studio.storeHepMC(selectedFile)}
    FileDialog {id:figureSave;fileMode:FileDialog.SaveFile;nameFilters:["PNG (*.png)","PDF (*.pdf)"];onAccepted:colliderPlot.exportFigure(selectedFile)}
    property string relinkingSample: ""
    FileDialog {id:sampleRelink;nameFilters:["HepMC3 / sample manifest (*.hepmc *.hepmc3 *.hepsample.json)"];onAccepted:studio.relinkSample(pane.relinkingSample,selectedFile)}
    FileDialog {id:configurationSave;fileMode:FileDialog.SaveFile;defaultSuffix:"cmnd";onAccepted:studio.exportGeneratorConfiguration(selectedFile)}
    FileDialog {id:codeSave;fileMode:FileDialog.SaveFile;defaultSuffix:"cpp";onAccepted:studio.exportCode(selectedFile)}
    Dialog {id:formulaDialog;title:"Structured expression";modal:true;anchors.centerIn:parent;width:720;standardButtons:Dialog.Ok|Dialog.Cancel;ExpressionEditor{id:formula;width:680}onAccepted:pane.set("expression",formula.expression)}
    RowLayout {
        Layout.fillWidth:true
        Button {text:"New collider workflow";enabled:!studio.busy;onClicked:studio.newColliderWorkflow(false)}
        Button {text:"Leading-jet example";enabled:!studio.busy;onClicked:studio.newColliderWorkflow(true)}
        Button {text:"Open HepMC…";enabled:!studio.busy;onClicked:hepmcOpen.open()}
        Item {Layout.fillWidth:true}
        SpinBox {id:previewCount;from:1;to:20;value:10}
        Button {text:"Generate PREVIEW";enabled:!studio.busy;onClicked:studio.previewCollider(previewCount.value)}
        Button {text:"Full Run";highlighted:true;enabled:!studio.busy;onClicked:studio.run()}
    }
    RowLayout {
        Layout.fillWidth:true;Layout.fillHeight:true
        ColumnLayout {
            Layout.preferredWidth:215;Layout.fillHeight:true
            Label {text:"COLLIDER WORKFLOW";color:"#66d4bd"}
            ListView {Layout.fillWidth:true;Layout.fillHeight:true;clip:true;model:studio.nodes;spacing:3
                delegate:ItemDelegate {required property var modelData;width:ListView.view.width;text:(modelData.stale?"● ":"")+modelData.name;highlighted:studio.selectedId===modelData.id;onClicked:studio.select(modelData.id)}
            }
            ComboBox {id:addKind;Layout.fillWidth:true;model:["Pythia","ClusterJets","CollectionFilter","CollectionSort","CollectionTake","Property","CollectionCount","Define","Filter","Histo1D","Count","Mean","Sum","Fit"]}
            Button {text:"Add connected node";Layout.fillWidth:true;enabled:!studio.busy;onClicked:studio.addColliderNode(addKind.currentText)}
            Button {text:"Store in runtime";Layout.fillWidth:true;enabled:!studio.busy;onClicked:studio.storeRuntimeSample()}
            Button {text:"Store HepMC…";Layout.fillWidth:true;enabled:!studio.busy;onClicked:hepmcSave.open()}
            Button {text:"Delete selected";Layout.fillWidth:true;enabled:!studio.busy;onClicked:studio.removeSelected()}
        }
        ColumnLayout {
            Layout.fillWidth:true;Layout.fillHeight:true
            TabBar {id:tabs;Layout.fillWidth:true;TabButton{text:"Configure"}TabButton{text:"Events / Jets"}TabButton{text:"Plot"}TabButton{text:"Runs / Code"}TabButton{text:"Runtime / Samples"}TabButton{text:"PDF Explorer"}}
            StackLayout {
                currentIndex:tabs.currentIndex;Layout.fillWidth:true;Layout.fillHeight:true
                ScrollView {
                    clip:true
                    ColumnLayout {
                        width:parent.width;spacing:12
                        Label {text:pane.kind||"Select or add a node";font.pixelSize:22;font.bold:true}
                        TabBar {id:detail;visible:pane.kind==="Pythia";Layout.fillWidth:true;TabButton{text:"Essential"}TabButton{text:"Advanced"}TabButton{text:"Research"}}
                        GridLayout {
                            visible:pane.kind==="Pythia"&&detail.currentIndex===0;columns:2;Layout.fillWidth:true
                            Label {text:"Collision beams"}
                            ComboBox {model:["pp","e− e+","p anti-p"];onActivated:{var c=JSON.parse(JSON.stringify(pane.config));c.beamA=currentIndex===1?11:2212;c.beamB=currentIndex===1?-11:currentIndex===2?-2212:2212;studio.updateAnalysisNode(c)}}
                            Label {text:"Centre-of-mass energy [GeV]"}
                            TextField {text:String(pane.config.energyGeV||13600);validator:DoubleValidator{bottom:0.001} onEditingFinished:pane.set("energyGeV",Number(text))}
                            Label {text:"Find a process"}
                            TextField {id:processSearch;placeholderText:"Z, QCD, W, Higgs, top…"}
                            Label {text:"Process"}
                            ComboBox {textRole:"label";valueRole:"id";model:pane.processChoices.filter(function(x){return x.label.toLowerCase().indexOf(processSearch.text.toLowerCase())>=0});Component.onCompleted:currentIndex=0;onActivated:pane.set("process",currentValue)}
                            Label {text:"Selected process"} Label {text:typeof pane.config.process==="string"?pane.config.process:"";color:"#66d4bd"}
                            Label {text:"Events"} SpinBox {from:1;to:1000000000;value:pane.config.events||1000;editable:true;onValueModified:pane.set("events",value)}
                            Label {text:"Hard process pT minimum [GeV]"} TextField {text:String(pane.config.pTHatMinGeV===undefined?20:pane.config.pTHatMinGeV);validator:DoubleValidator{bottom:0} onEditingFinished:pane.set("pTHatMinGeV",Number(text))}
                            Label {text:"Seed strategy"} ComboBox {model:["fixed","project-derived"];currentIndex:pane.config.seedStrategy==="project-derived"?1:0;onActivated:pane.set("seedStrategy",currentText)}
                            Label {text:"Fixed seed"} TextField {text:String(pane.config.seed||"1");validator:IntValidator{bottom:1;top:900000000} onEditingFinished:pane.set("seed",text)}
                            Label {text:"Shower / underlying event"}
                            RowLayout {CheckBox{text:"ISR";checked:pane.config.isr!==false;onClicked:pane.set("isr",checked)}CheckBox{text:"FSR";checked:pane.config.fsr!==false;onClicked:pane.set("fsr",checked)}CheckBox{text:"MPI";checked:pane.config.mpi!==false;onClicked:pane.set("mpi",checked)}}
                            Label {text:"Hadronisation"} CheckBox {checked:pane.config.hadronisation!==false;onClicked:pane.set("hadronisation",checked)}
                            Label {text:"PDF"}RowLayout {Button{text:"Refresh installed sets";enabled:!studio.busy;onClicked:studio.queryPdfSets()}ComboBox{id:generatorPdf;model:["PYTHIA default"].concat((studio.pdfData.sets||[]).map(function(s){return s.name}));onActivated:pane.set("pdf",currentIndex===0?{}:{set:currentText,member:0})}SpinBox{from:0;to:10000;value:(pane.config.pdf||{}).member||0;onValueModified:{var pdf=JSON.parse(JSON.stringify(pane.config.pdf||{}));pdf.member=value;pane.set("pdf",pdf)}}}
                            Label {text:"Selected PDF"}Label{text:(pane.config.pdf||{}).set||"PYTHIA default"}
                            Label {text:"pp tune"} SpinBox {from:0;to:100;value:pane.config.tune===undefined?14:pane.config.tune;editable:true;onValueModified:pane.set("tune",value)}
                        }
                        ColumnLayout {
                            visible:pane.kind==="Pythia"&&detail.currentIndex===1;Layout.fillWidth:true
                            Label{text:"Random streams: "+(pane.config.streamPolicy||"legacy-streams-v1");color:"#9eafbf"}
                            RowLayout {visible:pane.config.streamPolicy==="logical-blocks-v2";Label{text:"Events per logical stream"}SpinBox{from:1;to:1000000;editable:true;value:pane.config.partitionEvents||4096;onValueModified:pane.set("partitionEvents",value)}}
                            Label{text:"Logical streams: "+(pane.config.streamPolicy==="logical-blocks-v2"?Math.ceil((pane.config.events||1000)/(pane.config.partitionEvents||4096)):(pane.config.logicalStreams||1))+" · active processes are limited by stream count";color:"#9eafbf";wrapMode:Text.Wrap;Layout.fillWidth:true}
                            RowLayout {Label{text:"Generator workers"}SpinBox{from:1;to:32;value:pane.config.workers||1;onValueModified:pane.set("workers",value)}}
                            Label{text:"Worker count controls scheduling, not randomness. Logical streams and seeds are recorded. Preview uses one worker.";wrapMode:Text.Wrap;Layout.fillWidth:true;color:"#9eafbf"}
                            RowLayout {TextField{id:settingSearch;placeholderText:"Search installed PYTHIA settings";Layout.fillWidth:true}CheckBox{id:changedOnly;text:"Changed only"}Button{text:"Search";enabled:!studio.busy;onClicked:studio.queryGeneratorSettings(settingSearch.text,changedOnly.checked)}}
                            Label {text:"Settings come from the installed library. Graphical conflicts are rejected before generation.";wrapMode:Text.Wrap;Layout.fillWidth:true;color:"#9eafbf"}
                            Repeater {model:studio.generatorSettings.settings||[]
                                delegate:RowLayout {required property var modelData;Layout.fillWidth:true
                                    Label {text:modelData.key+" ("+modelData.type+")";Layout.preferredWidth:310;elide:Text.ElideRight;ToolTip.visible:settingMouse.containsMouse;ToolTip.text:modelData.documentation;MouseArea{id:settingMouse;anchors.fill:parent;hoverEnabled:true}}
                                    TextField {id:settingValue;text:String(modelData.value);Layout.preferredWidth:130}
                                    Button {text:"Apply";onClicked:{var c=JSON.parse(JSON.stringify(pane.config));c.advanced=c.advanced||{};c.advanced[modelData.key]=modelData.type==="Bool"?settingValue.text==="true":modelData.type==="String"?settingValue.text:Number(settingValue.text);studio.updateAnalysisNode(c)}}
                                    Button {text:"Reset";onClicked:{var c=JSON.parse(JSON.stringify(pane.config));delete c.advanced[modelData.key];studio.updateAnalysisNode(c)}}
                                    Label {text:"default: "+String(modelData.default);color:"#9eafbf"}
                                }
                            }
                        }
                        ColumnLayout {
                            visible:pane.kind==="Pythia"&&detail.currentIndex===2;Layout.fillWidth:true
                            Label {text:"EXPERT RAW OVERRIDES — one key = value per line. Recorded in provenance and scientific identity.";wrapMode:Text.Wrap;Layout.fillWidth:true;color:"#e9ad79"}
                            TextArea {id:rawSettings;Layout.fillWidth:true;Layout.preferredHeight:150;text:(pane.config.rawOverrides||[]).join("\n");placeholderText:"Additional settings"}
                            Button {text:"Apply expert overrides";onClicked:pane.set("rawOverrides",rawSettings.text.split("\n").filter(function(x){return x.trim().length>0}))}
                            RowLayout {Label{text:"Particle PDG ID"}SpinBox{id:decayId;from:1;to:100000;value:111;editable:true}CheckBox{id:decayEnabled;text:"May decay";checked:true}Button{text:"Set decay control";onClicked:pane.set("decays",[{pdgId:decayId.value,enabled:decayEnabled.checked}])}}
                        }
                        GridLayout {
                            visible:pane.kind==="ClusterJets";columns:2
                            Label {text:"Algorithm"}ComboBox {model:["antikt","kt","cambridge"];currentIndex:Math.max(0,model.indexOf(pane.config.algorithm));onActivated:pane.set("algorithm",currentText)}
                            Label {text:"Radius R"}TextField {text:String(pane.config.R||.4);validator:DoubleValidator{bottom:.01;top:10} onEditingFinished:pane.set("R",Number(text))}
                            Label {text:"Minimum jet pT [GeV]"}TextField {text:String(pane.config.minimumPtGeV||0);validator:DoubleValidator{bottom:0} onEditingFinished:pane.set("minimumPtGeV",Number(text))}
                            Label {text:"Recombination"}ComboBox {model:["E","pt","pt2"];currentIndex:Math.max(0,model.indexOf(pane.config.recombination));onActivated:pane.set("recombination",currentText)}
                            Label {text:"Include neutrinos"}CheckBox {checked:pane.config.includeInvisible===true;onClicked:pane.set("includeInvisible",checked)}
                        }
                        RowLayout {visible:pane.kind==="CollectionFilter"||pane.kind==="Filter"||pane.kind==="Define"
                            Button {text:"Build expression…";onClicked:pane.expression()}
                            Button {text:"pT > 30 GeV AND |eta| < 2.5";visible:pane.kind==="CollectionFilter";onClicked:pane.set("expression",{op:"and",args:[{op:"gt",args:[{op:"column",name:"pt"},{op:"literal",value:30,unit:"GeV"}]},{op:"lt",args:[{op:"abs",args:[{op:"column",name:"eta"}]},{op:"literal",value:2.5,unit:"1"}]}]})}
                            TextField {visible:pane.kind==="Define";text:pane.config.name||"observable";onEditingFinished:pane.set("name",text)}
                        }
                        RowLayout {visible:pane.kind==="CollectionSort"||pane.kind==="Property";Label{text:"Property"}ComboBox{model:["pt","eta","phi","mass","energy"];currentIndex:Math.max(0,model.indexOf(pane.config.property));onActivated:pane.set("property",currentText)}CheckBox{visible:pane.kind==="CollectionSort";text:"Descending";checked:pane.config.descending!==false;onClicked:pane.set("descending",checked)}}
                        RowLayout {visible:pane.kind==="CollectionTake";Label{text:"Leading N objects"}SpinBox{from:1;to:10000;value:pane.config.count||1;editable:true;onValueModified:pane.set("count",value)}}
                        GridLayout {visible:pane.kind==="Histo1D";columns:2
                            Label{text:"Observable"}Button{text:"Build expression…";onClicked:pane.expression()}
                            Label{text:"Bins"}SpinBox{from:1;to:4096;value:pane.config.bins||50;editable:true;onValueModified:pane.set("bins",value)}
                            Label{text:"Lower / upper (canonical units)"}RowLayout{TextField{text:String(pane.config.lower||0);onEditingFinished:pane.set("lower",Number(text))}TextField{text:String(pane.config.upper||500);onEditingFinished:pane.set("upper",Number(text))}}
                            Label{text:"Normalization"}ComboBox{model:["counts","unit-area","density"];currentIndex:Math.max(0,model.indexOf(pane.config.normalization||"counts"));onActivated:pane.set("normalization",currentText)}
                            Label{text:"Weights"}Label{text:"Nominal generator weight by default"}
                        }
                        RowLayout {visible:pane.kind==="Fit";Label{text:"Fit model"}ComboBox{model:["gaussian","exponential","polynomial"];currentIndex:Math.max(0,model.indexOf(pane.config.model||"gaussian"));onActivated:pane.set("model",currentText)}SpinBox{visible:pane.config.model==="polynomial";from:0;to:5;value:pane.config.order||1;onValueModified:pane.set("order",value)}}
                        Label {text:JSON.stringify(pane.config,null,2);font.family:"Monospace";font.pixelSize:11;color:"#91a5b7";wrapMode:Text.Wrap;Layout.fillWidth:true;visible:detail.currentIndex===2||pane.kind!=="Pythia"}
                    }
                }
                ColumnLayout {
                    property var event:studio.colliderEvents.length?studio.colliderEvents[Math.min(eventChoice.currentIndex,studio.colliderEvents.length-1)]:({})
                    id:eventPanel
                    RowLayout {Label{text:studio.colliderPreviewActive?"PREVIEW — not a Run":"RUN EVENT INSPECTION";color:"#66d4bd"}ComboBox{id:eventChoice;model:studio.colliderEvents.map(function(e){return "Event "+e.eventNumber})}Label{text:eventPanel.event.totalParticles===undefined?"Generate a preview or Run":eventPanel.event.totalParticles+" particles"}}
                    SplitView {Layout.fillWidth:true;Layout.fillHeight:true;orientation:Qt.Vertical
                        ListView {SplitView.fillWidth:true;SplitView.fillHeight:true;clip:true;model:eventPanel.event.particles||[]
                            header:Label{text:"Index    PDG      status       pT         eta       phi       energy       mass        mothers → daughters";font.family:"Monospace"}
                            delegate:Label {required property var modelData;font.family:"Monospace";font.pixelSize:12;text:String(modelData.index).padEnd(8)+String(modelData.pdgId).padEnd(9)+String(modelData.status).padEnd(8)+Number(modelData.pt).toFixed(3).padEnd(11)+(modelData.eta===null?"—":Number(modelData.eta).toFixed(3)).padEnd(10)+Number(modelData.phi).toFixed(3).padEnd(10)+Number(modelData.energy).toFixed(3).padEnd(12)+Number(modelData.mass).toFixed(3).padEnd(12)+modelData.mothers.join(",")+" → "+modelData.daughters.join(",")}
                            ScrollBar.vertical:ScrollBar{} ScrollBar.horizontal:ScrollBar{}
                        }
                        AncestryView {SplitView.fillWidth:true;SplitView.preferredHeight:170;event:eventPanel.event}
                        JetInspector {SplitView.fillWidth:true;SplitView.preferredHeight:230;event:eventPanel.event}
                    }
                }
                ColumnLayout {
                    RowLayout {TextField{Layout.fillWidth:true;text:studio.plotSettings.title||"Collider histogram";placeholderText:"Plot title";onEditingFinished:pane.plotOption("title",text)}TextField{Layout.fillWidth:true;text:studio.plotSettings.xLabel||"Observable (canonical units)";onEditingFinished:pane.plotOption("xLabel",text)}}
                    RowLayout {CheckBox{text:"Log Y";checked:studio.plotSettings.logY||false;onClicked:pane.plotOption("logY",checked)}ComboBox{model:["step","bar"];currentIndex:studio.plotSettings.style==="bar"?1:0;onActivated:pane.plotOption("style",currentText)}SpinBox{from:8;to:28;value:studio.plotSettings.fontSize||12;onValueModified:pane.plotOption("fontSize",value)}ComboBox{model:["right","left"];currentIndex:studio.plotSettings.legendPosition==="left"?1:0;onActivated:pane.plotOption("legendPosition",currentText)}Button{text:"−";onClicked:colliderPlot.zoom(.8)}Button{text:"+";onClicked:colliderPlot.zoom(1.25)}Button{text:"←";onClicked:colliderPlot.pan(-.1)}Button{text:"→";onClicked:colliderPlot.pan(.1)}Button{text:"Reset view";onClicked:colliderPlot.resetView()}Button{text:"Export figure…";onClicked:figureSave.open()}}
                    HistogramPlot {id:colliderPlot;Layout.fillWidth:true;Layout.fillHeight:true;series:studio.plotSeries;curve:studio.fitCurve;title:studio.plotSettings.title||"Collider histogram";xLabel:studio.plotSettings.xLabel||"Observable (canonical units)";logY:studio.plotSettings.logY||false;style:studio.plotSettings.style||"step";fontSize:studio.plotSettings.fontSize||12;legendPosition:studio.plotSettings.legendPosition||"right"}
                    Label {text:studio.fitDiagnostics;wrapMode:Text.Wrap;Layout.fillWidth:true;maximumLineCount:5;elide:Text.ElideRight}
                }
                ColumnLayout {
                    RowLayout {ComboBox{id:primary;model:studio.runs;textRole:"status";onActivated:studio.chooseRuns(currentIndex,overlay.currentIndex-1)}ComboBox{id:overlay;model:["No overlay"].concat(studio.runs.map(function(r,i){return "Run "+(studio.runs.length-i)}));onActivated:studio.chooseRuns(primary.currentIndex,currentIndex-1)}Button{text:"Export configuration…";onClicked:configurationSave.open()}Button{text:"Export equivalent code…";onClicked:codeSave.open()}}
                    TabBar {id:runDetail;Layout.fillWidth:true;TabButton{text:"Parameter differences"}TabButton{text:"Provenance"}TabButton{text:"Equivalent configuration / code"}TabButton{text:"Placement"}}
                    ScrollView {Layout.fillWidth:true;Layout.fillHeight:true;TextArea{readOnly:true;selectByMouse:true;wrapMode:TextEdit.Wrap;font.family:"Monospace";text:runDetail.currentIndex===0?studio.comparison:runDetail.currentIndex===1?studio.provenance:runDetail.currentIndex===2?studio.generatedCode:studio.executionPlacement}}
                }
                ScrollView {
                    ColumnLayout {width:parent.width
                        Label {text:"Managed Linux runtime: "+studio.managedRuntime.state;visible:Qt.platform.os==="windows";font.pixelSize:18}
                        Label {text:studio.managedRuntime.message||"";visible:Qt.platform.os==="windows";wrapMode:Text.Wrap;Layout.fillWidth:true}
                        RowLayout {visible:Qt.platform.os==="windows";Button{text:"Enable WSL2…";enabled:!studio.busy;onClicked:wslSetup.open()}Button{text:"Verify Runtime";enabled:!studio.busy;onClicked:studio.detectManagedRuntime()}Button{text:"Repair / Update…";enabled:!studio.busy&&studio.managedRuntime.present===true;onClicked:runtimeBundle.open()}Button{text:"Install Runtime Image…";enabled:!studio.busy;onClicked:runtimeImage.open()}}
                        Label {text:"Scientific Runtime · "+studio.colliderInfo.state;font.pixelSize:20}
                        Repeater {model:["ROOT","PYTHIA","HepMC3","FastJet","LHAPDF"];delegate:Label{required property string modelData;property var lib:(studio.colliderInfo.libraries||{})[modelData]||{};text:modelData+"    "+(lib.status||"Unavailable")+"    "+(lib.version||"");color:lib.available?"#66d4bd":"#e9ad79"}}
                        Label {text:studio.colliderInfo.error||studio.colliderInfo.reason||"";wrapMode:Text.Wrap;Layout.fillWidth:true}
                        RowLayout {Button{text:"Restart worker";enabled:!studio.busy;onClicked:studio.restartCollider()}Button{text:"Use current environment as preferred";enabled:!studio.busy;onClicked:studio.pinEnvironment()}}
                        Label {text:JSON.stringify(studio.colliderInfo.environment||{},null,2);font.family:"Monospace";font.pixelSize:11;wrapMode:Text.Wrap;Layout.fillWidth:true}
                        Label {text:"Stored samples";font.pixelSize:18}
                        Repeater {model:studio.samples;delegate:RowLayout{required property var modelData;Label{text:(modelData.name||modelData.id)+" · "+(modelData.available?"Available":"Sample unavailable / runtime-side")}Button{text:"Reuse";enabled:!studio.busy;onClicked:studio.reuseSample(modelData.id)}Button{text:"Export one file…";enabled:!studio.busy;onClicked:{pane.relinkingSample=modelData.id;sampleExport.open()}}Button{text:"Relink…";enabled:!studio.busy;onClicked:{pane.relinkingSample=modelData.id;sampleRelink.open()}}}}
                    }
                }
                PdfExplorer {}
            }
        }
    }
    Label {text:studio.progressText;visible:studio.busy;color:"#66d4bd"}
}
