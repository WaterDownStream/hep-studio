import QtQuick
import QtQuick.Controls
import QtQuick.Layouts
import QtQuick.Dialogs

ApplicationWindow {
    id: window
    width: 1440; height: 940
    minimumWidth: 1080; minimumHeight: 720
    visible: true
    title: "HEP Studio · " + studio.projectName
    color: "#111820"
    palette.window: "#17212b"
    palette.base: "#111820"
    palette.text: "#dde5ee"
    palette.windowText: "#dde5ee"
    palette.button: "#263442"
    palette.buttonText: "#dde5ee"
    palette.highlight: "#47baa6"
    font.family: "Sans Serif"
    font.pixelSize: 13
    property string pendingSource: ""

    FileDialog { id: openDialog; title: "Open HEP Studio project"; nameFilters: ["HEP projects (*.hep.json *.json)"]; onAccepted: studio.open(selectedFile) }
    FileDialog { id: saveDialog; title: "Save HEP Studio project"; fileMode: FileDialog.SaveFile; defaultSuffix: "hep.json"; nameFilters: ["HEP projects (*.hep.json)"]; onAccepted: studio.save(selectedFile) }
    Dialog {
        id: newDialog; title: "Create a new mock project?"; anchors.centerIn: parent; modal: true
        property bool jets: false
        standardButtons: Dialog.Ok | Dialog.Cancel
        Label { text: "Save a named copy first if you want to keep the current study." }
        onAccepted: { pendingSource = ""; studio.newProject(jets) }
    }
    Dialog {id:renameDialog;title:"Rename workflow";anchors.centerIn:parent;modal:true;standardButtons:Dialog.Ok|Dialog.Cancel;TextField{id:workflowName;placeholderText:"Workflow name"}onAccepted:studio.renameWorkflow(workflowName.text)}
    Dialog {id:deleteDialog;title:"Delete this workflow?";anchors.centerIn:parent;modal:true;standardButtons:Dialog.Ok|Dialog.Cancel;Label{text:"The workflow will be removed. Existing Runs are retained."}onAccepted:studio.deleteWorkflow()}
    Shortcut {sequences:[StandardKey.Undo];onActivated:studio.undo()}
    Shortcut {sequences:[StandardKey.Redo];onActivated:studio.redo()}
    header: ToolBar {
        height: 66
        background: Rectangle {color: "#1b2732"; border.color: "#2b3945"}
        RowLayout {
            anchors.fill: parent; anchors.margins: 14; spacing: 14
            Label {text: "HEP"; font.bold: true; font.pixelSize: 23; color: "#66d4bd"}
            Label {text: "STUDIO"; font.pixelSize: 18; font.letterSpacing: 2}
            Rectangle {width: 1; Layout.fillHeight: true; color: "#40515f"}
            ToolButton {
                text: "Project ▾"; enabled: !studio.busy; onClicked: projectMenu.open()
                Menu {
                    id: projectMenu
                    MenuItem {text: "New particle workflow"; onTriggered: {newDialog.jets=false; newDialog.open()}}
                    MenuItem {text: "New jet workflow"; onTriggered: {newDialog.jets=true; newDialog.open()}}
                    MenuSeparator {}
                    MenuItem {text: "Open…"; onTriggered: openDialog.open()}
                    MenuItem {text: "Recover last autosave"; enabled: studio.recoveryAvailable; onTriggered: studio.recover()}
                }
            }
            ToolButton {text: "Save…"; onClicked: saveDialog.open()}
            Label {text: studio.projectName; color: "#9eafbf"; Layout.fillWidth: true; elide: Text.ElideRight}
            Label {text: "●  " + studio.workerState; color: studio.workerState === "Healthy" || studio.workerState === "Busy" ? "#66d4bd" : "#e9ad79"}
            Button {text: "Run"; highlighted: true; enabled: !studio.busy; onClicked: studio.run()}
            Button {text: "Cancel"; enabled: studio.busy; onClicked: studio.cancel()}
        }
    }
    ColumnLayout {
        anchors.fill: parent; spacing: 0
        Rectangle {
            Layout.fillWidth: true; height: 37; color: "#23322e"
            Label {anchors.centerIn: parent; text: "ROOT STUDIO CORE     •     Scientific execution stays in an isolated worker."; color: "#b0cfc4"; font.pixelSize: 12}
        }
        RowLayout {
            Layout.fillWidth:true;Layout.leftMargin:12;Layout.rightMargin:12
            ComboBox {id:workflows;model:studio.workflows;textRole:"name";valueRole:"id";currentIndex:studio.workflows.findIndex(function(w){return w.id===studio.activeWorkflowId});onActivated:studio.switchToWorkflow(currentValue);enabled:!studio.busy}
            Button {text:"New";enabled:!studio.busy;onClicked:studio.createWorkflow("Analysis")}
            Button {text:"Rename";enabled:!studio.busy;onClicked:renameDialog.open()}
            Button {text:"Duplicate";enabled:!studio.busy;onClicked:studio.duplicateWorkflow()}
            Button {text:"Delete";enabled:!studio.busy&&studio.workflows.length>1;onClicked:deleteDialog.open()}
            Item {Layout.fillWidth:true}
            Button {text:"Undo";enabled:!studio.busy&&studio.canUndo;onClicked:studio.undo()}
            Button {text:"Redo";enabled:!studio.busy&&studio.canRedo;onClicked:studio.redo()}
        }
        TabBar {id:workspaceTabs;Layout.fillWidth:true;currentIndex:0;TabButton{text:"ROOT Studio"}TabButton{text:"Collider Studio"}TabButton{text:"Research Pipeline"}TabButton{text:"Graph canvas & diagnostics"}}
        RootStudio {visible:workspaceTabs.currentIndex===0;Layout.fillWidth:true;Layout.fillHeight:true;Layout.margins:12}
        ColliderStudio {visible:workspaceTabs.currentIndex===1;Layout.fillWidth:true;Layout.fillHeight:true;Layout.margins:12}
        ResearchStudio {visible:workspaceTabs.currentIndex===2;Layout.fillWidth:true;Layout.fillHeight:true;Layout.margins:12}
        SplitView {
            visible:workspaceTabs.currentIndex===3
            Layout.fillWidth: true; Layout.fillHeight: true; orientation: Qt.Vertical
            SplitView {
                SplitView.fillHeight: true; orientation: Qt.Horizontal
                Rectangle {
                    SplitView.preferredWidth: 210; SplitView.minimumWidth: 175; color: "#17212b"
                    ColumnLayout {
                        anchors.fill: parent; anchors.margins: 18; spacing: 16
                        Label {text: "PROJECT EXPLORER"; color: "#92a7ba"; font.pixelSize: 11; font.letterSpacing: 1}
                        Label {text: studio.projectName; font.bold: true; wrapMode: Text.Wrap; Layout.fillWidth: true}
                        Label {text: "Workflow  /  " + studio.nodes.length + " nodes"; color: "#66d4bd"}
                        ListView {
                            Layout.fillWidth: true; Layout.fillHeight: true; spacing: 6; clip: true
                            model: studio.nodes
                            delegate: ItemDelegate {
                                required property var modelData
                                width: ListView.view.width; text: modelData.name
                                highlighted: studio.selectedId === modelData.id
                                onClicked: studio.select(modelData.id)
                            }
                        }
                        Label {text: "Runs  /  " + studio.runs.length; color: "#92a7ba"}
                        Rectangle {Layout.fillWidth: true; height: 1; color: "#30404d"}
                        Label {text: studio.resources; color: "#93a4b5"; font.pixelSize: 11; wrapMode: Text.Wrap; Layout.fillWidth: true; lineHeight: 1.4}
                    }
                }
                Rectangle {
                    SplitView.fillWidth: true; SplitView.minimumWidth: 500; color: "#111820"
                    ColumnLayout {
                        anchors.fill: parent; spacing: 0
                        RowLayout {
                            Layout.fillWidth: true; Layout.margins: 14
                            Label {text: "WORKFLOW"; font.bold: true; font.letterSpacing: 1; Layout.fillWidth: true}
                            ComboBox {id: nodeKind; model: ["ParticleSource","Filter","Histogram","ParticleCollection","JetCluster","JetCollection"]; implicitWidth: 158; enabled: !studio.busy}
                            Button {text: "+ Add node"; enabled: !studio.busy; onClicked: studio.addNode(nodeKind.currentText)}
                        }
                        Label {
                            Layout.leftMargin: 14; Layout.rightMargin: 14; Layout.fillWidth: true
                            text: pendingSource ? "Choose an INPUT port to finish the connection. Escape clears selection." : "Drag nodes to arrange. Click an OUTPUT, then an INPUT, to connect."
                            color: pendingSource ? "#66d4bd" : "#7f94a7"; font.pixelSize: 11; wrapMode: Text.Wrap
                        }
                        Flickable {
                            id: graphView
                            Layout.fillWidth: true; Layout.fillHeight: true; clip: true
                            contentWidth: 3800; contentHeight: 2100
                            boundsBehavior: Flickable.StopAtBounds
                            ScrollBar.horizontal: ScrollBar { }
                            ScrollBar.vertical: ScrollBar { }
                            Canvas {
                                id: wires; width: graphView.contentWidth; height: graphView.contentHeight
                                onPaint: {
                                    var ctx = getContext("2d"); ctx.reset()
                                    ctx.fillStyle = "#25313c"
                                    for (var x=20;x<width;x+=24) for(var y=20;y<height;y+=24) ctx.fillRect(x,y,1,1)
                                    var es=studio.edges
                                    ctx.lineWidth=2; ctx.strokeStyle="#66bcae"
                                    for(var i=0;i<es.length;i++) {
                                        var e=es[i];ctx.beginPath();ctx.moveTo(e.x1,e.y1)
                                        ctx.bezierCurveTo(e.x1+75,e.y1,e.x2-75,e.y2,e.x2,e.y2);ctx.stroke()
                                    }
                                }
                                Connections {target: studio; function onModelChanged(){wires.requestPaint()} }
                            }
                            Repeater {
                                model: studio.nodes
                                delegate: Rectangle {
                                    id: card
                                    required property var modelData
                                    x: modelData.x; y: modelData.y; width: 218; height: 120; radius: 8
                                    color: "#1e2b36"; border.width: 1
                                    border.color: studio.selectedId === modelData.id ? "#66d4bd" : "#3b4c5b"
                                    Rectangle {anchors.left: parent.left; anchors.right: parent.right; anchors.top: parent.top; height: 4; radius: 2; color: "#62bea9"}
                                    MouseArea {
                                        anchors.left: parent.left; anchors.right: parent.right; anchors.top: parent.top; height: 62
                                        enabled: !studio.busy
                                        drag.target: card; drag.minimumX: 0; drag.minimumY: 0; drag.maximumX: 3500; drag.maximumY: 1800
                                        onClicked: studio.select(card.modelData.id)
                                        onReleased: studio.moveNode(card.modelData.id,card.x,card.y)
                                    }
                                    Label {x: 14; y: 17; text: modelData.name; font.bold: true; font.pixelSize: 13}
                                    Label {x: 14; y: 39; text: (modelData.kind.indexOf("hep.root.")===0?"ROOT":"MOCK") + (modelData.stale?"  ·  STALE":"  ·  v1"); color: "#7e95a8"; font.pixelSize: 10}
                                    Row {
                                        x: 8; y: 65; spacing: 4
                                        Repeater {
                                            model: card.modelData.ports
                                            delegate: Button {
                                                required property var modelData
                                                width: card.modelData.ports.length === 1 ? 200 : 99; height: 43
                                                text: (modelData.direction === "input" ? "● IN" : "OUT ●") + "\n" + modelData.type
                                                font.pixelSize: 9; enabled: !studio.busy
                                                onClicked: {
                                                    studio.select(card.modelData.id)
                                                    if(modelData.direction === "output") {pendingSource=card.modelData.id; studio.setNotice("Output selected. Choose a compatible input.")}
                                                    else if(pendingSource) {if(studio.connectNodes(pendingSource,card.modelData.id)) pendingSource=""}
                                                    else studio.setNotice("Choose an output port first.")
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
                Rectangle {
                    SplitView.preferredWidth: 265; SplitView.minimumWidth: 230; color: "#17212b"
                    ColumnLayout {
                        anchors.fill: parent; anchors.margins: 18; spacing: 18
                        Label {text: "INSPECTOR"; color: "#92a7ba"; font.pixelSize: 11; font.letterSpacing: 1}
                        Label {text: studio.inspector; wrapMode: Text.Wrap; Layout.fillWidth: true; lineHeight: 1.35; font.pixelSize: 12}
                        Button {text: "Disconnect input"; Layout.fillWidth: true; enabled: studio.selectedId !== "" && !studio.busy; onClicked: studio.disconnectInput(studio.selectedId)}
                        Button {text: "Remove node"; Layout.fillWidth: true; enabled: studio.selectedId !== "" && !studio.busy; onClicked: {pendingSource="";studio.removeSelected()}}
                        Item {Layout.fillHeight: true}
                        Label {text: "WORKER DIAGNOSTICS"; color: "#92a7ba"; font.pixelSize: 10}
                        Button {text: "Restart worker"; Layout.fillWidth: true; enabled: studio.workerState === "Crashed" || studio.workerState === "Stopped" || studio.workerState === "Unavailable"; onClicked: studio.restartWorker()}
                        Button {text: "Kill worker (crash test)"; Layout.fillWidth: true; enabled: studio.workerState === "Healthy" || studio.workerState === "Busy"; onClicked: studio.crashWorker()}
                    }
                }
            }
            Rectangle {
                SplitView.preferredHeight: 225; SplitView.minimumHeight: 160; color: "#17212b"
                ColumnLayout {
                    anchors.fill: parent; anchors.margins: 12; spacing: 8
                    TabBar {
                        id: tabs; Layout.fillWidth: true
                        TabButton {text: "Jobs / " + studio.runs.length}
                        TabButton {text: "Validation / " + studio.issues.length}
                        TabButton {text: "Logs"}
                    }
                    StackLayout {
                        currentIndex: tabs.currentIndex; Layout.fillWidth: true; Layout.fillHeight: true
                        ColumnLayout {
                            RowLayout {
                                Label {text: studio.jobState; font.bold: true}
                                ProgressBar {indeterminate:studio.busy&&studio.progress===0;value: studio.progress; Layout.fillWidth: true}
                                Label {text: studio.progressText; color: "#99adbd"}
                            }
                            ListView {
                                Layout.fillWidth: true; Layout.fillHeight: true; clip: true; spacing: 6
                                model: studio.runs
                                delegate: Label {
                                    required property var modelData
                                    width: ListView.view.width
                                    text: modelData.started + "    " + modelData.status + "    " + modelData.id.substring(0,10) + (modelData.stale ? "    • workflow changed" : "")
                                    color: modelData.status === "Completed" ? "#9bcec0" : "#dfb48a"; font.pixelSize: 12
                                }
                            }
                        }
                        ListView {
                            model: studio.issues; clip: true; spacing: 8
                            Label {visible: studio.issues.length===0; text: "No structural errors. This validates mock contracts, not physics."; color: "#9bcec0"}
                            delegate: Label {required property var modelData; width: ListView.view.width; text: "ERROR  ·  " + modelData.message; color: "#e6b395"; wrapMode: Text.Wrap}
                        }
                        ScrollView {clip: true; TextArea {text: studio.logs; readOnly: true; wrapMode: Text.Wrap; font.pixelSize: 11; font.family: "Monospace"}}
                    }
                }
            }
        }
        Rectangle {
            Layout.fillWidth: true; height: 36; color: "#21303b"
            Label {anchors.fill: parent; anchors.leftMargin: 15; anchors.rightMargin: 15; verticalAlignment: Text.AlignVCenter; text: studio.notice || "Ready. Start with the mock graph, or add and connect your own nodes."; elide: Text.ElideRight; color: "#b5c7d6"; font.pixelSize: 12}
        }
    }
    Shortcut {sequence: "Escape"; onActivated: pendingSource=""}
    Shortcut {sequence: StandardKey.Save; onActivated: saveDialog.open()}
    Shortcut {sequence: StandardKey.Open; enabled: !studio.busy; onActivated: openDialog.open()}
}
