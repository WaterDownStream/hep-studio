#include "apps/desktop/bridge.hpp"
#include "core/analysis/analysis.hpp"
#include "core/collider/collider.hpp"
#include "core/research/research.hpp"
#include "core/graph/graph.hpp"
#include "core/units/units.hpp"
#include "runtime/project_store.hpp"
#include <QJsonDocument>
#include <QSaveFile>
#include <QFileInfo>
#include <algorithm>
namespace hep {
static QVariant variant(const Json& j){auto text=j.dump();return QJsonDocument::fromJson(QByteArray::fromStdString(text)).toVariant();}
static Json json(const QVariant& v){const auto b=QJsonDocument::fromVariant(v).toJson(QJsonDocument::Compact);return Json::parse(b.constData(),b.constData()+b.size());}
// Qt's JSON serialization writes integral-valued doubles as integers. Keep the
// canonical JSON for unchanged fields instead of making an inspector edit alter
// unrelated scientific settings (and their hashes).
static Json preserveUnchangedValues(const Json& previous,Json edited){
    if(previous==edited)return previous;
    if(previous.is_object()&&edited.is_object())for(auto& [key,value]:edited.items()){
        if(previous.contains(key))value=preserveUnchangedValues(previous.at(key),std::move(value));
    }
    else if(previous.is_array()&&edited.is_array())for(std::size_t i=0;i<std::min(previous.size(),edited.size());++i)
        edited[i]=preserveUnchangedValues(previous[i],std::move(edited[i]));
    return edited;
}
QVariantList Bridge::workflows()const{QVariantList list;for(const auto& w:project_.workflows)list.push_back(QVariantMap{{"id",QString::fromStdString(w.id.value)},{"name",QString::fromStdString(w.name)}});return list;}
QString Bridge::activeWorkflowId()const{return QString::fromStdString(workflow().id.value);}
bool Bridge::canUndo()const{auto it=histories_.find(workflow().id.value);return it!=histories_.end()&&it->second.canUndo();}
bool Bridge::canRedo()const{auto it=histories_.find(workflow().id.value);return it!=histories_.end()&&it->second.canRedo();}
void Bridge::switchToWorkflow(const QString& id){if(busy())return;try{hep::switchWorkflow(project_,Id(id.toStdString()));selected_.clear();colliderPreview_=Json::object();schema_=Json::object();preview_=Json::object();storedHistogram_=Json::object();edited();}catch(const std::exception& e){setNotice(e.what());}}
void Bridge::createWorkflow(const QString& name){if(busy())return;auto w=Workflow{newId(),name.isEmpty()?"Analysis":name.toStdString(),{}, {}};project_.workflows.push_back(w);hep::switchWorkflow(project_,w.id);selected_.clear();colliderPreview_=Json::object();edited();}
void Bridge::renameWorkflow(const QString& name){if(busy()||name.trimmed().isEmpty())return;workflow().name=name.trimmed().toStdString();edited();}
void Bridge::duplicateWorkflow(){if(busy())return;hep::duplicateWorkflow(project_,workflow().id);selected_.clear();colliderPreview_=Json::object();edited();}
void Bridge::deleteWorkflow(){if(busy())return;try{const auto id=workflow().id;hep::deleteWorkflow(project_,id);histories_.erase(id.value);selected_.clear();colliderPreview_=Json::object();edited();}catch(const std::exception& e){setNotice(e.what());}}
void Bridge::undo(){if(!busy()&&history().undo(workflow()))edited();}
void Bridge::redo(){if(!busy()&&history().redo(workflow()))edited();}
QString Bridge::rootStatus()const{const auto& c=root_.capability();if(!c.value("available",false))return "ROOT "+root_.state()+" · "+QString::fromStdString(c.value("reason","Detecting runtime"));return "ROOT "+QString::fromStdString(c.value("version",""))+" · "+root_.state()+"\n"+QString::fromStdString(c.value("location",""));}
QString Bridge::datasetInfo()const{
    for(const auto& n:workflow().nodes)if(n.typeId=="hep.root.Source"&&n.extensions.contains("config")){
        const auto& c=n.extensions["config"];if(!c.contains("datasetId")||!c.contains("schema"))return "Dataset definition incomplete";
        const auto datasets=project_.extensions.value("datasets",Json::object());const auto d=datasets.value(c.at("datasetId").get<std::string>(),Json::object());const auto path=QString::fromStdString(d.value("location",""));
        return (QFileInfo::exists(path)?QFileInfo(path).fileName():"Dataset unavailable — Open ROOT / Relink")+" · "+QString::fromStdString(c.value("object",""))+" · "+QString::number(c.at("schema").value("entries",std::uint64_t(0)))+" entries";
    }return "Open a ROOT file and select a dataset.";
}
QVariantList Bridge::rootObjects()const{return variant(rootObjects_).toList();}
QVariantList Bridge::columns()const{
    Json cols=Json::array();
    for(const auto& n:workflow().nodes)if(n.typeId=="hep.root.Source"&&n.extensions.contains("config")&&n.extensions["config"].contains("schema"))cols=n.extensions["config"]["schema"].value("columns",Json::array());
    for(const auto& n:workflow().nodes)if(n.typeId=="hep.root.Define"&&n.extensions.contains("config")&&n.extensions["config"].contains("name"))cols.push_back({{"name",n.extensions.at("config").at("name")},{"backendType","derived"},{"unit","inferred"},{"unitKnown",true}});
    if(cols.empty())for(const auto& n:workflow().nodes)if(n.typeId.starts_with("hep.collider.")||n.typeId.starts_with("hep.research.")){for(const auto* name:{"pt","eta","phi","mass","energy","charge","value","weight"})cols.push_back({{"name",name},{"backendType","double"},{"unit","inferred"},{"unitKnown",true}});break;}
    if(const auto* selected=selected_.isEmpty()?nullptr:findNode(workflow(),Id(selected_.toStdString()))){
        auto semantic=selected->extensions.value("config",Json::object()).value("collectionType",std::string());
        for(const auto& port:selected->ports)if(port.direction==Direction::Output&&port.type.name.starts_with("Reco")&&port.type.name.ends_with("Collection"))semantic=port.type.name;
        if(semantic=="RecoMuonCollection"||semantic=="RecoElectronCollection"||semantic=="RecoLeptonCollection"||semantic=="RecoPhotonCollection")cols.push_back({{"name","isolation"},{"backendType","double"},{"unit","1"},{"unitKnown",true}});
        if(semantic=="RecoJetCollection")cols.push_back({{"name","btag"},{"backendType","unsigned int"},{"unit","1"},{"unitKnown",true}});
    }
    if(cols.empty()&&schema_.contains("columns"))cols=schema_["columns"];
    return variant(cols).toList();
}
QVariantMap Bridge::previewData()const{return variant(preview_).toMap();}
QString Bridge::selectedKind()const{if(selected_.isEmpty())return {};const auto* n=findNode(workflow(),Id(selected_.toStdString()));return n&&n->typeId.starts_with("hep.root.")?QString::fromStdString(n->typeId.substr(9)):n&&(n->typeId.starts_with("hep.collider.")||n->typeId.starts_with("hep.research."))?QString::fromStdString(n->typeId.substr(13)):QString();}
QVariantMap Bridge::selectedConfig()const{if(selected_.isEmpty())return {};const auto* n=findNode(workflow(),Id(selected_.toStdString()));return n?variant(n->extensions.value("config",Json::object())).toMap():QVariantMap();}
void Bridge::inspectRoot(const QUrl& file){if(busy())return;if(!file.isLocalFile()){setNotice("Choose a local ROOT file");return;}rootPath_=file.toLocalFile();root_.request("inspect",{{"path",rootPath_.toStdString()}});}
void Bridge::selectRootObject(const QString& path,const QString& kind){if(busy())return;rootObject_=path;root_.request(kind=="histogram"?"histogram":"schema",{{"path",rootPath_.toStdString()},{"object",path.toStdString()}});}
void Bridge::previewRoot(int offset,int limit){if(busy())return;for(const auto& n:workflow().nodes)if(n.typeId=="hep.root.Source"){
    const auto& c=n.extensions.at("config");const auto& dataset=project_.extensions.at("datasets").at(c.at("datasetId").get<std::string>());
    root_.request("preview",{{"path",dataset.at("location")},{"object",c.at("object")},{"offset",std::max(0,offset)},{"limit",std::clamp(limit,1,500)}});return;
}setNotice("Select a ROOT dataset first");}
void Bridge::installSource(const Json& s){
    if(!workflow().nodes.empty()&&!workflow().nodes.front().typeId.starts_with("hep.root."))createWorkflow("ROOT analysis");
    Node* source=nullptr;for(auto& n:workflow().nodes)if(n.typeId=="hep.root.Source"){source=&n;break;}
    const auto datasetId=source?source->extensions.at("config").at("datasetId").get<std::string>():newId().value;
    project_.extensions["datasets"][datasetId]={{"id",datasetId},{"location",rootPath_.toStdString()},{"logicalUri","hep://dataset/"+datasetId},{"fingerprint",s.at("fingerprint")}};
    const Json config={{"datasetId",datasetId},{"object",s.at("object")},{"schema",s},{"fingerprint",s.at("fingerprint")}};
    if(source){auto after=source->extensions;after["config"]=config;history().execute(workflow(),ConfigEdit{source->id,source->extensions,after});selected_=QString::fromStdString(source->id.value);}
    else{auto n=rootNode("Source",newId(),40,85);n.extensions["config"]=config;selected_=QString::fromStdString(n.id.value);history().execute(workflow(),NodeEdit{std::nullopt,n,{}});}
    schema_=s;edited();
}
void Bridge::setColumnUnit(const QString& name,const QString& u){if(busy())return;for(auto& n:workflow().nodes)if(n.typeId=="hep.root.Source"){
    auto after=n.extensions;for(auto& c:after["config"]["schema"]["columns"])if(c.at("name").get<std::string>()==name.toStdString()){c["unit"]=u.toStdString();c["unitKnown"]=true;}
    history().execute(workflow(),ConfigEdit{n.id,n.extensions,after});edited();return;
}}
void Bridge::addAnalysisNode(const QString& kind,const QVariantMap& config){
    if(busy())return;
    try{
        const bool fit=kind=="Fit";const Node* input=nullptr;
        for(const auto& n:workflow().nodes)for(const auto& p:n.ports)if(p.direction==Direction::Output&&p.type.name==(fit?"Histogram1D":"EventTable")){
            if(!input||QString::fromStdString(n.id.value)==selected_)input=&n;
            if(QString::fromStdString(n.id.value)==selected_)break;
        }
        if(!input)throw std::invalid_argument(fit?"Select or add a histogram first":"Select a ROOT dataset first");
        const auto inputId=input->id;
        auto n=rootNode(kind.toStdString(),newId(),40+static_cast<double>(workflow().nodes.size()%3)*260,85+static_cast<double>(workflow().nodes.size()/3)*160);
        n.extensions["config"]=json(config);if(kind=="Define")n.name="Define "+n.extensions["config"].value("name","");history().execute(workflow(),NodeEdit{std::nullopt,n,{}});
        history().execute(workflow(),EdgeEdit{{inputId,Id("out"),n.id,Id("in")},true});selected_=QString::fromStdString(n.id.value);edited();
    }catch(const std::exception& e){setNotice(e.what());}
}
void Bridge::updateAnalysisNode(const QVariantMap& config){if(busy()||selected_.isEmpty())return;try{const auto* n=findNode(workflow(),Id(selected_.toStdString()));if(!n)return;auto after=n->extensions;after["config"]=preserveUnchangedValues(n->extensions.value("config",Json::object()),json(config));history().execute(workflow(),ConfigEdit{n->id,n->extensions,after});edited();}catch(const std::exception& e){setNotice(e.what());}}
Json Bridge::hashes()const{Json out=Json::object();for(const auto& n:workflow().nodes)out[n.id.value]=workflowHash(dependencyJson(workflow(),n.id,project_.seed)).toStdString();return out;}
void Bridge::runRoot(){
    if(busy())return;
    try{
        auto plan=lowerRoot(workflow());if(!project_.extensions.contains("datasets"))throw std::invalid_argument("Dataset unavailable; relink using Open ROOT");
        rootLease_=coordinator_.broker().acquire({1,512*1024*1024});
        if(!rootLease_)throw std::runtime_error("Insufficient resource budget for ROOT");
        if(root_.request("execute",{{"plan",plan},{"datasets",project_.extensions.at("datasets")}})){
            rootRun_=Run{newId(),"Running",workflowJson(workflow()),workflowHash(scientificJson(workflow(),project_.seed)).toStdString()};
            rootRun_->started=ipc::utcNow();rootRun_->backend="hep.root/1";rootRun_->environment="hep-env://root/"+root_.capability().value("version","");
            rootRun_->resources=hardwareJson(coordinator_.broker().hardware());rootRun_->resources["allocatedThreads"]=1;rootRun_->resources["reservedMemoryBytes"]=512*1024*1024;rootRun_->resources["qtVersion"]=qVersion();rootRun_->resources["hepStudioVersion"]="0.2.0";
            rootRun_->extensions["nodeHashes"]=hashes();rootRun_->extensions["workflowRevision"]=workflowHash(rootRun_->workflowSnapshot).toStdString();rootRun_->extensions["executionPlan"]=plan;rootRun_->extensions["rootCapability"]=root_.capability();checkpoint();
        }else {coordinator_.broker().release(rootLease_->id);rootLease_.reset();setNotice(root_.error());}
    }catch(const std::exception& e){setNotice(e.what());}
}
void Bridge::rootFinished(bool success,bool cancelled){
    const auto operation=root_.operation();
    if(rootLease_){coordinator_.broker().release(rootLease_->id);rootLease_.reset();}
    if(rootRun_&&operation=="execute"){
        rootRun_->status=success?"Completed":cancelled?"Cancelled":root_.state()=="Crashed"?"Interrupted":"Failed";rootRun_->ended=ipc::utcNow();
        rootRun_->result=success?root_.result():Json{{"valid",false},{"partial",true},{"message",root_.error().toStdString()}};
        rootRun_->logs.push_back({{"timestamp",ipc::utcNow()},{"severity",success?"Info":"Error"},{"subsystem","ROOT"},{"jobId",rootRun_->id.value},{"nodeId",""},{"message",root_.diagnostics().toStdString()}});
        project_.runs.push_back(*rootRun_);rootRun_.reset();primaryRun_=0;storedHistogram_=Json::object();checkpoint();
    }else if(success){
        if(operation=="inspect")rootObjects_=root_.result().at("objects");
        else if(operation=="schema")installSource(root_.result());
        else if(operation=="preview")preview_=root_.result();
        else if(operation=="histogram")storedHistogram_=root_.result();
    }
    setNotice(success?"ROOT "+QString::fromStdString(operation)+" completed":root_.error());emit modelChanged();emit runtimeChanged();
}
void Bridge::restartRoot(){if(!busy())root_.restart();}
const Run* Bridge::selectedRun(int index)const{if(index<0||static_cast<std::size_t>(index)>=project_.runs.size())return nullptr;return &project_.runs[project_.runs.size()-1-static_cast<std::size_t>(index)];}
void Bridge::chooseRuns(int primary,int overlay){primaryRun_=primary;overlayRun_=overlay;colliderPreview_=Json::object();storedHistogram_=Json::object();emit modelChanged();}
Json Bridge::displayedResults()const{const auto* r=selectedRun(primaryRun_);return r?r->result.value("results",Json::object()):Json::object();}
QVariantList Bridge::plotSeries()const{
    Json out=Json::array();if(!storedHistogram_.empty()){auto h=storedHistogram_;h["legend"]="Stored ROOT histogram";out.push_back(h);return variant(out).toList();}
    auto results=displayedResults();std::string id;
    if(results.contains(selected_.toStdString())&&results.at(selected_.toStdString()).value("kind","")=="Histogram1D")id=selected_.toStdString();
    else if(results.contains(selected_.toStdString())&&results.at(selected_.toStdString()).value("kind","")=="FitResult"){
        const auto target=results.at(selected_.toStdString()).value("histogramId",std::string());if(results.contains(target)&&results.at(target).value("kind","")=="Histogram1D")id=target;
    }
    else for(const auto& [key,r]:results.items())if(r.value("kind","")=="Histogram1D"){id=key;break;}
    if(id.empty())return {};
    auto h=results.at(id);h["legend"]="Run "+std::to_string(project_.runs.size()-static_cast<std::size_t>(std::max(primaryRun_,0)));out.push_back(h);
    const auto* other=selectedRun(overlayRun_);if(other&&other->result.contains("results")&&other->result["results"].contains(id)){
        auto h2=other->result["results"][id];if(h2.value("edges",Json::array())==h.at("edges")&&h2.value("normalization","counts")==h.value("normalization","counts")&&h2.value("dimension",Json::array())==h.value("dimension",Json::array())){h2["legend"]="Comparison run";out.push_back(h2);}
    }return variant(out).toList();
}
QVariantList Bridge::fitCurve()const{const auto results=displayedResults();std::string hist;
    if(results.contains(selected_.toStdString())&&results.at(selected_.toStdString()).value("kind","")=="Histogram1D")hist=selected_.toStdString();
    else if(results.contains(selected_.toStdString())&&results.at(selected_.toStdString()).value("kind","")=="FitResult")hist=results.at(selected_.toStdString()).value("histogramId",std::string());
    if(hist.empty())for(const auto& [id,r]:results.items())if(r.value("kind","")=="Histogram1D"){hist=id;break;}
    for(const auto& [id,r]:results.items())if(r.value("kind","")=="FitResult"&&r.value("histogramId","")==hist&&r.value("converged",false)&&r.value("covarianceStatus",-1)>=2)return variant(r.at("curve")).toList();
    return {}; }
QString Bridge::fitDiagnostics()const{const auto results=displayedResults();QString diagnostics;for(const auto& [id,r]:results.items())if(r.value("kind","")=="FitResult"||r.value("kind","")=="HypothesisResult") {auto diagnostic=r;diagnostic.erase("curve");const bool fit=r.value("kind","")=="FitResult";const bool valid=fit?r.value("converged",false)&&r.value("covarianceStatus",-1)>=2:r.value("valid",false);diagnostics+=QString::fromStdString(std::string(valid?(fit?"FIT CONVERGED\n":"INFERENCE RESULT\n"):"FAILED OR UNRELIABLE\n")+diagnostic.dump(2)+"\n");}return diagnostics.isEmpty()?QString("No fit or inference result selected."):diagnostics;}
QString Bridge::generatedCode()const{const auto* r=selectedRun(primaryRun_);return r?QString::fromStdString(r->result.value("generatedCode","Run a ROOT analysis to inspect equivalent code.")):"Run a ROOT analysis to inspect equivalent code.";}
QString Bridge::provenance()const{const auto* r=selectedRun(primaryRun_);if(!r)return "No run selected.";auto p=projectJson({project_.id,project_.name,{}, {*r}});return QString::fromStdString(p.at("runs")[0].dump(2));}
QString Bridge::comparison()const{
    const auto* a=selectedRun(primaryRun_);const auto* b=selectedRun(overlayRun_);if(!a||!b)return "Choose a second run to compare.";
    Json changes=Json::array(),execution=Json::array();
    for(const auto& n:a->workflowSnapshot.at("nodes"))for(const auto& m:b->workflowSnapshot.at("nodes"))if(n.at("id")==m.at("id")){
        auto primary=n.value("config",Json::object()),other=m.value("config",Json::object());
        if((n.at("typeId")=="hep.collider.Pythia"||n.at("typeId")=="hep.research.Shower")&&n.at("typeId")==m.at("typeId")){
            const auto pw=primary.value("workers",1),ow=other.value("workers",1);
            for(auto* config:{&primary,&other}){
                if(n.at("typeId")=="hep.collider.Pythia"&&!config->contains("streamPolicy")){(*config)["streamPolicy"]="legacy-streams-v1";(*config)["logicalStreams"]=config->value("workers",1);}
                config->erase("workers");
            }
            if(pw!=ow)execution.push_back({{"node",n.at("name")},{"property","workers"},{"primary",pw},{"comparison",ow}});
        }
        if(primary!=other)changes.push_back({{"node",n.at("name")},{"primary",primary},{"comparison",other}});
    }
    Json result={{"parameters",changes},{"execution",execution},{"scientificHash",{{"primary",a->workflowHash},{"comparison",b->workflowHash},{"equal",a->workflowHash==b->workflowHash}}},{"environment",Json::diff(a->extensions.value("frozenEnvironment",Json::object()),b->extensions.value("frozenEnvironment",Json::object()))},{"generatorProvenance",Json::diff(a->result.value("generator",Json::object()),b->result.value("generator",Json::object()))}};
    return QString::fromStdString(result.dump(2));
}
QString Bridge::expressionSummary(const QVariantMap& expression)const{
    try{DatasetSchema s;for(const auto& n:workflow().nodes)if(n.typeId.starts_with("hep.collider.")){s=jetSchema();break;}for(const auto& n:workflow().nodes)if(n.typeId.starts_with("hep.research.")){const auto* selected=findNode(workflow(),Id(selected_.toStdString()));s=reconstructedSchema(!selected||selected->typeId!="hep.research.CollectionFilter",selected?selected->extensions.value("config",Json::object()).value("collectionType",std::string()):std::string());break;}for(const auto& n:workflow().nodes)if(n.typeId=="hep.root.Source")s=datasetSchema(n.extensions.at("config").at("schema"));
        for(const auto& id:topologicalOrder(workflow())){const auto& n=*findNode(workflow(),id);if(n.typeId=="hep.root.Define"){const auto& c=n.extensions.at("config");auto t=inferExpression(c.at("expression"),s);s.columns.push_back({c.at("name"),"double","1",true,false,scalar(t.dimension)});}}
        const auto t=inferExpression(json(expression),s);if(t.boolean)return "Output: Boolean condition";if(t.dimension==energy)return "Output: energy / momentum (GeV, natural units)";if(t.dimension==dimensionless)return "Output: dimensionless scalar";
        return "Output dimensions [energy, length, time, angle]: "+QString::number(t.dimension.powers[0])+", "+QString::number(t.dimension.powers[1])+", "+QString::number(t.dimension.powers[2])+", "+QString::number(t.dimension.powers[3]);
    }catch(const std::exception& e){return "Validation: "+QString::fromUtf8(e.what());}
}
QVariantMap Bridge::plotSettings()const{return variant(workflow().extensions.value("presentation",Json::object()).value("plot",Json::object())).toMap();}
void Bridge::setPlotSettings(const QVariantMap& settings){workflow().extensions["presentation"]["plot"]=json(settings);edited();}
void Bridge::exportCode(const QUrl& file){if(!file.isLocalFile())return;QSaveFile f(file.toLocalFile());auto text=generatedCode().toUtf8();if(!f.open(QIODevice::WriteOnly)||f.write(text)!=text.size()||!f.commit())setNotice("Code export failed");else setNotice("Equivalent code exported");}
}
