import QtQuick
import QtQuick.Controls
import QtQuick.Layouts
ColumnLayout {
    id:view
    property var event:({})
    function tree() {
        var particles=event.particles||[], byId={}, result=[], seen={}
        particles.forEach(function(p){byId[p.index]=p})
        if(!particles.length)return result
        function visit(id,depth) {
            if(result.length>=200||depth>12)return
            var p=byId[id]
            if(!p)return
            result.push({index:id,pdg:p.pdgId,depth:depth,reference:seen[id]===true})
            if(seen[id])return
            seen[id]=true
            p.daughters.forEach(function(child){visit(child,depth+1)})
        }
        visit(particles[Math.max(0,Math.min(choice.currentIndex,particles.length-1))].index,0)
        return result
    }
    RowLayout {
        Label {text:"Decay / ancestry tree";font.bold:true}
        ComboBox {id:choice;Layout.fillWidth:true;model:(view.event.particles||[]).map(function(p){return "Particle "+p.index+" · PDG "+p.pdgId})}
    }
    ListView {
        Layout.fillWidth:true;Layout.fillHeight:true;clip:true;model:view.tree()
        delegate:Label {required property var modelData;leftPadding:modelData.depth*18;text:(modelData.depth?"↳ ":"")+"PDG "+modelData.pdg+"  ["+modelData.index+"]"+(modelData.reference?" (shared ancestry)":"");font.family:"Monospace"}
        ScrollBar.vertical:ScrollBar {}
    }
    Label {text:"Selected particle and descendants · bounded to 200 rows / 12 generations";font.pixelSize:10;color:"#9eafbf"}
}
