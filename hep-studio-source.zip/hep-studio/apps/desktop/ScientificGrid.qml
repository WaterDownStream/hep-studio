import QtQuick
import QtQuick.Controls
import QtQuick.Layouts
import QtQuick.Dialogs
import HEPStudio 1.0
ColumnLayout {
    id: root
    property var plotData: ({})
    property var inspected: ({})
    property string exportError: ""
    RowLayout {
        Button { text: "Export PNG/PDF…"; onClicked: save.open() }
        Button { text: "Reset view"; onClicked: plot.resetView() }
        Label { text: "Recorded points; no interpolation"; Layout.fillWidth: true }
    }
    ScanGridPlot {
        id: plot; objectName: "scanGridPlot"
        Layout.fillWidth: true; Layout.fillHeight: true
        plotData: root.plotData
        MouseArea {
            anchors.fill: parent; hoverEnabled: true
            property real previousX: 0
            property real previousY: 0
            onPressed: function(mouse) { previousX=mouse.x; previousY=mouse.y }
            onPositionChanged: function(mouse) {
                if(pressed) { plot.pan((previousX-mouse.x)/width,(mouse.y-previousY)/height); previousX=mouse.x; previousY=mouse.y }
                root.inspected=plot.pointAt(mouse.x,mouse.y)
            }
            onWheel: function(wheel) { plot.zoom(wheel.angleDelta.y>0?1.2:1/1.2) }
        }
    }
    Label {
        Layout.fillWidth: true; wrapMode: Text.Wrap
        text: root.inspected.status ? "("+root.inspected.x+", "+root.inspected.y+") · "+root.inspected.status+(root.inspected.value!==null?" · "+root.inspected.value:"")+" · Run "+(root.inspected.runId||"uncommitted") : "Hover over a point to inspect its value and Run. Crosses indicate failed/missing/unavailable results."
    }
    Label { visible: root.exportError.length>0; text: root.exportError; color: "#ef8b89" }
    FileDialog { id: save; fileMode: FileDialog.SaveFile; nameFilters: ["PNG (*.png)","PDF (*.pdf)"]; onAccepted: root.exportError=plot.exportFigure(selectedFile)?"":"Scan figure export failed" }
}
