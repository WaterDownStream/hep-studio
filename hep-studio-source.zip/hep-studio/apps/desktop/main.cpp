#include "apps/desktop/bridge.hpp"
#include "render/plots/histogram_item.hpp"
#include "render/plots/scan_grid_item.hpp"
#include <QGuiApplication>
#include <QQmlApplicationEngine>
#include <QQmlContext>
#include <QQuickWindow>
#include <QQuickStyle>
#include <QTimer>
#include <QTemporaryDir>
#include <QImage>
#include <QStandardPaths>
#include <iostream>
#include <memory>
int main(int argc,char** argv) {
    QGuiApplication app(argc,argv);
    app.setOrganizationName("HEPStudio");app.setApplicationName("HEPStudio");
    const auto arguments=app.arguments();const bool smoke=arguments.contains("--smoke-test");
    QQuickStyle::setStyle("Fusion");
    std::unique_ptr<QTemporaryDir> smokeData;
    if(smoke){
        QStandardPaths::setTestModeEnabled(true);
#ifdef Q_OS_LINUX
        smokeData=std::make_unique<QTemporaryDir>();if(!smokeData->isValid())return 10;
        qputenv("XDG_DATA_HOME",smokeData->path().toUtf8());QStandardPaths::setTestModeEnabled(false);
#endif
    }
    qmlRegisterType<hep::HistogramItem>("HEPStudio",1,0,"HistogramPlot");
    qmlRegisterType<hep::ScanGridItem>("HEPStudio",1,0,"ScanGridPlot");
    hep::Bridge bridge;
    QQmlApplicationEngine engine;engine.rootContext()->setContextProperty("studio",&bridge);
    engine.load(QUrl("qrc:/apps/desktop/Main.qml"));
    if(engine.rootObjects().isEmpty())return 1;
    const auto shotIndex=arguments.indexOf("--screenshot");
    if(shotIndex>=0 && shotIndex+1<arguments.size()) {
        QTimer::singleShot(800,&app,[&]{
            auto* window=qobject_cast<QQuickWindow*>(engine.rootObjects().front());
            if(!window || !window->grabWindow().save(arguments[shotIndex+1]))app.exit(3);
            else if(!smoke)app.quit();
        });
    }
    QTimer poll,deadline;int smokeStage=0;
    if(smoke) {
        deadline.setSingleShot(true);QObject::connect(&deadline,&QTimer::timeout,&app,[&]{std::cerr<<"Desktop smoke timed out\n";app.exit(2);});deadline.start(10000);
        QObject::connect(&poll,&QTimer::timeout,&app,[&]{
            if(bridge.workerState()=="Healthy" && (smokeStage==0 || smokeStage==4)){
                poll.stop();smokeStage=smokeStage==0?1:5;
                if(!bridge.coordinator().submit(bridge.project().workflows.front(),"0",4,10))app.exit(4);
            }
        });
        QObject::connect(&bridge.coordinator(),&hep::Coordinator::finalized,&app,[&]{
            if(smokeStage==1 || smokeStage==2) {
                const auto expected=smokeStage==1?QString("Completed"):QString("Cancelled");
                if(bridge.jobState()!=expected){app.exit(5);return;}
                ++smokeStage;
                if(!bridge.coordinator().submit(bridge.project().workflows.front(),"0",1000,10)){app.exit(7);return;}
                QTimer::singleShot(40,&app,[&]{if(smokeStage==2)bridge.cancel();else bridge.crashWorker();});
                return;
            }
            if(smokeStage==3) {
                if(bridge.jobState()!="Interrupted"){app.exit(8);return;}
                smokeStage=4;
                QTimer::singleShot(80,&app,[&]{bridge.restartWorker();poll.start(20);});return;
            }
            if(smokeStage!=5 || bridge.jobState()!="Completed" || bridge.project().runs.size()!=4){app.exit(9);return;}
            QTemporaryDir temporary;
            const auto file=QUrl::fromLocalFile(temporary.path()+"/smoke.hep.json");
            if(!bridge.save(file)||!bridge.open(file)||bridge.project().runs.size()!=4){app.exit(6);return;}
            smokeStage=6;
            QTimer::singleShot(shotIndex>=0?1000:100,&app,[&]{app.quit();});
        });poll.start(20);
    }
    return app.exec();
}
